import LeanVerification.WedgeCompletion.QuadraticResolvent
import Mathlib.MeasureTheory.Integral.IntegralEqImproper

/-! A normalized logarithmic primitive on the genuine right half-plane. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
set_option maxHeartbeats 1600000

/-- Its value at zero is zero and its limit along the right half-plane
at infinity is the positive half-arctangent mass. -/
def halfPlanePrimitive (e:ℝ) (z:ℂ) : ℂ :=
  (Complex.log (z-(Real.sqrt e:ℂ)*Complex.I)-
    Complex.log (z+(Real.sqrt e:ℂ)*Complex.I))/
      (2*Complex.I*(Real.sqrt e:ℂ))+(Real.pi/(2*Real.sqrt e):ℝ)

theorem shifted_imaginary_slit {e:ℝ} {z:ℂ} (hz:0<z.re) :
    z-(Real.sqrt e:ℂ)*Complex.I∈Complex.slitPlane ∧
      z+(Real.sqrt e:ℂ)*Complex.I∈Complex.slitPlane := by
  constructor <;> left <;> simpa using hz

theorem halfPlanePrimitive_hasDerivAt {e:ℝ} {z:ℂ}
    (he:0<e) (hz:0<z.re) :
    HasDerivAt (halfPlanePrimitive e) ((e:ℂ)+z^2)⁻¹ z := by
  obtain ⟨hm,hp⟩ := shifted_imaginary_slit (e:=e) hz
  have hd := ((((Complex.hasDerivAt_log hm).comp z
    ((hasDerivAt_id z).sub_const ((Real.sqrt e:ℂ)*Complex.I))).sub
    ((Complex.hasDerivAt_log hp).comp z
      ((hasDerivAt_id z).add_const ((Real.sqrt e:ℂ)*Complex.I)))).div_const
        (2*Complex.I*(Real.sqrt e:ℂ))).add_const ((Real.pi/(2*Real.sqrt e):ℝ):ℂ)
  have hs : (Real.sqrt e:ℂ)^2=(e:ℂ) := by exact_mod_cast Real.sq_sqrt he.le
  have hm0 := Complex.slitPlane_ne_zero hm
  have hp0 := Complex.slitPlane_ne_zero hp
  have heq : (z-(Real.sqrt e:ℂ)*Complex.I)*(z+(Real.sqrt e:ℂ)*Complex.I)=
      (e:ℂ)+z^2 := by
    calc
      _=z^2-(Real.sqrt e:ℂ)^2*Complex.I^2 := by ring
      _=_ := by rw [Complex.I_sq,hs];ring
  have hden : (e:ℂ)+z^2≠0 := by rw [←heq];exact mul_ne_zero hm0 hp0
  have hs0 : (Real.sqrt e:ℂ)≠0 := Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr he).ne'
  convert hd using 1
  simp only [mul_one]
  rw [←heq]
  field_simp
  <;> ring

theorem halfPlanePrimitive_continuousAt_zero {e:ℝ} (he:0<e) :
    ContinuousAt (halfPlanePrimitive e) 0 := by
  have hs := Real.sqrt_pos.mpr he
  have hm : (0:ℂ)-(Real.sqrt e:ℂ)*Complex.I∈Complex.slitPlane := by
    right
    simpa using neg_ne_zero.mpr hs.ne'
  have hp : (0:ℂ)+(Real.sqrt e:ℂ)*Complex.I∈Complex.slitPlane := by
    right
    simpa using hs.ne'
  exact (((continuousAt_clog hm).comp (f:=fun w:ℂ=>w-(Real.sqrt e:ℂ)*Complex.I)
    (continuousAt_id.sub continuousAt_const)).sub
    ((continuousAt_clog hp).comp (f:=fun w:ℂ=>w+(Real.sqrt e:ℂ)*Complex.I)
      (continuousAt_id.add continuousAt_const))).div_const _ |>.add_const _

theorem halfPlanePrimitive_zero {e:ℝ} (he:0<e) :
    halfPlanePrimitive e 0=0 := by
  have hs := Real.sqrt_pos.mpr he
  have hs0 : (Real.sqrt e:ℂ)≠0 := Complex.ofReal_ne_zero.mpr hs.ne'
  unfold halfPlanePrimitive
  rw [zero_sub,zero_add,show -((Real.sqrt e:ℂ)*Complex.I)=
    (Real.sqrt e:ℂ)*(-Complex.I) by ring,
    Complex.log_ofReal_mul hs (neg_ne_zero.mpr Complex.I_ne_zero),
    Complex.log_ofReal_mul hs Complex.I_ne_zero,Complex.log_I,Complex.log_neg_I]
  push_cast
  field_simp
  ring_nf

/-- Combining the two logs uses actual half-plane argument bounds. -/
theorem halfPlane_log_difference {c:ℝ} {z:ℂ} (hz:0<z.re) :
    Complex.log (z-(c:ℂ)*Complex.I)-Complex.log (z+(c:ℂ)*Complex.I)=
      Complex.log ((z-(c:ℂ)*Complex.I)/(z+(c:ℂ)*Complex.I)) := by
  have hm : 0<(z-(c:ℂ)*Complex.I).re := by simpa using hz
  have hp : 0<(z+(c:ℂ)*Complex.I).re := by simpa using hz
  have ham := abs_lt.mp (Complex.abs_arg_lt_pi_div_two_iff.mpr (Or.inl hm))
  have hap := abs_lt.mp (Complex.abs_arg_lt_pi_div_two_iff.mpr (Or.inl hp))
  have hpπ : (z+(c:ℂ)*Complex.I).arg≠Real.pi := by linarith [Real.pi_pos]
  have harg : (z-(c:ℂ)*Complex.I).arg+((z+(c:ℂ)*Complex.I)⁻¹).arg∈
      Ioc (-Real.pi) Real.pi := by
    rw [Complex.arg_inv,if_neg hpπ]
    constructor <;> linarith
  have hm0 : z-(c:ℂ)*Complex.I≠0 := by intro h;simpa [h] using hm
  have hp0 : z+(c:ℂ)*Complex.I≠0 := by intro h;simpa [h] using hp
  rw [div_eq_mul_inv,Complex.log_mul hm0 (inv_ne_zero hp0) harg,Complex.log_inv _ hpπ]
  ring

/-- Finite total change is proved for every right-half-plane path whose
inverse tends to zero; no direction of approach is assumed. -/
theorem halfPlanePrimitive_tendsto_infinity
    {α:Type*} {l:Filter α} {u:α→ℂ} {e:ℝ} (he:0<e)
    (hu:∀ᶠx in l,0<(u x).re)
    (hi:Tendsto (fun x=>(u x)⁻¹) l (𝓝 0)) :
    Tendsto (fun x=>halfPlanePrimitive e (u x)) l (𝓝 ((Real.pi/(2*Real.sqrt e):ℝ):ℂ)) := by
  have hz : Tendsto (fun x=>
      (1-(Real.sqrt e:ℂ)*Complex.I*(u x)⁻¹)/
        (1+(Real.sqrt e:ℂ)*Complex.I*(u x)⁻¹)) l (𝓝 (1:ℂ)) := by
    have h1 : Tendsto (fun _:α=>(1:ℂ)) l (𝓝 1) := tendsto_const_nhds
    have ha : Tendsto (fun x=>1-(Real.sqrt e:ℂ)*Complex.I*(u x)⁻¹) l (𝓝 (1:ℂ)) := by
      simpa using h1.sub (hi.const_mul ((Real.sqrt e:ℂ)*Complex.I))
    have hb : Tendsto (fun x=>1+(Real.sqrt e:ℂ)*Complex.I*(u x)⁻¹) l (𝓝 (1:ℂ)) := by
      simpa using h1.add (hi.const_mul ((Real.sqrt e:ℂ)*Complex.I))
    simpa using ha.div hb one_ne_zero
  have hl := (continuousAt_clog (by simp : (1:ℂ)∈Complex.slitPlane)).tendsto.comp hz
  have ht := (hl.div_const (2*Complex.I*(Real.sqrt e:ℂ))).add_const
    ((Real.pi/(2*Real.sqrt e):ℝ):ℂ)
  simp only [Complex.log_one,zero_div,zero_add] at ht
  apply ht.congr'
  filter_upwards [hu] with x hx
  rw [halfPlanePrimitive,halfPlane_log_difference hx]
  have hn : u x≠0 := by intro h;simpa [h] using hx
  congr 3
  field_simp

end LeanVerification.WedgeIntegralCompletion
