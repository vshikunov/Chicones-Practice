import LeanVerification.WedgeIntegralCompletion.ComplexRectangleCauchy
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.MeasureTheory.Measure.Haar.NormedSpace

/-! Absolute convergence and the three outer-bank estimates for the actual
lower-half-plane Cauchy contour. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
set_option maxHeartbeats 1000000

def lowerCauchyPole (a b : ℝ) : ℂ := (a:ℂ)-(b:ℂ)*Complex.I

def upperCauchyPole (a b : ℝ) : ℂ := (a:ℂ)+(b:ℂ)*Complex.I

def quadraticCauchyKernel (f:ℂ→ℂ) (a b:ℝ) (z:ℂ) : ℂ :=
  f z/((z-(a:ℂ))^2+(b:ℂ)^2)

theorem quadraticCauchy_factor (a b:ℝ) (z:ℂ) :
    (z-(a:ℂ))^2+(b:ℂ)^2=(z-lowerCauchyPole a b)*(z-upperCauchyPole a b) := by
  unfold lowerCauchyPole upperCauchyPole
  calc
    _=(z-(a:ℂ))^2-((b:ℂ)*Complex.I)^2 := by simp [mul_pow]
    _=_ := by ring

theorem integrable_inv_shifted_quadratic {a b:ℝ} (hb:0<b) :
    Integrable (fun x:ℝ => ((x-a)^2+b^2)⁻¹) := by
  have hi := ((integrable_inv_one_add_sq.comp_div hb.ne').comp_sub_right a).const_mul (b^2)⁻¹
  convert hi using 1
  funext x
  have hx : 1+((x-a)/b)^2≠0 := by positivity
  have hx' : (x-a)^2+b^2≠0 := by positivity
  field_simp [hb.ne',hx,hx']
  <;> ring

theorem quadraticCauchyKernel_real (f:ℂ→ℂ) (a b x:ℝ) :
    quadraticCauchyKernel f a b (x:ℂ)=f (x:ℂ)/(((x-a)^2+b^2:ℝ):ℂ) := by
  unfold quadraticCauchyKernel
  push_cast
  rfl

theorem quadraticCauchyKernel_integrable {f:ℂ→ℂ} {a b M:ℝ}
    (hb:0<b) (hM:0≤M)
    (hf:DifferentiableOn ℂ f {z:ℂ|z.im≤0})
    (hbound:∀z:ℂ,z.im≤0→‖f z‖≤M) :
    Integrable (fun x:ℝ => quadraticCauchyKernel f a b (x:ℂ)) := by
  have hc : Continuous (fun x:ℝ => f (x:ℂ)) := by
    apply continuous_iff_continuousOn_univ.2
    apply hf.continuousOn.comp (by fun_prop)
    intro x hx
    simp
  have hk : Continuous (fun x:ℝ => quadraticCauchyKernel f a b (x:ℂ)) := by
    simp_rw [quadraticCauchyKernel_real]
    apply hc.div (by fun_prop)
    intro x
    exact Complex.ofReal_ne_zero.mpr (by positivity)
  apply ((integrable_inv_shifted_quadratic (a:=a) hb).const_mul M).mono' hk.aestronglyMeasurable
  filter_upwards [] with x
  rw [quadraticCauchyKernel_real,norm_div,Complex.norm_real,Real.norm_eq_abs,
    abs_of_pos (by positivity : 0<(x-a)^2+b^2),←div_eq_mul_inv]
  exact div_le_div_of_nonneg_right (hbound _ (by simp)) (by positivity)

theorem quadraticCauchyKernel_norm_le {f:ℂ→ℂ} {a b M R:ℝ} {z:ℂ}
    (hR:0<R) (hM:0≤M) (hf:‖f z‖≤M)
    (hp:R/2≤‖z-lowerCauchyPole a b‖) (hq:R/2≤‖z-upperCauchyPole a b‖) :
    ‖quadraticCauchyKernel f a b z‖≤4*M/R^2 := by
  rw [quadraticCauchyKernel,quadraticCauchy_factor,norm_div,norm_mul]
  calc
    _≤M/(‖z-lowerCauchyPole a b‖*‖z-upperCauchyPole a b‖) :=
      div_le_div_of_nonneg_right hf (mul_nonneg (norm_nonneg _) (norm_nonneg _))
    _≤M/((R/2)*(R/2)) := div_le_div_of_nonneg_left hM (by positivity)
      (mul_le_mul hp hq (by positivity) (norm_nonneg _))
    _=4*M/R^2 := by field_simp; ring

theorem quadraticCauchyKernel_outer_norm_le {f:ℂ→ℂ} {a b M R:ℝ} {z:ℂ}
    (hb:0<b) (hR:2*b≤R) (hM:0≤M)
    (hbound:∀z:ℂ,z.im≤0→‖f z‖≤M) (hz:z.im≤0)
    (hedge:z.im= -R ∨ z.re=a+R ∨ z.re=a-R) :
    ‖quadraticCauchyKernel f a b z‖≤4*M/R^2 := by
  have hRp : 0<R := by linarith
  apply quadraticCauchyKernel_norm_le hRp hM (hbound z hz)
  · change R/2≤‖z-((a:ℂ)-(b:ℂ)*Complex.I)‖
    rcases hedge with h|h|h
    · have hh := Complex.abs_im_le_norm (z-lowerCauchyPole a b)
      simp only [lowerCauchyPole,Complex.sub_im,Complex.ofReal_im,Complex.mul_im,
        Complex.ofReal_re,Complex.I_im,Complex.I_re,mul_one,mul_zero,add_zero,zero_sub,h] at hh
      rw [abs_of_nonpos (by linarith : -R- -b≤0)] at hh
      linarith
    · have hh := Complex.abs_re_le_norm (z-lowerCauchyPole a b)
      simp only [lowerCauchyPole,Complex.sub_re,Complex.ofReal_re,Complex.mul_re,
        Complex.ofReal_im,Complex.I_re,Complex.I_im,mul_zero,zero_mul,sub_zero,h,add_sub_cancel_left,
        abs_of_pos hRp] at hh
      linarith
    · have hh := Complex.abs_re_le_norm (z-lowerCauchyPole a b)
      simp only [lowerCauchyPole,Complex.sub_re,Complex.ofReal_re,Complex.mul_re,
        Complex.ofReal_im,Complex.I_re,Complex.I_im,mul_zero,zero_mul,sub_zero,h] at hh
      rw [show a-R-a= -R by ring,abs_neg,abs_of_pos hRp] at hh
      linarith
  · change R/2≤‖z-((a:ℂ)+(b:ℂ)*Complex.I)‖
    rcases hedge with h|h|h
    · have hh := Complex.abs_im_le_norm (z-upperCauchyPole a b)
      simp only [upperCauchyPole,Complex.sub_im,Complex.add_im,Complex.ofReal_im,Complex.mul_im,
        Complex.ofReal_re,Complex.I_im,Complex.I_re,mul_one,mul_zero,add_zero,zero_add,h] at hh
      rw [abs_of_neg (by linarith : -R-b<0)] at hh
      linarith
    · have hh := Complex.abs_re_le_norm (z-upperCauchyPole a b)
      simp only [upperCauchyPole,Complex.sub_re,Complex.add_re,Complex.ofReal_re,Complex.mul_re,
        Complex.ofReal_im,Complex.I_re,Complex.I_im,mul_zero,zero_mul,sub_zero,add_zero,h,add_sub_cancel_left,
        abs_of_pos hRp] at hh
      linarith
    · have hh := Complex.abs_re_le_norm (z-upperCauchyPole a b)
      simp only [upperCauchyPole,Complex.sub_re,Complex.add_re,Complex.ofReal_re,Complex.mul_re,
        Complex.ofReal_im,Complex.I_re,Complex.I_im,mul_zero,zero_mul,sub_zero,add_zero,h] at hh
      rw [show a-R-a= -R by ring,abs_neg,abs_of_pos hRp] at hh
      linarith

end LeanVerification.WedgeIntegralCompletion
