import LeanVerification.MiddleStripSpectral.OneZeroBlocks

/-! A continuous cut density with no negative-positive-negative triple
has at most two ordered sign changes. An isolated exceptional point is
removed only as a Lebesgue null set; every retained block has positive mass. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
open MiddleStripSpectral MeasureSigns
set_option maxHeartbeats 2200000

theorem open_strict_density_blocks {H q : ℝ} {f : ℝ→ℝ} {n : ℕ}
    (hH : 0≤H) (B : Fin (n+1)→Set ℝ)
    (hop : ∀i,IsOpen (B i)) (hne : ∀i,(B i).Nonempty)
    (hsub : ∀i,B i⊆Ioi H)
    (horder : ∀i j,i<j → ∀x∈B i,∀y∈B j,x<y)
    (hcover : ∀ᵐt ∂volume.restrict (Ioi H), f t≠0 → ∃i,t∈B i)
    (hq : q≠0) (hsign : ∀i,∀t∈B i,0<(-1:ℝ)^i.val*(q*f t)) :
    Nonempty (BlockDecomposition (volume.restrict (Ioi H)) f n) := by
  apply blockDecomposition_of_ordered_blocks B (fun i => (hop i).measurableSet)
    (fun i t ht => hH.trans (hsub i ht).le) horder
  · intro i
    apply open_block_nonzero_ae (hop i) (hne i) (hsub i)
    intro t ht hz
    have hh := hsign i t ht
    simp only [hz,mul_zero,lt_self_iff_false] at hh
  · exact hcover
  · exact hq
  · intro i
    exact Eventually.of_forall fun t ht => (hsign i t ht).le

theorem no_negative_positive_negative_sign_blocks {H : ℝ} {S : Set ℝ} {f : ℝ→ℝ}
    (hH : 0≤H) (hS : IsOpen S) (hsub : S⊆Ioi H)
    (hae : ∀ᵐt ∂volume.restrict (Ioi H), t∈S)
    (hf : ContinuousOn f S) (hnz : ∃t∈S,f t≠0)
    (htriple : ∀x∈S,∀y∈S,∀z∈S,x<y → y<z → f x<0 → 0<f y → f z<0 → False) :
    ∃n:ℕ,n≤2 ∧ Nonempty (BlockDecomposition (volume.restrict (Ioi H)) f n) := by
  classical
  let P : Set ℝ := {t | t∈S ∧ 0<f t}
  let N : Set ℝ := {t | t∈S ∧ f t<0}
  have hPo : IsOpen P := hf.isOpen_inter_preimage hS isOpen_Ioi
  have hNo : IsOpen N := hf.isOpen_inter_preimage hS isOpen_Iio
  by_cases hN : N.Nonempty
  · obtain ⟨z,hz⟩ := hN
    let L : Set ℝ := {t | t∈P ∧ t<z}
    let R : Set ℝ := {t | t∈P ∧ z<t}
    have hLo : IsOpen L := hPo.inter isOpen_Iio
    have hRo : IsOpen R := hPo.inter isOpen_Ioi
    have hLN : ∀x∈L,∀y∈N,x<y := by
      intro x hx y hy
      by_contra hn
      have hne : y≠x := by intro he;subst y;exact (not_lt_of_ge hx.1.2.le) hy.2
      have hlt : y<x := lt_of_le_of_ne (le_of_not_gt hn) hne
      exact htriple y hy.1 x hx.1.1 z hz.1 hlt hx.2 hy.2 hx.1.2 hz.2
    have hNR : ∀x∈N,∀y∈R,x<y := by
      intro x hx y hy
      by_contra hn
      have hne : y≠x := by intro he;subst y;exact (not_lt_of_ge hy.1.2.le) hx.2
      have hlt : y<x := lt_of_le_of_ne (le_of_not_gt hn) hne
      exact htriple z hz.1 y hy.1.1 x hx.1 hy.2 hlt hz.2 hy.1.2 hx.2
    have hLR : ∀x∈L,∀y∈R,x<y := fun _ hx _ hy => hx.2.trans hy.2
    have hcover : ∀t∈S,f t≠0 → t∈L ∨ t∈N ∨ t∈R := by
      intro t ht hnt
      rcases lt_or_gt_of_ne hnt with hneg|hpos
      · exact Or.inr (Or.inl ⟨ht,hneg⟩)
      · rcases lt_trichotomy t z with htz|rfl|hzt
        · exact Or.inl ⟨⟨ht,hpos⟩,htz⟩
        · exact (not_lt_of_ge hpos.le hz.2).elim
        · exact Or.inr (Or.inr ⟨⟨ht,hpos⟩,hzt⟩)
    by_cases hL : L.Nonempty
    · by_cases hR : R.Nonempty
      · refine ⟨2,le_rfl,open_strict_density_blocks (q:=1) hH ![L,N,R] ?_ ?_ ?_ ?_ ?_ (by norm_num) ?_⟩
        · intro i;fin_cases i
          · exact hLo
          · exact hNo
          · exact hRo
        · intro i;fin_cases i
          · exact hL
          · exact ⟨z,hz⟩
          · exact hR
        · intro i;fin_cases i
          · exact fun _ ht => hsub ht.1.1
          · exact fun _ ht => hsub ht.1
          · exact fun _ ht => hsub ht.1.1
        · intro i j hij
          fin_cases i <;> fin_cases j <;> norm_num at hij ⊢
          · exact hLN
          · exact hLR
          · exact hNR
        · filter_upwards [hae] with t ht hn
          rcases hcover t ht hn with hl|hn|hr
          · exact ⟨0,hl⟩
          · exact ⟨1,hn⟩
          · exact ⟨2,hr⟩
        · intro i;fin_cases i <;> intro t ht
          · simpa using ht.1.2
          · simpa using neg_pos.mpr ht.2
          · simpa using ht.1.2
      · refine ⟨1,by omega,open_strict_density_blocks (q:=1) hH ![L,N] ?_ ?_ ?_ ?_ ?_ (by norm_num) ?_⟩
        · intro i;fin_cases i
          · exact hLo
          · exact hNo
        · intro i;fin_cases i
          · exact hL
          · exact ⟨z,hz⟩
        · intro i;fin_cases i
          · exact fun _ ht => hsub ht.1.1
          · exact fun _ ht => hsub ht.1
        · intro i j hij
          fin_cases i <;> fin_cases j <;> norm_num at hij ⊢
          exact hLN
        · filter_upwards [hae] with t ht hn
          rcases hcover t ht hn with hl|hn|hr
          · exact ⟨0,hl⟩
          · exact ⟨1,hn⟩
          · exact (hR ⟨t,hr⟩).elim
        · intro i;fin_cases i <;> intro t ht
          · simpa using ht.1.2
          · simpa using neg_pos.mpr ht.2
    · by_cases hR : R.Nonempty
      · refine ⟨1,by omega,open_strict_density_blocks (q:=-1) hH ![N,R] ?_ ?_ ?_ ?_ ?_ (by norm_num) ?_⟩
        · intro i;fin_cases i
          · exact hNo
          · exact hRo
        · intro i;fin_cases i
          · exact ⟨z,hz⟩
          · exact hR
        · intro i;fin_cases i
          · exact fun _ ht => hsub ht.1
          · exact fun _ ht => hsub ht.1.1
        · intro i j hij
          fin_cases i <;> fin_cases j <;> norm_num at hij ⊢
          exact hNR
        · filter_upwards [hae] with t ht hn
          rcases hcover t ht hn with hl|hn|hr
          · exact (hL ⟨t,hl⟩).elim
          · exact ⟨0,hn⟩
          · exact ⟨1,hr⟩
        · intro i;fin_cases i <;> intro t ht
          · simpa using neg_pos.mpr ht.2
          · simpa using ht.1.2
      · refine ⟨0,by omega,open_strict_density_blocks (q:=-1) hH (fun _ => N)
          (fun _ => hNo) (fun _ => ⟨z,hz⟩) (fun _ _ ht => hsub ht.1) ?_ ?_ (by norm_num) ?_⟩
        · intro i j hij
          fin_cases i;fin_cases j;exact (lt_irrefl _ hij).elim
        · filter_upwards [hae] with t ht hn
          rcases hcover t ht hn with hl|hn|hr
          · exact (hL ⟨t,hl⟩).elim
          · exact ⟨0,hn⟩
          · exact (hR ⟨t,hr⟩).elim
        · intro i t ht
          fin_cases i
          simpa using neg_pos.mpr ht.2
  · have hPc : ∀t∈S,f t≠0 → t∈P := by
      intro t ht hn
      exact ⟨ht,lt_of_le_of_ne (le_of_not_gt (fun hneg => hN ⟨t,ht,hneg⟩)) hn.symm⟩
    obtain ⟨z,hz,hzn⟩ := hnz
    refine ⟨0,by omega,open_strict_density_blocks (q:=1) hH (fun _ => P)
      (fun _ => hPo) (fun _ => ⟨z,hPc z hz hzn⟩) (fun _ _ ht => hsub ht.1) ?_ ?_ (by norm_num) ?_⟩
    · intro i j hij
      fin_cases i;fin_cases j;exact (lt_irrefl _ hij).elim
    · filter_upwards [hae] with t ht hn
      exact ⟨0,hPc t ht hn⟩
    · intro i t ht
      fin_cases i
      simpa using ht.2

theorem punctured_halfline_two_density_blocks {H Vs : ℝ} {f : ℝ→ℝ}
    (hH : 0≤H) (hVs : H<Vs)
    (hf : ContinuousOn f {t:ℝ | H<t ∧ t≠Vs})
    (hnz : ∃t∈{t:ℝ | H<t ∧ t≠Vs},f t≠0)
    (htriple : ∀x∈{t:ℝ | H<t ∧ t≠Vs},∀y∈{t:ℝ | H<t ∧ t≠Vs},
      ∀z∈{t:ℝ | H<t ∧ t≠Vs},x<y → y<z → f x<0 → 0<f y → f z<0 → False) :
    ∃n:ℕ,n≤2 ∧ Nonempty (BlockDecomposition (volume.restrict (Ioi H)) f n) := by
  apply no_negative_positive_negative_sign_blocks hH
    (isOpen_Ioi.inter (isClosed_singleton.isOpen_compl)) (fun _ ht => ht.1) ?_ hf hnz htriple
  have hne : ∀ᵐt:ℝ ∂volume,t≠Vs := by simp [ae_iff]
  filter_upwards [ae_restrict_mem measurableSet_Ioi,ae_restrict_of_ae hne] with t ht hn
  exact ⟨ht,hn⟩

end LeanVerification.WedgeIntegralCompletion
