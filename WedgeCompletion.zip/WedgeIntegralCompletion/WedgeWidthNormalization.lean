import LeanVerification.WedgeIntegralCompletion.WedgeWidthInfinity

/-! Both actual wedge branches choose the same leading square-root sign. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
open MiddleStripCompletion MiddleStripSpectral ContourCompletion WedgeFullCompletion
set_option maxHeartbeats 1600000

theorem wedge_halfRatios_square_eq {D F:ℝ} (hD:D< -1) (hF:3/2<F)
    {g:ℂ→ℂ} {z:ℂ} (hz:z≠0) (he:logPotential D F (g z)=z)
    (hb:‖normalizedInverseFactor D F (g z)-1‖≤1/2) :
    (inverseHalfRatio F g z)^2=(wedgeApproximateHalfRatio D F g z)^2 := by
  have hA := (wedge_coefficients_pos hD hF).1
  have hlead : leading D F<0 := by simpa only [wedgeLeading,neg_pos] using hA
  have hnq:normalizedInverseFactor D F (g z)≠0 := by
    intro heq
    have hp := normalizedInverseFactor_re_pos hb
    simpa [heq] using hp
  have han:(leading D F:ℂ)≠0 := Complex.ofReal_ne_zero.mpr hlead.ne
  have hfac:(leading D F:ℂ)*normalizedInverseFactor D F (g z)=
      (leading D F:ℂ)+infinityResidual D F (g z) := by
    rw [normalizedInverseFactor]
    field_simp
    <;> ring
  have hexp:(Complex.exp ((F:ℂ)*g z))^2=Complex.exp (((2*F:ℝ):ℂ)*g z) := by
    rw [pow_two,←Complex.exp_add]
    congr 1
    push_cast
    ring
  have hbase := logPotential_infinity_factorization D F (g z)
  rw [he,←hfac] at hbase
  rw [inverseHalfRatio,wedgeApproximateHalfRatio,div_pow,hexp,principalSquareRoot_square hz,
    mul_pow,Complex.I_sq,inv_pow,mul_pow,←Complex.ofReal_pow,Real.sq_sqrt hA.le,
    principalSquareRoot_square hnq]
  calc
    _=Complex.exp (((2*F:ℝ):ℂ)*g z)/(Complex.exp (((2*F:ℝ):ℂ)*g z)*
        ((leading D F:ℂ)*normalizedInverseFactor D F (g z))) :=
      congrArg (fun t:ℂ=>Complex.exp (((2*F:ℝ):ℂ)*g z)/t) hbase
    _=((leading D F:ℂ)*normalizedInverseFactor D F (g z))⁻¹ := by
      field_simp
    _=_ := by simp [wedgeLeading]

theorem wedgeApproximateHalfRatio_continuousOn {D F R:ℝ} {g:ℂ→ℂ}
    (hD:D< -1) (hF:3/2<F) (hg:ContinuousOn g upperEnergy)
    (hb:∀z∈upperExterior R,‖normalizedInverseFactor D F (g z)-1‖≤1/2) :
    ContinuousOn (wedgeApproximateHalfRatio D F g) (upperExterior R) := by
  have hres:Continuous (infinityResidual D F) := by
    change Continuous (fun w:ℂ=>(height D F:ℂ)*Complex.exp (((-(2*F):ℝ):ℂ)*w)+
      (middle D F:ℂ)*Complex.exp (-w)-(trailing D F:ℂ)*Complex.exp (-2*w))
    exact ((continuous_const.mul (Complex.continuous_exp.comp
      (continuous_const.mul continuous_id))).add
      (continuous_const.mul (Complex.continuous_exp.comp continuous_neg))).sub
      (continuous_const.mul (Complex.continuous_exp.comp (continuous_const.mul continuous_id)))
  have hnorm:Continuous (normalizedInverseFactor D F) :=
    continuous_const.add (hres.div_const _)
  intro z hz
  have hgc := (hg z hz.1).continuousAt (upperEnergy_open.mem_nhds hz.1)
  have hqc:ContinuousAt (fun w:ℂ=>normalizedInverseFactor D F (g w)) z :=
    hnorm.continuousAt.comp hgc
  have hqr := normalizedInverseFactor_re_pos (hb z hz)
  have hroot:ContinuousAt principalSquareRoot (normalizedInverseFactor D F (g z)) :=
    (analyticAt_principalSquareRoot (Or.inl hqr)).continuousAt
  have hsc:ContinuousAt (fun w=>principalSquareRoot (normalizedInverseFactor D F (g w))) z :=
    hroot.comp (f:=fun w:ℂ=>normalizedInverseFactor D F (g w)) hqc
  have hprod:ContinuousAt (fun w:ℂ=>(Real.sqrt (wedgeLeading D F):ℂ)*
      principalSquareRoot (normalizedInverseFactor D F (g w))) z := continuousAt_const.mul hsc
  have hn:((Real.sqrt (wedgeLeading D F):ℂ)*
      principalSquareRoot (normalizedInverseFactor D F (g z)))≠0 := mul_ne_zero
    (Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr (wedge_coefficients_pos hD hF).1).ne')
    (Complex.exp_ne_zero _)
  exact (continuousAt_const.mul (hprod.inv₀ hn)).continuousWithinAt

theorem wedge_halfRatio_uniform_sign {D F R:ℝ} {g:ℂ→ℂ}
    (hD:D< -1) (hF:3/2<F) (hR:0<R)
    (hg:ContinuousOn g upperEnergy)
    (he:∀z∈upperEnergy,logPotential D F (g z)=z)
    (hb:∀z∈upperExterior R,‖normalizedInverseFactor D F (g z)-1‖≤1/2) :
    EqOn (inverseHalfRatio F g) (wedgeApproximateHalfRatio D F g) (upperExterior R) ∨
      EqOn (inverseHalfRatio F g) (fun z=>-wedgeApproximateHalfRatio D F g z) (upperExterior R) := by
  apply (upperExterior_isPreconnected hR).eq_or_eq_neg_of_sq_eq
    ((inverseHalfRatio_continuousOn hg).mono (fun _ hz=>hz.1))
    (wedgeApproximateHalfRatio_continuousOn hD hF hg hb)
  · intro z hz
    exact wedge_halfRatios_square_eq hD hF (Complex.slitPlane_ne_zero (Or.inr hz.1.ne'))
      (he z hz.1) (hb z hz)
  · intro z hz
    exact mul_ne_zero Complex.I_ne_zero (inv_ne_zero (mul_ne_zero
      (Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr (wedge_coefficients_pos hD hF).1).ne')
      (Complex.exp_ne_zero _)))

theorem wedge_right_halfRatio_uniform_normalization {D F R:ℝ} {g:ℂ→ℂ}
    (hD:D< -1) (hF:3/2<F) (hDF:-F<D) (hR:0<R)
    (hg:ContinuousOn g upperEnergy) (hm:MapsTo g upperEnergy (rightDomain D F))
    (he:∀z∈upperEnergy,logPotential D F (g z)=z)
    (hb:∀z∈upperExterior R,‖normalizedInverseFactor D F (g z)-1‖≤1/2) :
    EqOn (inverseHalfRatio F g) (wedgeApproximateHalfRatio D F g) (upperExterior R) := by
  rcases wedge_halfRatio_uniform_sign hD hF hR hg he hb with hpos|hneg
  · exact hpos
  · exfalso
    let z:ℂ := ((R+1:ℝ):ℂ)*Complex.I
    have hz:z∈upperExterior R := imaginary_test_mem_upperExterior hR
    have hs := hm hz.1
    rw [rightDomain_eq_strict hD hF hDF] at hs
    have hFp : 0<F := by linarith
    have hg0:0<F*(g z).im := mul_pos hFp hs.1.1
    have hgπ:F*(g z).im<Real.pi := by
      have hh := mul_lt_mul_of_pos_left hs.1.2.1 hFp
      have heq : F*wedgeRightAngle F=Real.pi := by
        unfold wedgeRightAngle
        field_simp
        <;> ring
      rwa [heq] at hh
    have hi:0<(Complex.exp ((F:ℂ)*g z)).im := by
      rw [Complex.exp_im]
      have harg:((F:ℂ)*g z).im=F*(g z).im := by simp
      rw [harg]
      exact mul_pos (Real.exp_pos _) (Real.sin_pos_of_pos_of_lt_pi hg0 hgπ)
    have hquad := wedge_sqrt_imaginary_quadrant hD hF (show 0<R+1 by linarith) (hb z hz)
    have hr := hneg hz
    change Complex.exp ((F:ℂ)*g z)/principalSquareRoot z= -wedgeApproximateHalfRatio D F g z at hr
    have heq := (div_eq_iff (Complex.exp_ne_zero (Complex.log z/2))).mp hr
    have hval:Complex.exp ((F:ℂ)*g z)=
        -(principalSquareRoot z*wedgeApproximateHalfRatio D F g z) := by rw [heq];unfold principalSquareRoot;ring
    rw [hval,Complex.neg_im] at hi
    linarith [hquad.2]

theorem wedge_left_halfRatio_uniform_normalization {D F R:ℝ} {g:ℂ→ℂ}
    (hD:D< -1) (hF:3/2<F) (hDF:-F<D) (hR:0<R)
    (hg:ContinuousOn g upperEnergy) (hm:MapsTo g upperEnergy (leftDomain D F))
    (he:∀z∈upperEnergy,logPotential D F (g z)=z)
    (hb:∀z∈upperExterior R,‖normalizedInverseFactor D F (g z)-1‖≤1/2)
    (hlarge:∀z∈upperExterior R,wedgeLogRadius D F<(g z).re) :
    EqOn (inverseHalfRatio F g) (wedgeApproximateHalfRatio D F g) (upperExterior R) := by
  rcases wedge_halfRatio_uniform_sign hD hF hR hg he hb with hpos|hneg
  · exact hpos
  · exfalso
    let z:ℂ := ((R+1:ℝ):ℂ)*Complex.I
    have hz:z∈upperExterior R := imaginary_test_mem_upperExterior hR
    have hs := hm hz.1
    rw [leftDomain_eq_strict hD hF hDF] at hs
    change star (g z)∈zeroFrameInterior D F ∧ _ at hs
    simp only [zeroFrameInterior,mem_setOf_eq,Complex.star_def,Complex.conj_im,Complex.conj_re] at hs
    have hFp : 0<F := by linarith
    have ha : wedgeFirstAngle F< -(g z).im := hs.1.2.2.1.resolve_right
      (not_lt.mpr (hlarge z hz).le)
    have hfirst : Real.pi/2<F*wedgeFirstAngle F := by
      unfold wedgeFirstAngle
      rw [←mul_div_assoc]
      apply (lt_div_iff₀ (show 0<2*F-1 by linarith)).mpr
      nlinarith [Real.pi_pos]
    have hglo:-(3*Real.pi/2)<F*(g z).im := by
      have hh := mul_lt_mul_of_pos_left hs.1.2.1 hFp
      have heq : F*wedgeZeroAngle F=3*Real.pi/2 := by
        unfold wedgeZeroAngle
        field_simp
        <;> ring
      rw [heq] at hh
      nlinarith
    have hghi:F*(g z).im< -Real.pi/2 := by
      nlinarith [mul_lt_mul_of_pos_left ha hFp]
    have hre:(Complex.exp ((F:ℂ)*g z)).re<0 := by
      rw [Complex.exp_re]
      have harg:((F:ℂ)*g z).im=F*(g z).im := by simp
      rw [harg,←Real.cos_neg]
      exact mul_neg_of_pos_of_neg (Real.exp_pos _)
        (Real.cos_neg_of_pi_div_two_lt_of_lt (by linarith) (by linarith))
    have hquad := wedge_sqrt_imaginary_quadrant hD hF (show 0<R+1 by linarith) (hb z hz)
    have hr := hneg hz
    change Complex.exp ((F:ℂ)*g z)/principalSquareRoot z= -wedgeApproximateHalfRatio D F g z at hr
    have heq := (div_eq_iff (Complex.exp_ne_zero (Complex.log z/2))).mp hr
    have hval:Complex.exp ((F:ℂ)*g z)=
        -(principalSquareRoot z*wedgeApproximateHalfRatio D F g z) := by rw [heq];unfold principalSquareRoot;ring
    rw [hval,Complex.neg_re] at hre
    linarith [hquad.1]

end LeanVerification.WedgeIntegralCompletion
