import LeanVerification.WedgeIntegralCompletion.ImproperPowerControl

/-! Strict improper comparison from an actual primitive and a positive
correction. This also proves convergence of the correction itself. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
set_option maxHeartbeats 1000000

theorem improper_strict_comparison_of_derivative
    {f F d:ℝ→ℝ} {L:ℝ}
    (hfi:IntegrableOn f (Ioi 0)) (hfc:ContinuousOn f (Ioi 0))
    (hF0:ContinuousWithinAt F (Ici 0) 0)
    (hFd:∀x:ℝ,0<x→HasDerivAt F (d x) x)
    (hFL:Tendsto F atTop (𝓝 L))
    (hpos:∀x:ℝ,0<x→f x<d x) :
    IntegrableOn (fun x=>d x-f x) (Ioi 0) ∧
      (∫x in Ioi (0:ℝ),d x-f x)=L-F 0-(∫x in Ioi (0:ℝ),f x) ∧
      (∫x in Ioi (0:ℝ),f x)<L-F 0 := by
  let J : ℝ→ℝ := fun x=>∫t in (0:ℝ)..x,f t
  have hi (x:ℝ) (hx:0≤x) : IntervalIntegrable f volume 0 x := by
    rw [intervalIntegrable_iff_integrableOn_Ioc_of_le hx]
    exact hfi.mono_set (fun _ ht=>ht.1)
  have hJ0 : ContinuousWithinAt J (Ici 0) 0 := by
    have hc := intervalIntegral.continuousOn_primitive_interval' (hi 1 zero_le_one)
      (a:=0) left_mem_uIcc
    rw [uIcc_of_le zero_le_one] at hc
    exact (hc 0 ⟨le_rfl,zero_le_one⟩).mono_of_mem_nhdsWithin
      (Icc_mem_nhdsGE zero_lt_one)
  have hJd (x:ℝ) (hx:0<x) : HasDerivAt J (f x) x := by
    exact intervalIntegral.integral_hasDerivAt_right (hi x hx.le)
      (hfc.stronglyMeasurableAtFilter isOpen_Ioi x hx)
      ((hfc x hx).continuousAt (Ioi_mem_nhds hx))
  have hJL : Tendsto J atTop (𝓝 (∫x in Ioi (0:ℝ),f x)) :=
    intervalIntegral_tendsto_integral_Ioi 0 hfi tendsto_id
  have hd (x:ℝ) (hx:x∈Ioi (0:ℝ)) :
      HasDerivAt (fun x=>F x-J x) (d x-f x) x := (hFd x hx).sub (hJd x hx)
  have hn (x:ℝ) (hx:x∈Ioi (0:ℝ)) : 0≤d x-f x := (sub_pos.mpr (hpos x hx)).le
  have hG := integrableOn_Ioi_deriv_of_nonneg (hF0.sub hJ0) hd hn (hFL.sub hJL)
  have hEq := integral_Ioi_of_hasDerivAt_of_nonneg (hF0.sub hJ0) hd hn (hFL.sub hJL)
  have hJz : J 0=0 := by simp [J]
  simp only [hJz,sub_zero] at hEq
  have hmass : 0<∫x in Ioi (0:ℝ),d x-f x := by
    apply (setIntegral_pos_iff_support_of_nonneg_ae
      (show 0≤ᵐ[volume.restrict (Ioi (0:ℝ))] (fun x=>d x-f x) from by
        filter_upwards [ae_restrict_mem measurableSet_Ioi] with x hx
        exact hn x hx) hG).mpr
    have hs : Function.support (fun x=>d x-f x) ∩ Ioi (0:ℝ)=Ioi 0 := by
      ext x
      exact ⟨fun h=>h.2,fun hx=>⟨(sub_pos.mpr (hpos x hx)).ne',hx⟩⟩
    rw [hs]
    simp
  exact ⟨hG,by linarith,by linarith⟩

end LeanVerification.WedgeIntegralCompletion
