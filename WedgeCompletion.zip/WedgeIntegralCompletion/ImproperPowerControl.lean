import Mathlib.MeasureTheory.Integral.Asymptotics
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals

/-! Endpoint and tail domination for the actual improper wedge integrals. -/
noncomputable section
open Set Filter MeasureTheory Asymptotics
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
set_option maxHeartbeats 800000

/-- Local continuity and genuine endpoint bounds imply absolute integrability
on the whole positive ray. The bounds are required near both open ends. -/
theorem integrableOn_positive_ray_of_power_bounds
    {E : Type*} [NormedAddCommGroup E] {f : ℝ → E} {a b C₀ Ctop : ℝ}
    (hf : ContinuousOn f (Ioi 0)) (ha : -1<a) (hb : b< -1)
    (h₀ : ∀ᶠ x in 𝓝[>] (0:ℝ), ‖f x‖≤C₀*x^a)
    (htop : ∀ᶠ x in atTop, ‖f x‖≤Ctop*x^b) :
    IntegrableOn f (Ioi 0) := by
  have hm : AEStronglyMeasurable f (volume.restrict (Ioi 0)) :=
    hf.aestronglyMeasurable measurableSet_Ioi
  have ho₀ : f =O[𝓝[>] (0:ℝ)] (fun x:ℝ=>x^a) := by
    apply isBigO_iff.mpr
    refine ⟨C₀,?_⟩
    filter_upwards [h₀,self_mem_nhdsWithin] with x hx hx0
    rw [Real.norm_of_nonneg (Real.rpow_nonneg (le_of_lt hx0) _)]
    exact hx
  have hotop : f =O[atTop] (fun x:ℝ=>x^b) := by
    apply isBigO_iff.mpr
    refine ⟨Ctop,?_⟩
    filter_upwards [htop,Ioi_mem_atTop (0:ℝ)] with x hx hx0
    rw [Real.norm_of_nonneg (Real.rpow_nonneg hx0.le _)]
    exact hx
  have hi₀ : IntegrableAtFilter (fun x:ℝ=>x^a) (𝓝[>] (0:ℝ)) := by
    refine ⟨Ioc 0 1,?_,?_⟩
    · exact Ioc_mem_nhdsGT zero_lt_one
    · exact (intervalIntegral.intervalIntegrable_rpow' ha :
        IntervalIntegrable (fun x:ℝ=>x^a) volume 0 1).1
  have hitop : IntegrableAtFilter (fun x:ℝ=>x^b) atTop :=
    ⟨Ioi 1,Ioi_mem_atTop 1,integrableOn_Ioi_rpow_of_lt hb zero_lt_one⟩
  apply integrableOn_Ioi_iff_integrableAtFilter_atTop_nhdsWithin.mpr
  exact ⟨hotop.integrableAtFilter ⟨Ioi 0,Ioi_mem_atTop 0,hm⟩ hitop,
    ho₀.integrableAtFilter ⟨Ioi 0,self_mem_nhdsWithin,hm⟩ hi₀,
    hf.locallyIntegrableOn measurableSet_Ioi⟩

/-- A finite limit of a power-normalized norm supplies the needed bound. -/
theorem eventually_norm_le_power_of_tendsto
    {E : Type*} [NormedAddCommGroup E] {f : ℝ → E} {a L : ℝ} {l : Filter ℝ}
    (hpos : ∀ᶠ x in l,0<x)
    (hlim : Tendsto (fun x=>‖f x‖/x^a) l (𝓝 L)) :
    ∀ᶠ x in l, ‖f x‖≤(L+1)*x^a := by
  filter_upwards [hpos,hlim.eventually (gt_mem_nhds (show L<L+1 by linarith))] with x hx hh
  exact (le_of_lt ((div_lt_iff₀ (Real.rpow_pos_of_pos hx _)).mp hh))

end LeanVerification.WedgeIntegralCompletion
