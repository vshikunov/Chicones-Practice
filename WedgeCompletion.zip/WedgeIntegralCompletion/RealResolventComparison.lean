import LeanVerification.WedgeIntegralCompletion.RealSquareComparison

/-! Complete real half of the quadratic-resolvent comparison. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
set_option maxHeartbeats 1400000

def realResolventDenominator (e b σ x : ℝ) : ℝ :=
  e+x^(2*σ-2)*(x^2-b*x+1)

def realResolventWeight (e b σ x : ℝ) : ℝ :=
  x^(σ-1)/realResolventDenominator e b σ x

theorem realResolventDenominator_continuous {e b σ : ℝ} (hσ : 1<σ) :
    Continuous (realResolventDenominator e b σ) := by
  exact continuous_const.add ((Real.continuous_rpow_const (show 0≤2*σ-2 by linarith)).mul
    (((continuous_id.pow 2).sub (continuous_const.mul continuous_id)).add continuous_const))

theorem realResolventWeight_integrable {e b σ : ℝ}
    (he : 0<e) (hσ : 1<σ)
    (hden : ∀x:ℝ,0<x→0<realResolventDenominator e b σ x) :
    IntegrableOn (realResolventWeight e b σ) (Ioi 0) := by
  have hc := realResolventDenominator_continuous (e:=e) (b:=b) hσ
  have hf : ContinuousOn (realResolventWeight e b σ) (Ioi 0) := by
    intro x hx
    exact ((Real.continuousAt_rpow_const x (σ-1) (Or.inl (ne_of_gt hx))).div
      hc.continuousAt (hden x hx).ne').continuousWithinAt
  apply integrableOn_positive_ray_of_power_bounds (C₀:=2/e) (Ctop:=2) hf
    (by linarith : -1<σ-1) (by linarith : -σ-1< -1)
  · have hz : realResolventDenominator e b σ 0=e := by
      simp only [realResolventDenominator,Real.zero_rpow (show 2*σ-2≠0 by linarith),
        zero_mul,add_zero]
    have ht : Tendsto (realResolventDenominator e b σ) (𝓝[>] 0) (𝓝 e) := by
      simpa only [hz] using (hc.continuousAt (x:=0)).tendsto.mono_left
        (nhdsWithin_le_nhds (s:=Ioi 0))
    filter_upwards [self_mem_nhdsWithin,
      ht.eventually (lt_mem_nhds (show e/2<e by linarith))] with x hx hd
    have hx0 : 0<x := hx
    rw [realResolventWeight,Real.norm_of_nonneg
      (div_nonneg (Real.rpow_nonneg hx0.le _) (hden x hx0).le)]
    apply (div_le_div_of_nonneg_left (Real.rpow_nonneg hx0.le _)
      (by linarith : 0<e/2) hd.le).trans_eq
    ring
  · filter_upwards [Ioi_mem_atTop (max 0 (2*b))] with x hx
    have hx0 : 0<x := (le_max_left _ _).trans_lt hx
    have hbx : 2*b≤x := (le_max_right _ _).trans hx.le
    have hq : x^2/2≤x^2-b*x+1 := by nlinarith
    have hp : 0<x^(2*σ-2) := Real.rpow_pos_of_pos hx0 _
    have hpow : x^(2*σ-2)*x^2=x^(2*σ) := by
      rw [←Real.rpow_natCast,←Real.rpow_add hx0]
      congr 1
      ring
    have hl : x^(2*σ)/2≤realResolventDenominator e b σ x := by
      unfold realResolventDenominator
      nlinarith [mul_le_mul_of_nonneg_left hq hp.le]
    rw [realResolventWeight,Real.norm_of_nonneg
      (div_nonneg (Real.rpow_nonneg hx0.le _) (hden x hx0).le)]
    apply (div_le_div_of_nonneg_left (Real.rpow_nonneg hx0.le _)
      (by positivity : 0<x^(2*σ)/2) hl).trans_eq
    have hr : x^(-σ-1)=x^(σ-1)/x^(2*σ) := by
      rw [←Real.rpow_sub hx0]
      congr 1
      ring
    rw [hr]
    ring

theorem realResolventDenominator_le_square {e b σ x : ℝ}
    (hb : 2≤b) (hx : 0<x) :
    realResolventDenominator e b σ x≤realSquareDenominator e (b/2) σ x := by
  have hp : 0≤x^(2*σ-2) := Real.rpow_nonneg hx.le _
  have hsq : (x^(σ-1))^2=x^(2*σ-2) := by
    rw [←Real.rpow_mul_natCast hx.le]
    congr 1
    ring
  unfold realResolventDenominator realSquareDenominator
  rw [mul_pow,hsq]
  have hq : x^2-b*x+1≤(x-b/2)^2 := by nlinarith
  linarith [mul_le_mul_of_nonneg_left hq hp]

/-- The first strict inequality of the actual improper comparison. -/
theorem real_quadratic_resolvent_integral_strict {e b σ : ℝ}
    (he : 0<e) (hb : 2≤b) (hσ : 1<σ)
    (hden : ∀x:ℝ,0<x→0<realResolventDenominator e b σ x) :
    Real.pi/(2*σ*Real.sqrt e)<
      ∫x in Ioi (0:ℝ),realResolventWeight e b σ x := by
  have hs := realSquare_integral_strict (a:=b/2) he (by linarith) hσ
  have hle : (∫x in Ioi (0:ℝ),realSquareWeight e (b/2) σ (σ-1) x)≤
      ∫x in Ioi (0:ℝ),realResolventWeight e b σ x := by
    apply integral_mono_ae
      (realSquareWeight_integrable he (by linarith) (by linarith))
      (realResolventWeight_integrable he hσ hden)
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with x hx
    exact div_le_div_of_nonneg_left (Real.rpow_nonneg hx.le _) (hden x hx)
      (realResolventDenominator_le_square hb hx)
  exact hs.trans_le hle

end LeanVerification.WedgeIntegralCompletion
