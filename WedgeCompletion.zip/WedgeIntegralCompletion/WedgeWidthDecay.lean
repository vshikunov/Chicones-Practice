import LeanVerification.WedgeIntegralCompletion.WedgeWidthNormalization

/-! The equal leading signs cancel. This gives the actual uniform power
decay needed to close the wedge width contour at infinity. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
open MiddleStripCompletion MiddleStripSpectral ContourCompletion WedgeFullCompletion
set_option maxHeartbeats 1600000

theorem wedgeApproximateHalfRatio_residual_bound {D F:ℝ} (hD:D< -1) (hF:3/2<F)
    {g:ℂ→ℂ} {z:ℂ} (hb:‖normalizedInverseFactor D F (g z)-1‖≤1/2) :
    ‖wedgeApproximateHalfRatio D F g z-Complex.I*(Real.sqrt (wedgeLeading D F):ℂ)⁻¹‖≤
      (2/(Real.sqrt (wedgeLeading D F)*wedgeLeading D F))*‖infinityResidual D F (g z)‖ := by
  have hA := (wedge_coefficients_pos hD hF).1
  have hlead : leading D F<0 := by simpa only [wedgeLeading,neg_pos] using hA
  have hs := Real.sqrt_pos.mpr hA
  have herr := principalSquareRoot_inverse_error_bound
    (Or.inl (normalizedInverseFactor_re_pos hb)) hb
  have he:wedgeApproximateHalfRatio D F g z-Complex.I*(Real.sqrt (wedgeLeading D F):ℂ)⁻¹=
      Complex.I*(Real.sqrt (wedgeLeading D F):ℂ)⁻¹*
        ((principalSquareRoot (normalizedInverseFactor D F (g z)))⁻¹-1) := by
    rw [wedgeApproximateHalfRatio,mul_inv]
    ring
  rw [he,norm_mul,norm_mul,Complex.norm_I,one_mul,norm_inv,Complex.norm_real,
    Real.norm_of_nonneg hs.le]
  have hh := mul_le_mul_of_nonneg_left herr (inv_nonneg.mpr hs.le)
  have hq:‖normalizedInverseFactor D F (g z)-1‖=
      ‖infinityResidual D F (g z)‖/wedgeLeading D F := by
    rw [normalizedInverseFactor,add_sub_cancel_left,norm_div,Complex.norm_real,
      Real.norm_eq_abs,abs_of_neg hlead]
    rfl
  rw [hq] at hh
  convert hh using 1 <;> ring

def wedgeHalfRatioDecayBound (D F:ℝ) : ℝ :=
  (2/(Real.sqrt (wedgeLeading D F)*wedgeLeading D F))*
    (|height D F|+|middle D F|+|trailing D F|)*(coefficientBound D F)^(1/(2*F))

theorem wedgeHalfRatioDecayBound_nonneg {D F:ℝ} (hD:D< -1) (hF:3/2<F) :
    0≤wedgeHalfRatioDecayBound D F := by
  have hA := (wedge_coefficients_pos hD hF).1
  have hC := wedge_coefficientBound_pos hD hF
  unfold wedgeHalfRatioDecayBound
  positivity

theorem wedgeApproximateHalfRatio_energy_bound {D F:ℝ} (hD:D< -1) (hF:3/2<F)
    {g:ℂ→ℂ} {z:ℂ} (hz:z≠0) (he:logPotential D F (g z)=z)
    (hgre:0≤(g z).re) (hb:‖normalizedInverseFactor D F (g z)-1‖≤1/2) :
    ‖wedgeApproximateHalfRatio D F g z-Complex.I*(Real.sqrt (wedgeLeading D F):ℂ)⁻¹‖≤
      wedgeHalfRatioDecayBound D F*‖z‖^(-(1/(2*F))) := by
  have hA := (wedge_coefficients_pos hD hF).1
  have hfac:0≤2/(Real.sqrt (wedgeLeading D F)*wedgeLeading D F) := by positivity
  have hcoef:0≤|height D F|+|middle D F|+|trailing D F| := by positivity
  have hres := infinityResidual_exponential_bound (D:=D) hF hgre
  have hpow := wedge_inverse_exponential_energy_bound hD hF hgre (by rw [he];exact hz)
  rw [he] at hpow
  have hres' := hres.trans (mul_le_mul_of_nonneg_left hpow hcoef)
  have hbound := (wedgeApproximateHalfRatio_residual_bound hD hF hb).trans
    (mul_le_mul_of_nonneg_left hres' hfac)
  simpa only [wedgeHalfRatioDecayBound,mul_assoc] using hbound

/-- A uniform bound on the full upper half-plane, including its banks. -/
theorem actual_wedge_upperWidth_uniform_decay {D F:ℝ} {gp gm:ℂ→ℂ}
    (hD:D< -1) (hF:3/2<F) (hDF:-F<D)
    (hgp:ContinuousOn gp upperEnergy) (hgm:ContinuousOn gm upperEnergy)
    (hmp:MapsTo gp upperEnergy (rightDomain D F))
    (hmm:MapsTo gm upperEnergy (leftDomain D F))
    (hep:∀z∈upperEnergy,logPotential D F (gp z)=z)
    (hem:∀z∈upperEnergy,logPotential D F (gm z)=z) :
    ∃R>0,∀z∈upperEnergy,R≤‖z‖→
      ‖upperNormalizedWidth F gp gm z‖≤
        (2*wedgeHalfRatioDecayBound D F/F)*‖z‖^(-(1/(2*F))) := by
  obtain ⟨R,hR,hsmall⟩ := exists_wedge_inverse_factor_uniform_small hD hF
  have hsp:∀z∈upperExterior R,0≤(gp z).re ∧ wedgeLogRadius D F<(gp z).re ∧
      ‖normalizedInverseFactor D F (gp z)-1‖≤1/2 := by
    intro z hz
    apply hsmall
    rw [hep z hz.1]
    exact hz.2
  have hsm:∀z∈upperExterior R,0≤(gm z).re ∧ wedgeLogRadius D F<(gm z).re ∧
      ‖normalizedInverseFactor D F (gm z)-1‖≤1/2 := by
    intro z hz
    apply hsmall
    rw [hem z hz.1]
    exact hz.2
  have hpn := wedge_right_halfRatio_uniform_normalization hD hF hDF hR hgp hmp hep
    (fun z hz=>(hsp z hz).2.2)
  have hmn := wedge_left_halfRatio_uniform_normalization hD hF hDF hR hgm hmm hem
    (fun z hz=>(hsm z hz).2.2) (fun z hz=>(hsm z hz).2.1)
  have hFp:0<F := by linarith
  refine ⟨R+1,by linarith,fun z hz hzR=>?_⟩
  have hz':z∈upperExterior R := ⟨hz,by linarith⟩
  have hzn:z≠0 := Complex.slitPlane_ne_zero (Or.inr (ne_of_gt hz))
  have hp := wedgeApproximateHalfRatio_energy_bound hD hF hzn (hep z hz)
    (hsp z hz').1 (hsp z hz').2.2
  have hm := wedgeApproximateHalfRatio_energy_bound hD hF hzn (hem z hz)
    (hsm z hz').1 (hsm z hz').2.2
  have he:upperNormalizedWidth F gp gm z=
      ((wedgeApproximateHalfRatio D F gp z-Complex.I*(Real.sqrt (wedgeLeading D F):ℂ)⁻¹)-
        (wedgeApproximateHalfRatio D F gm z-Complex.I*(Real.sqrt (wedgeLeading D F):ℂ)⁻¹))/(F:ℂ) := by
    have hw:upperNormalizedWidth F gp gm z=
        (inverseHalfRatio F gp z-inverseHalfRatio F gm z)/(F:ℂ) := by
      unfold upperNormalizedWidth inverseHalfRatio
      rw [←sub_div,div_div,mul_comm (principalSquareRoot z) (F:ℂ)]
    rw [hw,hpn hz',hmn hz']
    ring
  rw [he,norm_div,Complex.norm_real,Real.norm_of_nonneg hFp.le]
  apply (div_le_div_of_nonneg_right (norm_sub_le _ _) hFp.le).trans
  have hh := div_le_div_of_nonneg_right (add_le_add hp hm) hFp.le
  convert hh using 1 <;> ring

end LeanVerification.WedgeIntegralCompletion
