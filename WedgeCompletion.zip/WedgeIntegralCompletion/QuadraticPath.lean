import LeanVerification.WedgeIntegralCompletion.HalfPlanePrimitive
import LeanVerification.WedgeIntegralCompletion.ComplexPowerDenominator

/-! The actual square-root path used in the improper resolvent comparison. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
open WedgeCompletion
set_option maxHeartbeats 1800000

theorem actualQuadraticRoot_analytic_right {b:ℝ} {z:ℂ}
    (hb:2≤b) (hz:0≤z.re) : AnalyticAt ℂ (actualQuadraticRoot b) z := by
  obtain ⟨hu,huv,-,-⟩ := quadratic_endpoints hb
  have hv := hu.trans_le huv
  have hiu : AnalyticAt ℂ (fun w:ℂ=>w+(quadraticLowerEndpoint b:ℂ)) z :=
    analyticAt_id.add analyticAt_const
  have hiv : AnalyticAt ℂ (fun w:ℂ=>w+(quadraticUpperEndpoint b:ℂ)) z :=
    analyticAt_id.add analyticAt_const
  have hsu : z+(quadraticLowerEndpoint b:ℂ)∈Complex.slitPlane := by left;simpa using add_pos_of_nonneg_of_pos hz hu
  have hsv : z+(quadraticUpperEndpoint b:ℂ)∈Complex.slitPlane := by left;simpa using add_pos_of_nonneg_of_pos hz hv
  exact ((MiddleStripSpectral.analyticAt_principalSquareRoot hsu).comp
    (f:=fun w:ℂ=>w+(quadraticLowerEndpoint b:ℂ)) hiu).mul
      ((MiddleStripSpectral.analyticAt_principalSquareRoot hsv).comp
        (f:=fun w:ℂ=>w+(quadraticUpperEndpoint b:ℂ)) hiv)

theorem actualQuadraticRoot_zero {b:ℝ} (hb:2≤b) : actualQuadraticRoot b 0=1 := by
  obtain ⟨hu,huv,hp,-⟩ := quadratic_endpoints hb
  exact quadraticRoot_zero hu (hu.trans_le huv) hp

def quadraticPath (b σ:ℝ) (ζ:ℂ) (x:ℝ) : ℂ :=
  (x^σ:ℝ)*actualQuadraticRoot b (ζ/(x:ℂ))

def quadraticPathDerivative (b σ:ℝ) (ζ:ℂ) (x:ℝ) : ℂ :=
  (x^(σ-1):ℝ)*((σ:ℂ)*actualQuadraticRoot b (ζ/(x:ℂ))-
    (ζ/(x:ℂ))*deriv (actualQuadraticRoot b) (ζ/(x:ℂ)))

theorem ray_div_re_nonneg {ζ:ℂ} {x:ℝ} (hζ:0≤ζ.re) (hx:0<x) :
    0≤(ζ/(x:ℂ)).re := by
  simpa only [Complex.div_ofReal_re] using div_nonneg hζ hx.le

theorem quadraticPath_hasDerivAt {b σ x:ℝ} {ζ:ℂ}
    (hb:2≤b) (hζ:0≤ζ.re) (hx:0<x) :
    HasDerivAt (quadraticPath b σ ζ) (quadraticPathDerivative b σ ζ x) x := by
  have hn : (x:ℂ)≠0 := Complex.ofReal_ne_zero.mpr hx.ne'
  have hdR := (actualQuadraticRoot_analytic_right hb (ray_div_re_nonneg hζ hx)).differentiableAt.hasDerivAt
  have hdz := ((hasDerivAt_const (x:ℂ) ζ).div (hasDerivAt_id (x:ℂ)) hn).comp_ofReal
  have hdp := Complex.ofRealCLM.hasFDerivAt.comp_hasDerivAt x
    (Real.hasDerivAt_rpow_const (p:=σ) (Or.inl hx.ne'))
  have hd := hdp.mul (hdR.scomp x hdz)
  have hpow : x^σ=x^(σ-1)*x := by
    calc
      x^σ=x^((σ-1)+1) := by congr 1;ring
      _=x^(σ-1)*x := by rw [Real.rpow_add hx,Real.rpow_one]
  convert hd using 1
  dsimp only [quadraticPathDerivative,id_eq,Function.comp_def,Complex.ofRealCLM_apply]
  simp only [smul_eq_mul,zero_mul,sub_zero,zero_sub,mul_one,Complex.ofReal_mul,hpow]
  field_simp [hn]
  <;> ring

theorem quadraticPath_re_pos {b σ x:ℝ} {ζ:ℂ}
    (hb:2≤b) (hζ:0≤ζ.re) (hx:0<x) : 0<(quadraticPath b σ ζ x).re := by
  simp only [quadraticPath,Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero]
  exact mul_pos (Real.rpow_pos_of_pos hx _)
    (actualQuadraticRoot_re_pos hb (ray_div_re_nonneg hζ hx))

theorem quadraticPath_square {b σ x:ℝ} {ζ:ℂ}
    (hb:2≤b) (hζ:0≤ζ.re) (hx:0<x) :
    quadraticPath b σ ζ x^2=(x^(2*σ-2):ℝ)*((x:ℂ)^2+(b:ℂ)*ζ*(x:ℂ)+ζ^2) := by
  have hn : (x:ℂ)≠0 := Complex.ofReal_ne_zero.mpr hx.ne'
  have hp : (x^σ)^2=x^(2*σ-2)*x^2 := by
    rw [←Real.rpow_mul_natCast hx.le,←Real.rpow_natCast,←Real.rpow_add hx]
    congr 1
    ring
  unfold quadraticPath
  rw [mul_pow,actualQuadraticRoot_square hb (ray_div_re_nonneg hζ hx),←Complex.ofReal_pow,hp]
  push_cast
  field_simp [hn]
  <;> ring

theorem quadraticPath_zero {b σ:ℝ} {ζ:ℂ} (hσ:1<σ) : quadraticPath b σ ζ 0=0 := by
  simp only [quadraticPath,Real.zero_rpow (show σ≠0 by linarith),Complex.ofReal_zero,zero_mul]

/-- The zero endpoint follows from the actual squared path, including its
fractional power. -/
theorem quadraticPath_tendsto_zero {b σ:ℝ} {ζ:ℂ}
    (hb:2≤b) (hσ:1<σ) (hζ:0≤ζ.re) :
    Tendsto (quadraticPath b σ ζ) (𝓝[>] (0:ℝ)) (𝓝 0) := by
  have hc : Continuous (fun x:ℝ=>x^(2*σ-2)*‖(x:ℂ)^2+(b:ℂ)*ζ*(x:ℂ)+ζ^2‖) := by
    apply (Real.continuous_rpow_const (show 0≤2*σ-2 by linarith)).mul
    fun_prop
  have ht : Tendsto (fun x:ℝ=>x^(2*σ-2)*‖(x:ℂ)^2+(b:ℂ)*ζ*(x:ℂ)+ζ^2‖)
      (𝓝[>] 0) (𝓝 0) := by
    simpa only [Real.zero_rpow (show 2*σ-2≠0 by linarith),zero_mul] using
      (hc.continuousAt (x:=0)).tendsto.mono_left (nhdsWithin_le_nhds (s:=Ioi 0))
  have hn : Tendsto (fun x:ℝ=>‖quadraticPath b σ ζ x‖^2) (𝓝[>] 0) (𝓝 0) := by
    apply ht.congr'
    filter_upwards [self_mem_nhdsWithin] with x hx
    rw [←norm_pow,quadraticPath_square hb hζ hx,norm_mul,Complex.norm_real,
      Real.norm_of_nonneg (Real.rpow_nonneg (le_of_lt hx) _)]
  have hn' := (Real.continuous_sqrt.tendsto 0).comp hn
  simp only [Function.comp_def,Real.sqrt_sq_eq_abs,abs_norm,Real.sqrt_zero] at hn'
  exact tendsto_zero_iff_norm_tendsto_zero.mpr hn'

theorem quadraticPath_continuousWithinAt_zero {b σ:ℝ} {ζ:ℂ}
    (hb:2≤b) (hσ:1<σ) (hζ:0≤ζ.re) :
    ContinuousWithinAt (quadraticPath b σ ζ) (Ici 0) 0 := by
  have h : ContinuousWithinAt (quadraticPath b σ ζ) (Ioi 0) 0 := by
    rw [ContinuousWithinAt,quadraticPath_zero hσ]
    exact quadraticPath_tendsto_zero hb hσ hζ
  simpa only [Ioi_insert] using h.insert

/-- The reciprocal tends to zero at infinity, without a guessed phase limit. -/
theorem quadraticPath_inverse_tendsto {b σ:ℝ} {ζ:ℂ}
    (hb:2≤b) (hσ:1<σ) :
    Tendsto (fun x:ℝ=>(quadraticPath b σ ζ x)⁻¹) atTop (𝓝 0) := by
  have hi : Tendsto (fun x:ℝ=>(x:ℂ)⁻¹) atTop (𝓝 (0:ℂ)) := by
    simpa only [Function.comp_def,Pi.inv_apply,Complex.ofReal_inv,Complex.ofReal_zero] using
      Complex.continuous_ofReal.continuousAt.tendsto.comp
        (tendsto_inv_atTop_zero : Tendsto (fun x:ℝ=>x⁻¹) atTop (𝓝 0))
  have hz : Tendsto (fun x:ℝ=>ζ/(x:ℂ)) atTop (𝓝 0) := by
    simpa only [div_eq_mul_inv,mul_zero] using hi.const_mul ζ
  have hr : Tendsto (fun x:ℝ=>actualQuadraticRoot b (ζ/(x:ℂ))) atTop (𝓝 1) := by
    simpa only [actualQuadraticRoot_zero hb] using
      (actualQuadraticRoot_analytic_right hb (z:=0) (by simp)).continuousAt.tendsto.comp hz
  have hp : Tendsto (fun x:ℝ=>((x^σ:ℝ):ℂ)⁻¹) atTop (𝓝 (0:ℂ)) := by
    simpa only [Function.comp_def,Pi.inv_apply,Complex.ofReal_inv,Complex.ofReal_zero] using
      Complex.continuous_ofReal.continuousAt.tendsto.comp
        (tendsto_rpow_atTop (show 0<σ by linarith)).inv_tendsto_atTop
  simpa only [quadraticPath,mul_inv_rev,inv_one,mul_zero] using
    (hr.inv₀ one_ne_zero).mul hp

end LeanVerification.WedgeIntegralCompletion
