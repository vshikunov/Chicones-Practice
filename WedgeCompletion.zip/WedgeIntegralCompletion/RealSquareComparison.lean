import LeanVerification.WedgeIntegralCompletion.ImproperPowerControl
import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv

/-! The strict real-side improper comparison, with both endpoint estimates. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
set_option maxHeartbeats 1600000

def realSquareDenominator (e a σ x : ℝ) : ℝ := e+(x^(σ-1)*(x-a))^2

def realSquareWeight (e a σ δ x : ℝ) : ℝ := x^δ/realSquareDenominator e a σ x

theorem realSquareDenominator_pos {e a σ x : ℝ} (he : 0<e) :
    0<realSquareDenominator e a σ x := by
  unfold realSquareDenominator
  positivity

theorem realSquareDenominator_continuousAt {e a σ x : ℝ} (hx : 0<x) :
    ContinuousAt (realSquareDenominator e a σ) x := by
  exact continuousAt_const.add
    (((Real.continuousAt_rpow_const x (σ-1) (Or.inl hx.ne')).mul
      (continuousAt_id.sub continuousAt_const)).pow 2)

theorem realSquareWeight_continuous {e a σ δ : ℝ} (he : 0<e) :
    ContinuousOn (realSquareWeight e a σ δ) (Ioi 0) := by
  intro x hx
  exact ((Real.continuousAt_rpow_const x δ (Or.inl (ne_of_gt hx))).div
    (realSquareDenominator_continuousAt hx) (realSquareDenominator_pos he).ne').continuousWithinAt

theorem realSquareWeight_near_zero {e a σ δ x : ℝ} (he : 0<e) (hx : 0<x) :
    ‖realSquareWeight e a σ δ x‖≤e⁻¹*x^δ := by
  have hd := realSquareDenominator_pos (a:=a) (σ:=σ) (x:=x) he
  rw [realSquareWeight,Real.norm_of_nonneg (div_nonneg (Real.rpow_nonneg hx.le _) hd.le)]
  have hl : e≤realSquareDenominator e a σ x := by
    unfold realSquareDenominator
    nlinarith [sq_nonneg (x^(σ-1)*(x-a))]
  exact (div_le_div_of_nonneg_left (Real.rpow_nonneg hx.le _) he hl).trans_eq (by ring)

theorem realSquareDenominator_tail {e a σ x : ℝ}
    (he : 0<e) (hx : 0<x) (hax : 2*a≤x) :
    x^(2*σ)/4≤realSquareDenominator e a σ x := by
  have hxa : x/2≤x-a := by linarith
  have hs : (x/2)^2≤(x-a)^2 :=
    (sq_le_sq₀ (by positivity) (by linarith)).mpr hxa
  have hp : 0≤(x^(σ-1))^2 := sq_nonneg _
  have heq : (x^(σ-1))^2*x^2=x^(2*σ) := by
    rw [←Real.rpow_mul_natCast hx.le,←Real.rpow_natCast,←Real.rpow_add hx]
    congr 1
    ring
  unfold realSquareDenominator
  rw [mul_pow]
  nlinarith [mul_le_mul_of_nonneg_left hs hp]

theorem realSquareWeight_tail {e a σ δ x : ℝ}
    (he : 0<e) (hx : 0<x) (hax : 2*a≤x) :
    ‖realSquareWeight e a σ δ x‖≤4*x^(δ-2*σ) := by
  have hd := realSquareDenominator_pos (a:=a) (σ:=σ) (x:=x) he
  rw [realSquareWeight,Real.norm_of_nonneg (div_nonneg (Real.rpow_nonneg hx.le _) hd.le)]
  apply (div_le_div_of_nonneg_left (Real.rpow_nonneg hx.le _)
    (by positivity : 0<x^(2*σ)/4) (realSquareDenominator_tail he hx hax)).trans_eq
  rw [Real.rpow_sub hx]
  ring

/-- The weight and the correction term are separately absolutely integrable. -/
theorem realSquareWeight_integrable {e a σ δ : ℝ}
    (he : 0<e) (hδ : -1<δ) (hδσ : δ-2*σ< -1) :
    IntegrableOn (realSquareWeight e a σ δ) (Ioi 0) := by
  apply integrableOn_positive_ray_of_power_bounds (realSquareWeight_continuous he) hδ hδσ
  · filter_upwards [self_mem_nhdsWithin] with x hx
    exact realSquareWeight_near_zero he hx
  · filter_upwards [Ioi_mem_atTop (max 0 (2*a))] with x hx
    exact realSquareWeight_tail he ((le_max_left _ _).trans_lt hx)
      ((le_max_right _ _).trans hx.le)

def realSquarePrimitive (e a σ x : ℝ) : ℝ :=
  Real.arctan ((x^(σ-1)*(x-a))/Real.sqrt e)/Real.sqrt e

theorem realSquarePrimitive_hasDerivAt {e a σ x : ℝ}
    (he : 0<e) (hx : 0<x) :
    HasDerivAt (realSquarePrimitive e a σ)
      (σ*realSquareWeight e a σ (σ-1) x-
        a*(σ-1)*realSquareWeight e a σ (σ-2) x) x := by
  have hs := Real.sqrt_pos.mpr he
  have hd := (((Real.hasDerivAt_rpow_const (p:=σ-1) (Or.inl hx.ne')).mul
    ((hasDerivAt_id x).sub_const a)).div_const (Real.sqrt e))
  have h := ((Real.hasDerivAt_arctan _).comp x hd).div_const (Real.sqrt e)
  have hpow : x^(σ-1)=x^(σ-2)*x := by
    rw [show σ-1=(σ-2)+1 by ring,Real.rpow_add hx,Real.rpow_one]
  convert h using 1
  dsimp only [realSquareWeight,realSquareDenominator]
  rw [show σ-1-1=σ-2 by ring,hpow]
  have hdn : e+(x^(σ-2)*x*(x-a))^2≠0 := by positivity
  have hqn : 1+(x^(σ-2)*x*(x-a)/Real.sqrt e)^2≠0 := by positivity
  field_simp
  ring_nf
  rw [Real.sq_sqrt he.le]
  ring


theorem realSquarePrimitive_continuous {e a σ : ℝ} (hσ : 1<σ) :
    Continuous (realSquarePrimitive e a σ) := by
  exact (Real.continuous_arctan.comp
    ((((Real.continuous_rpow_const (show 0≤σ-1 by linarith)).mul
      (continuous_id.sub continuous_const)).div_const (Real.sqrt e)))).div_const (Real.sqrt e)

theorem realSquarePrimitive_zero {e a σ : ℝ} (hσ : 1<σ) :
    realSquarePrimitive e a σ 0=0 := by
  simp only [realSquarePrimitive,Real.zero_rpow (show σ-1≠0 by linarith),
    zero_mul,zero_div,Real.arctan_zero]

theorem realSquarePrimitive_tendsto {e a σ : ℝ} (he : 0<e) (hσ : 1<σ) :
    Tendsto (realSquarePrimitive e a σ) atTop (𝓝 (Real.pi/(2*Real.sqrt e))) := by
  have hx : Tendsto (fun x:ℝ=>x-a) atTop atTop := by
    simpa only [sub_eq_add_neg] using tendsto_atTop_add_const_right atTop (-a) tendsto_id
  have hu := (tendsto_rpow_atTop (show 0<σ-1 by linarith)).atTop_mul_atTop₀ hx
  have ht := (Real.tendsto_arctan_atTop.mono_right nhdsWithin_le_nhds).comp
    (Tendsto.atTop_div_const (Real.sqrt_pos.mpr he) hu)
  simpa only [div_div,realSquarePrimitive] using ht.div_const (Real.sqrt e)

/-- Exact evaluation of the arctangent derivative, including its integrability. -/
theorem realSquare_integral_identity {e a σ : ℝ} (he : 0<e) (hσ : 1<σ) :
    (∫x in Ioi (0:ℝ),realSquareWeight e a σ (σ-1) x)=
      Real.pi/(2*σ*Real.sqrt e)+a*(σ-1)/σ*
        (∫x in Ioi (0:ℝ),realSquareWeight e a σ (σ-2) x) := by
  have hi₀ := realSquareWeight_integrable (a:=a) he
    (by linarith : -1<σ-1) (by linarith : σ-1-2*σ< -1)
  have hi₁ := realSquareWeight_integrable (a:=a) he
    (by linarith : -1<σ-2) (by linarith : σ-2-2*σ< -1)
  have hi := (hi₀.const_mul σ).sub (hi₁.const_mul (a*(σ-1)))
  have h := integral_Ioi_of_hasDerivAt_of_tendsto
    (realSquarePrimitive_continuous hσ).continuousAt.continuousWithinAt
    (fun x hx=>realSquarePrimitive_hasDerivAt he hx) hi
    (realSquarePrimitive_tendsto he hσ)
  rw [realSquarePrimitive_zero hσ,sub_zero,integral_sub (hi₀.const_mul σ)
    (hi₁.const_mul (a*(σ-1))),integral_const_mul,integral_const_mul] at h
  have hσn : σ≠0 := by linarith
  have hes : Real.sqrt e≠0 := (Real.sqrt_pos.mpr he).ne'
  field_simp at h ⊢
  nlinarith [h]

theorem realSquare_correction_pos {e a σ : ℝ} (he : 0<e) (hσ : 1<σ) :
    0<∫x in Ioi (0:ℝ),realSquareWeight e a σ (σ-2) x := by
  have hp (x:ℝ) (hx:0<x) : 0<realSquareWeight e a σ (σ-2) x :=
    div_pos (Real.rpow_pos_of_pos hx _) (realSquareDenominator_pos he)
  have hi := realSquareWeight_integrable (a:=a) he
    (by linarith : -1<σ-2) (by linarith : σ-2-2*σ< -1)
  have hn : 0≤ᵐ[volume.restrict (Ioi (0:ℝ))] realSquareWeight e a σ (σ-2) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with x hx
    exact (hp x hx).le
  apply (setIntegral_pos_iff_support_of_nonneg_ae hn hi).mpr
  have hs : Function.support (realSquareWeight e a σ (σ-2)) ∩ Ioi (0:ℝ)=Ioi 0 := by
    ext x
    exact ⟨fun h=>h.2,fun hx=>⟨(hp x hx).ne',hx⟩⟩
  rw [hs]
  simp

/-- The real square comparison is strict because its correction has positive mass. -/
theorem realSquare_integral_strict {e a σ : ℝ}
    (he : 0<e) (ha : 0<a) (hσ : 1<σ) :
    Real.pi/(2*σ*Real.sqrt e)<
      ∫x in Ioi (0:ℝ),realSquareWeight e a σ (σ-1) x := by
  rw [realSquare_integral_identity he hσ]
  have hp : 0<a*(σ-1)/σ :=
    div_pos (mul_pos ha (by linarith)) (by linarith)
  exact lt_add_of_pos_right _ (mul_pos hp (realSquare_correction_pos he hσ))

end LeanVerification.WedgeIntegralCompletion
