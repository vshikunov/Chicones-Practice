import LeanVerification.WedgeIntegralCompletion.ComplexRectangleCauchy

/-! An actual two-pole residue formula, obtained by removing the two simple
zeros with divided differences and applying the rectangular Cauchy formula. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
open RectangularCauchy
set_option maxHeartbeats 800000

theorem rectangle_two_simple_poles {f q : ℂ → ℂ} {a b c d : ℝ} {wp wm : ℂ}
    (hne : wp ≠ wm)
    (hp : wp ∈ Ioo a b ×ℂ Ioo c d) (hm : wm ∈ Ioo a b ×ℂ Ioo c d)
    (hf : AnalyticOnNhd ℂ f (Icc a b ×ℂ Icc c d))
    (hq : AnalyticOnNhd ℂ q (Icc a b ×ℂ Icc c d))
    (hqp : q wp = 0) (hqm : q wm = 0)
    (hdp : deriv q wp ≠ 0) (hdm : deriv q wm ≠ 0)
    (hz : ∀ z ∈ Icc a b ×ℂ Icc c d, q z = 0 → z = wp ∨ z = wm) :
    boundary (fun z => f z/q z) a b c d =
      2*(Real.pi:ℂ)*Complex.I*(f wp/deriv q wp+f wm/deriv q wm) := by
  have hab : a ≤ b := (lt_trans hp.1.1 hp.1.2).le
  have hcd : c ≤ d := (lt_trans hp.2.1 hp.2.2).le
  have hrect : uIcc a b ×ℂ uIcc c d = Icc a b ×ℂ Icc c d := by
    rw [uIcc_of_le hab,uIcc_of_le hcd]
  have hp' : wp ∈ uIcc a b ×ℂ uIcc c d :=
    ⟨Icc_subset_uIcc (Ioo_subset_Icc_self hp.1),
      Icc_subset_uIcc (Ioo_subset_Icc_self hp.2)⟩
  have hm' : wm ∈ uIcc a b ×ℂ uIcc c d :=
    ⟨Icc_subset_uIcc (Ioo_subset_Icc_self hm.1),
      Icc_subset_uIcc (Ioo_subset_Icc_self hm.2)⟩
  have hfd : DifferentiableOn ℂ f (uIcc a b ×ℂ uIcc c d) := by
    rw [hrect]; exact hf.differentiableOn
  have hqd : DifferentiableOn ℂ q (uIcc a b ×ℂ uIcc c d) := by
    rw [hrect]; exact hq.differentiableOn
  let g := dslope q wp
  let Q := dslope g wm
  have hg : DifferentiableOn ℂ g (uIcc a b ×ℂ uIcc c d) :=
    (Complex.differentiableOn_dslope (rectangle_mem_nhds hp)).mpr hqd
  have hQ : DifferentiableOn ℂ Q (uIcc a b ×ℂ uIcc c d) :=
    (Complex.differentiableOn_dslope (rectangle_mem_nhds hm)).mpr hg
  have hgm : g wm = 0 := by
    dsimp [g]
    rw [dslope_of_ne q hne.symm,slope_def_field,hqm,hqp]
    simp
  have hfac1 (z : ℂ) : q z = (z-wp)*g z := by
    simpa only [g,smul_eq_mul,hqp,sub_zero] using (sub_smul_dslope q wp z).symm
  have hfac2 (z : ℂ) : g z = (z-wm)*Q z := by
    simpa only [Q,smul_eq_mul,hgm,sub_zero] using (sub_smul_dslope g wm z).symm
  have hfac (z : ℂ) : q z = (z-wp)*(z-wm)*Q z := by
    rw [hfac1,hfac2]; ring
  have hQp : (wp-wm)*Q wp = deriv q wp := by
    simpa only [g,dslope_same] using (hfac2 wp).symm
  have hQm : (wm-wp)*Q wm = deriv q wm := by
    have hga := (hg wm hm').differentiableAt (rectangle_mem_nhds hm)
    have hmul := ((hasDerivAt_id wm).sub_const wp).mul hga.hasDerivAt
    have hmul' : HasDerivAt q ((wm-wp)*Q wm) wm := by
      convert hmul using 1
      · funext z; exact hfac1 z
      · simp only [one_mul,hgm,zero_add,Q,dslope_same,id_eq]
    exact hmul'.deriv.symm
  have hQne (z : ℂ) (hzr : z ∈ uIcc a b ×ℂ uIcc c d) : Q z ≠ 0 := by
    intro he
    by_cases hzp : z = wp
    · subst z
      exact hdp (by rw [←hQp,he,mul_zero])
    by_cases hzm : z = wm
    · subst z
      exact hdm (by rw [←hQm,he,mul_zero])
    have hqz : q z = 0 := by rw [hfac,he,mul_zero]
    rcases hz z (by rwa [←hrect]) hqz with h|h
    · exact hzp h
    · exact hzm h
  let F := fun z => f z/Q z
  have hF : DifferentiableOn ℂ F (uIcc a b ×ℂ uIcc c d) := hfd.div hQ hQne
  let s : ℂ := (wp-wm)⁻¹
  have hsn : wp-wm ≠ 0 := sub_ne_zero.mpr hne
  have he (z : ℂ) (hzp : z ≠ wp) (hzm : z ≠ wm) :
      f z/q z = s*(F z/(z-wp))+(-s)*(F z/(z-wm)) := by
    dsimp [s,F]
    rw [hfac]
    by_cases hzero : Q z = 0
    · simp [hzero]
    · field_simp [sub_ne_zero.mpr hzp,sub_ne_zero.mpr hzm,hsn,hzero]
      <;> ring
  obtain ⟨hpc,hpd,hpb,hpa⟩ := rectangle_edge_ne_pole hp
  obtain ⟨hmc,hmd,hmb,hma⟩ := rectangle_edge_ne_pole hm
  rw [boundary_congr
    (g:=fun z => s*(F z/(z-wp))+(-s)*(F z/(z-wm)))
    (fun x _ => he _ (hpc x) (hmc x))
    (fun x _ => he _ (hpd x) (hmd x))
    (fun y _ => he _ (hpb y) (hmb y))
    (fun y _ => he _ (hpa y) (hma y)),
    boundary_add
      ((rectangle_edgeIntegrable_div_complex hp hF.continuousOn).const_mul s)
      ((rectangle_edgeIntegrable_div_complex hm hF.continuousOn).const_mul (-s)),
    boundary_const_mul,boundary_const_mul,
    rectangle_boundary_cauchy_complex hp hF,
    rectangle_boundary_cauchy_complex hm hF]
  have hpQ := hQne wp hp'
  have hmQ := hQne wm hm'
  dsimp [s,F]
  rw [←hQp,←hQm]
  field_simp [hpQ,hmQ,hsn,sub_ne_zero.mpr hne.symm]
  <;> ring

end LeanVerification.WedgeIntegralCompletion
