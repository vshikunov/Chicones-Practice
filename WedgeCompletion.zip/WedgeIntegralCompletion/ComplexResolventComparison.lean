import LeanVerification.WedgeIntegralCompletion.QuadraticPath
import LeanVerification.WedgeIntegralCompletion.ImproperDerivativeComparison
import LeanVerification.WedgeIntegralCompletion.RealResolventComparison

/-! The complete complex half of the actual improper quadratic-resolvent
comparison. The correction's integrability follows from its positive derivative
and the proved endpoint values of the logarithmic primitive. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
open WedgeCompletion
set_option maxHeartbeats 2400000

def AllowedQuadraticAngle (σ:ℝ) (ζ:ℂ) : Prop :=
  (2≤σ ∧ 0≤ζ.re) ∨
    (3/2≤σ ∧ σ≤2 ∧ 0<ζ.re ∧ |ζ.im|≤Real.sqrt 3*ζ.re)

theorem allowedQuadraticAngle_data {σ:ℝ} {ζ:ℂ} (h:AllowedQuadraticAngle σ ζ) :
    1<σ ∧ 0≤ζ.re := by
  rcases h with ⟨hs,hz⟩ | ⟨hs,-,hz,-⟩
  · exact ⟨by linarith,hz⟩
  · exact ⟨by linarith,hz.le⟩

def complexResolventDenominator (e b σ:ℝ) (ζ:ℂ) (x:ℝ) : ℂ :=
  powerQuadraticDenominator (e:ℂ) ((b:ℂ)*ζ) (ζ^2) (2*σ-2) x

def complexResolventWeight (e b σ:ℝ) (ζ:ℂ) (x:ℝ) : ℂ :=
  (x^(σ-1):ℝ)/complexResolventDenominator e b σ ζ x

theorem complexResolventDenominator_eq_path {e b σ x:ℝ} {ζ:ℂ}
    (hb:2≤b) (hζ:0≤ζ.re) (hx:0<x) :
    complexResolventDenominator e b σ ζ x=(e:ℂ)+(quadraticPath b σ ζ x)^2 := by
  rw [quadraticPath_square hb hζ hx]
  rfl

theorem complexResolventDenominator_ne_zero {e b σ x:ℝ} {ζ:ℂ}
    (he:0<e) (hb:2≤b) (hζ:0≤ζ.re) (hx:0<x) :
    complexResolventDenominator e b σ ζ x≠0 := by
  have hz := quadraticPath_re_pos (σ:=σ) hb hζ hx
  obtain ⟨hm,hp⟩ := shifted_imaginary_slit (e:=e) hz
  have hs : (Real.sqrt e:ℂ)^2=(e:ℂ) := by exact_mod_cast Real.sq_sqrt he.le
  have hfactor : (quadraticPath b σ ζ x-(Real.sqrt e:ℂ)*Complex.I)*
      (quadraticPath b σ ζ x+(Real.sqrt e:ℂ)*Complex.I)=
        (e:ℂ)+(quadraticPath b σ ζ x)^2 := by
    calc
      _=(quadraticPath b σ ζ x)^2-(Real.sqrt e:ℂ)^2*Complex.I^2 := by ring
      _=_ := by rw [Complex.I_sq,hs];ring
  rw [complexResolventDenominator_eq_path hb hζ hx,←hfactor]
  exact mul_ne_zero (Complex.slitPlane_ne_zero hm) (Complex.slitPlane_ne_zero hp)

theorem complexResolventWeight_integrable {e b σ:ℝ} {ζ:ℂ}
    (he:0<e) (hb:2≤b) (hσ:1<σ) (hζ:0≤ζ.re) :
    IntegrableOn (complexResolventWeight e b σ ζ) (Ioi 0) := by
  exact powerQuadraticWeight_integrable (Complex.ofReal_ne_zero.mpr he.ne')
    (by linarith) (by linarith) (by linarith)
    (fun x hx=>complexResolventDenominator_ne_zero he hb hζ hx)

theorem complexResolventWeight_continuous {e b σ:ℝ} {ζ:ℂ}
    (he:0<e) (hb:2≤b) (hσ:1<σ) (hζ:0≤ζ.re) :
    ContinuousOn (complexResolventWeight e b σ ζ) (Ioi 0) := by
  intro x hx
  exact ((Complex.continuous_ofReal.continuousAt.comp
    (Real.continuousAt_rpow_const x (σ-1) (Or.inl (ne_of_gt hx)))).div
      (powerQuadraticDenominator_continuous (by linarith : 0<2*σ-2)).continuousAt
      (complexResolventDenominator_ne_zero he hb hζ hx)).continuousWithinAt

theorem actual_defect_shifted_positive {e b σ x:ℝ} {ζ:ℂ}
    (he:0<e) (hb:2≤b) (ha:AllowedQuadraticAngle σ ζ) (hζ0:ζ≠0) (hx:0<x) :
    ((e/x^(2*σ):ℝ):ℂ)+(actualQuadraticRoot b (ζ/(x:ℂ)))^2≠0 ∧
      0<(actualQuadraticDefect b σ (ζ/(x:ℂ))/
        (((e/x^(2*σ):ℝ):ℂ)+(actualQuadraticRoot b (ζ/(x:ℂ)))^2)).re := by
  have hk : 0≤e/x^(2*σ) := div_nonneg he.le (Real.rpow_nonneg hx.le _)
  have hz0 : ζ/(x:ℂ)≠0 := div_ne_zero hζ0 (Complex.ofReal_ne_zero.mpr hx.ne')
  rcases ha with ⟨hσ,hζ⟩ | ⟨hσ,hσ',hζ,hy⟩
  · exact (actual_quadratic_resolvent_half_plane hb hσ (ray_div_re_nonneg hζ hx) hz0).2.2 _ hk
  · have hzr : 0<(ζ/(x:ℂ)).re := by
      simpa only [Complex.div_ofReal_re] using div_pos hζ hx
    have hzi : |(ζ/(x:ℂ)).im|≤Real.sqrt 3*(ζ/(x:ℂ)).re := by
      rw [Complex.div_ofReal_im,Complex.div_ofReal_re,abs_div,abs_of_pos hx]
      exact (div_le_div_of_nonneg_right hy hx.le).trans_eq (by ring)
    exact (actual_quadratic_resolvent_sector hb hσ hσ' hzr hzi).2.2 _ hk

theorem quadraticPath_defect_identity {b σ x:ℝ} {ζ:ℂ} (hσ:σ≠0) :
    quadraticPathDerivative b σ ζ x/(σ:ℂ)-(x^(σ-1):ℝ)=
      (x^(σ-1):ℝ)*actualQuadraticDefect b σ (ζ/(x:ℂ)) := by
  unfold quadraticPathDerivative actualQuadraticDefect quadraticDefect actualQuadraticRoot
  simp only [div_eq_mul_inv]
  linear_combination ((x^(σ-1):ℝ):ℂ)*
    quadraticRoot (quadraticLowerEndpoint b) (quadraticUpperEndpoint b) (ζ*(x:ℂ)⁻¹)*
      (mul_inv_cancel₀ (Complex.ofReal_ne_zero.mpr hσ))

/-- The strict pointwise comparison uses the already checked sector resolvent
on its actual scaled ray. -/
theorem complexResolvent_derivative_strict {e b σ x:ℝ} {ζ:ℂ}
    (he:0<e) (hb:2≤b) (ha:AllowedQuadraticAngle σ ζ) (hζ0:ζ≠0) (hx:0<x) :
    (complexResolventWeight e b σ ζ x).re<
      (quadraticPathDerivative b σ ζ x/complexResolventDenominator e b σ ζ x).re/σ := by
  obtain ⟨hσ,hζ⟩ := allowedQuadraticAngle_data ha
  obtain ⟨hk0,hkp⟩ := actual_defect_shifted_positive he hb ha hζ0 hx
  have hZ0 := complexResolventDenominator_ne_zero (σ:=σ) he hb hζ hx
  have hs0 : σ≠0 := by linarith
  have hp0 : ((x^(2*σ):ℝ):ℂ)≠0 := Complex.ofReal_ne_zero.mpr
    (Real.rpow_pos_of_pos hx _).ne'
  have hsq : ((x^σ:ℝ):ℂ)^2=(x^(2*σ):ℝ) := by
    rw [←Complex.ofReal_pow]
    congr 1
    rw [←Real.rpow_mul_natCast hx.le]
    congr 1
    ring
  have hZ : complexResolventDenominator e b σ ζ x=
      (x^(2*σ):ℝ)*(((e/x^(2*σ):ℝ):ℂ)+(actualQuadraticRoot b (ζ/(x:ℂ)))^2) := by
    rw [complexResolventDenominator_eq_path hb hζ hx,quadraticPath,mul_pow,hsq]
    push_cast
    field_simp [hp0]
    <;> ring
  have hd := quadraticPath_defect_identity (b:=b) (x:=x) (ζ:=ζ) hs0
  have heq : quadraticPathDerivative b σ ζ x/complexResolventDenominator e b σ ζ x/(σ:ℂ)-
      complexResolventWeight e b σ ζ x=
      ((x^(σ-1)/x^(2*σ):ℝ):ℂ)*(actualQuadraticDefect b σ (ζ/(x:ℂ))/
        (((e/x^(2*σ):ℝ):ℂ)+(actualQuadraticRoot b (ζ/(x:ℂ)))^2)) := by
    unfold complexResolventWeight
    calc
      _=(quadraticPathDerivative b σ ζ x/(σ:ℂ)-(x^(σ-1):ℝ))/
          complexResolventDenominator e b σ ζ x := by ring
      _=((x^(σ-1):ℝ)*actualQuadraticDefect b σ (ζ/(x:ℂ)))/
          complexResolventDenominator e b σ ζ x := by rw [hd]
      _=_ := by
        rw [hZ]
        push_cast
        simp only [div_eq_mul_inv,mul_inv_rev]
        ring
  have hr := congrArg Complex.re heq
  simp only [Complex.sub_re,Complex.div_ofReal_re,Complex.mul_re,Complex.ofReal_re,
    Complex.ofReal_im,zero_mul,sub_zero] at hr
  have hp : 0<x^(σ-1)/x^(2*σ) := div_pos (Real.rpow_pos_of_pos hx _)
    (Real.rpow_pos_of_pos hx _)
  linarith [mul_pos hp hkp]


def scaledQuadraticPrimitive (e b σ:ℝ) (ζ:ℂ) (x:ℝ) : ℝ :=
  (halfPlanePrimitive e (quadraticPath b σ ζ x)).re/σ

def scaledQuadraticDerivative (e b σ:ℝ) (ζ:ℂ) (x:ℝ) : ℝ :=
  (quadraticPathDerivative b σ ζ x/complexResolventDenominator e b σ ζ x).re/σ

theorem scaledQuadraticPrimitive_hasDerivAt {e b σ x:ℝ} {ζ:ℂ}
    (he:0<e) (hb:2≤b) (hζ:0≤ζ.re) (hx:0<x) :
    HasDerivAt (scaledQuadraticPrimitive e b σ ζ)
      (scaledQuadraticDerivative e b σ ζ x) x := by
  have hd := (halfPlanePrimitive_hasDerivAt he (quadraticPath_re_pos (σ:=σ) hb hζ hx)).scomp x
    (quadraticPath_hasDerivAt hb hζ hx)
  have hr := (Complex.reCLM.hasFDerivAt.comp_hasDerivAt x hd).div_const σ
  convert hr using 1
  simp only [scaledQuadraticDerivative,complexResolventDenominator_eq_path hb hζ hx,
    smul_eq_mul,div_eq_mul_inv,Complex.reCLM_apply]

theorem scaledQuadraticPrimitive_zero {e b σ:ℝ} {ζ:ℂ} (he:0<e) (hσ:1<σ) :
    scaledQuadraticPrimitive e b σ ζ 0=0 := by
  simp only [scaledQuadraticPrimitive,quadraticPath_zero hσ,halfPlanePrimitive_zero he,
    Complex.zero_re,zero_div]

theorem scaledQuadraticPrimitive_continuous_zero {e b σ:ℝ} {ζ:ℂ}
    (he:0<e) (hb:2≤b) (hσ:1<σ) (hζ:0≤ζ.re) :
    ContinuousWithinAt (scaledQuadraticPrimitive e b σ ζ) (Ici 0) 0 := by
  have hc : ContinuousAt (halfPlanePrimitive e) (quadraticPath b σ ζ 0) := by
    rw [quadraticPath_zero hσ]
    exact halfPlanePrimitive_continuousAt_zero he
  exact ((Complex.continuous_re.continuousAt.comp_continuousWithinAt
    (hc.comp_continuousWithinAt (quadraticPath_continuousWithinAt_zero hb hσ hζ))).div_const σ)

theorem scaledQuadraticPrimitive_tendsto {e b σ:ℝ} {ζ:ℂ}
    (he:0<e) (hb:2≤b) (hσ:1<σ) (hζ:0≤ζ.re) :
    Tendsto (scaledQuadraticPrimitive e b σ ζ) atTop (𝓝 (Real.pi/(2*σ*Real.sqrt e))) := by
  have hr : ∀ᶠx:ℝ in atTop,0<(quadraticPath b σ ζ x).re := by
    filter_upwards [Ioi_mem_atTop (0:ℝ)] with x hx
    exact quadraticPath_re_pos hb hζ hx
  have ht := halfPlanePrimitive_tendsto_infinity he hr (quadraticPath_inverse_tendsto hb hσ)
  have hre := Complex.continuous_re.continuousAt.tendsto.comp ht
  simp only [Function.comp_def,Complex.ofReal_re] at hre
  convert hre.div_const σ using 1
  ring

/-- Both the strict comparison and absolute convergence of its positive
correction are obtained from the actual path and primitive. -/
theorem complex_quadratic_resolvent_integral_data {e b σ:ℝ} {ζ:ℂ}
    (he:0<e) (hb:2≤b) (ha:AllowedQuadraticAngle σ ζ) (hζ0:ζ≠0) :
    IntegrableOn (fun x=>scaledQuadraticDerivative e b σ ζ x-
      (complexResolventWeight e b σ ζ x).re) (Ioi 0) ∧
      (∫x in Ioi (0:ℝ),scaledQuadraticDerivative e b σ ζ x-
        (complexResolventWeight e b σ ζ x).re)=
        Real.pi/(2*σ*Real.sqrt e)-(∫x in Ioi (0:ℝ),complexResolventWeight e b σ ζ x).re ∧
      (∫x in Ioi (0:ℝ),complexResolventWeight e b σ ζ x).re<Real.pi/(2*σ*Real.sqrt e) := by
  obtain ⟨hσ,hζ⟩ := allowedQuadraticAngle_data ha
  have hi := complexResolventWeight_integrable (ζ:=ζ) he hb hσ hζ
  have hc : ContinuousOn (fun x=>(complexResolventWeight e b σ ζ x).re) (Ioi 0) := by
    intro x hx
    exact Complex.continuous_re.continuousAt.comp_continuousWithinAt
      (complexResolventWeight_continuous (ζ:=ζ) he hb hσ hζ x hx)
  have h := improper_strict_comparison_of_derivative hi.re hc
    (scaledQuadraticPrimitive_continuous_zero he hb hσ hζ)
    (fun x hx=>scaledQuadraticPrimitive_hasDerivAt he hb hζ hx)
    (scaledQuadraticPrimitive_tendsto he hb hσ hζ)
    (fun x hx=>complexResolvent_derivative_strict he hb ha hζ0 hx)
  have hRe := integral_re hi
  change (∫x in Ioi (0:ℝ),(complexResolventWeight e b σ ζ x).re)=
    (∫x in Ioi (0:ℝ),complexResolventWeight e b σ ζ x).re at hRe
  simp only [show (RCLike.re:ℂ→ℝ)=Complex.re from rfl] at h
  simpa only [scaledQuadraticPrimitive_zero he hσ,sub_zero,hRe] using h

/-- The complete two-sided improper comparison, with its real positivity
hypothesis exactly on the genuine unrotated denominator. -/
theorem full_quadratic_resolvent_integral_comparison {e b σ:ℝ} {ζ:ℂ}
    (he:0<e) (hb:2≤b) (ha:AllowedQuadraticAngle σ ζ) (hζ0:ζ≠0)
    (hden:∀x:ℝ,0<x→0<realResolventDenominator e b σ x) :
    (∫x in Ioi (0:ℝ),realResolventWeight e b σ x)>Real.pi/(2*σ*Real.sqrt e) ∧
      Real.pi/(2*σ*Real.sqrt e)>(∫x in Ioi (0:ℝ),complexResolventWeight e b σ ζ x).re := by
  exact ⟨real_quadratic_resolvent_integral_strict he hb (allowedQuadraticAngle_data ha).1 hden,
    (complex_quadratic_resolvent_integral_data he hb ha hζ0).2.2⟩

end LeanVerification.WedgeIntegralCompletion
