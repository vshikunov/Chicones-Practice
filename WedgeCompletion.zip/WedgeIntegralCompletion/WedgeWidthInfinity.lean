import LeanVerification.MiddleStripSpectral.WidthDecay
import LeanVerification.WedgeFullCompletion.PhysicalDomains

/-! Uniform large-energy estimates for the actual negative-leading wedge. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
open MiddleStripCompletion MiddleStripSpectral ContourCompletion WedgeFullCompletion
set_option maxHeartbeats 1400000

theorem wedge_coefficientBound_pos {D F:ℝ} (hD:D< -1) (hF:3/2<F) :
    0<coefficientBound D F := by
  have hA := (wedge_coefficients_pos hD hF).1
  have hn : leading D F<0 := by simpa only [wedgeLeading,neg_pos] using hA
  unfold coefficientBound
  rw [abs_of_neg hn]
  linarith [abs_nonneg (height D F),abs_nonneg (middle D F),abs_nonneg (trailing D F)]

theorem wedge_inverse_exponential_energy_bound {D F:ℝ} (hD:D< -1) (hF:3/2<F)
    {z:ℂ} (hz:0≤z.re) (hn:logPotential D F z≠0):
    Real.exp (-z.re)≤(coefficientBound D F)^(1/(2*F))*
      ‖logPotential D F z‖^(-(1/(2*F))) := by
  have hC := wedge_coefficientBound_pos hD hF
  have hp:0<2*F := by linarith
  have hq:0<1/(2*F) := one_div_pos.mpr hp
  have hnorm:0<‖logPotential D F z‖ := norm_pos_iff.mpr hn
  have hb := Real.rpow_le_rpow_of_nonpos hnorm
    (norm_logPotential_le_exponential hF hz) (neg_nonpos.mpr hq.le)
  rw [Real.mul_rpow hC.le (Real.exp_pos _).le,Real.rpow_def_of_pos (Real.exp_pos _),Real.log_exp] at hb
  have he:((2*F)*z.re)*(-(1/(2*F)))= -z.re := by field_simp;ring
  rw [he] at hb
  have hc:coefficientBound D F^(1/(2*F))*coefficientBound D F^(-(1/(2*F)))=1 := by
    rw [←Real.rpow_add hC,add_neg_cancel,Real.rpow_zero]
  have hh := mul_le_mul_of_nonneg_left hb
    (Real.rpow_pos_of_pos hC (1/(2*F))).le
  simpa only [←mul_assoc,hc,one_mul] using hh

theorem exists_wedge_inverse_factor_uniform_small {D F:ℝ} (hD:D< -1) (hF:3/2<F) :
    ∃R>0,∀w:ℂ,R<‖logPotential D F w‖→
      0≤w.re ∧ wedgeLogRadius D F<w.re ∧ ‖normalizedInverseFactor D F w-1‖≤1/2 := by
  have hA := (wedge_coefficients_pos hD hF).1
  have hn : leading D F<0 := by simpa only [wedgeLeading,neg_pos] using hA
  obtain ⟨b,hb⟩ := eventually_atTop.mp ((infinityEndBound_tendsto_zero D F hF).eventually
    (Iio_mem_nhds (half_pos hA)))
  let b₀ := max (max 0 (wedgeLogRadius D F)) b
  let R := max 1 (|height D F|+zeroEndBound D F b₀)
  refine ⟨R,lt_of_lt_of_le zero_lt_one (le_max_left _ _),fun w hw=>?_⟩
  have hwr:b₀<w.re := inverse_real_large_of_energy_large hF
    ((le_max_right _ _).trans_lt hw)
  have hsmall:‖infinityResidual D F w‖≤wedgeLeading D F/2 :=
    (norm_infinityResidual_le D F w).trans (hb w.re
      ((le_max_right _ _).trans hwr.le)).le
  refine ⟨((le_max_left _ _).trans (le_max_left _ _)).trans hwr.le,
    ((le_max_right _ _).trans (le_max_left _ _)).trans_lt hwr,?_⟩
  rw [normalizedInverseFactor,add_sub_cancel_left,norm_div,Complex.norm_real,
    Real.norm_eq_abs,abs_of_neg hn]
  change ‖infinityResidual D F w‖/wedgeLeading D F≤1/2
  exact (div_le_iff₀ hA).mpr (by linarith)

def wedgeApproximateHalfRatio (D F:ℝ) (g:ℂ→ℂ) (z:ℂ) : ℂ :=
  Complex.I*((Real.sqrt (wedgeLeading D F):ℂ)*principalSquareRoot
    (normalizedInverseFactor D F (g z)))⁻¹

theorem wedgeBaseHalfRatio_right_quadrant {D F:ℝ} (hD:D< -1) (hF:3/2<F)
    {g:ℂ→ℂ} {z:ℂ} (hb:‖normalizedInverseFactor D F (g z)-1‖≤1/2) :
    |(((Real.sqrt (wedgeLeading D F):ℂ)*principalSquareRoot
      (normalizedInverseFactor D F (g z)))⁻¹).im|<
    (((Real.sqrt (wedgeLeading D F):ℂ)*principalSquareRoot
      (normalizedInverseFactor D F (g z)))⁻¹).re := by
  have hs := principalSquareRoot_right_quadrant (normalizedInverseFactor_re_pos hb)
  have hA := Real.sqrt_pos.mpr (wedge_coefficients_pos hD hF).1
  apply inv_right_quadrant
  simp only [Complex.mul_im,Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,
    zero_mul,add_zero,sub_zero,abs_mul,abs_of_pos hA]
  exact mul_lt_mul_of_pos_left hs hA

theorem wedge_sqrt_imaginary_quadrant {D F R:ℝ} (hD:D< -1) (hF:3/2<F) (hR:0<R)
    {g:ℂ→ℂ} {z:ℂ} (hb:‖normalizedInverseFactor D F (g z)-1‖≤1/2) :
    (principalSquareRoot ((R:ℂ)*Complex.I)*wedgeApproximateHalfRatio D F g z).re<0 ∧
      0<(principalSquareRoot ((R:ℂ)*Complex.I)*wedgeApproximateHalfRatio D F g z).im := by
  have h := sqrt_imaginary_mul_first_quadrant hR (wedgeBaseHalfRatio_right_quadrant hD hF hb)
  have he : principalSquareRoot ((R:ℂ)*Complex.I)*wedgeApproximateHalfRatio D F g z=
      Complex.I*(principalSquareRoot ((R:ℂ)*Complex.I)*
        ((Real.sqrt (wedgeLeading D F):ℂ)*principalSquareRoot
          (normalizedInverseFactor D F (g z)))⁻¹) := by
    unfold wedgeApproximateHalfRatio
    ring
  rw [he]
  simpa only [Complex.I_mul_re,Complex.I_mul_im,neg_lt_zero] using And.intro h.2 h.1

end LeanVerification.WedgeIntegralCompletion
