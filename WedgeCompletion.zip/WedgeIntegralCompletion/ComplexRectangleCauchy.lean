import LeanVerification.RectangularCauchy

/-! Rectangular Cauchy formulas at arbitrary complex interior points. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
open RectangularCauchy

theorem rectangle_boundary_translate_im (f : ℂ → ℂ) (a b c d s : ℝ) :
    boundary (fun z => f (z + (s : ℂ) * Complex.I)) a b (c-s) (d-s) =
      boundary f a b c d := by
  have hh (x y : ℝ) :
      (x : ℂ) + ((y-s : ℝ) : ℂ) * Complex.I + (s : ℂ) * Complex.I =
        (x : ℂ) + (y : ℂ) * Complex.I := by push_cast; ring
  have hv (x y : ℝ) :
      (x : ℂ) + (y : ℂ) * Complex.I + (s : ℂ) * Complex.I =
        (x : ℂ) + ((y+s : ℝ) : ℂ) * Complex.I := by push_cast; ring
  have hi (x : ℝ) :
      (∫ y in c-s..d-s, f ((x:ℂ)+(y+s:ℝ)*Complex.I)) =
        ∫ y in c..d, f ((x:ℂ)+y*Complex.I) := by
    simpa only [sub_add_cancel] using
      (intervalIntegral.integral_comp_add_right
        (fun y : ℝ => f ((x:ℂ)+y*Complex.I)) s (a:=c-s) (b:=d-s))
  unfold boundary
  simp_rw [hh, hv]
  rw [hi,hi]

theorem rectangle_mem_nhds {a b c d : ℝ} {z : ℂ}
    (hz : z ∈ Ioo a b ×ℂ Ioo c d) :
    uIcc a b ×ℂ uIcc c d ∈ 𝓝 z := by
  have ho : IsOpen (Ioo a b ×ℂ Ioo c d) :=
    (isOpen_Ioo.preimage Complex.continuous_re).inter
      (isOpen_Ioo.preimage Complex.continuous_im)
  apply mem_of_superset (ho.mem_nhds hz)
  intro w hw
  exact ⟨Icc_subset_uIcc (Ioo_subset_Icc_self hw.1),
    Icc_subset_uIcc (Ioo_subset_Icc_self hw.2)⟩

theorem rectangle_boundary_cauchy_complex {f : ℂ → ℂ} {a b c d : ℝ} {p : ℂ}
    (hp : p ∈ Ioo a b ×ℂ Ioo c d)
    (hf : DifferentiableOn ℂ f (uIcc a b ×ℂ uIcc c d)) :
    boundary (fun w => f w / (w-p)) a b c d =
      2 * (Real.pi : ℂ) * Complex.I * f p := by
  have hab : a ≤ b := le_of_lt (lt_trans hp.1.1 hp.1.2)
  have hcd : c ≤ d := le_of_lt (lt_trans hp.2.1 hp.2.2)
  have hmap : MapsTo (fun z : ℂ => z + (p.im : ℂ) * Complex.I)
      (uIcc a b ×ℂ uIcc (c-p.im) (d-p.im)) (uIcc a b ×ℂ uIcc c d) := by
    intro z hz
    simp only [uIcc_of_le hab, uIcc_of_le hcd,
      uIcc_of_le (sub_le_sub_right hcd p.im), Complex.mem_reProdIm,
      Complex.add_re, Complex.add_im, Complex.mul_re, Complex.mul_im,
      Complex.ofReal_re, Complex.ofReal_im, Complex.I_re, Complex.I_im,
      mul_zero, mul_one, zero_mul, add_zero, sub_zero, zero_add,
      mem_Icc] at hz ⊢
    exact ⟨hz.1, by constructor <;> linarith [hz.2.1,hz.2.2]⟩
  have hdif : DifferentiableOn ℂ (fun z => f (z+(p.im : ℂ)*Complex.I))
      (uIcc a b ×ℂ uIcc (c-p.im) (d-p.im)) :=
    hf.comp (by fun_prop) hmap
  have hc := boundary_cauchy hp.1.1 hp.1.2
    (sub_neg.mpr hp.2.1) (sub_pos.mpr hp.2.2) hdif
  have he : (p.re : ℂ)+(p.im : ℂ)*Complex.I=p := Complex.re_add_im p
  have hden (w : ℂ) : w+(p.im : ℂ)*Complex.I-p=w-(p.re : ℂ) := by
    apply Complex.ext <;> simp <;> ring
  rw [he] at hc
  rw [←rectangle_boundary_translate_im (fun w => f w/(w-p)) a b c d p.im]
  simpa only [hden] using hc

theorem rectangle_edge_ne_pole {a b c d : ℝ} {p : ℂ}
    (hp : p ∈ Ioo a b ×ℂ Ioo c d) :
    (∀ x : ℝ, (x : ℂ)+c*Complex.I ≠ p) ∧
    (∀ x : ℝ, (x : ℂ)+d*Complex.I ≠ p) ∧
    (∀ y : ℝ, (b : ℂ)+y*Complex.I ≠ p) ∧
    (∀ y : ℝ, (a : ℂ)+y*Complex.I ≠ p) := by
  have hh (x y : ℝ) (hy : y ≠ p.im) : (x : ℂ)+y*Complex.I ≠ p := by
    intro he
    apply hy
    simpa using congrArg Complex.im he
  have hv (x y : ℝ) (hx : x ≠ p.re) : (x : ℂ)+y*Complex.I ≠ p := by
    intro he
    apply hx
    simpa using congrArg Complex.re he
  exact ⟨fun x => hh x c hp.2.1.ne, fun x => hh x d hp.2.2.ne',
    fun y => hv b y hp.1.2.ne', fun y => hv a y hp.1.1.ne⟩

theorem rectangle_edgeIntegrable_inv_complex {a b c d : ℝ} {p : ℂ}
    (hp : p ∈ Ioo a b ×ℂ Ioo c d) :
    EdgeIntegrable (fun w => (w-p)⁻¹) a b c d := by
  obtain ⟨hc,hd,hb,ha⟩ := rectangle_edge_ne_pole hp
  exact ⟨(Continuous.inv₀ (by fun_prop) (fun x => sub_ne_zero.mpr (hc x))).intervalIntegrable a b,
    (Continuous.inv₀ (by fun_prop) (fun x => sub_ne_zero.mpr (hd x))).intervalIntegrable a b,
    (Continuous.inv₀ (by fun_prop) (fun y => sub_ne_zero.mpr (hb y))).intervalIntegrable c d,
    (Continuous.inv₀ (by fun_prop) (fun y => sub_ne_zero.mpr (ha y))).intervalIntegrable c d⟩

theorem rectangle_edgeIntegrable_div_complex {f : ℂ → ℂ} {a b c d : ℝ} {p : ℂ}
    (hp : p ∈ Ioo a b ×ℂ Ioo c d)
    (hf : ContinuousOn f (uIcc a b ×ℂ uIcc c d)) :
    EdgeIntegrable (fun w => f w/(w-p)) a b c d := by
  obtain ⟨hc,hd,hb,ha⟩ := rectangle_edge_ne_pole hp
  have hh (y : ℝ) (hy : y ∈ uIcc c d) (hn : ∀x : ℝ,(x:ℂ)+y*Complex.I ≠ p) :
      ContinuousOn (fun x : ℝ => f ((x:ℂ)+y*Complex.I)/((x:ℂ)+y*Complex.I-p))
        (uIcc a b) := by
    apply ContinuousOn.div (hf.comp (by fun_prop) ?_) (by fun_prop)
      (fun x _ => sub_ne_zero.mpr (hn x))
    intro x hx
    simpa [Complex.mem_reProdIm] using And.intro hx hy
  have hv (x : ℝ) (hx : x ∈ uIcc a b) (hn : ∀y : ℝ,(x:ℂ)+y*Complex.I ≠ p) :
      ContinuousOn (fun y : ℝ => f ((x:ℂ)+y*Complex.I)/((x:ℂ)+y*Complex.I-p))
        (uIcc c d) := by
    apply ContinuousOn.div (hf.comp (by fun_prop) ?_) (by fun_prop)
      (fun y _ => sub_ne_zero.mpr (hn y))
    intro y hy
    simpa [Complex.mem_reProdIm] using And.intro hx hy
  exact ⟨(hh c left_mem_uIcc hc).intervalIntegrable,
    (hh d right_mem_uIcc hd).intervalIntegrable,
    (hv b right_mem_uIcc hb).intervalIntegrable,
    (hv a left_mem_uIcc ha).intervalIntegrable⟩

end LeanVerification.WedgeIntegralCompletion
