import LeanVerification.WedgeIntegralCompletion.LowerHalfPlaneQuadratic

/-! The complete real-axis Cauchy integral from the actual lower rectangle.
Absolute convergence and the vanishing of all three remaining banks are
proved from boundedness; no contour identity is assumed. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
open RectangularCauchy
set_option maxHeartbeats 1200000

theorem quadraticCauchy_rectangle_identity {f:ℂ→ℂ} {a b R:ℝ}
    (hb:0<b) (hR:b<R) (hf:DifferentiableOn ℂ f {z:ℂ|z.im≤0}) :
    boundary (quadraticCauchyKernel f a b) (a-R) (a+R) (-R) 0=
      -((Real.pi/b:ℝ):ℂ)*f (lowerCauchyPole a b) := by
  have hRp : 0<R := hb.trans hR
  have hrect : uIcc (a-R) (a+R) ×ℂ uIcc (-R) 0 ⊆ {z:ℂ|z.im≤0} := by
    intro z hz
    exact (uIcc_of_le (by linarith : -R≤0) ▸ hz.2).2
  have hq (z:ℂ) (hz:z∈uIcc (a-R) (a+R) ×ℂ uIcc (-R) 0) : z-upperCauchyPole a b≠0 := by
    intro he
    have he' := congrArg Complex.im (sub_eq_zero.mp he)
    have him := hrect hz
    change z.im≤0 at him
    simp only [upperCauchyPole,Complex.add_im,Complex.ofReal_im,Complex.mul_im,
      Complex.ofReal_re,Complex.I_re,Complex.I_im,mul_one,mul_zero,add_zero,zero_add] at he'
    linarith
  have hdf : DifferentiableOn ℂ (fun z => f z/(z-upperCauchyPole a b))
      (uIcc (a-R) (a+R) ×ℂ uIcc (-R) 0) :=
    (hf.mono hrect).div (by fun_prop) hq
  have hp : lowerCauchyPole a b∈Ioo (a-R) (a+R) ×ℂ Ioo (-R) 0 := by
    simp only [lowerCauchyPole,Complex.mem_reProdIm,Complex.sub_re,Complex.sub_im,
      Complex.ofReal_re,Complex.ofReal_im,Complex.mul_re,Complex.mul_im,
      Complex.I_re,Complex.I_im,mul_zero,mul_one,zero_mul,sub_zero,zero_sub,add_zero,mem_Ioo]
    constructor <;> constructor <;> linarith
  have he := rectangle_boundary_cauchy_complex hp hdf
  have hfun : (fun z => (f z/(z-upperCauchyPole a b))/(z-lowerCauchyPole a b))=
      quadraticCauchyKernel f a b := by
    funext z
    rw [quadraticCauchyKernel,quadraticCauchy_factor,div_div,mul_comm (z-upperCauchyPole a b)]
  rw [hfun] at he
  rw [he]
  have hden : lowerCauchyPole a b-upperCauchyPole a b= -2*(b:ℂ)*Complex.I := by
    unfold lowerCauchyPole upperCauchyPole
    ring
  rw [hden]
  push_cast
  field_simp [Complex.ofReal_ne_zero.mpr hb.ne',Complex.I_ne_zero]
  <;> ring

theorem quadraticCauchy_rectangle_error {f:ℂ→ℂ} {a b M R:ℝ}
    (hb:0<b) (hR:2*b<R) (hM:0≤M)
    (hf:DifferentiableOn ℂ f {z:ℂ|z.im≤0})
    (hbound:∀z:ℂ,z.im≤0→‖f z‖≤M) :
    ‖(∫ x in (a-R)..(a+R),quadraticCauchyKernel f a b (x:ℂ))-
      ((Real.pi/b:ℝ):ℂ)*f (lowerCauchyPole a b)‖≤16*M/R := by
  have hRp : 0<R := by linarith
  let g := quadraticCauchyKernel f a b
  have he := quadraticCauchy_rectangle_identity (a:=a) hb (by linarith : b<R) hf
  have hbnd : ∀x:ℝ,‖g ((x:ℂ)+(-R:ℝ)*Complex.I)‖≤4*M/R^2 := by
    intro x
    apply quadraticCauchyKernel_outer_norm_le hb hR.le hM hbound
    · simp only [Complex.add_im,Complex.ofReal_im,Complex.mul_im,Complex.ofReal_re,
        Complex.I_im,Complex.I_re,mul_one,mul_zero,add_zero,zero_add]
      linarith
    · exact Or.inl (by simp)
  have hvbnd (x:ℝ) (hx:x=a+R ∨ x=a-R) (y:ℝ) (hy:y∈uIoc (-R) 0) :
      ‖g ((x:ℂ)+y*Complex.I)‖≤4*M/R^2 := by
    apply quadraticCauchyKernel_outer_norm_le hb hR.le hM hbound
    · simpa using (uIoc_of_le (by linarith : -R≤0) ▸ hy).2
    · right
      simpa using hx
  have hbottom := intervalIntegral.norm_integral_le_of_norm_le_const
    (a:=a-R) (b:=a+R) (fun x _ => hbnd x)
  have hright := intervalIntegral.norm_integral_le_of_norm_le_const
    (a:= -R) (b:=0) (fun y hy => hvbnd (a+R) (Or.inl rfl) y hy)
  have hleft := intervalIntegral.norm_integral_le_of_norm_le_const
    (a:= -R) (b:=0) (fun y hy => hvbnd (a-R) (Or.inr rfl) y hy)
  rw [abs_of_nonneg (by linarith : 0≤a+R-(a-R))] at hbottom
  rw [abs_of_nonneg (by linarith : 0≤(0:ℝ)- -R)] at hright hleft
  have heq : (∫ x in (a-R)..(a+R),g (x:ℂ))-
      ((Real.pi/b:ℝ):ℂ)*f (lowerCauchyPole a b)=
      (∫ x in (a-R)..(a+R),g ((x:ℂ)+(-R:ℝ)*Complex.I))+
      Complex.I*(∫ y in (-R)..0,g ((a+R:ℝ)+y*Complex.I))-
      Complex.I*(∫ y in (-R)..0,g ((a-R:ℝ)+y*Complex.I)) := by
    unfold boundary at he
    simp only [Complex.ofReal_zero,zero_mul,add_zero] at he
    change (∫ x in (a-R)..(a+R),g ((x:ℂ)+(-R:ℝ)*Complex.I))-
      (∫ x in (a-R)..(a+R),g (x:ℂ))+
      Complex.I*(∫ y in (-R)..0,g ((a+R:ℝ)+y*Complex.I))-
      Complex.I*(∫ y in (-R)..0,g ((a-R:ℝ)+y*Complex.I))=
      -((Real.pi/b:ℝ):ℂ)*f (lowerCauchyPole a b) at he
    linear_combination -he
  change ‖(∫ x in (a-R)..(a+R),g (x:ℂ))-
      ((Real.pi/b:ℝ):ℂ)*f (lowerCauchyPole a b)‖≤_
  rw [heq]
  calc
    _≤‖∫ x in (a-R)..(a+R),g ((x:ℂ)+(-R:ℝ)*Complex.I)‖+
      ‖Complex.I*(∫ y in (-R)..0,g ((a+R:ℝ)+y*Complex.I))‖+
      ‖Complex.I*(∫ y in (-R)..0,g ((a-R:ℝ)+y*Complex.I))‖ :=
      (norm_sub_le _ _).trans (add_le_add_right (norm_add_le _ _) _)
    _≤(a+R-(a-R))*(4*M/R^2)+(0- -R)*(4*M/R^2)+(0- -R)*(4*M/R^2) := by
      simp only [norm_mul,Complex.norm_I,one_mul]
      simpa only [mul_comm] using add_le_add (add_le_add hbottom hright) hleft
    _=16*M/R := by field_simp; ring

theorem bounded_lowerHalfPlane_quadratic_cauchy {f:ℂ→ℂ} {a b M:ℝ}
    (hb:0<b) (hM:0≤M)
    (hf:DifferentiableOn ℂ f {z:ℂ|z.im≤0})
    (hbound:∀z:ℂ,z.im≤0→‖f z‖≤M) :
    Integrable (fun x:ℝ=>f (x:ℂ)/(((x-a)^2+b^2:ℝ):ℂ)) ∧
      (∫x:ℝ,f (x:ℂ)/(((x-a)^2+b^2:ℝ):ℂ))=
        ((Real.pi/b:ℝ):ℂ)*f ((a:ℂ)-(b:ℂ)*Complex.I) := by
  have hi := quadraticCauchyKernel_integrable (a:=a) hb hM hf hbound
  have hbot : Tendsto (fun R:ℝ=>a-R) atTop atBot := by
    simpa only [sub_eq_add_neg] using tendsto_atBot_add_const_left atTop a tendsto_neg_atTop_atBot
  have htop : Tendsto (fun R:ℝ=>a+R) atTop atTop := tendsto_atTop_add_const_left _ a tendsto_id
  have hlim := intervalIntegral_tendsto_integral hi hbot htop
  have herr : Tendsto (fun R:ℝ=>(∫x in (a-R)..(a+R),quadraticCauchyKernel f a b (x:ℂ))-
      ((Real.pi/b:ℝ):ℂ)*f (lowerCauchyPole a b)) atTop (𝓝 0) := by
    have hz : Tendsto (fun R:ℝ=>16*M/R) atTop (𝓝 0) := tendsto_const_nhds.div_atTop tendsto_id
    apply squeeze_zero_norm' ?_ hz
    filter_upwards [eventually_gt_atTop (2*b)] with R hR
    exact quadraticCauchy_rectangle_error hb hR hM hf hbound
  have he := tendsto_nhds_unique (hlim.sub_const (((Real.pi/b:ℝ):ℂ)*f (lowerCauchyPole a b))) herr
  have hi' := hi
  simp only [quadraticCauchyKernel_real] at hi' he
  exact ⟨hi',sub_eq_zero.mp he⟩

end LeanVerification.WedgeIntegralCompletion
