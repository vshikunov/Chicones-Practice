import LeanVerification.WedgeIntegralCompletion.ImproperPowerControl
import LeanVerification.WedgeCompletion.QuadraticResolvent

/-! Absolute convergence of the genuine complex quadratic-power resolvents. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeIntegralCompletion
set_option maxHeartbeats 1800000

def powerQuadraticDenominator (e B C:ℂ) (ρ x:ℝ) : ℂ :=
  e+(x^ρ:ℝ)*((x:ℂ)^2+B*(x:ℂ)+C)

def powerQuadraticWeight (e B C:ℂ) (ρ δ x:ℝ) : ℂ :=
  (x^δ:ℝ)/powerQuadraticDenominator e B C ρ x

theorem powerQuadraticDenominator_continuous {e B C:ℂ} {ρ:ℝ} (hρ:0<ρ) :
    Continuous (powerQuadraticDenominator e B C ρ) := by
  exact continuous_const.add ((Complex.continuous_ofReal.comp
    (Real.continuous_rpow_const hρ.le)).mul
      (((Complex.continuous_ofReal.pow 2).add
        (continuous_const.mul Complex.continuous_ofReal)).add continuous_const))

theorem powerQuadraticDenominator_zero {e B C:ℂ} {ρ:ℝ} (hρ:0<ρ) :
    powerQuadraticDenominator e B C ρ 0=e := by
  simp [powerQuadraticDenominator,Real.zero_rpow hρ.ne']

theorem powerQuadraticDenominator_normalized_limit {e B C:ℂ} {ρ:ℝ} (hρ:0<ρ) :
    Tendsto (fun x:ℝ=>powerQuadraticDenominator e B C ρ x/
      ((x^ρ:ℝ)*(x:ℂ)^2)) atTop (𝓝 (1:ℂ)) := by
  have hi : Tendsto (fun x:ℝ=>(x:ℂ)⁻¹) atTop (𝓝 (0:ℂ)) := by
    simpa only [Function.comp_def,Pi.inv_apply,Complex.ofReal_inv,Complex.ofReal_zero] using
      Complex.continuous_ofReal.continuousAt.tendsto.comp
      (tendsto_inv_atTop_zero : Tendsto (fun x:ℝ=>x⁻¹) atTop (𝓝 0))
  have hr : Tendsto (fun x:ℝ=>((x^ρ:ℝ):ℂ)⁻¹) atTop (𝓝 (0:ℂ)) := by
    simpa only [Function.comp_def,Pi.inv_apply,Complex.ofReal_inv,Complex.ofReal_zero] using
      Complex.continuous_ofReal.continuousAt.tendsto.comp
      (tendsto_rpow_atTop hρ).inv_tendsto_atTop
  have ht := (((hr.mul (hi.pow 2)).const_mul e).add
    (tendsto_const_nhds (x:=(1:ℂ)))).add (hi.const_mul B) |>.add ((hi.pow 2).const_mul C)
  simp only [zero_pow (by norm_num : (2:ℕ)≠0),mul_zero,add_zero,zero_add] at ht
  apply ht.congr'
  filter_upwards [Ioi_mem_atTop (0:ℝ)] with x hx
  have hx0 : (x:ℂ)≠0 := Complex.ofReal_ne_zero.mpr hx.ne'
  have hp0 : ((x^ρ:ℝ):ℂ)≠0 := Complex.ofReal_ne_zero.mpr (Real.rpow_pos_of_pos hx _).ne'
  unfold powerQuadraticDenominator
  field_simp [hx0,hp0]
  <;> ring

/-- All required endpoint control is obtained from the actual denominator:
its nonzero constant at zero and its quadratic leading term at infinity. -/
theorem powerQuadraticWeight_integrable {e B C:ℂ} {ρ δ:ℝ}
    (he:e≠0) (hρ:0<ρ) (hδ: -1<δ) (hδρ:δ-ρ-2< -1)
    (hne:∀x:ℝ,0<x→powerQuadraticDenominator e B C ρ x≠0) :
    IntegrableOn (powerQuadraticWeight e B C ρ δ) (Ioi 0) := by
  have hc := powerQuadraticDenominator_continuous (e:=e) (B:=B) (C:=C) hρ
  have hf : ContinuousOn (powerQuadraticWeight e B C ρ δ) (Ioi 0) := by
    intro x hx
    exact ((Complex.continuous_ofReal.continuousAt.comp
      (Real.continuousAt_rpow_const x δ (Or.inl (ne_of_gt hx)))).div
        hc.continuousAt (hne x hx)).continuousWithinAt
  apply integrableOn_positive_ray_of_power_bounds (C₀:=2/‖e‖) (Ctop:=2) hf hδ hδρ
  · have he0 := norm_pos_iff.mpr he
    have ht : Tendsto (fun x:ℝ=>‖powerQuadraticDenominator e B C ρ x‖)
        (𝓝[>] 0) (𝓝 ‖e‖) := by
      simpa only [powerQuadraticDenominator_zero hρ] using
        (hc.continuousAt (x:=0)).tendsto.norm.mono_left (nhdsWithin_le_nhds (s:=Ioi 0))
    filter_upwards [self_mem_nhdsWithin,
      ht.eventually (lt_mem_nhds (show ‖e‖/2<‖e‖ by linarith))] with x hx hd
    have hx0 : 0<x := hx
    rw [powerQuadraticWeight,norm_div,Complex.norm_real,
      Real.norm_of_nonneg (Real.rpow_nonneg hx0.le _)]
    apply (div_le_div_of_nonneg_left (Real.rpow_nonneg hx0.le _)
      (by linarith : 0<‖e‖/2) hd.le).trans_eq
    ring
  · have ht := (powerQuadraticDenominator_normalized_limit (e:=e) (B:=B) (C:=C) hρ).norm
    simp only [norm_one] at ht
    filter_upwards [Ioi_mem_atTop (0:ℝ),
      ht.eventually (lt_mem_nhds (show (1/2:ℝ)<1 by norm_num))] with x hx hd
    have hxpos : 0<x := hx
    have hp : 0<x^ρ := Real.rpow_pos_of_pos hxpos _
    rw [norm_div,norm_mul,norm_pow,Complex.norm_real,Complex.norm_real,
      Real.norm_of_nonneg hp.le,Real.norm_of_nonneg hx.le] at hd
    have hbase : 0<x^ρ*x^2/2 := by positivity
    have hbound : x^ρ*x^2/2≤‖powerQuadraticDenominator e B C ρ x‖ := by
      have h := (lt_div_iff₀ (show 0<x^ρ*x^2 by positivity)).mp hd
      linarith
    rw [powerQuadraticWeight,norm_div,Complex.norm_real,
      Real.norm_of_nonneg (Real.rpow_nonneg hx.le _)]
    apply (div_le_div_of_nonneg_left (Real.rpow_nonneg hx.le _) hbase hbound).trans_eq
    have hr : x^(δ-ρ-2)=x^δ/(x^ρ*x^2) := by
      rw [show δ-ρ-2=δ-(ρ+2) by ring,Real.rpow_sub hx,
        Real.rpow_add hx,Real.rpow_two]
    rw [hr]
    ring

end LeanVerification.WedgeIntegralCompletion
