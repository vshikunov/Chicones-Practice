import LeanVerification.ReflectedWedgeCompletion.RationalSigns
import LeanVerification.ReflectedWedgeCompletion.SourceCoefficientPolynomial04

/-! Exact source identity 4, with one fixed denominator and opaque
polynomial numerators throughout the rational cancellation. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 50000

namespace LowerWeakCone
variable {a f rho : ℝ} (h : LowerWeakCone a f rho)
include h

theorem sourceCoefficient4_identity : modelV4 a f rho=
    8*modelM a f rho*modelAlpha4 a f rho-jetDAlpha4 a f rho+6*modelM a f rho*modelAlpha3 a f rho-modelSigma f*jetDAlpha3 a f rho := by
  have ha := h.a_pos.ne'
  have hj : 1+f≠0 := by linarith [h.f_pos]
  have hg := h.base_signs.1.ne'
  have hfa := (sub_pos.mpr h.f_lower).ne'
  have hfu := (sub_pos.mpr h.f_upper).ne'
  have hru := (sub_pos.mpr h.rho_upper).ne'
  rw [sourceDAlpha4_fraction,sourceDAlpha3_fraction]
  unfold modelV4 modelE4 modelM modelSigma modelAlpha4 modelAlpha3 
  rw [sourceCoefficient4_numerator]
  unfold sourceDAlphaDenominator4 sourceDAlphaDenominator3 modelG at *
  generalize weakNum03 a f rho=A4
  generalize sourceDAlphaNumerator4 a f rho=N4
  generalize weakNum02 a f rho=A3
  generalize sourceDAlphaNumerator3 a f rho=N3
  generalize f-a=q at *
  generalize 1-f=t at *
  generalize 1+f=j at *
  generalize 1-rho=r at *
  generalize 1-a^2*rho=g at *
  field_simp [ha,hj,hg,hfa,hfu,hru]
  <;> ring

end LowerWeakCone
end LeanVerification.ReflectedWedgeCompletion
