import LeanVerification.ReflectedWedgeCompletion.SourceCoefficientJets
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate05

/-! Polynomial numerator certificate for source coefficient 2. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 8000000
set_option maxRecDepth 50000

theorem sourceCoefficient2_numerator (a f rho : ℝ) :
    weakNum05 a f rho=
    (4*(1+a)*(f-a*rho)*a*(f-a)*(1-rho)*weakNum01 a f rho-
      sourceDAlphaNumerator2 a f rho+
      (1+a)*(f-a*rho)*a*(f-a)*(1+f)*(1-rho)*weakNum00 a f rho-
      f*sourceDAlphaNumerator1 a f rho)/2 := by
  unfold weakNum05 weakNum01 weakNum00 sourceDAlphaNumerator2 sourceDAlphaPolynomial2 sourceDAlphaNumerator1 sourceDAlphaPolynomial1
  ring

end LeanVerification.ReflectedWedgeCompletion
