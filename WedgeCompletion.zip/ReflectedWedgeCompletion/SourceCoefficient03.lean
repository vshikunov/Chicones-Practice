import LeanVerification.ReflectedWedgeCompletion.RationalSigns
import LeanVerification.ReflectedWedgeCompletion.SourceCoefficientPolynomial03

/-! Exact source identity 3, with one fixed denominator and opaque
polynomial numerators throughout the rational cancellation. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 50000

namespace LowerWeakCone
variable {a f rho : ℝ} (h : LowerWeakCone a f rho)
include h

theorem sourceCoefficient3_identity : modelV3 a f rho=
    6*modelM a f rho*modelAlpha3 a f rho-jetDAlpha3 a f rho+4*modelM a f rho*modelAlpha2 a f rho-modelSigma f*jetDAlpha2 a f rho := by
  have ha := h.a_pos.ne'
  have hj : 1+f≠0 := by linarith [h.f_pos]
  have hg := h.base_signs.1.ne'
  have hfa := (sub_pos.mpr h.f_lower).ne'
  have hfu := (sub_pos.mpr h.f_upper).ne'
  have hru := (sub_pos.mpr h.rho_upper).ne'
  rw [sourceDAlpha3_fraction,sourceDAlpha2_fraction]
  unfold modelV3 modelE3 modelM modelSigma modelAlpha3 modelAlpha2 
  rw [sourceCoefficient3_numerator]
  unfold sourceDAlphaDenominator3 sourceDAlphaDenominator2 modelG at *
  generalize weakNum02 a f rho=A3
  generalize sourceDAlphaNumerator3 a f rho=N3
  generalize weakNum01 a f rho=A2
  generalize sourceDAlphaNumerator2 a f rho=N2
  generalize f-a=q at *
  generalize 1-f=t at *
  generalize 1+f=j at *
  generalize 1-rho=r at *
  generalize 1-a^2*rho=g at *
  field_simp [ha,hj,hg,hfa,hfu,hru]
  <;> ring

end LowerWeakCone
end LeanVerification.ReflectedWedgeCompletion
