import LeanVerification.ReflectedWedgeCompletion.CompactSourceComparison
import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Analysis.Calculus.Deriv.Pow

/-! The source formula is the complete derivative of the curvature quotient,
including the moving pole and the moving quartic coefficients. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 8000000
set_option maxRecDepth 20000

theorem compactPsi_hasDerivAt_flow
    {a₁ a₂ a₃ a₄ w : ℝ → ℝ} {h lam M ell sigma d₁ d₂ d₃ d₄ : ℝ}
    (hL : 1+ell*w h≠0)
    (ha₁ : HasDerivAt a₁ (lam*(1+sigma*w h)/(1+ell*w h)*d₁) h)
    (ha₂ : HasDerivAt a₂ (lam*(1+sigma*w h)/(1+ell*w h)*d₂) h)
    (ha₃ : HasDerivAt a₃ (lam*(1+sigma*w h)/(1+ell*w h)*d₃) h)
    (ha₄ : HasDerivAt a₄ (lam*(1+sigma*w h)/(1+ell*w h)*d₄) h)
    (hw : HasDerivAt w (-lam*2*M*w h*(1+w h)/(1+ell*w h)) h) :
    HasDerivAt (fun x => compactPsi (a₁ x) (a₂ x) (a₃ x) (a₄ x) (w x))
      (lam*compactSourceNumerator
        (2*M*a₁ h-d₁)
        (4*M*a₂ h-d₂+2*M*a₁ h-sigma*d₁)
        (6*M*a₃ h-d₃+4*M*a₂ h-sigma*d₂)
        (8*M*a₄ h-d₄+6*M*a₃ h-sigma*d₃)
        (8*M*a₄ h-sigma*d₄) (w h)/(1+ell*w h)) h := by
  have hd := ((((ha₁.mul hw).const_sub 1).sub (ha₂.mul (hw.pow 2))).sub
    (ha₃.mul (hw.pow 3))).sub (ha₄.mul (hw.pow 4))
  convert hd using 1
  unfold compactSourceNumerator
  field_simp [hL]
  <;> ring

theorem complete_curvature_source_derivative
    {p b w A₁ A₂ A₃ A₄ : ℝ → ℝ}
    {h lam M sigma t R₀ v₁ v₂ v₃ v₄ v₅ : ℝ}
    (hL : 1+b h*w h≠0) (hw1 : 1+w h≠0)
    (hPsi : compactPsi (A₁ h) (A₂ h) (A₃ h) (A₄ h) (w h)≠0)
    (hp : HasDerivAt p
      (lam*((1+sigma*w h)/(1+b h*w h))*p h*(R₀-1)) h)
    (hb : HasDerivAt b (-lam*((1+sigma*w h)/(1+b h*w h))*t) h)
    (hw : HasDerivAt w (-lam*2*M*w h*(1+w h)/(1+b h*w h)) h)
    (hPsiD : HasDerivAt (fun x => compactPsi (A₁ x) (A₂ x) (A₃ x) (A₄ x) (w x))
      (lam*compactSourceNumerator v₁ v₂ v₃ v₄ v₅ (w h)/(1+b h*w h)) h) :
    HasDerivAt
      (fun x => p x*compactPsi (A₁ x) (A₂ x) (A₃ x) (A₄ x) (w x)/
        ((1+w x)*(1+b x*w x)^3))
      (lam*(p h*compactPsi (A₁ h) (A₂ h) (A₃ h) (A₄ h) (w h)/
        ((1+w h)*(1+b h*w h)^3))*
        (((1+sigma*w h)/(1+b h*w h))*(R₀-1)+
          compactSource M (b h) sigma t (A₁ h) (A₂ h) (A₃ h) (A₄ h)
            v₁ v₂ v₃ v₄ v₅ (w h))) h := by
  have hld := ((hb.mul hw).const_add 1).pow 3
  have hwd := hw.const_add 1
  have hd := (hp.mul hPsiD).div (hwd.mul hld) (mul_ne_zero hw1 (pow_ne_zero 3 hL))
  convert hd using 1
  unfold compactSource compactPoleNumerator
  field_simp [hL,hw1,hPsi]
  <;> ring

end LeanVerification.ReflectedWedgeCompletion
