import LeanVerification.ReflectedWedgeCompletion.RationalSigns
import LeanVerification.ReflectedWedgeCompletion.SourceCoefficientPolynomial02

/-! Exact source identity 2, with one fixed denominator and opaque
polynomial numerators throughout the rational cancellation. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 50000

namespace LowerWeakCone
variable {a f rho : ℝ} (h : LowerWeakCone a f rho)
include h

theorem sourceCoefficient2_identity : modelV2 a f rho=
    4*modelM a f rho*modelAlpha2 a f rho-jetDAlpha2 a f rho+2*modelM a f rho*modelAlpha1 a f rho-modelSigma f*jetDAlpha1 a f rho := by
  have ha := h.a_pos.ne'
  have hj : 1+f≠0 := by linarith [h.f_pos]
  have hg := h.base_signs.1.ne'
  have hfa := (sub_pos.mpr h.f_lower).ne'
  have hfu := (sub_pos.mpr h.f_upper).ne'
  have hru := (sub_pos.mpr h.rho_upper).ne'
  rw [sourceDAlpha2_fraction,sourceDAlpha1_fraction]
  unfold modelV2 modelE2 modelM modelSigma modelAlpha2 modelAlpha1 
  rw [sourceCoefficient2_numerator]
  unfold sourceDAlphaDenominator2 sourceDAlphaDenominator1 modelG at *
  generalize weakNum01 a f rho=A2
  generalize sourceDAlphaNumerator2 a f rho=N2
  generalize weakNum00 a f rho=A1
  generalize sourceDAlphaNumerator1 a f rho=N1
  generalize f-a=q at *
  generalize 1-f=t at *
  generalize 1+f=j at *
  generalize 1-rho=r at *
  generalize 1-a^2*rho=g at *
  field_simp [ha,hj,hg,hfa,hfu,hru]
  <;> ring

end LowerWeakCone
end LeanVerification.ReflectedWedgeCompletion
