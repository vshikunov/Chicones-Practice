import LeanVerification.ReflectedWedgeCompletion.ActualModel
import LeanVerification.ReflectedWedgeCompletion.WidthPeriodTransfer

/-! The checked secant model implies the complete physical-period bound. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.ReflectedWedgeCompletion
open Loud ReflectedCompletion
set_option maxHeartbeats 6400000

theorem wedge_stiffness_width_identity {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    1/(wedgeEnergyScale D F*lowerPhysicalD D)=
      wedgeWidth D F h*deriv (wedgeWidth D F) h*wedgeK D F h := by
  apply widthjet_stiffness_identity (S:={h|AdmissibleEnergy D F h})
    (E:=wedgeNormalizedEnergy D F) (U:=wedgeU D F)
    (isOpen_admissibleEnergy D F) hh (analyticAt_wedgeWidth hh)
    (wedgeWidth_pos (by linarith : 0<F) hh).ne'
    (hasDerivAt_wedgeNormalizedEnergy D F h)
  · simpa only [wedgeRate] using hasDerivAt_wedgeU hF0 hF1 hD0 hD1 hh
  · intro t ht
    exact actual_physical_energy_width_identity hF0 hF1 hD0 hD1 ht

theorem wedge_curvature_width_identity {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    ((deriv (wedgeWidth D F) h)^2+wedgeWidth D F h*deriv (deriv (wedgeWidth D F)) h)*
      wedgeK D F h=(deriv (wedgeWidth D F) h)^2*wedgeCurvature D F h := by
  apply widthjet_curvature_identity (S:={h|AdmissibleEnergy D F h})
    (c:=1/(wedgeEnergyScale D F*lowerPhysicalD D))
    (isOpen_admissibleEnergy D F) hh (analyticAt_wedgeWidth hh)
    (wedgeWidth_pos (by linarith : 0<F) hh).ne'
  · simpa only [wedgeRate,neg_div] using hasDerivAt_wedgeK hF0 hF1 hD0 hD1 hh
  · intro t ht
    exact wedge_stiffness_width_identity hF0 hF1 hD0 hD1 ht

theorem wedge_third_width_identity {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) (hΦ : 0<wedgeCurvature D F h) :
    wedgeK D F h*(3*wedgeWidth D F h*deriv (wedgeWidth D F) h*
      deriv (deriv (wedgeWidth D F)) h+(wedgeWidth D F h)^2*deriv (deriv (deriv (wedgeWidth D F))) h)=
      wedgeCurvature D F h*(3*wedgeWidth D F h*deriv (wedgeWidth D F) h*
        deriv (deriv (wedgeWidth D F)) h+(deriv (wedgeWidth D F) h)^3*wedgeR D F h) := by
  apply widthjet_third_identity (S:={h|AdmissibleEnergy D F h})
    (isOpen_admissibleEnergy D F) hh (analyticAt_wedgeWidth hh)
    (wedgeWidth_pos (by linarith : 0<F) hh).ne'
  · simpa only [wedgeRate,neg_div] using hasDerivAt_wedgeK hF0 hF1 hD0 hD1 hh
  · simpa only [wedgeRate] using hasDerivAt_wedgeCurvature hF0 hF1 hD0 hD1 hh hΦ
  · intro t ht
    exact wedge_curvature_width_identity hF0 hF1 hD0 hD1 ht

theorem actual_wedge_width_concave {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) : deriv (deriv (wedgeWidth D F)) h<0 :=
  widthjet_concave (wedgeWidth_pos (by linarith : 0<F) hh)
    (wedgeWidth_deriv_pos (by linarith : 0<F) hh) (wedgeK_pos hF0 hF1 hD0 hD1 hh)
    (wedge_curvature_width_identity hF0 hF1 hD0 hD1 hh) (wedgeChi_lt_one hF0 hF1 hD0 hD1 hh)

theorem actual_wedge_width_half_comparison {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h)
    (hc : 0<1+wedgeWidth D F h*deriv (deriv (wedgeWidth D F)) h/(deriv (wedgeWidth D F) h)^2) :
    0<deriv (wedgeWidth D F) h*deriv (deriv (deriv (wedgeWidth D F))) h-
      3*(deriv (deriv (wedgeWidth D F)) h)^2+
      (1/2:ℝ)*(deriv (deriv (wedgeWidth D F)) h)^2*
        (1+wedgeWidth D F h*deriv (deriv (wedgeWidth D F)) h/(deriv (wedgeWidth D F) h)^2) := by
  have hw := wedgeWidth_pos (by linarith : 0<F) hh
  have hw1 := wedgeWidth_deriv_pos (by linarith : 0<F) hh
  have hk := wedgeK_pos hF0 hF1 hD0 hD1 hh
  have hsecond := wedge_curvature_width_identity hF0 hF1 hD0 hD1 hh
  have hechi := widthjet_chi_eq hw1.ne' hk.ne' hsecond
  have hchi : 0<wedgeChi D F h := by
    change 0<wedgeCurvature D F h/wedgeK D F h
    rwa [hechi]
  have hΦ : 0<wedgeCurvature D F h := by
    simpa only [zero_mul] using (lt_div_iff₀ hk).mp hchi
  exact widthjet_half_comparison hw hw1 hk hchi hsecond
    (wedge_third_width_identity hF0 hF1 hD0 hD1 hh hΦ)
    (wedge_global_half_target hF0 hF1 hD0 hD1 hh hchi)

theorem actual_wedge_width_euler_pos {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h)
    (hQ : 0<InverseWidthComparison.widthQ (physicalEnergyWidth D F) h) :
    0<h*deriv (InverseWidthComparison.widthQ (physicalEnergyWidth D F)) h+
      (1/2:ℝ)*InverseWidthComparison.widthQ (physicalEnergyWidth D F) h := by
  apply physical_width_euler_of_scaled_jets D F h F hh (by linarith) (w:=wedgeWidth D F)
    (by funext t;exact wedgeWidth_eq D F t)
    (actual_wedge_width_concave hF0 hF1 hD0 hD1 hh)
    (actual_wedge_width_half_comparison hF0 hF1 hD0 hD1 hh) hQ

theorem criticalPeriodBound_one_reflected_wedge (D F : ℝ)
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2)) :
    CriticalPeriodBound 1 D F :=
  criticalPeriodBound_one_of_width_euler D F
    (fun h hh hQ => (actual_wedge_width_euler_pos hF0 hF1 hD0 hD1 hh hQ).le)

end LeanVerification.ReflectedWedgeCompletion
