import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity

/-!
The finite source comparison used by the compact inverse-width argument.
This module proves only the rational comparison step.  The hypotheses on
its coefficients must still be established for the actual Loud secants.
It therefore does not assert a regional period bound.
-/

noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion

set_option maxHeartbeats 1600000

/-- The quartic whose positive branch is the inverse-width condition `χ > 0`. -/
def compactPsi (a₁ a₂ a₃ a₄ ω : ℝ) : ℝ :=
  1 - a₁ * ω - a₂ * ω ^ 2 - a₃ * ω ^ 3 - a₄ * ω ^ 4

/-- The numerator of the transported source term. -/
def compactSourceNumerator (v₁ v₂ v₃ v₄ v₅ ω : ℝ) : ℝ :=
  v₁ * ω + v₂ * ω ^ 2 + v₃ * ω ^ 3 + v₄ * ω ^ 4 + v₅ * ω ^ 5

/-- The pole part of the transported source term. -/
def compactPoleNumerator (M ell sigma t ω : ℝ) : ℝ :=
  (2 * M + 6 * M * ell + 3 * t) * ω +
    (8 * M * ell + 3 * sigma * t) * ω ^ 2

def compactSource (M ell sigma t a₁ a₂ a₃ a₄ v₁ v₂ v₃ v₄ v₅ ω : ℝ) : ℝ :=
  compactPoleNumerator M ell sigma t ω / (1 + ell * ω) ^ 2 +
    compactSourceNumerator v₁ v₂ v₃ v₄ v₅ ω /
      ((1 + ell * ω) * compactPsi a₁ a₂ a₃ a₄ ω)

/-- The source comparison needs only coefficient values, without any partial
parameter derivatives or an assumed monotonicity of `S/χ`. -/
theorem compactSourceNumerator_lower
    {M a₁ a₂ a₃ a₄ v₁ v₂ v₃ v₄ v₅ ω : ℝ}
    (hω : 0 < ω) (h₁ : -M < v₁)
    (h₂ : M * a₁ ≤ v₂) (h₃ : M * a₂ ≤ v₃)
    (h₄ : M * a₃ ≤ v₄) (h₅ : M * a₄ ≤ v₅) :
    -M * ω * compactPsi a₁ a₂ a₃ a₄ ω <
      compactSourceNumerator v₁ v₂ v₃ v₄ v₅ ω := by
  have hfirst : 0 < ω * (v₁ + M) := mul_pos hω (by linarith)
  have hsecond : 0 ≤ ω ^ 2 * (v₂ - M * a₁) := mul_nonneg (sq_nonneg _) (sub_nonneg.mpr h₂)
  have hthird : 0 ≤ ω ^ 3 * (v₃ - M * a₂) := mul_nonneg (pow_nonneg hω.le _) (sub_nonneg.mpr h₃)
  have hfourth : 0 ≤ ω ^ 4 * (v₄ - M * a₃) := mul_nonneg (pow_nonneg hω.le _) (sub_nonneg.mpr h₄)
  have hfifth : 0 ≤ ω ^ 5 * (v₅ - M * a₄) := mul_nonneg (pow_nonneg hω.le _) (sub_nonneg.mpr h₅)
  have hid : compactSourceNumerator v₁ v₂ v₃ v₄ v₅ ω +
      M * ω * compactPsi a₁ a₂ a₃ a₄ ω =
      ω * (v₁ + M) + ω ^ 2 * (v₂ - M * a₁) +
        ω ^ 3 * (v₃ - M * a₂) + ω ^ 4 * (v₄ - M * a₃) +
        ω ^ 5 * (v₅ - M * a₄) := by
    unfold compactSourceNumerator compactPsi
    ring
  linarith

theorem compactPoleNumerator_lower
    {M ell sigma t ω : ℝ}
    (hM : 0 ≤ M) (hell : 0 ≤ ell) (hsigma : 0 ≤ sigma)
    (ht : 0 ≤ t) (hω : 0 ≤ ω) :
    2 * M * ω * (1 + ell * ω) ≤ compactPoleNumerator M ell sigma t ω := by
  have hp : 0 ≤ 3 * ω * (2 * M * ell + t + (2 * M * ell + sigma * t) * ω) := by
    positivity
  unfold compactPoleNumerator
  nlinarith

theorem compactSource_lower
    {M ell sigma t a₁ a₂ a₃ a₄ v₁ v₂ v₃ v₄ v₅ ω : ℝ}
    (hM : 0 ≤ M) (hell : 0 ≤ ell) (hsigma : 0 ≤ sigma) (ht : 0 ≤ t)
    (hω : 0 < ω) (hPsi : 0 < compactPsi a₁ a₂ a₃ a₄ ω)
    (h₁ : -M < v₁) (h₂ : M * a₁ ≤ v₂) (h₃ : M * a₂ ≤ v₃)
    (h₄ : M * a₃ ≤ v₄) (h₅ : M * a₄ ≤ v₅) :
    M * ω / (1 + ell * ω) <
      compactSource M ell sigma t a₁ a₂ a₃ a₄ v₁ v₂ v₃ v₄ v₅ ω := by
  have hL : 0 < 1 + ell * ω := by positivity
  have hB := div_le_div_of_nonneg_right
    (compactPoleNumerator_lower hM hell hsigma ht hω.le) (sq_nonneg (1 + ell * ω))
  have hV := div_lt_div_of_pos_right
    (compactSourceNumerator_lower hω h₁ h₂ h₃ h₄ h₅) (mul_pos hL hPsi)
  have hBnorm : 2 * M * ω * (1 + ell * ω) / (1 + ell * ω) ^ 2 =
      2 * M * ω / (1 + ell * ω) := by
    field_simp [hL.ne']
    <;> ring
  have hVnorm : -M * ω * compactPsi a₁ a₂ a₃ a₄ ω /
      ((1 + ell * ω) * compactPsi a₁ a₂ a₃ a₄ ω) =
      -M * ω / (1 + ell * ω) := by
    field_simp [hL.ne', hPsi.ne']
    <;> ring
  rw [hBnorm] at hB
  rw [hVnorm] at hV
  have htotal := add_lt_add_of_le_of_lt hB hV
  have hnorm : 2 * M * ω / (1 + ell * ω) + -M * ω / (1 + ell * ω) = M * ω / (1 + ell * ω) := by ring
  rw [hnorm] at htotal
  exact htotal

/-- A positive diagonal ratio and the finite source values already give
positive compact inverse-width curvature for every positive mixture. -/
theorem compactRatio_pos_of_source_values
    {a ell sigma t a₁ a₂ a₃ a₄ v₁ v₂ v₃ v₄ v₅ ω R₀ : ℝ}
    (ha : 0 ≤ a) (hell : 0 ≤ ell) (hsigma : ell ≤ sigma) (ht : 0 ≤ t)
    (hω : 0 < ω) (hPsi : 0 < compactPsi a₁ a₂ a₃ a₄ ω)
    (hR₀ : 0 < R₀)
    (h₁ : -(1 + a) * (sigma - ell) < v₁)
    (h₂ : (1 + a) * (sigma - ell) * a₁ ≤ v₂)
    (h₃ : (1 + a) * (sigma - ell) * a₂ ≤ v₃)
    (h₄ : (1 + a) * (sigma - ell) * a₃ ≤ v₄)
    (h₅ : (1 + a) * (sigma - ell) * a₄ ≤ v₅) :
    0 < 1 + (1 + sigma * ω) / (1 + ell * ω) * (R₀ - 1) +
      compactSource ((1 + a) * (sigma - ell)) ell sigma t
        a₁ a₂ a₃ a₄ v₁ v₂ v₃ v₄ v₅ ω := by
  have hM : 0 ≤ (1 + a) * (sigma - ell) := mul_nonneg (by linarith) (sub_nonneg.mpr hsigma)
  have hL : 0 < 1 + ell * ω := by positivity
  have hA := compactSource_lower hM hell (hell.trans hsigma) ht hω hPsi
    (by simpa only [neg_mul] using h₁) h₂ h₃ h₄ h₅
  have hratio : 1 ≤ (1 + sigma * ω) / (1 + ell * ω) := by
    apply (le_div_iff₀ hL).mpr
    nlinarith
  have hpositive : 0 < (1 + sigma * ω) / (1 + ell * ω) * R₀ +
      a * ((1 + sigma * ω) / (1 + ell * ω) - 1) :=
    add_pos_of_pos_of_nonneg (mul_pos (by linarith) hR₀) (mul_nonneg ha (by linarith))
  have hid : 1 + (1 + sigma * ω) / (1 + ell * ω) * (R₀ - 1) +
      ((1 + a) * (sigma - ell)) * ω / (1 + ell * ω) =
      (1 + sigma * ω) / (1 + ell * ω) * R₀ +
        a * ((1 + sigma * ω) / (1 + ell * ω) - 1) := by
    field_simp [hL.ne']
    <;> ring
  linarith

end LeanVerification.ReflectedWedgeCompletion
