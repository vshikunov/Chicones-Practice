import LeanVerification.ReflectedWedgeCompletion.PhysicalNormalization
import LeanVerification.ReflectedWedgeCompletion.HyperbolicSecants
import LeanVerification.Loud.PotentialBranchIntegral

/-! Actual positive turns and their secant coordinates in the lower wedge. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.ReflectedWedgeCompletion
open Loud ReflectedCompletion
set_option maxHeartbeats 6000000
set_option maxRecDepth 12000

def wedgeLeft (D F h : ℝ) : ℝ := 1+F*potentialLeftPosition D F h
def wedgeRight (D F h : ℝ) : ℝ := 1+F*potentialRightPosition D F h
def wedgeWidth (D F h : ℝ) : ℝ := wedgeRight D F h-wedgeLeft D F h
def wedgeLogSecant (D F h : ℝ) : ℝ :=
  (Real.log (wedgeRight D F h)-Real.log (wedgeLeft D F h))/2
def wedgeGeometricMean (D F h : ℝ) : ℝ :=
  Real.sqrt (wedgeRight D F h*wedgeLeft D F h)
def wedgeMixtureScale (D F : ℝ) : ℝ := Real.sqrt (lowerPhysicalA F*lowerPhysicalD D)
def wedgeBeta (D F : ℝ) : ℝ :=
  lowerPhysicalA F*(1-lowerPhysicalD D)/((1-lowerPhysicalA F)*wedgeMixtureScale D F)
def wedgeMixtureRoot (D F h : ℝ) : ℝ :=
  wedgeMixtureScale D F*wedgeGeometricMean D F h^(1+lowerPhysicalA F)*
    Real.sinh (wedgeLogSecant D F h)/Real.sinh (lowerPhysicalA F*wedgeLogSecant D F h)
def wedgeOmega (D F h : ℝ) : ℝ := (wedgeMixtureRoot D F h)^2-1

theorem wedgeWidth_eq (D F h : ℝ) :
    wedgeWidth D F h=F*physicalEnergyWidth D F h := by
  unfold wedgeWidth wedgeRight wedgeLeft potentialLeftPosition potentialRightPosition
  rw [physicalEnergyWidth,physicalWidth_eq]
  ring

theorem wedge_turns_pos (D F h : ℝ) (hh : AdmissibleEnergy D F h) :
    0<wedgeLeft D F h ∧ 0<wedgeRight D F h := by
  have hr := Real.sqrt_nonneg (2*h)
  have hl := mechanicalDomain_morsePosition D F (-Real.sqrt (2*h))
    (morse_amplitude_in_range D F h hh ⟨le_rfl,by linarith⟩)
  have hu := mechanicalDomain_morsePosition D F (Real.sqrt (2*h))
    (morse_amplitude_in_range D F h hh ⟨by linarith,le_rfl⟩)
  exact ⟨hl,hu⟩

theorem wedgeWidth_pos {D F h : ℝ} (hF : 0<F) (hh : AdmissibleEnergy D F h) :
    0<wedgeWidth D F h := by rw [wedgeWidth_eq];exact mul_pos hF (physicalEnergyWidth_pos D F h hh)

theorem wedgeLogSecant_pos {D F h : ℝ} (hF : 0<F) (hh : AdmissibleEnergy D F h) :
    0<wedgeLogSecant D F h := by
  have hp := wedge_turns_pos D F h hh
  have hw := wedgeWidth_pos hF hh
  have hlr : wedgeLeft D F h<wedgeRight D F h := sub_pos.mp hw
  unfold wedgeLogSecant
  exact div_pos (sub_pos.mpr (Real.log_lt_log hp.1 hlr)) (by norm_num)

theorem wedgeGeometricMean_pos {D F h : ℝ} (hh : AdmissibleEnergy D F h) :
    0<wedgeGeometricMean D F h :=
  Real.sqrt_pos.mpr (mul_pos (wedge_turns_pos D F h hh).2 (wedge_turns_pos D F h hh).1)

theorem wedge_turn_decomposition {D F h : ℝ} (hh : AdmissibleEnergy D F h) :
    wedgeRight D F h=wedgeGeometricMean D F h*Real.exp (wedgeLogSecant D F h) ∧
    wedgeLeft D F h=wedgeGeometricMean D F h*Real.exp (-wedgeLogSecant D F h) := by
  have hp := wedge_turns_pos D F h hh
  have hn := wedgeGeometricMean_pos hh
  have hlog : Real.log (wedgeGeometricMean D F h)=
      (Real.log (wedgeRight D F h)+Real.log (wedgeLeft D F h))/2 := by
    rw [wedgeGeometricMean,Real.log_sqrt (mul_pos hp.2 hp.1).le,Real.log_mul hp.2.ne' hp.1.ne']
  have hR : Real.log (wedgeRight D F h)=Real.log (wedgeGeometricMean D F h)+wedgeLogSecant D F h := by
    rw [hlog];unfold wedgeLogSecant;ring
  have hL : Real.log (wedgeLeft D F h)=Real.log (wedgeGeometricMean D F h)-wedgeLogSecant D F h := by
    rw [hlog];unfold wedgeLogSecant;ring
  constructor
  · calc
      _ = Real.exp (Real.log (wedgeRight D F h)) := (Real.exp_log hp.2).symm
      _ = _ := by rw [hR,Real.exp_add,Real.exp_log hn]
  · calc
      _ = Real.exp (Real.log (wedgeLeft D F h)) := (Real.exp_log hp.1).symm
      _ = _ := by rw [hL,sub_eq_add_neg,Real.exp_add,Real.exp_log hn]

theorem wedgeWidth_hyperbolic {D F h : ℝ} (hh : AdmissibleEnergy D F h) :
    wedgeWidth D F h=2*wedgeGeometricMean D F h*Real.sinh (wedgeLogSecant D F h) := by
  have ht := wedge_turn_decomposition hh
  unfold wedgeWidth
  rw [ht.1,ht.2,Real.sinh_eq]
  ring

theorem analyticAt_wedge_turns {D F h : ℝ} (hh : AdmissibleEnergy D F h) :
    AnalyticAt ℝ (wedgeLeft D F) h ∧ AnalyticAt ℝ (wedgeRight D F) h := by
  have hr := Real.sqrt_nonneg (2*h)
  have hl := analyticAt_morsePosition D F (-Real.sqrt (2*h))
    (morse_amplitude_in_range D F h hh ⟨le_rfl,by linarith⟩)
  have hu := analyticAt_morsePosition D F (Real.sqrt (2*h))
    (morse_amplitude_in_range D F h hh ⟨by linarith,le_rfl⟩)
  have hs := analyticAt_energyAmplitude hh.1
  exact ⟨analyticAt_const.add (analyticAt_const.mul (hl.comp_of_eq hs.neg rfl)),
    analyticAt_const.add (analyticAt_const.mul (hu.comp_of_eq hs rfl))⟩

theorem wedge_turns_same_potential (D F h : ℝ)
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    wedgePotential (lowerPhysicalA F) (lowerPhysicalD D) (wedgeLeft D F h)=
      wedgePotential (lowerPhysicalA F) (lowerPhysicalD D) (wedgeRight D F h) := by
  have hp := wedge_turns_pos D F h hh
  have hv := potential_branches_values D F h hh (show h∈Icc 0 h from ⟨hh.1.le,le_rfl⟩)
  have hL := wedgePhysical_potential_normalization D F (potentialLeftPosition D F h)
    hF0 hF1 hD0 hD1 hp.1
  have hR := wedgePhysical_potential_normalization D F (potentialRightPosition D F h)
    hF0 hF1 hD0 hD1 hp.2
  rw [hv.1] at hL
  rw [hv.2] at hR
  have hscale := wedgeEnergyScale_pos (by linarith : D<0) (by linarith : 0<F)
  change h=wedgeEnergyScale D F*wedgePotential (lowerPhysicalA F) (lowerPhysicalD D) (wedgeLeft D F h)+zeroEndpointHeight D F at hL
  change h=wedgeEnergyScale D F*wedgePotential (lowerPhysicalA F) (lowerPhysicalD D) (wedgeRight D F h)+zeroEndpointHeight D F at hR
  nlinarith

theorem wedgeBeta_bounds {D F : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2)) :
    0<wedgeBeta D F ∧ wedgeBeta D F<1 := by
  obtain ⟨ha,hau,had,hdu⟩ := wedgePhysical_parameters hF0 hF1 hD0 hD1
  have hd := ha.trans had
  have h1a : 0<1-lowerPhysicalA F := by linarith
  have h1d : 0<1-lowerPhysicalD D := by linarith
  have hs : 0<wedgeMixtureScale D F := Real.sqrt_pos.mpr (mul_pos ha hd)
  have hs2 : wedgeMixtureScale D F^2=lowerPhysicalA F*lowerPhysicalD D :=
    Real.sq_sqrt (mul_pos ha hd).le
  have had1 : lowerPhysicalA F*lowerPhysicalD D<1 := by
    have hm := mul_lt_of_lt_one_right ha hdu
    linarith
  have hgap : 0<lowerPhysicalD D-lowerPhysicalA F := sub_pos.mpr had
  have hgap2 : 0<1-lowerPhysicalA F*lowerPhysicalD D := sub_pos.mpr had1
  have hp : 0<(lowerPhysicalD D-lowerPhysicalA F)*(1-lowerPhysicalA F*lowerPhysicalD D) := mul_pos hgap hgap2
  have hid : ((1-lowerPhysicalA F)*wedgeMixtureScale D F)^2-
      (lowerPhysicalA F*(1-lowerPhysicalD D))^2=
        lowerPhysicalA F*(lowerPhysicalD D-lowerPhysicalA F)*(1-lowerPhysicalA F*lowerPhysicalD D) := by
    rw [mul_pow,hs2]
    ring
  have hineq : lowerPhysicalA F*(1-lowerPhysicalD D)<
      (1-lowerPhysicalA F)*wedgeMixtureScale D F := by
    nlinarith [mul_pos ha hp,mul_pos ha h1d,mul_pos h1a hs]
  unfold wedgeBeta
  exact ⟨div_pos (mul_pos ha h1d) (mul_pos h1a hs),
    (div_lt_one (mul_pos h1a hs)).mpr hineq⟩

end LeanVerification.ReflectedWedgeCompletion
