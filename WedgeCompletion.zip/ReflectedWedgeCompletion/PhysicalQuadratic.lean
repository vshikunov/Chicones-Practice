import LeanVerification.ReflectedWedgeCompletion.PhysicalSecants

/-! The mixture quadratic is derived from the equal energies of the actual
physical turns.  No independently specified turn or endpoint condition occurs. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.ReflectedWedgeCompletion
open Loud ReflectedCompletion
set_option maxHeartbeats 10000000
set_option maxRecDepth 12000

theorem secant_power_difference {nu : ℝ} (hnu : 0<nu) (p q : ℝ) :
    (nu*Real.exp q)^p-(nu*Real.exp (-q))^p=
      2*nu^p*Real.sinh (p*q) := by
  rw [Real.mul_rpow hnu.le (Real.exp_pos q).le,
    Real.mul_rpow hnu.le (Real.exp_pos (-q)).le,
    ←Real.exp_mul,←Real.exp_mul,Real.sinh_eq]
  congr 1 <;> ring

theorem secant_power_sum {nu : ℝ} (hnu : 0<nu) (p q : ℝ) :
    (nu*Real.exp q)^p+(nu*Real.exp (-q))^p=
      2*nu^p*Real.cosh (p*q) := by
  rw [Real.mul_rpow hnu.le (Real.exp_pos q).le,
    Real.mul_rpow hnu.le (Real.exp_pos (-q)).le,
    ←Real.exp_mul,←Real.exp_mul,Real.cosh_eq]
  congr 1 <;> ring

theorem secant_power_relations {nu : ℝ} (hnu : 0<nu) (a : ℝ) :
    nu^(2*a)*nu^2=(nu^(1+a))^2 ∧
    nu^(2*a)*nu^(1-a)=nu^(1+a) ∧
    nu^(2*a)*nu^(-2*a)=1 := by
  constructor
  · rw [←Real.rpow_two,←Real.rpow_two,←Real.rpow_mul hnu.le,←Real.rpow_add hnu]
    congr 1 <;> ring
  constructor
  · rw [←Real.rpow_add hnu]
    congr 1 <;> ring
  · rw [←Real.rpow_add hnu]
    convert Real.rpow_zero nu using 1 <;> ring

theorem wedge_equal_potential_secant_equation
    {a d nu q : ℝ} (ha : 0<a) (ha1 : a<1) (hnu : 0<nu)
    (hpot : wedgePotential a d (nu*Real.exp q)=wedgePotential a d (nu*Real.exp (-q))) :
    a*d*(nu^(1+a))^2*Real.sinh (2*q)+
      2*a*(1-d)/(1-a)*nu^(1+a)*Real.sinh ((1-a)*q)-Real.sinh (2*a*q)=0 := by
  have hpow := secant_power_relations hnu a
  have hdiff : wedgePotential a d (nu*Real.exp q)-wedgePotential a d (nu*Real.exp (-q))=
      d*nu^2*Real.sinh (2*q)+2*(1-d)/(1-a)*nu^(1-a)*Real.sinh ((1-a)*q)-
        1/a*nu^(-2*a)*Real.sinh (2*a*q) := by
    unfold wedgePotential
    calc
      _ = d/2*((nu*Real.exp q)^2-(nu*Real.exp (-q))^2)+
          (1-d)/(1-a)*((nu*Real.exp q)^(1-a)-(nu*Real.exp (-q))^(1-a))+
          1/(2*a)*((nu*Real.exp q)^(-2*a)-(nu*Real.exp (-q))^(-2*a)) := by ring
      _ = _ := by
        rw [←Real.rpow_two (nu*Real.exp q),←Real.rpow_two (nu*Real.exp (-q)),
          secant_power_difference hnu,secant_power_difference hnu,secant_power_difference hnu]
        have he : -2*a*q= -(2*a*q) := by ring
        rw [he,Real.sinh_neg,Real.rpow_two]
        ring
  have hzero : d*nu^2*Real.sinh (2*q)+2*(1-d)/(1-a)*nu^(1-a)*Real.sinh ((1-a)*q)-
      1/a*nu^(-2*a)*Real.sinh (2*a*q)=0 := by rw [hpot,sub_self] at hdiff;exact hdiff.symm
  calc
    _ = a*nu^(2*a)*(d*nu^2*Real.sinh (2*q)+2*(1-d)/(1-a)*nu^(1-a)*Real.sinh ((1-a)*q)-
      1/a*nu^(-2*a)*Real.sinh (2*a*q)) := by
        calc
          _ = a*d*(nu^(2*a)*nu^2)*Real.sinh (2*q)+
            2*a*(1-d)/(1-a)*(nu^(2*a)*nu^(1-a))*Real.sinh ((1-a)*q)-
              (nu^(2*a)*nu^(-2*a))*Real.sinh (2*a*q) := by rw [hpow.1,hpow.2.1,hpow.2.2];ring
          _ = _ := by
            field_simp [ha.ne',show 1-a≠0 by linarith]
            <;> ring
    _ = 0 := by rw [hzero,mul_zero]

theorem mixture_quadratic_of_secant_equation
    {a d nu q B : ℝ} (ha : 0<a) (ha1 : a<1) (hq : 0<q) (hB : 0<B)
    (hB2 : B^2=a*d)
    (heq : a*d*(nu^(1+a))^2*Real.sinh (2*q)+
      2*a*(1-d)/(1-a)*nu^(1+a)*Real.sinh ((1-a)*q)-Real.sinh (2*a*q)=0) :
    secantF a q*(B*nu^(1+a)*Real.sinh q/Real.sinh (a*q))^2+
      (a*(1-d)/((1-a)*B))*(1-secantF a q)*(B*nu^(1+a)*Real.sinh q/Real.sinh (a*q))-1=0 := by
  have hs := Real.sinh_pos_iff.mpr hq
  have hsa := Real.sinh_pos_iff.mpr (mul_pos ha hq)
  have hc := Real.cosh_pos (a*q)
  have h1a : 1-a≠0 := by linarith
  have he : (1-a)*q=q-a*q := by ring
  rw [he,Real.sinh_sub,Real.sinh_two_mul,
    show 2*a*q=2*(a*q) by ring,Real.sinh_two_mul] at heq
  have heval :
      secantF a q*(B*nu^(1+a)*Real.sinh q/Real.sinh (a*q))^2+
        (a*(1-d)/((1-a)*B))*(1-secantF a q)*(B*nu^(1+a)*Real.sinh q/Real.sinh (a*q))-1=
      (a*d*(nu^(1+a))^2*Real.sinh q*Real.cosh q+
        a*(1-d)/(1-a)*nu^(1+a)*(Real.sinh q*Real.cosh (a*q)-Real.cosh q*Real.sinh (a*q))-
          Real.sinh (a*q)*Real.cosh (a*q))/(Real.sinh (a*q)*Real.cosh (a*q)) := by
    unfold secantF secantR
    rw [div_pow,mul_pow,mul_pow,hB2]
    field_simp [ha.ne',hs.ne',hsa.ne',hc.ne',hB.ne',h1a]
    <;> ring
  rw [heval]
  apply div_eq_zero_iff.mpr
  left
  linear_combination (1 / 2 : ℝ) * heq

theorem wedgeMixtureRoot_quadratic {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    secantF (lowerPhysicalA F) (wedgeLogSecant D F h)*(wedgeMixtureRoot D F h)^2+
      wedgeBeta D F*(1-secantF (lowerPhysicalA F) (wedgeLogSecant D F h))*wedgeMixtureRoot D F h-1=0 := by
  obtain ⟨ha,hau,had,hdu⟩ := wedgePhysical_parameters hF0 hF1 hD0 hD1
  have ht := wedge_turn_decomposition hh
  have hp := (wedge_turns_same_potential D F h hF0 hF1 hD0 hD1 hh).symm
  rw [ht.1,ht.2] at hp
  have heq := wedge_equal_potential_secant_equation ha (by linarith : lowerPhysicalA F<1)
    (wedgeGeometricMean_pos hh) hp
  exact mixture_quadratic_of_secant_equation ha (by linarith)
    (wedgeLogSecant_pos (by linarith : 0<F) hh)
    (Real.sqrt_pos.mpr (mul_pos ha (ha.trans had)))
    (Real.sq_sqrt (mul_pos ha (ha.trans had)).le) heq

theorem wedgeMixtureRoot_gt_one {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) : 1<wedgeMixtureRoot D F h := by
  obtain ⟨ha,hau,had,hdu⟩ := wedgePhysical_parameters hF0 hF1 hD0 hD1
  have hq := wedgeLogSecant_pos (by linarith : 0<F) hh
  have hf := secantF_bounds ha (by linarith : lowerPhysicalA F<1) hq
  have hb := wedgeBeta_bounds hF0 hF1 hD0 hD1
  have hroot : 0<wedgeMixtureRoot D F h := by
    unfold wedgeMixtureRoot wedgeMixtureScale
    exact div_pos (mul_pos (mul_pos (Real.sqrt_pos.mpr (mul_pos ha (ha.trans had)))
      (Real.rpow_pos_of_pos (wedgeGeometricMean_pos hh) _)) (Real.sinh_pos_iff.mpr hq))
        (Real.sinh_pos_iff.mpr (mul_pos ha hq))
  have heq := wedgeMixtureRoot_quadratic hF0 hF1 hD0 hD1 hh
  by_contra hn
  have hr := le_of_not_gt hn
  have hsq : wedgeMixtureRoot D F h^2≤1 := by nlinarith
  have h1f : 0<1-secantF (lowerPhysicalA F) (wedgeLogSecant D F h) := by linarith
  have hprod := mul_lt_mul_of_pos_right hb.2 h1f
  have hlinear := mul_le_mul_of_nonneg_left hr (mul_pos hb.1 h1f).le
  have hquad := mul_le_mul_of_nonneg_left hsq (ha.trans hf.1).le
  nlinarith

theorem wedgeOmega_pos {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) : 0<wedgeOmega D F h := by
  have hq := wedgeMixtureRoot_gt_one hF0 hF1 hD0 hD1 hh
  unfold wedgeOmega
  nlinarith

end LeanVerification.ReflectedWedgeCompletion
