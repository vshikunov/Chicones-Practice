import LeanVerification.ReflectedWedgeCompletion.PhysicalEnergyRatio

/-! Fixed common denominators for directional rational jets. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion

theorem scaled_three_common_denominator (s p q r u v w t : ℝ) :
    p*(s*u/t)+q*(s*v/t)+r*(s*w/t)=s*(p*u+q*v+r*w)/t := by ring

theorem scaled_two_common_denominator (s p q u v t : ℝ) :
    p*(s*u/t)+q*(s*v/t)=s*(p*u+q*v)/t := by ring

theorem quotient_jet_common_denominator (s np nq p q t : ℝ) :
    ((s*np/t)*q-p*(s*nq/t))/q^2=s*(np*q-p*nq)/(t*q^2) := by
  simp only [div_eq_mul_inv,mul_inv_rev]
  ring

theorem scaled_ratio_of_polynomial_identities {s p q n d c : ℝ}
    (hc : c≠0) (hp : p=c*n) (hq : q=c*d) : s*p/q=s*(n/d) := by
  rw [hp,hq]
  simp only [div_eq_mul_inv,mul_inv_rev]
  calc
    _ = s*(n*d⁻¹)*(c*c⁻¹) := by ring
    _ = _ := by rw [mul_inv_cancel₀ hc,mul_one]

theorem stiffness_energy_difference (p u A w N : ℝ) (hN : N≠0) :
    (p-u*N)/(4*A*w*N)=p/(4*A*w*N)-2*(u/(8*A*w)) := by
  simp only [div_eq_mul_inv,mul_inv_rev]
  have hn : N*N⁻¹=1 := mul_inv_cancel₀ hN
  calc
    _ = p*(4*A*w*N)⁻¹-u*(4*A*w)⁻¹*(N*N⁻¹) := by
      simp only [mul_inv_rev]
      ring
    _ = _ := by rw [hn];simp only [mul_one,mul_inv_rev];ring

theorem secantEnergyRatio_fraction {a f rho omega : ℝ} (hw : 1+omega≠0) :
    secantEnergyRatio a f rho omega=
      (1+f)^2*(1-a^2*rho*(1+omega))/(8*(f^2-a^2*rho)*(1+omega)) := by
  have hi := mul_inv_cancel₀ hw
  dsimp only [secantEnergyRatio]
  simp only [div_eq_mul_inv,mul_inv_rev]
  linear_combination (1+f)^2*a^2*rho*(8:ℝ)⁻¹*(f^2-a^2*rho)⁻¹*hi

end LeanVerification.ReflectedWedgeCompletion
