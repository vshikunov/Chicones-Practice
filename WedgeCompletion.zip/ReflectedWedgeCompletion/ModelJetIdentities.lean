import LeanVerification.ReflectedWedgeCompletion.RationalSigns
import LeanVerification.ReflectedWedgeCompletion.RawStiffnessJets
import LeanVerification.ReflectedWedgeCompletion.DiagonalJetModel
import LeanVerification.ReflectedWedgeCompletion.ModelNumeratorIdentities
import LeanVerification.ReflectedWedgeCompletion.ModelFractionAlgebra

/-! The certified rational model is identified with the differentiated energy
and stiffness jets. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 48000000
set_option maxRecDepth 50000
namespace LowerWeakCone
variable {a f rho omega : ℝ} (h : LowerWeakCone a f rho)
include h

theorem modelAlpha1_eq_jet : modelAlpha1 a f rho=jetAlpha1 a f rho := by
  unfold modelAlpha1 jetAlpha1 modelG
  ring

theorem modelAlpha2_eq_jet : modelAlpha2 a f rho=jetAlpha2 a f rho := by
  unfold modelAlpha2 jetAlpha2 modelG
  ring

theorem modelAlpha3_eq_jet : modelAlpha3 a f rho=jetAlpha3 a f rho := by
  unfold modelAlpha3 jetAlpha3 modelG
  ring

theorem modelAlpha4_eq_jet : modelAlpha4 a f rho=jetAlpha4 a f rho := by
  unfold modelAlpha4 jetAlpha4 modelG
  ring

theorem modelEll_eq_jet : modelEll a f rho=jetEll a f rho := by
  unfold modelEll jetEll modelG
  simp only [div_eq_mul_inv,mul_inv,sub_eq_add_neg,mul_comm rho (a^2),neg_one_mul]
  ring

theorem modelPoleFlow_eq_jet : modelPoleFlow a f rho=jetPoleFlow a f rho := by
  have hg := h.base_signs.1.ne'
  have hj : 1+f≠0 := by linarith [h.f_pos]
  have hGN : (-1 : ℝ)+rho*a^2≠0 := by
    convert neg_ne_zero.mpr hg using 1 <;> unfold modelG <;> ring
  have hGP : (1 : ℝ)+(-1)*(rho*a^2)≠0 := by
    convert hg using 1 <;> unfold modelG <;> ring
  unfold modelPoleFlow jetPoleFlow
  unfold modelG at *
  field_simp (disch := simp [hg,hj,hGN,hGP]) [hg,hj,hGN,hGP]
  <;> ring

theorem modelFZero_eq_jet : modelFZero a f rho=jetFZero a f rho := by
  have hA2 : (2:ℝ)*f^2+(-2)*(rho*a^2)=2*modelA a f rho := by
    unfold modelA
    ring
  unfold modelFZero jetFZero
  rw [hA2]
  ring

theorem modelRZero_eq_jet : modelRZero a f rho=jetRZero a f rho := by
  unfold modelRZero jetRZero modelG
  rfl

theorem modelL_transportN : modelL a f rho omega=
    transportN a f rho omega/(modelG a rho*(1+f)) := by
  have hg := h.base_signs.1.ne'
  have hj : 1+f≠0 := by linarith [h.f_pos]
  unfold modelL modelEll transportN
  field_simp (disch := simp [hg,hj]) [hg,hj]
  unfold modelG
  ring

theorem modelLambda_transportF (ho : 0≤omega) :
    modelLambda a f rho omega*diagonalTransportF a f rho=transportF a f rho omega := by
  have hg := h.base_signs.1.ne'
  have hj : 1+f≠0 := by linarith [h.f_pos]
  have hn := (transportN_pos h.a_pos (by linarith [h.a_upper]) h.f_lower h.f_upper h.rho_pos h.rho_upper ho).ne'
  unfold modelLambda
  rw [h.modelL_transportN]
  unfold diagonalTransportF modelSigma transportF
  rw [show (1:ℝ)+(-1)*(rho*a^2)=modelG a rho by unfold modelG; ring]
  unfold modelG at *
  field_simp (disch := simp [hg,hj,hn]) [hg,hj,hn]
  <;> ring

theorem modelLambda_transportRho (ho : 0≤omega) :
    modelLambda a f rho omega*diagonalTransportRho a f rho=transportRho a f rho omega := by
  have hg := h.base_signs.1.ne'
  have hj : 1+f≠0 := by linarith [h.f_pos]
  have hn := (transportN_pos h.a_pos (by linarith [h.a_upper]) h.f_lower h.f_upper h.rho_pos h.rho_upper ho).ne'
  unfold modelLambda
  rw [h.modelL_transportN]
  unfold diagonalTransportRho modelSigma transportRho
  unfold modelG at *
  field_simp (disch := simp [h.a_pos.ne',hg,hj,hn]) [h.a_pos.ne',hg,hj,hn]
  <;> ring

theorem modelOmega_transport (ho : 0≤omega) :
    -2*modelM a f rho*omega*(1+omega)/modelL a f rho omega=transportOmega a f rho omega := by
  have hg := h.base_signs.1.ne'
  have hj : 1+f≠0 := by linarith [h.f_pos]
  have hn := (transportN_pos h.a_pos (by linarith [h.a_upper]) h.f_lower h.f_upper h.rho_pos h.rho_upper ho).ne'
  rw [h.modelL_transportN]
  unfold modelM transportOmega
  unfold modelG at *
  field_simp (disch := simp [hg,hj,hn]) [hg,hj,hn]
  <;> ring

theorem jetK_eq_model (ho : 0≤omega) : jetK a f rho omega=modelK a f rho omega := by
  have hs := h.base_signs
  have ha := h.a_pos.ne'
  have hj : 1+f≠0 := by linarith [h.f_pos]
  have hw : 1+omega≠0 := by positivity
  have hg := hs.1.ne'
  have hA := hs.2.1.ne'
  have hD := hs.2.2.2.1.ne'
  have he := hs.2.2.2.2.1.ne'
  have hn := (transportN_pos h.a_pos (by linarith [h.a_upper]) h.f_lower h.f_upper h.rho_pos h.rho_upper ho).ne'
  have hAP : f^2+(-1)*(rho*a^2)=modelA a f rho := by unfold modelA; ring
  have hW4 : (4:ℝ)+4*omega=4*(1+omega) := by ring
  have hNP : (1+f)*(1+(-1)*(rho*a^2))+(a*rho)*(omega*(1+(-1)*(a*f)))=
      transportN a f rho omega := by unfold transportN; ring
  have hraw : jetK a f rho omega=
      modelStiffnessNumerator a f rho omega/(4*(1+omega)*modelA a f rho*transportN a f rho omega) := by
    change ((4+4*omega)⁻¹*(f^2+(-1)*(rho*a^2))⁻¹)*
      (((1+f)*(1+(-1)*(rho*a^2))+(a*rho)*(omega*(1+(-1)*(a*f))))⁻¹*
      modelStiffnessNumerator a f rho omega) = _
    simp only [hAP,hW4,hNP,div_eq_mul_inv,mul_inv]
    ring
  have hp : a*(1-a*f)*modelD a f rho*modelStiffnessNumerator a f rho omega =
      a*modelD a f rho*(1+f)*(modelA a f rho*(1-a^2)-(a^2*rho)*(f-a)^2)*
        (1+omega)*transportN a f rho omega +
      (1-a*f)*(1+f)*(modelA a f rho*(1-a^2)-(f-a)^2)*transportN a f rho omega +
      a*((1+a)^2*(f-a*rho)^2*(1-f^2))*modelG a rho*(1+f)*(1+omega) := by
    convert model_stiffness_numerator_identity a f rho omega using 1 <;>
      unfold modelD modelA modelG <;> ring
  have hx := stiffness_fraction_assembly a (1-a*f) (modelD a f rho) (1+f)
    (modelG a rho) (modelA a f rho) (1+omega) (transportN a f rho omega)
    (f-a) (a^2*rho) (1-a^2) ((1+a)^2*(f-a*rho)^2*(1-f^2))
    (modelStiffnessNumerator a f rho omega) ha he hD hj hg hA hw hn hp
  rw [hraw]
  unfold modelK modelKInfinity modelKOne modelKTwo modelTheta
  rw [h.modelL_transportN]
  convert hx using 1 <;> ring

theorem jetCurvature_eq_model (ho : 0≤omega) : jetCurvature a f rho omega=modelF a f rho omega := by
  have hs := h.base_signs
  have hj : 1+f≠0 := by linarith [h.f_pos]
  have hw : 1+omega≠0 := by positivity
  have hg := hs.1.ne'
  have hA := hs.2.1.ne'
  have hfa := (sub_pos.mpr h.f_lower).ne'
  have hfu := (sub_pos.mpr h.f_upper).ne'
  have hru := (sub_pos.mpr h.rho_upper).ne'
  have hn := (transportN_pos h.a_pos (by linarith [h.a_upper]) h.f_lower h.f_upper h.rho_pos h.rho_upper ho).ne'
  have hAP : f^2+(-1)*(rho*a^2)=modelA a f rho := by unfold modelA; ring
  have hW4 : (4:ℝ)+4*omega=4*(1+omega) := by ring
  have hNP : (1+f)*(1+(-1)*(rho*a^2))+(a*rho)*(omega*(1+(-1)*(a*f)))=
      transportN a f rho omega := by unfold transportN; ring
  have hraw : jetCurvature a f rho omega=
      modelCurvatureNumerator a f rho omega/(4*(1+omega)*modelA a f rho*(transportN a f rho omega)^3) := by
    change ((4+4*omega)⁻¹*(f^2+(-1)*(rho*a^2))⁻¹)*
      ((((1+f)*(1+(-1)*(rho*a^2))+(a*rho)*(omega*(1+(-1)*(a*f))))^3)⁻¹*
      modelCurvatureNumerator a f rho omega) = _
    simp only [hAP,hW4,hNP,div_eq_mul_inv,mul_inv]
    ring
  let B := 2*(f-a)*(1-f)*(1-rho)
  have hB : B≠0 := mul_ne_zero (mul_ne_zero (mul_ne_zero (by norm_num) hfa) hfu) hru
  have hFform : modelF a f rho omega =
      (1+a)*B/(4*modelA a f rho)*
        (1-weakNum00 a f rho/(B*(1+f)*(modelG a rho)^2)*omega-
          weakNum01 a f rho/(B*(1+f)^2*(modelG a rho)^2)*omega^2-
          weakNum02 a f rho/(B*(1+f)^3*(modelG a rho)^3)*omega^3-
          weakNum03 a f rho/(B*(1+f)^3*(modelG a rho)^3)*omega^4)/
        ((1+omega)*(transportN a f rho omega/(modelG a rho*(1+f)))^3) := by
    unfold modelF
    rw [h.modelL_transportN]
    unfold modelFZero modelPsi compactPsi modelAlpha1 modelAlpha2 modelAlpha3 modelAlpha4
    dsimp only [B]
    ring
  have hnum : modelCurvatureNumerator a f rho omega = (1+a)*
      (B*(1+f)^3*(modelG a rho)^3-
        weakNum00 a f rho*(1+f)^2*modelG a rho*omega-
        weakNum01 a f rho*(1+f)*modelG a rho*omega^2-
        weakNum02 a f rho*omega^3-weakNum03 a f rho*omega^4) := by
    rw [model_curvature_numerator_identity]
    dsimp only [B,modelG]
    ring
  have hx := curvature_fraction_assembly B (1+f) (modelG a rho) (modelA a f rho)
    (1+omega) (transportN a f rho omega) (1+a) omega
    (weakNum00 a f rho) (weakNum01 a f rho) (weakNum02 a f rho) (weakNum03 a f rho)
    hB hj hg hA hw hn
  rw [hraw,hFform,hx,← hnum]

end LowerWeakCone
end LeanVerification.ReflectedWedgeCompletion
