import LeanVerification.ReflectedWedgeCompletion.PhysicalTransport

/-! The rational energy/width ratio is identified with the actual normalized
physical energy, so the subsequent jet comparison concerns the physical period. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.ReflectedWedgeCompletion
open Loud ReflectedCompletion
set_option maxHeartbeats 16000000
set_option maxRecDepth 25000

def secantEnergyRatio (a f rho omega : ℝ) : ℝ :=
  (1+f)^2*(1/(1+omega)-a^2*rho)/(8*(f^2-a^2*rho))
def wedgeNormalizedEnergy (D F h : ℝ) : ℝ :=
  (h-zeroEndpointHeight D F)/(wedgeEnergyScale D F*lowerPhysicalD D)

theorem secant_potential_average {a d nu q : ℝ} (hnu : 0<nu)
    (heq : wedgePotential a d (nu*Real.exp q)=wedgePotential a d (nu*Real.exp (-q))) :
    wedgePotential a d (nu*Real.exp q)=
      d*nu^2*Real.cosh (2*q)/2+(1-d)/(1-a)*nu^(1-a)*Real.cosh ((1-a)*q)+
        1/(2*a)*nu^(-2*a)*Real.cosh (2*a*q) := by
  have hs : wedgePotential a d (nu*Real.exp q)+wedgePotential a d (nu*Real.exp (-q))=
      d*nu^2*Real.cosh (2*q)+2*(1-d)/(1-a)*nu^(1-a)*Real.cosh ((1-a)*q)+
        1/a*nu^(-2*a)*Real.cosh (2*a*q) := by
    unfold wedgePotential
    calc
      _ = d/2*((nu*Real.exp q)^2+(nu*Real.exp (-q))^2)+
          (1-d)/(1-a)*((nu*Real.exp q)^(1-a)+(nu*Real.exp (-q))^(1-a))+
          1/(2*a)*((nu*Real.exp q)^(-2*a)+(nu*Real.exp (-q))^(-2*a)) := by ring
      _ = _ := by
        rw [←Real.rpow_two (nu*Real.exp q),←Real.rpow_two (nu*Real.exp (-q)),
          secant_power_sum hnu,secant_power_sum hnu,secant_power_sum hnu]
        have he : -2*a*q= -(2*a*q) := by ring
        rw [he,Real.cosh_neg,Real.rpow_two]
        ring
  rw [←heq] at hs
  linear_combination hs/2

theorem secant_energy_hyperbolic {a d nu q B : ℝ}
    (ha : 0<a) (ha1 : a<1) (hnu : 0<nu) (hq : 0<q) (hB : 0<B) (hB2 : B^2=a*d)
    (heq : wedgePotential a d (nu*Real.exp q)=wedgePotential a d (nu*Real.exp (-q))) :
    wedgePotential a d (nu*Real.exp q)/(d*(2*nu*Real.sinh q)^2)=
      Real.cosh (2*q)/(8*Real.sinh q^2)+
        (a*(1-d)/((1-a)*B))*Real.cosh ((1-a)*q)/
          (4*(B*nu^(1+a)*Real.sinh q/Real.sinh (a*q))*Real.sinh q*Real.sinh (a*q))+
        Real.cosh (2*a*q)/
          (8*(B*nu^(1+a)*Real.sinh q/Real.sinh (a*q))^2*Real.sinh (a*q)^2) := by
  have hpow1 : nu^(1-a)=nu^2/nu^(1+a) := by
    rw [←Real.rpow_two,←Real.rpow_sub hnu]
    congr 1 <;> ring
  have hpow2 : nu^(-2*a)=nu^2/(nu^(1+a))^2 := by
    rw [←Real.rpow_two,←Real.rpow_two,←Real.rpow_mul hnu.le,←Real.rpow_sub hnu]
    congr 1 <;> ring
  have hd : d=B^2/a := (eq_div_iff ha.ne').mpr (by nlinarith [hB2])
  have hd0 : 0<d := by nlinarith [sq_pos_of_pos hB]
  have hB3 : B^3=B*(a*d) := by
    calc
      B^3=B*B^2 := by ring
      _ = _ := by rw [hB2]
  have hB4 : B^4=(a*d)^2 := by
    calc
      B^4=(B^2)^2 := by ring
      _ = _ := by rw [hB2]
  have h1a : 0<1-a := by linarith
  have hs := Real.sinh_pos_iff.mpr hq
  have hsa := Real.sinh_pos_iff.mpr (mul_pos ha hq)
  have hN := Real.rpow_pos_of_pos hnu (1+a)
  rw [secant_potential_average hnu heq,hpow1,hpow2]
  field_simp (disch := positivity)
  ring_nf
  simp only [hB2,hB3,hB4]
  ring


theorem energy_ratio_eliminate {f r Q beta K : ℝ}
    (hQ : Q≠0) (hf : 1-f≠0) (hA : f^2-r≠0)
    (hquad : f*Q^2+beta*(1-f)*Q-1=0)
    (hK : (f^2-r)*K=1-r) :
    (f^2*K+1)/8+beta*(f*K-1)/(4*Q)+(K+1)/(8*Q^2)=
      (1+f)^2*(1/Q^2-r)/(8*(f^2-r)) := by
  let P := (f^2-r)*Q^2*(f^2*K+1)+2*beta*Q*(f^2-r)*(f*K-1)+
    (f^2-r)*(K+1)-(1+f)^2*(1-r*Q^2)
  have hP : (1-f)*P=0 := by
    dsimp only [P]
    linear_combination 2*(f^2-r)*(f*K-1)*hquad-
      (1+f)*(Q^2*f^2-1)*hK
  have hP0 : P=0 := (mul_eq_zero.mp hP).resolve_left hf
  apply sub_eq_zero.mp
  calc
    _ = P/(8*Q^2*(f^2-r)) := by
      dsimp only [P]
      field_simp [hQ,hA]
      <;> ring
    _ = 0 := by rw [hP0,zero_div]

theorem hyperbolic_energy_ratio {a q Q beta : ℝ}
    (ha : 0<a) (ha1 : a<1) (hq : 0<q) (hQ : 0<Q)
    (hquad : secantF a q*Q^2+beta*(1-secantF a q)*Q-1=0) :
    Real.cosh (2*q)/(8*Real.sinh q^2)+
      beta*Real.cosh ((1-a)*q)/(4*Q*Real.sinh q*Real.sinh (a*q))+
      Real.cosh (2*a*q)/(8*Q^2*Real.sinh (a*q)^2)=
    (1+secantF a q)^2*(1/Q^2-a^2*secantRho a q)/
      (8*((secantF a q)^2-a^2*secantRho a q)) := by
  have hs := Real.sinh_pos_iff.mpr hq
  have hsa := Real.sinh_pos_iff.mpr (mul_pos ha hq)
  have hc := Real.cosh_pos (a*q)
  have hf := secantF_bounds ha ha1 hq
  have hr := secantRho_bounds ha ha1 hq
  have hA : 0<(secantF a q)^2-a^2*secantRho a q := by
    have hmul := mul_lt_mul_of_pos_left hr.2 (sq_pos_of_pos ha)
    nlinarith
  have hfeq : secantF a q=Real.sinh (a*q)*Real.cosh q/(Real.sinh q*Real.cosh (a*q)) := by
    unfold secantF secantR
    field_simp [ha.ne',hs.ne',hc.ne']
    <;> ring
  have hreq : a^2*secantRho a q=Real.sinh (a*q)^2/Real.sinh q^2 := by
    unfold secantRho
    field_simp [ha.ne',hs.ne']
    <;> ring
  let K := Real.cosh (a*q)^2/Real.sinh (a*q)^2
  have hK : ((secantF a q)^2-a^2*secantRho a q)*K=1-a^2*secantRho a q := by
    have hfirst : ((secantF a q)^2-a^2*secantRho a q)*K=
        (Real.cosh q^2-Real.cosh (a*q)^2)/Real.sinh q^2 := by
      rw [hfeq,hreq]
      dsimp only [K]
      field_simp [hs.ne',hsa.ne',hc.ne']
      <;> ring
    rw [hfirst,hreq]
    have hp : Real.cosh q^2-Real.cosh (a*q)^2=Real.sinh q^2-Real.sinh (a*q)^2 := by
      linarith [Real.cosh_sq_sub_sinh_sq q,Real.cosh_sq_sub_sinh_sq (a*q)]
    rw [hp]
    field_simp [hs.ne']
    <;> ring
  have hterm1 : Real.cosh (2*q)/(8*Real.sinh q^2)=((secantF a q)^2*K+1)/8 := by
    rw [Real.cosh_two_mul,hfeq]
    dsimp only [K]
    field_simp [hs.ne',hsa.ne',hc.ne']
    <;> ring
  have hterm2 : beta*Real.cosh ((1-a)*q)/(4*Q*Real.sinh q*Real.sinh (a*q))=
      beta*(secantF a q*K-1)/(4*Q) := by
    rw [show (1-a)*q=q-a*q by ring,Real.cosh_sub,hfeq]
    dsimp only [K]
    field_simp [hs.ne',hsa.ne',hc.ne',hQ.ne']
    <;> ring
  have hterm3 : Real.cosh (2*a*q)/(8*Q^2*Real.sinh (a*q)^2)=(K+1)/(8*Q^2) := by
    rw [show 2*a*q=2*(a*q) by ring,Real.cosh_two_mul]
    dsimp only [K]
    field_simp [hsa.ne',hQ.ne']
    <;> ring_nf <;> simp
  rw [hterm1,hterm2,hterm3]
  exact energy_ratio_eliminate hQ.ne' (by linarith : 1-secantF a q≠0) hA.ne' hquad hK

theorem wedgeNormalizedEnergy_eq_potential {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    wedgeNormalizedEnergy D F h=
      wedgePotential (lowerPhysicalA F) (lowerPhysicalD D) (wedgeRight D F h)/lowerPhysicalD D := by
  have hp := (wedge_turns_pos D F h hh).2
  have hv := (potential_branches_values D F h hh (show h∈Icc 0 h from ⟨hh.1.le,le_rfl⟩)).2
  have hR := wedgePhysical_potential_normalization D F (potentialRightPosition D F h)
    hF0 hF1 hD0 hD1 hp
  rw [hv] at hR
  change h=wedgeEnergyScale D F*
    wedgePotential (lowerPhysicalA F) (lowerPhysicalD D) (wedgeRight D F h)+zeroEndpointHeight D F at hR
  obtain ⟨ha,hau,had,hdu⟩ := wedgePhysical_parameters hF0 hF1 hD0 hD1
  have hs := wedgeEnergyScale_pos (by linarith : D<0) (by linarith : 0<F)
  unfold wedgeNormalizedEnergy
  conv_lhs => rw [hR]
  field_simp [hs.ne',(ha.trans had).ne']
  <;> ring

theorem actual_physical_energy_ratio {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    wedgeNormalizedEnergy D F h/(wedgeWidth D F h)^2=
      secantEnergyRatio (lowerPhysicalA F) (wedgeF D F h) (wedgeRho D F h) (wedgeOmega D F h) := by
  obtain ⟨ha,hau,had,hdu⟩ := wedgePhysical_parameters hF0 hF1 hD0 hD1
  have ha1 : lowerPhysicalA F<1 := by linarith
  have hF : 0<F := by linarith
  have hq := wedgeLogSecant_pos hF hh
  have hnu := wedgeGeometricMean_pos hh
  have ht := wedge_turn_decomposition hh
  have hp := (wedge_turns_same_potential D F h hF0 hF1 hD0 hD1 hh).symm
  rw [ht.1,ht.2] at hp
  have hB : 0<wedgeMixtureScale D F := Real.sqrt_pos.mpr (mul_pos ha (ha.trans had))
  have hB2 : wedgeMixtureScale D F^2=lowerPhysicalA F*lowerPhysicalD D :=
    Real.sq_sqrt (mul_pos ha (ha.trans had)).le
  have he := secant_energy_hyperbolic ha ha1 hnu hq hB hB2 hp
  have hr := hyperbolic_energy_ratio ha ha1 hq
    (by linarith [wedgeMixtureRoot_gt_one hF0 hF1 hD0 hD1 hh] : 0<wedgeMixtureRoot D F h)
    (wedgeMixtureRoot_quadratic hF0 hF1 hD0 hD1 hh)
  rw [wedgeNormalizedEnergy_eq_potential hF0 hF1 hD0 hD1 hh,div_div,ht.1,wedgeWidth_hyperbolic hh,he]
  change Real.cosh (2*wedgeLogSecant D F h)/(8*Real.sinh (wedgeLogSecant D F h)^2)+
      wedgeBeta D F*Real.cosh ((1-lowerPhysicalA F)*wedgeLogSecant D F h)/
        (4*wedgeMixtureRoot D F h*Real.sinh (wedgeLogSecant D F h)*
          Real.sinh (lowerPhysicalA F*wedgeLogSecant D F h))+
      Real.cosh (2*lowerPhysicalA F*wedgeLogSecant D F h)/
        (8*wedgeMixtureRoot D F h^2*Real.sinh (lowerPhysicalA F*wedgeLogSecant D F h)^2)=_
  rw [hr]
  unfold secantEnergyRatio wedgeF wedgeRho wedgeOmega
  congr 3 <;> ring

theorem actual_physical_energy_width_identity {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    wedgeNormalizedEnergy D F h=(wedgeWidth D F h)^2*
      secantEnergyRatio (lowerPhysicalA F) (wedgeF D F h) (wedgeRho D F h) (wedgeOmega D F h) := by
  have he := actual_physical_energy_ratio hF0 hF1 hD0 hD1 hh
  have hw := wedgeWidth_pos (by linarith : 0<F) hh
  exact (div_eq_iff (pow_ne_zero 2 hw.ne')).mp he |>.trans (mul_comm _ _)

theorem hasDerivAt_wedgeNormalizedEnergy (D F h : ℝ) :
    HasDerivAt (wedgeNormalizedEnergy D F)
      (1/(wedgeEnergyScale D F*lowerPhysicalD D)) h := by
  exact ((hasDerivAt_id h).sub_const (zeroEndpointHeight D F)).div_const _

theorem wedgeNormalizedEnergy_slope_pos {D F : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2)) :
    0<1/(wedgeEnergyScale D F*lowerPhysicalD D) := by
  obtain ⟨ha,hau,had,hdu⟩ := wedgePhysical_parameters hF0 hF1 hD0 hD1
  exact one_div_pos.mpr (mul_pos
    (wedgeEnergyScale_pos (by linarith : D<0) (by linarith : 0<F)) (ha.trans had))

end LeanVerification.ReflectedWedgeCompletion
