import LeanVerification.ReflectedWedgeCompletion.SourceCoefficientJets
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate07

/-! Polynomial numerator certificate for source coefficient 4. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 8000000
set_option maxRecDepth 50000

theorem sourceCoefficient4_numerator (a f rho : ℝ) :
    weakNum07 a f rho=
    (8*(1+a)*(f-a*rho)*a*(f-a)*(1+f)*(1-rho)*weakNum03 a f rho-
      a*(1+f)*sourceDAlphaNumerator4 a f rho+
      5*(1+a)*(f-a*rho)*a*(f-a)*(1+f)*(1-rho)*weakNum02 a f rho-
      f*sourceDAlphaNumerator3 a f rho)/2 := by
  unfold weakNum07 weakNum03 weakNum02 sourceDAlphaNumerator4 sourceDAlphaPolynomial4 sourceDAlphaNumerator3 sourceDAlphaPolynomial3
  ring

end LeanVerification.ReflectedWedgeCompletion
