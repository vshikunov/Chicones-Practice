import LeanVerification.ReflectedWedgeCompletion.RationalModel
import LeanVerification.ReflectedWedgeCompletion.ModelFractionAlgebra

/-! All scalar signs are established on the entire weak secant cone. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 18000000
set_option maxRecDepth 50000

structure LowerWeakCone (a f rho : ℝ) : Prop where
  a_pos : 0<a
  a_upper : a<1/3
  f_lower : a<f
  f_upper : f<1
  rho_pos : 0<rho
  rho_upper : rho<1
  weak : 2≤f/a+rho

namespace LowerWeakCone
variable {a f rho : ℝ} (h : LowerWeakCone a f rho)
include h

theorem f_pos : 0<f := h.a_pos.trans h.f_lower

theorem base_signs :
    0<modelG a rho ∧ 0<modelA a f rho ∧ 0<modelC a f rho ∧
    0<modelD a f rho ∧ 0<1-a*f ∧ 0<f-a*rho := by
  have ha := h.a_pos
  have hau := h.a_upper
  have hf := h.f_pos
  have haf := h.f_lower
  have hfu := h.f_upper
  have hr := h.rho_pos
  have hru := h.rho_upper
  have ha2 : a^2<1/9 := by nlinarith
  have har : a*rho<a := by nlinarith
  have haf' : a*f<a := by nlinarith
  have ha2r : a^2*rho<a^2 := mul_lt_of_lt_one_right (sq_pos_of_pos ha) hru
  have hm : a*(1+a)*rho<a*(1+a) := mul_lt_of_lt_one_right (by positivity) hru
  have hfa : 0<f-a := sub_pos.mpr haf
  have hrr : 0<1-rho := sub_pos.mpr hru
  have hc : 0<(f-a)*(2+a+a*rho)+a*(1+a)*(1-rho) := by positivity
  dsimp only [modelG,modelA,modelC,modelD]
  exact ⟨by linarith,by nlinarith, hc,by nlinarith,by linarith,by linarith⟩

theorem modelSigma_pos : 0<modelSigma f := div_pos h.f_pos (by linarith [h.f_pos])

theorem modelSigma_lt_one : modelSigma f<1 := by
  unfold modelSigma
  exact (div_lt_one (by linarith [h.f_pos])).mpr (by linarith)

theorem modelEll_pos : 0<modelEll a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  unfold modelEll
  exact div_pos (mul_pos (mul_pos h.a_pos h.rho_pos) hs.2.2.2.2.1)
    (mul_pos hs.1 (by linarith [h.f_pos]))

theorem modelSigma_sub_ell :
    modelSigma f-modelEll a f rho=(f-a*rho)/(modelG a rho*(1+f)) := by
  have hg := h.base_signs.1.ne'
  have hJ : 1+f≠0 := by linarith [h.f_pos]
  unfold modelSigma modelEll
  field_simp (disch := simp [hg,hJ]) [hg,hJ]
  unfold modelG
  ring

theorem modelEll_lt_sigma : modelEll a f rho<modelSigma f := by
  apply sub_pos.mp
  rw [h.modelSigma_sub_ell]
  exact div_pos h.base_signs.2.2.2.2.2 (mul_pos h.base_signs.1 (by linarith [h.f_pos]))

theorem modelM_eq_transport :
    modelM a f rho=(1+a)*(modelSigma f-modelEll a f rho) := by
  rw [h.modelSigma_sub_ell]
  unfold modelM
  ring

theorem modelM_pos : 0<modelM a f rho := by
  rw [h.modelM_eq_transport]
  exact mul_pos (by linarith [h.a_pos]) (sub_pos.mpr h.modelEll_lt_sigma)

theorem modelPoleFlow_pos : 0<modelPoleFlow a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hr := h.rho_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hfu : 0<1-f := sub_pos.mpr h.f_upper
  unfold modelPoleFlow
  positivity

 theorem modelAlpha1_nonneg : 0≤modelAlpha1 a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hfu : 0<1-f := sub_pos.mpr h.f_upper
  have hru : 0<1-rho := sub_pos.mpr h.rho_upper
  unfold modelAlpha1
  exact div_nonneg (weakNum00_nonneg h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak) (by positivity)

 theorem modelAlpha2_nonneg : 0≤modelAlpha2 a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hfu : 0<1-f := sub_pos.mpr h.f_upper
  have hru : 0<1-rho := sub_pos.mpr h.rho_upper
  unfold modelAlpha2
  exact div_nonneg (weakNum01_nonneg h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak) (by positivity)

 theorem modelAlpha3_nonneg : 0≤modelAlpha3 a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hfu : 0<1-f := sub_pos.mpr h.f_upper
  have hru : 0<1-rho := sub_pos.mpr h.rho_upper
  unfold modelAlpha3
  exact div_nonneg (weakNum02_nonneg h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak) (by positivity)

 theorem modelAlpha4_nonneg : 0≤modelAlpha4 a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hfu : 0<1-f := sub_pos.mpr h.f_upper
  have hru : 0<1-rho := sub_pos.mpr h.rho_upper
  unfold modelAlpha4
  exact div_nonneg (weakNum03_nonneg h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak) (by positivity)

 theorem modelE1_pos : 0<modelE1 a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hfu : 0<1-f := sub_pos.mpr h.f_upper
  have hru : 0<1-rho := sub_pos.mpr h.rho_upper
  unfold modelE1
  exact div_pos (weakNum04_pos h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak) (by positivity)

 theorem modelE2_nonneg : 0≤modelE2 a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hfu : 0<1-f := sub_pos.mpr h.f_upper
  have hru : 0<1-rho := sub_pos.mpr h.rho_upper
  unfold modelE2
  exact div_nonneg (weakNum05_nonneg h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak) (by positivity)

 theorem modelE3_nonneg : 0≤modelE3 a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hfu : 0<1-f := sub_pos.mpr h.f_upper
  have hru : 0<1-rho := sub_pos.mpr h.rho_upper
  unfold modelE3
  exact div_nonneg (weakNum06_nonneg h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak) (by positivity)

 theorem modelE4_nonneg : 0≤modelE4 a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hfu : 0<1-f := sub_pos.mpr h.f_upper
  have hru : 0<1-rho := sub_pos.mpr h.rho_upper
  unfold modelE4
  exact div_nonneg (weakNum07_nonneg h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak) (by positivity)

 theorem modelE5_nonneg : 0≤modelE5 a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hfu : 0<1-f := sub_pos.mpr h.f_upper
  have hru : 0<1-rho := sub_pos.mpr h.rho_upper
  unfold modelE5
  exact div_nonneg (weakNum08_nonneg h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak) (by positivity)

 theorem modelRZero_add_a_pos : 0<modelRZero a f rho+a := by
  have hg := h.base_signs.1
  have ha := h.a_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hru : 0<1-rho := sub_pos.mpr h.rho_upper
  have hp := div_pos (weakNum09_pos h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak)
    (show 0<a*(f-a)*(1+f)*(1-rho)*modelG a rho by positivity)
  dsimp only [modelRZero]
  linarith

 theorem modelTheta_bounds : 0≤modelTheta a f rho ∧ modelTheta a f rho<1-a^2 := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hau := h.a_upper
  have haf := h.f_lower
  have hf := h.f_pos
  have hfu := h.f_upper
  have hr := h.rho_pos
  have hru := h.rho_upper
  have ha2 : a^2<1/9 := by nlinarith
  have haf' : a*f<a := by nlinarith
  have hb : 0<2-a*(f+a) := by nlinarith
  have hfa : 0<f-a := sub_pos.mpr haf
  have hrr : 0<1-rho := sub_pos.mpr hru
  have hAunit : 0<1-a^2 := by linarith
  have hp : 0<a*(f-a)*(2-a*(f+a))+a^2*(1-a^2)*(1-rho) := by positivity
  constructor
  · exact div_nonneg (sq_nonneg _) hs.2.1.le
  · apply (div_lt_iff₀ hs.2.1).mpr
    unfold modelA
    nlinarith only [hp]

 theorem modelKInfinity_pos : 0<modelKInfinity a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ht := h.modelTheta_bounds
  have ha := h.a_pos
  have hau := h.a_upper
  have hr := h.rho_pos
  have hru := h.rho_upper
  have ha2 : a^2<1/9 := by nlinarith
  have htu : modelTheta a f rho<1 := by linarith [sq_nonneg a]
  have hprod : rho*modelTheta a f rho<1 := by
    have hm := mul_lt_mul_of_pos_left htu hr
    nlinarith
  have hm := mul_lt_mul_of_pos_left hprod (sq_pos_of_pos ha)
  unfold modelKInfinity
  exact mul_pos (div_pos (by linarith [h.f_pos]) (by linarith [hs.2.2.2.2.1])) (by nlinarith)

 theorem modelKOne_pos : 0<modelKOne a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ht := h.modelTheta_bounds
  have ha := h.a_pos
  unfold modelKOne
  exact mul_pos (div_pos (by linarith [h.f_pos]) (by positivity)) (by linarith)

 theorem modelKTwo_pos : 0<modelKTwo a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf := h.f_pos
  have hfu := h.f_upper
  have hf2 : 0<1-f^2 := by nlinarith
  unfold modelKTwo
  positivity

 theorem modelKZero_pos : 0<modelKZero a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  unfold modelKZero
  exact div_pos (mul_pos (by linarith [h.f_pos]) hs.2.2.1) (mul_pos (by norm_num) hs.2.1)

 theorem modelFZero_pos : 0<modelFZero a f rho := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf : 0<1-f := sub_pos.mpr h.f_upper
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hr : 0<1-rho := sub_pos.mpr h.rho_upper
  unfold modelFZero
  positivity

 theorem modelKZero_residues :
    modelKInfinity a f rho+modelKOne a f rho+modelKTwo a f rho=modelKZero a f rho := by
  have hs := h.base_signs
  have hp : a*modelD a f rho*(1+f)*(modelA a f rho*(1-a^2)-(a^2*rho)*(f-a)^2)+
      (1-a*f)*(1+f)*(modelA a f rho*(1-a^2)-(f-a)^2)+
      a*((1+a)^2*(f-a*rho)^2*(1-f^2))=
        a*(1-a*f)*modelD a f rho*(1+f)*modelC a f rho := by
    unfold modelA modelD modelC
    ring
  have hx := residue_fraction_assembly a (1-a*f) (modelD a f rho) (1+f)
    (modelA a f rho) (1-a^2) (a^2*rho) (f-a)
    ((1+a)^2*(f-a*rho)^2*(1-f^2)) (modelC a f rho)
    h.a_pos.ne' hs.2.2.2.2.1.ne' hs.2.2.2.1.ne' hs.2.1.ne' hp
  convert hx using 1 <;> dsimp only [modelKInfinity,modelKOne,modelKTwo,modelKZero,modelTheta] <;> ring

 theorem diagonal_chi_gap_identity :
    1-modelChiZero a f rho=weakNum10 a f rho/((1+f)*modelC a f rho) := by
  have hs := h.base_signs
  have hJ : 1+f≠0 := by linarith [h.f_pos]
  have hp : weakNum10 a f rho=(1+f)*modelC a f rho-
      2*((1+a)*(1-f)*(f-a)*(1-rho)) := by
    unfold weakNum10 modelC
    ring
  rw [hp]
  exact chi_gap_fraction_assembly (modelA a f rho) ((1+a)*(1-f)*(f-a)*(1-rho))
    (1+f) (modelC a f rho) hs.2.1.ne' hJ hs.2.2.1.ne'

 theorem diagonal_half_target_identity :
    modelRZero a f rho+(1/2:ℝ)*(1-modelChiZero a f rho)^2 =
      weakNum11 a f rho/(2*a*(f-a)*(1+f)^2*(1-rho)*modelG a rho*(modelC a f rho)^2) := by
  have hs := h.base_signs
  have hJ : 1+f≠0 := by linarith [h.f_pos]
  have hfa := (sub_pos.mpr h.f_lower).ne'
  have hru := (sub_pos.mpr h.rho_upper).ne'
  have hp : weakNum11 a f rho=
      2*(1+f)*(modelC a f rho)^2*weakNum09 a f rho-
      2*a^2*(f-a)*(1+f)^2*(1-rho)*modelG a rho*(modelC a f rho)^2+
      a*(f-a)*(1-rho)*modelG a rho*(weakNum10 a f rho)^2 := by
    unfold weakNum11 weakNum09 weakNum10 modelG modelC
    ring
  rw [h.diagonal_chi_gap_identity,hp]
  exact half_target_fraction_assembly a (f-a) (1+f) (1-rho) (modelG a rho) (modelC a f rho)
    (weakNum09 a f rho) (weakNum10 a f rho) h.a_pos.ne' hfa hJ hru hs.1.ne' hs.2.2.1.ne'

 theorem modelChiZero_lt_one : modelChiZero a f rho<1 := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have hp : 0<weakNum10 a f rho/((1+f)*modelC a f rho) :=
    div_pos (weakNum10_pos h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak)
      (mul_pos (by linarith [h.f_pos]) hs.2.2.1)
  rw [←h.diagonal_chi_gap_identity] at hp
  linarith

 theorem diagonal_half_target_pos :
    0<modelRZero a f rho+(1/2:ℝ)*(1-modelChiZero a f rho)^2 := by
  have hs := h.base_signs
  have hGs := hs.1
  have hAs := hs.2.1
  have hCs := hs.2.2.1
  have hDs := hs.2.2.2.1
  have hEs := hs.2.2.2.2.1
  have hFs := hs.2.2.2.2.2
  have ha := h.a_pos
  have hf := h.f_pos
  have hfa : 0<f-a := sub_pos.mpr h.f_lower
  have hru : 0<1-rho := sub_pos.mpr h.rho_upper
  rw [h.diagonal_half_target_identity]
  exact div_pos (weakNum11_pos h.a_pos h.a_upper h.f_lower h.f_upper h.rho_pos h.rho_upper h.weak) (by positivity)

end LowerWeakCone
end LeanVerification.ReflectedWedgeCompletion
