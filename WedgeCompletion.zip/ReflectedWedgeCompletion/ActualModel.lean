import LeanVerification.ReflectedWedgeCompletion.FullModelCurvatureJet
import LeanVerification.ReflectedWedgeCompletion.GlobalRationalComparison
import LeanVerification.ReflectedWedgeCompletion.ModelJetIdentities
import LeanVerification.ReflectedWedgeCompletion.DiagonalJet00
import LeanVerification.ReflectedWedgeCompletion.DiagonalJet01
import LeanVerification.ReflectedWedgeCompletion.DiagonalJet02
import LeanVerification.ReflectedWedgeCompletion.DiagonalJet03
import LeanVerification.ReflectedWedgeCompletion.DiagonalJet04
import LeanVerification.ReflectedWedgeCompletion.DiagonalJet05
import LeanVerification.ReflectedWedgeCompletion.SourceCoefficient01
import LeanVerification.ReflectedWedgeCompletion.SourceCoefficient02
import LeanVerification.ReflectedWedgeCompletion.SourceCoefficient03
import LeanVerification.ReflectedWedgeCompletion.SourceCoefficient04
import LeanVerification.ReflectedWedgeCompletion.SourceCoefficient05
import LeanVerification.ReflectedWedgeCompletion.SourceDerivative

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.ReflectedWedgeCompletion
open Loud ReflectedCompletion
set_option maxHeartbeats 16000000
set_option maxRecDepth 50000

def wedgeU (D F h : ℝ) : ℝ :=
  secantEnergyRatio (lowerPhysicalA F) (wedgeF D F h) (wedgeRho D F h) (wedgeOmega D F h)
def wedgeK (D F h : ℝ) : ℝ :=
  modelK (lowerPhysicalA F) (wedgeF D F h) (wedgeRho D F h) (wedgeOmega D F h)
def wedgeCurvature (D F h : ℝ) : ℝ :=
  modelF (lowerPhysicalA F) (wedgeF D F h) (wedgeRho D F h) (wedgeOmega D F h)
def wedgeChi (D F h : ℝ) : ℝ := wedgeCurvature D F h/wedgeK D F h
def wedgeR (D F h : ℝ) : ℝ :=
  modelR (lowerPhysicalA F) (wedgeF D F h) (wedgeRho D F h) (wedgeOmega D F h)

theorem actual_physical_weakCone {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    LowerWeakCone (lowerPhysicalA F) (wedgeF D F h) (wedgeRho D F h) := by
  obtain ⟨ha,hau,had,hdu⟩ := wedgePhysical_parameters hF0 hF1 hD0 hD1
  have hq := wedgeLogSecant_pos (by linarith : 0<F) hh
  have hf := secantF_bounds ha (by linarith : lowerPhysicalA F<1) hq
  have hr := secantRho_bounds ha (by linarith : lowerPhysicalA F<1) hq
  have hc := actual_secant_weak_cone ha hau.le hq
  refine ⟨ha,hau,hf.1,hf.2,hr.1,hr.2,?_⟩
  dsimp only [wedgeF,wedgeRho,secantF]
  simpa only [mul_div_cancel_left₀ _ ha.ne'] using hc

theorem hasDerivAt_wedgeU {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    HasDerivAt (wedgeU D F) (wedgeRate D F h*(wedgeK D F h-2*wedgeU D F h)) h := by
  have hc := actual_physical_weakCone hF0 hF1 hD0 hD1 hh
  have hw := wedgeOmega_pos hF0 hF1 hD0 hD1 hh
  have ht := actual_physical_secant_transport hF0 hF1 hD0 hD1 hh
  have hn := transportN_pos hc.a_pos (by linarith [hc.a_upper]) hc.f_lower hc.f_upper hc.rho_pos hc.rho_upper hw.le
  have hd := secantEnergyRatio_hasDerivAt hc.a_pos.ne'
    (show 1+wedgeF D F h≠0 by linarith [hc.f_pos]) (show 1+wedgeOmega D F h≠0 by positivity)
    hc.base_signs.2.1.ne' hn.ne' ht.1 ht.2.1 ht.2.2
  rw [hc.jetK_eq_model hw.le] at hd
  exact hd

theorem hasDerivAt_wedgeK {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    HasDerivAt (wedgeK D F) (-wedgeRate D F h*wedgeCurvature D F h) h := by
  have hc := actual_physical_weakCone hF0 hF1 hD0 hD1 hh
  have hw := wedgeOmega_pos hF0 hF1 hD0 hD1 hh
  have ht := actual_physical_secant_transport hF0 hF1 hD0 hD1 hh
  have hn := transportN_pos hc.a_pos (by linarith [hc.a_upper]) hc.f_lower hc.f_upper hc.rho_pos hc.rho_upper hw.le
  have hd := jetK_hasDerivAt hc.a_pos.ne'
    (show 1+wedgeF D F h≠0 by linarith [hc.f_pos]) (show 1+wedgeOmega D F h≠0 by positivity)
    hc.base_signs.2.1.ne' hn.ne' ht.1 ht.2.1 ht.2.2
  rw [hc.jetCurvature_eq_model hw.le] at hd
  have he : wedgeK D F =ᶠ[𝓝 h]
      fun x => jetK (lowerPhysicalA F) (wedgeF D F x) (wedgeRho D F x) (wedgeOmega D F x) := by
    filter_upwards [(isOpen_admissibleEnergy D F).mem_nhds hh] with x hx
    exact ((actual_physical_weakCone hF0 hF1 hD0 hD1 hx).jetK_eq_model
      (wedgeOmega_pos hF0 hF1 hD0 hD1 hx).le).symm
  exact hd.congr_of_eventuallyEq he

theorem hasDerivAt_wedgeCurvature {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) (hcurv : 0<wedgeCurvature D F h) :
    HasDerivAt (wedgeCurvature D F)
      (wedgeRate D F h*wedgeCurvature D F h*(wedgeR D F h-1)) h := by
  have hc := actual_physical_weakCone hF0 hF1 hD0 hD1 hh
  have hw := wedgeOmega_pos hF0 hF1 hD0 hD1 hh
  have ht := actual_physical_secant_transport hF0 hF1 hD0 hD1 hh
  have hchi : 0<modelChi (lowerPhysicalA F) (wedgeF D F h) (wedgeRho D F h) (wedgeOmega D F h) :=
    div_pos hcurv (hc.modelK_pos hw.le)
  have hPsi := hc.modelPsi_pos_of_chi_pos hw.le hchi
  have hCone : ∀ᶠ x in 𝓝 h, LowerWeakCone (lowerPhysicalA F) (wedgeF D F x) (wedgeRho D F x) := by
    filter_upwards [(isOpen_admissibleEnergy D F).mem_nhds hh] with x hx
    exact actual_physical_weakCone hF0 hF1 hD0 hD1 hx
  exact modelF_hasDerivAt_full hc hCone hw.le hPsi ht.1 ht.2.1 ht.2.2

theorem wedgeK_pos {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) : 0<wedgeK D F h :=
  (actual_physical_weakCone hF0 hF1 hD0 hD1 hh).modelK_pos
    (wedgeOmega_pos hF0 hF1 hD0 hD1 hh).le

theorem wedgeChi_lt_one {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) : wedgeChi D F h<1 := by
  have hc := actual_physical_weakCone hF0 hF1 hD0 hD1 hh
  exact (hc.modelChi_le_diagonal (wedgeOmega_pos hF0 hF1 hD0 hD1 hh).le).trans_lt
    hc.modelChiZero_lt_one

theorem wedge_global_half_target {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) (hchi : 0<wedgeChi D F h) :
    0<wedgeR D F h+(1/2:ℝ)*(1-wedgeChi D F h)^2 :=
  (actual_physical_weakCone hF0 hF1 hD0 hD1 hh).global_model_half_target
    (wedgeOmega_pos hF0 hF1 hD0 hD1 hh).le hchi

end LeanVerification.ReflectedWedgeCompletion
