import LeanVerification.ReflectedWedgeCompletion.PhysicalQuadratic
import LeanVerification.ReflectedWedgeCompletion.TransportAlgebra

/-! Differentiation of the actual physical secants, including the moving
mixture root.  The transport is with respect to the true energy derivative. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.ReflectedWedgeCompletion
open Loud ReflectedCompletion
set_option maxHeartbeats 12000000
set_option maxRecDepth 20000

def wedgeF (D F h : ℝ) : ℝ := secantF (lowerPhysicalA F) (wedgeLogSecant D F h)
def wedgeRho (D F h : ℝ) : ℝ := secantRho (lowerPhysicalA F) (wedgeLogSecant D F h)
def wedgeRate (D F h : ℝ) : ℝ := deriv (wedgeWidth D F) h/wedgeWidth D F h

theorem differentiableAt_wedgeLogSecant {D F h : ℝ} (hh : AdmissibleEnergy D F h) :
    DifferentiableAt ℝ (wedgeLogSecant D F) h := by
  have hp := wedge_turns_pos D F h hh
  have ht := analyticAt_wedge_turns hh
  exact ((ht.2.differentiableAt.log hp.2.ne').sub
    (ht.1.differentiableAt.log hp.1.ne')).div_const 2

theorem differentiableAt_wedgeGeometricMean {D F h : ℝ} (hh : AdmissibleEnergy D F h) :
    DifferentiableAt ℝ (wedgeGeometricMean D F) h := by
  have hp := wedge_turns_pos D F h hh
  have ht := analyticAt_wedge_turns hh
  exact (ht.2.differentiableAt.mul ht.1.differentiableAt).sqrt (mul_pos hp.2 hp.1).ne'

theorem differentiableAt_wedgeMixtureRoot {D F h : ℝ}
    (ha : 0<lowerPhysicalA F) (hF : 0<F) (hh : AdmissibleEnergy D F h) :
    DifferentiableAt ℝ (wedgeMixtureRoot D F) h := by
  have hq := differentiableAt_wedgeLogSecant hh
  have hn := differentiableAt_wedgeGeometricMean hh
  exact (((differentiableAt_const _).mul (hn.rpow_const (Or.inl (wedgeGeometricMean_pos hh).ne'))).mul
    hq.sinh).div ((hq.const_mul _).sinh)
      (Real.sinh_pos_iff.mpr (mul_pos ha (wedgeLogSecant_pos hF hh))).ne'

theorem analyticAt_wedgeWidth {D F h : ℝ} (hh : AdmissibleEnergy D F h) :
    AnalyticAt ℝ (wedgeWidth D F) h := by
  have hw : AnalyticAt ℝ (physicalEnergyWidth D F) h :=
    (analyticAt_physicalEnergyWidth_joint D F h hh).comp_of_eq
      (f := fun t : ℝ => ((D,F),t)) (analyticAt_const.prod analyticAt_id) rfl
  convert analyticAt_const.mul hw using 1
  ext t
  exact wedgeWidth_eq D F t

theorem wedgeWidth_deriv_pos {D F h : ℝ} (hF : 0<F) (hh : AdmissibleEnergy D F h) :
    0<deriv (wedgeWidth D F) h := by
  have hw := hasDerivAt_physicalEnergyWidth D F h hh
  have he : wedgeWidth D F=(fun t => F*physicalEnergyWidth D F t) := by ext t;exact wedgeWidth_eq D F t
  rw [he,(hw.const_mul F).deriv]
  have hd := physicalEnergyWidth_deriv_pos_of_width_chart D F h hh
  rw [hw.deriv] at hd
  exact mul_pos hF hd

theorem wedgeRate_pos {D F h : ℝ} (hF : 0<F) (hh : AdmissibleEnergy D F h) :
    0<wedgeRate D F h := div_pos (wedgeWidth_deriv_pos hF hh) (wedgeWidth_pos hF hh)

theorem wedge_width_log_derivative {D F h : ℝ} (hF : 0<F) (hh : AdmissibleEnergy D F h) :
    wedgeRate D F h=
      deriv (wedgeGeometricMean D F) h/wedgeGeometricMean D F h+
        Real.cosh (wedgeLogSecant D F h)/Real.sinh (wedgeLogSecant D F h)*
          deriv (wedgeLogSecant D F) h := by
  have hn := (differentiableAt_wedgeGeometricMean hh).hasDerivAt
  have hq := (differentiableAt_wedgeLogSecant hh).hasDerivAt
  have hd := (hn.const_mul 2).mul hq.sinh
  have he : (fun t => 2*wedgeGeometricMean D F t*Real.sinh (wedgeLogSecant D F t)) =ᶠ[𝓝 h]
      wedgeWidth D F := by
    filter_upwards [(isOpen_admissibleEnergy D F).mem_nhds hh] with t ht
    exact (wedgeWidth_hyperbolic ht).symm
  have hwd := (hd.congr_of_eventuallyEq he.symm).deriv
  unfold wedgeRate
  rw [hwd,wedgeWidth_hyperbolic hh]
  field_simp [(wedgeGeometricMean_pos hh).ne',
    (Real.sinh_pos_iff.mpr (wedgeLogSecant_pos hF hh)).ne']
  <;> ring

theorem wedge_root_log_derivative {D F h : ℝ}
    (ha : 0<lowerPhysicalA F) (hF : 0<F) (hh : AdmissibleEnergy D F h)
    (hB : 0<wedgeMixtureScale D F) :
    deriv (wedgeMixtureRoot D F) h/wedgeMixtureRoot D F h=
      (1+lowerPhysicalA F)*deriv (wedgeGeometricMean D F) h/wedgeGeometricMean D F h+
        (Real.cosh (wedgeLogSecant D F h)/Real.sinh (wedgeLogSecant D F h)-
          lowerPhysicalA F*Real.cosh (lowerPhysicalA F*wedgeLogSecant D F h)/
            Real.sinh (lowerPhysicalA F*wedgeLogSecant D F h))*deriv (wedgeLogSecant D F) h := by
  have hn := (differentiableAt_wedgeGeometricMean hh).hasDerivAt
  have hq := (differentiableAt_wedgeLogSecant hh).hasDerivAt
  have hnu := wedgeGeometricMean_pos hh
  have hs := Real.sinh_pos_iff.mpr (wedgeLogSecant_pos hF hh)
  have hsa := Real.sinh_pos_iff.mpr (mul_pos ha (wedgeLogSecant_pos hF hh))
  have hp := hn.rpow_const (p := 1+lowerPhysicalA F) (Or.inl hnu.ne')
  have hd := ((hp.const_mul (wedgeMixtureScale D F)).mul hq.sinh).div
    ((hq.const_mul (lowerPhysicalA F)).sinh) hsa.ne'
  have hder : deriv (wedgeMixtureRoot D F) h = _ := hd.deriv
  have hpow : wedgeGeometricMean D F h^(1+lowerPhysicalA F-1)=
      wedgeGeometricMean D F h^(1+lowerPhysicalA F)/wedgeGeometricMean D F h := by
    rw [Real.rpow_sub hnu,Real.rpow_one]
  rw [hder]
  dsimp only [wedgeMixtureRoot]
  rw [hpow]
  field_simp [hB.ne',hnu.ne',hs.ne',hsa.ne',
    (Real.rpow_pos_of_pos hnu (1+lowerPhysicalA F)).ne']
  <;> ring

def wedgeSecantRate (D F h : ℝ) : ℝ :=
  lowerPhysicalA F*Real.cosh (lowerPhysicalA F*wedgeLogSecant D F h)/
    Real.sinh (lowerPhysicalA F*wedgeLogSecant D F h)*(1+wedgeF D F h)*
      deriv (wedgeLogSecant D F) h

def wedgeRootRate (D F h : ℝ) : ℝ :=
  deriv (wedgeMixtureRoot D F) h/wedgeMixtureRoot D F h

theorem wedge_log_transport_identity {D F h : ℝ}
    (ha : 0<lowerPhysicalA F) (hF : 0<F) (hh : AdmissibleEnergy D F h)
    (hB : 0<wedgeMixtureScale D F) :
    (1+lowerPhysicalA F)*wedgeRate D F h=wedgeRootRate D F h+wedgeSecantRate D F h := by
  have hs := Real.sinh_pos_iff.mpr (wedgeLogSecant_pos hF hh)
  have hsa := Real.sinh_pos_iff.mpr (mul_pos ha (wedgeLogSecant_pos hF hh))
  have hc := Real.cosh_pos (lowerPhysicalA F*wedgeLogSecant D F h)
  have hcot : Real.cosh (wedgeLogSecant D F h)/Real.sinh (wedgeLogSecant D F h)=
      wedgeF D F h*Real.cosh (lowerPhysicalA F*wedgeLogSecant D F h)/
        Real.sinh (lowerPhysicalA F*wedgeLogSecant D F h) := by
    unfold wedgeF secantF secantR
    field_simp [ha.ne',hs.ne',hsa.ne',hc.ne']
    <;> ring
  unfold wedgeRootRate wedgeSecantRate
  rw [wedge_width_log_derivative hF hh,wedge_root_log_derivative ha hF hh hB,hcot]
  ring

theorem hasDerivAt_wedgeF {D F h : ℝ}
    (ha : 0<lowerPhysicalA F) (ha1 : lowerPhysicalA F<1)
    (hF : 0<F) (hh : AdmissibleEnergy D F h) :
    HasDerivAt (wedgeF D F)
      (wedgeSecantRate D F h*(wedgeF D F h-lowerPhysicalA F*wedgeRho D F h)*
        (1-wedgeF D F h)/(1-(lowerPhysicalA F)^2*wedgeRho D F h)) h := by
  have hq := (differentiableAt_wedgeLogSecant hh).hasDerivAt
  have hd := ((secantR_flow ha ha1 (wedgeLogSecant_pos hF hh)).const_mul (lowerPhysicalA F)).comp h hq
  convert hd using 1
  unfold wedgeSecantRate wedgeF wedgeRho secantF
  ring

theorem hasDerivAt_wedgeRho {D F h : ℝ}
    (ha : 0<lowerPhysicalA F) (ha1 : lowerPhysicalA F<1)
    (hF : 0<F) (hh : AdmissibleEnergy D F h) :
    HasDerivAt (wedgeRho D F)
      (-2*wedgeSecantRate D F h*(wedgeF D F h-lowerPhysicalA F)*wedgeRho D F h/
        (lowerPhysicalA F*(1+wedgeF D F h))) h := by
  have hq := (differentiableAt_wedgeLogSecant hh).hasDerivAt
  have hf := secantF_bounds ha ha1 (wedgeLogSecant_pos hF hh)
  have hj : 1+wedgeF D F h≠0 := by unfold wedgeF;linarith
  have hd := (secantRho_flow ha ha1 (wedgeLogSecant_pos hF hh)).comp h hq
  convert hd using 1
  have hsa := Real.sinh_pos_iff.mpr (mul_pos ha (wedgeLogSecant_pos hF hh))
  unfold wedgeF secantF at hj
  unfold wedgeSecantRate wedgeF wedgeRho secantF
  field_simp [ha.ne',hj,hsa.ne']
  <;> ring

theorem wedge_quadratic_log_derivative {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    (1+wedgeF D F h+wedgeF D F h*wedgeOmega D F h)*wedgeRootRate D F h+
      wedgeOmega D F h*deriv (wedgeF D F) h/(1-wedgeF D F h)=0 := by
  obtain ⟨ha,hau,had,hdu⟩ := wedgePhysical_parameters hF0 hF1 hD0 hD1
  have hF : 0<F := by linarith
  have hfd := (hasDerivAt_wedgeF ha (by linarith : lowerPhysicalA F<1) hF hh).differentiableAt.hasDerivAt
  have hQd := (differentiableAt_wedgeMixtureRoot ha hF hh).hasDerivAt
  have hd := ((hfd.mul (hQd.pow 2)).add
    (((hfd.const_sub 1).mul hQd).const_mul (wedgeBeta D F))).sub_const 1
  have he : (fun t => wedgeF D F t*wedgeMixtureRoot D F t^2+
      wedgeBeta D F*(1-wedgeF D F t)*wedgeMixtureRoot D F t-1) =ᶠ[𝓝 h] fun _ => (0 : ℝ) := by
    filter_upwards [(isOpen_admissibleEnergy D F).mem_nhds hh] with t ht
    exact wedgeMixtureRoot_quadratic hF0 hF1 hD0 hD1 ht
  have he' : (fun t => wedgeF D F t*wedgeMixtureRoot D F t^2+
      wedgeBeta D F*((1-wedgeF D F t)*wedgeMixtureRoot D F t)-1) =ᶠ[𝓝 h] fun _ => (0 : ℝ) := by
    filter_upwards [he] with t ht
    convert ht using 1 <;> ring
  have hdz := (hd.congr_of_eventuallyEq he'.symm).unique (hasDerivAt_const h (0 : ℝ))
  have hp := wedgeMixtureRoot_quadratic hF0 hF1 hD0 hD1 hh
  have hQ : wedgeMixtureRoot D F h≠0 := by linarith [wedgeMixtureRoot_gt_one hF0 hF1 hD0 hD1 hh]
  have hf := secantF_bounds ha (by linarith : lowerPhysicalA F<1) (wedgeLogSecant_pos hF hh)
  have h1f : 1-wedgeF D F h≠0 := by unfold wedgeF;linarith
  change wedgeF D F h*wedgeMixtureRoot D F h^2+
    wedgeBeta D F*(1-wedgeF D F h)*wedgeMixtureRoot D F h-1=0 at hp
  unfold wedgeRootRate wedgeOmega
  field_simp [hQ,h1f]
  linear_combination wedgeMixtureRoot D F h*(1-wedgeF D F h)*hdz-
    ((1-wedgeF D F h)*deriv (wedgeMixtureRoot D F) h-
      wedgeMixtureRoot D F h*deriv (wedgeF D F) h)*hp

theorem hasDerivAt_wedgeOmega {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    HasDerivAt (wedgeOmega D F) (2*(1+wedgeOmega D F h)*wedgeRootRate D F h) h := by
  obtain ⟨ha,hau,had,hdu⟩ := wedgePhysical_parameters hF0 hF1 hD0 hD1
  have hd := ((differentiableAt_wedgeMixtureRoot ha (by linarith : 0<F) hh).hasDerivAt.pow 2).sub_const 1
  have hQ : wedgeMixtureRoot D F h≠0 := by linarith [wedgeMixtureRoot_gt_one hF0 hF1 hD0 hD1 hh]
  convert hd using 1
  unfold wedgeRootRate wedgeOmega
  field_simp [hQ]
  <;> ring

theorem actual_physical_secant_transport {D F h : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hh : AdmissibleEnergy D F h) :
    HasDerivAt (wedgeF D F)
        (wedgeRate D F h*transportF (lowerPhysicalA F) (wedgeF D F h) (wedgeRho D F h) (wedgeOmega D F h)) h ∧
      HasDerivAt (wedgeRho D F)
        (wedgeRate D F h*transportRho (lowerPhysicalA F) (wedgeF D F h) (wedgeRho D F h) (wedgeOmega D F h)) h ∧
      HasDerivAt (wedgeOmega D F)
        (wedgeRate D F h*transportOmega (lowerPhysicalA F) (wedgeF D F h) (wedgeRho D F h) (wedgeOmega D F h)) h := by
  obtain ⟨ha,hau,had,hdu⟩ := wedgePhysical_parameters hF0 hF1 hD0 hD1
  have ha1 : lowerPhysicalA F<1 := by linarith
  have hF : 0<F := by linarith
  have hq := wedgeLogSecant_pos hF hh
  have hf := secantF_bounds ha ha1 hq
  have hr := secantRho_bounds ha ha1 hq
  change lowerPhysicalA F<wedgeF D F h ∧ wedgeF D F h<1 at hf
  change 0<wedgeRho D F h ∧ wedgeRho D F h<1 at hr
  have hw := wedgeOmega_pos hF0 hF1 hD0 hD1 hh
  have hn := transportN_pos ha ha1 hf.1 hf.2 hr.1 hr.2 hw.le
  have hg := secant_g_pos ha ha1 hq
  have hfd := hasDerivAt_wedgeF ha ha1 hF hh
  have hrd := hasDerivAt_wedgeRho ha ha1 hF hh
  have hwd := hasDerivAt_wedgeOmega hF0 hF1 hD0 hD1 hh
  have hs := solve_secant_transport ha.ne' (show 1+wedgeF D F h≠0 by linarith)
    (show 1-wedgeF D F h≠0 by linarith) hg.ne' hn.ne'
    (wedge_log_transport_identity ha hF hh (Real.sqrt_pos.mpr (mul_pos ha (ha.trans had))))
    (wedge_quadratic_log_derivative hF0 hF1 hD0 hD1 hh) hfd.deriv hrd.deriv hwd.deriv
  exact ⟨hs.1 ▸ hfd.differentiableAt.hasDerivAt,
    hs.2.1 ▸ hrd.differentiableAt.hasDerivAt,hs.2.2 ▸ hwd.differentiableAt.hasDerivAt⟩

end LeanVerification.ReflectedWedgeCompletion
