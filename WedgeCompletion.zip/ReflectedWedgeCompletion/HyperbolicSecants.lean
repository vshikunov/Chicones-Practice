import LeanVerification.AbelPositiveTransfer
import Mathlib.Analysis.Convex.Deriv
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Deriv

/-! Hyperbolic geometry of actual lower-family equal-energy secants.
The weak cone is proved from the actual hyperbolic functions, rather than
assumed as an independent algebraic parameter condition. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 6000

def secantR (a q : ℝ) : ℝ :=
  Real.sinh (a*q)*Real.cosh q/(a*Real.sinh q*Real.cosh (a*q))

def secantRho (a q : ℝ) : ℝ :=
  (Real.sinh (a*q)/(a*Real.sinh q))^2

def secantF (a q : ℝ) : ℝ := a*secantR a q

theorem hasDerivAt_tanh_explicit (q : ℝ) :
    HasDerivAt Real.tanh (1/(Real.cosh q)^2) q := by
  have hd := (Real.hasDerivAt_sinh q).div (Real.hasDerivAt_cosh q) (Real.cosh_pos q).ne'
  convert hd using 1
  · ext x
    exact Real.tanh_eq_sinh_div_cosh x
  · have he := Real.cosh_sq_sub_sinh_sq q
    congr 1
    nlinarith

theorem tanh_strictMono : StrictMono Real.tanh := by
  apply strictMono_of_deriv_pos
  intro q
  rw [(hasDerivAt_tanh_explicit q).deriv]
  exact div_pos zero_lt_one (sq_pos_of_pos (Real.cosh_pos q))

theorem sinh_strictConvex_nonneg : StrictConvexOn ℝ (Ici (0 : ℝ)) Real.sinh := by
  apply StrictMonoOn.strictConvexOn_of_deriv (convex_Ici 0) Real.continuous_sinh.continuousOn
  simpa only [Real.deriv_sinh, interior_Ici] using
    Real.cosh_strictMonoOn.mono (Ioi_subset_Ici_self : Ioi (0 : ℝ) ⊆ Ici 0)

theorem tanh_strictConcave_nonneg : StrictConcaveOn ℝ (Ici (0 : ℝ)) Real.tanh := by
  apply StrictAntiOn.strictConcaveOn_of_deriv (convex_Ici 0)
    (fun x _ => (hasDerivAt_tanh_explicit x).continuousAt.continuousWithinAt)
  intro x hx y hy hxy
  rw [(hasDerivAt_tanh_explicit x).deriv, (hasDerivAt_tanh_explicit y).deriv]
  have hcos := Real.cosh_strictMonoOn (interior_subset hx) (interior_subset hy) hxy
  apply one_div_lt_one_div_of_lt (sq_pos_of_pos (Real.cosh_pos x))
  nlinarith [Real.cosh_pos x, Real.cosh_pos y]

theorem sinh_scaled_lt {a q : ℝ} (ha : 0<a) (ha1 : a<1) (hq : 0<q) :
    Real.sinh (a*q)<a*Real.sinh q := by
  have hc := sinh_strictConvex_nonneg.2 (show (0 : ℝ)∈Ici 0 by simp)
    (show q∈Ici 0 from hq.le) hq.ne (show 0<1-a by linarith) ha (by ring : 1-a+a=1)
  simpa only [smul_eq_mul,mul_zero,zero_add,Real.sinh_zero] using hc

theorem tanh_scaled_gt {a q : ℝ} (ha : 0<a) (ha1 : a<1) (hq : 0<q) :
    a*Real.tanh q<Real.tanh (a*q) := by
  have hc := tanh_strictConcave_nonneg.2 (show (0 : ℝ)∈Ici 0 by simp)
    (show q∈Ici 0 from hq.le) hq.ne (show 0<1-a by linarith) ha (by ring : 1-a+a=1)
  simpa only [smul_eq_mul,mul_zero,zero_add,Real.tanh_zero] using hc

theorem secantR_gt_one {a q : ℝ} (ha : 0<a) (ha1 : a<1) (hq : 0<q) :
    1<secantR a q := by
  have hsq : 0<Real.sinh q := Real.sinh_pos_iff.mpr hq
  have hca := Real.cosh_pos (a*q)
  have hcq := Real.cosh_pos q
  have hc := tanh_scaled_gt ha ha1 hq
  rw [Real.tanh_eq_sinh_div_cosh,Real.tanh_eq_sinh_div_cosh] at hc
  have hc' : a*Real.sinh q*Real.cosh (a*q)<Real.sinh (a*q)*Real.cosh q := by
    apply (div_lt_div_iff₀ hcq hca).mp
    simpa only [mul_div_assoc] using hc
  apply (lt_div_iff₀ (mul_pos (mul_pos ha hsq) hca)).mpr
  simpa only [one_mul] using hc'

theorem secantRho_bounds {a q : ℝ} (ha : 0<a) (ha1 : a<1) (hq : 0<q) :
    0<secantRho a q ∧ secantRho a q<1 := by
  have hsq : 0<Real.sinh q := Real.sinh_pos_iff.mpr hq
  have hsa : 0<Real.sinh (a*q) := Real.sinh_pos_iff.mpr (mul_pos ha hq)
  have hz : 0<Real.sinh (a*q)/(a*Real.sinh q) := div_pos hsa (mul_pos ha hsq)
  have hb : Real.sinh (a*q)/(a*Real.sinh q)<1 :=
    (div_lt_one (mul_pos ha hsq)).mpr (sinh_scaled_lt ha ha1 hq)
  exact ⟨sq_pos_of_pos hz,by dsimp only [secantRho]; nlinarith⟩

theorem secantF_bounds {a q : ℝ} (ha : 0<a) (ha1 : a<1) (hq : 0<q) :
    a<secantF a q ∧ secantF a q<1 := by
  have hsq : 0<Real.sinh q := Real.sinh_pos_iff.mpr hq
  have hca := Real.cosh_pos (a*q)
  have hcq := Real.cosh_pos q
  have hne : a≠0 := ha.ne'
  refine ⟨?_,?_⟩
  · dsimp only [secantF]
    nlinarith [secantR_gt_one ha ha1 hq]
  · have hq' : a*q<q := by nlinarith
    have hh := tanh_strictMono hq'
    rw [Real.tanh_eq_sinh_div_cosh,Real.tanh_eq_sinh_div_cosh] at hh
    have hcross := (div_lt_div_iff₀ hca hcq).mp hh
    have heq : secantF a q = Real.sinh (a*q)*Real.cosh q/(Real.sinh q*Real.cosh (a*q)) := by
      unfold secantF secantR
      field_simp [hne,hsq.ne',hca.ne']
      <;> ring
    rw [heq]
    exact (div_lt_one (mul_pos hsq hca)).mpr hcross


theorem secant_g_pos {a q : ℝ} (ha : 0<a) (ha1 : a<1) (hq : 0<q) :
    0<1-a^2*secantRho a q := by
  have hp := secantRho_bounds ha ha1 hq
  have ha2 : a^2<1 := by nlinarith
  have hm := mul_lt_mul_of_pos_left hp.2 (sq_pos_of_pos ha)
  nlinarith

theorem secantR_flow {a q : ℝ} (ha : 0<a) (ha1 : a<1) (hq : 0<q) :
    HasDerivAt (secantR a)
      (a*Real.cosh (a*q)/Real.sinh (a*q) *
        (1+secantF a q)*(secantR a q-secantRho a q)*(1-secantF a q)/
          (1-a^2*secantRho a q)) q := by
  have hsq : 0<Real.sinh q := Real.sinh_pos_iff.mpr hq
  have hsa : 0<Real.sinh (a*q) := Real.sinh_pos_iff.mpr (mul_pos ha hq)
  have hca := Real.cosh_pos (a*q)
  have hcp := Real.cosh_pos q
  have hg := secant_g_pos ha ha1 hq
  have hsaq : Real.sinh (a*q)<Real.sinh q := Real.sinh_lt_sinh.mpr (by nlinarith)
  have hm : -Real.sinh q+Real.sinh (a*q)≠0 := by linarith
  have hp : Real.sinh q+Real.sinh (a*q)≠0 := (add_pos hsq hsa).ne'
  have hgeq : 1-a^2*secantRho a q = (Real.sinh q^2-Real.sinh (a*q)^2)/Real.sinh q^2 := by
    unfold secantRho
    field_simp [ha.ne',hsq.ne']
    <;> ring
  have hgn : Real.sinh q^2-Real.sinh (a*q)^2≠0 := by nlinarith
  have hd := (((Real.hasDerivAt_sinh (a*q)).comp q ((hasDerivAt_id q).const_mul a)).mul
      (Real.hasDerivAt_cosh q)).div
    (((Real.hasDerivAt_sinh q).const_mul a).mul
      ((Real.hasDerivAt_cosh (a*q)).comp q ((hasDerivAt_id q).const_mul a)))
      (mul_pos (mul_pos ha hsq) hca).ne'
  have halg :
      ((a*Real.cosh (a*q)*Real.cosh q+Real.sinh (a*q)*Real.sinh q)*
          (a*Real.sinh q*Real.cosh (a*q))-
        (Real.sinh (a*q)*Real.cosh q)*
          (a*Real.cosh q*Real.cosh (a*q)+a^2*Real.sinh q*Real.sinh (a*q)))/
            (a*Real.sinh q*Real.cosh (a*q))^2 -
      (a*Real.cosh (a*q)/Real.sinh (a*q) *
        (1+secantF a q)*(secantR a q-secantRho a q)*(1-secantF a q)/
          (1-a^2*secantRho a q)) =
      -Real.sinh (a*q)*(Real.cosh q*a*Real.sinh (a*q)-Real.sinh q*Real.cosh (a*q))*
        (Real.cosh q^2-Real.sinh q^2-Real.cosh (a*q)^2+Real.sinh (a*q)^2)/
        (Real.sinh q*a*Real.cosh (a*q)^2*(-Real.sinh q+Real.sinh (a*q))*
          (Real.sinh q+Real.sinh (a*q))) := by
    rw [hgeq]
    unfold secantF secantR secantRho
    field_simp [ha.ne',hsq.ne',hsa.ne',hca.ne',hgn,hm,hp]
    linear_combination (a^7*Real.cosh (a*q)^5*Real.sinh (a*q)^2*Real.sinh q^7*
      (Real.sinh q^2-Real.sinh (a*q)^2)*(Real.cosh (a*q)*Real.sinh q-a*Real.cosh q*Real.sinh (a*q)))*
        (Real.cosh_sq_sub_sinh_sq q)
  have hz : Real.cosh q^2-Real.sinh q^2-Real.cosh (a*q)^2+Real.sinh (a*q)^2=0 := by
    linarith [Real.cosh_sq_sub_sinh_sq q,Real.cosh_sq_sub_sinh_sq (a*q)]
  rw [hz,mul_zero,zero_div] at halg
  convert hd using 1
  dsimp only [Function.comp_apply,id_eq]
  convert (sub_eq_zero.mp halg).symm using 1 <;> ring

theorem secantRho_flow {a q : ℝ} (ha : 0<a) (ha1 : a<1) (hq : 0<q) :
    HasDerivAt (secantRho a)
      (-2*a*Real.cosh (a*q)/Real.sinh (a*q)*(secantR a q-1)*secantRho a q) q := by
  have hsq : 0<Real.sinh q := Real.sinh_pos_iff.mpr hq
  have hsa : 0<Real.sinh (a*q) := Real.sinh_pos_iff.mpr (mul_pos ha hq)
  have hca := Real.cosh_pos (a*q)
  have hd := ((((Real.hasDerivAt_sinh (a*q)).comp q ((hasDerivAt_id q).const_mul a))).div
    ((Real.hasDerivAt_sinh q).const_mul a) (mul_pos ha hsq).ne').pow 2
  convert hd using 1
  dsimp only [secantRho,secantR,id_eq,Function.comp_apply]
  field_simp [ha.ne',hsq.ne',hsa.ne',hca.ne']
  <;> ring


theorem secant_center_limits {a : ℝ} (ha : 0<a) :
    Tendsto (secantR a) (𝓝[>] (0 : ℝ)) (𝓝 1) ∧
      Tendsto (secantRho a) (𝓝[>] (0 : ℝ)) (𝓝 1) := by
  have hsa : Tendsto (fun q : ℝ => Real.sinh (a*q)/q) (𝓝[>] 0) (𝓝 a) := by
    have hd := ((Real.hasDerivAt_sinh (a*0)).comp 0 ((hasDerivAt_id (0 : ℝ)).const_mul a)).tendsto_slope_zero_right
    simpa only [Function.comp_apply,id_eq,add_zero,zero_add,mul_zero,Real.sinh_zero,
      sub_zero,Real.cosh_zero,mul_one,one_mul,smul_eq_mul,mul_comm,div_eq_mul_inv] using hd
  have hs : Tendsto (fun q : ℝ => Real.sinh q/q) (𝓝[>] 0) (𝓝 1) := by
    have hd := (Real.hasDerivAt_sinh (0 : ℝ)).tendsto_slope_zero_right
    simpa only [zero_add,Real.sinh_zero,sub_zero,Real.cosh_zero,smul_eq_mul,mul_comm,
      div_eq_mul_inv] using hd
  have hc : Tendsto Real.cosh (𝓝[>] (0 : ℝ)) (𝓝 1) := by
    simpa only [Real.cosh_zero] using (Real.continuous_cosh.continuousAt (x := (0 : ℝ))).tendsto.mono_left nhdsWithin_le_nhds
  have hca : Tendsto (fun q : ℝ => Real.cosh (a*q)) (𝓝[>] (0 : ℝ)) (𝓝 1) := by
    have hcont : Continuous (fun q : ℝ => Real.cosh (a*q)) := Real.continuous_cosh.comp (continuous_const.mul continuous_id)
    simpa using hcont.continuousAt.tendsto.mono_left (show 𝓝[>] (0 : ℝ) ≤ 𝓝 0 from nhdsWithin_le_nhds)
  have hquot : Tendsto (fun q : ℝ => Real.sinh (a*q)/(a*Real.sinh q)) (𝓝[>] 0) (𝓝 1) := by
    have ht := hsa.div (hs.const_mul a) (by simpa using ha.ne')
    simp only [mul_one,div_self ha.ne'] at ht
    apply ht.congr'
    filter_upwards [self_mem_nhdsWithin] with q hq
    have hq' : q≠0 := (show 0<q from hq).ne'
    field_simp [hq']
    <;> ring
  refine ⟨?_,?_⟩
  · have ht := (hquot.mul hc).div hca (by norm_num)
    simp only [one_mul,one_div_one] at ht
    apply ht.congr'
    filter_upwards [] with q
    dsimp only [Pi.div_apply]
    unfold secantR
    ring
  · simpa only [secantRho,one_pow] using hquot.pow 2

def secantWeakGap (a q : ℝ) : ℝ := secantR a q+secantRho a q-2

theorem secantWeakGap_flow {a q : ℝ} (ha : 0<a) (ha1 : a<1) (hq : 0<q) :
    HasDerivAt (secantWeakGap a)
      (a*Real.cosh (a*q)/(Real.sinh (a*q)*(1-a^2*secantRho a q)) *
        (2*a^2*(secantR a q-1)*(secantWeakGap a q)^2 +
          (-3*a^2*(secantR a q-1)^2+(6*a^2-2)*(secantR a q-1)+a^2-1)*secantWeakGap a q +
          2*(secantR a q-1)^2*(1-4*a^2))) q := by
  have hd := ((secantR_flow ha ha1 hq).add (secantRho_flow ha ha1 hq)).sub_const 2
  have hs : Real.sinh (a*q)≠0 := (Real.sinh_pos_iff.mpr (mul_pos ha hq)).ne'
  have hg := (secant_g_pos ha ha1 hq).ne'
  convert hd using 1
  unfold secantWeakGap secantF
  field_simp [hs,hg]
  <;> ring

theorem secantWeakGap_deriv_pos_of_nonpos {a q : ℝ}
    (ha : 0<a) (hau : a≤1/3) (hq : 0<q) (hgap : secantWeakGap a q≤0) :
    0<deriv (secantWeakGap a) q := by
  have ha1 : a<1 := by linarith
  rw [(secantWeakGap_flow ha ha1 hq).deriv]
  have hd : 0<secantR a q-1 := sub_pos.mpr (secantR_gt_one ha ha1 hq)
  have ha2 : a^2≤1/9 := by nlinarith
  have hB : -3*a^2*(secantR a q-1)^2+(6*a^2-2)*(secantR a q-1)+a^2-1<0 := by
    have hsq := sq_nonneg (secantR a q-1)
    have hm : (6*a^2-2)*(secantR a q-1)≤0 := mul_nonpos_of_nonpos_of_nonneg (by linarith) hd.le
    have hn : -3*a^2*(secantR a q-1)^2≤0 := mul_nonpos_of_nonpos_of_nonneg (by nlinarith [sq_nonneg a]) hsq
    linarith
  have hfirst : 0≤2*a^2*(secantR a q-1)*(secantWeakGap a q)^2 := by positivity
  have hsecond : 0≤(-3*a^2*(secantR a q-1)^2+(6*a^2-2)*(secantR a q-1)+a^2-1)*secantWeakGap a q :=
    mul_nonneg_of_nonpos_of_nonpos hB.le hgap
  have hthird : 0<2*(secantR a q-1)^2*(1-4*a^2) :=
    mul_pos (mul_pos (by norm_num) (sq_pos_of_pos hd)) (by linarith)
  have hp : 0<a*Real.cosh (a*q)/(Real.sinh (a*q)*(1-a^2*secantRho a q)) :=
    div_pos (mul_pos ha (Real.cosh_pos _))
      (mul_pos (Real.sinh_pos_iff.mpr (mul_pos ha hq)) (secant_g_pos ha ha1 hq))
  exact mul_pos hp (by linarith)

theorem actual_secant_weak_cone {a q : ℝ}
    (ha : 0<a) (hau : a≤1/3) (hq : 0<q) : 2≤secantR a q+secantRho a q := by
  have ha1 : a<1 := by linarith
  let z := secantWeakGap a
  let K := fun x => InverseWidthAbel.positiveSquare (-z x)
  have hdiff : ∀ x, 0<x → DifferentiableAt ℝ z x :=
    fun x hx => (secantWeakGap_flow ha ha1 hx).differentiableAt
  have hder : ∀ x, 0<x → HasDerivAt K ((2*max (-z x) 0)*(-deriv z x)) x := by
    intro x hx
    exact (InverseWidthAbel.hasDerivAt_positiveSquare (-z x)).comp x ((hdiff x hx).hasDerivAt.neg)
  have hanti : AntitoneOn K (Ioi 0) := by
    apply antitoneOn_of_hasDerivWithinAt_nonpos (convex_Ioi 0)
    · intro x hx
      exact (hder x hx).continuousAt.continuousWithinAt
    · intro x hx
      exact (hder x (by simpa only [interior_Ioi,mem_Ioi] using hx)).hasDerivWithinAt
    · intro x hx
      have hx' : 0<x := by simpa only [interior_Ioi,mem_Ioi] using hx
      by_cases hz : 0< -z x
      · have hp := secantWeakGap_deriv_pos_of_nonpos ha hau hx' (by dsimp only [z] at hz; linarith)
        exact mul_nonpos_of_nonneg_of_nonpos (by positivity) (by dsimp only [z]; linarith)
      · rw [max_eq_right (le_of_not_gt hz),mul_zero,zero_mul]
  have hzlim : Tendsto z (𝓝[>] (0 : ℝ)) (𝓝 0) := by
    have hs := secant_center_limits ha
    simpa only [z,secantWeakGap,show (1:ℝ)+1-2=0 by norm_num] using (hs.1.add hs.2).sub_const 2
  have hKlim : Tendsto K (𝓝[>] (0 : ℝ)) (𝓝 0) := by
    have hzneg : Tendsto (fun x => -z x) (𝓝[>] (0 : ℝ)) (𝓝 0) := by simpa only [neg_zero] using hzlim.neg
    have hp := (InverseWidthAbel.hasDerivAt_positiveSquare (0 : ℝ)).continuousAt.tendsto.comp hzneg
    simpa only [K,neg_zero,InverseWidthAbel.positiveSquare,max_self,zero_pow two_ne_zero] using hp
  have hK : K q≤0 := by
    apply ge_of_tendsto hKlim
    filter_upwards [self_mem_nhdsWithin,nhdsWithin_le_nhds (Iio_mem_nhds hq)] with x hx hxq
    exact hanti hx hq hxq.le
  by_contra hn
  have hzq : 0< -z q := by dsimp only [z,secantWeakGap]; linarith [lt_of_not_ge hn]
  have hp : 0<K q := by
    dsimp only [K,InverseWidthAbel.positiveSquare]
    rw [max_eq_left hzq.le]
    exact sq_pos_of_pos hzq
  linarith

end LeanVerification.ReflectedWedgeCompletion
