import LeanVerification.ReflectedCompletion.LowerEnergyPhysicalNormalization
import LeanVerification.Loud.InverseWidthJets
import LeanVerification.Loud.InverseWidthAbelPeriod

/-! Positive affine normalization for the physical lower wedge.  The formulas
are identities for the original Loud potential and retain its physical time. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.ReflectedWedgeCompletion
open Loud ReflectedCompletion
set_option maxHeartbeats 4000000

def wedgePotential (a d u : ℝ) : ℝ :=
  d*u^2/2+(1-d)/(1-a)*u^(1-a)+1/(2*a)*u^(-2*a)
def wedgeEnergyScale (D F : ℝ) : ℝ := -D/F

theorem wedgePhysical_parameters {D F : ℝ}
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2)) :
    0<lowerPhysicalA F ∧ lowerPhysicalA F<1/3 ∧
      lowerPhysicalA F<lowerPhysicalD D ∧ lowerPhysicalD D<1 := by
  have hF : 0<F := by linarith
  have hDn : 0< -D := by linarith
  dsimp only [lowerPhysicalA,lowerPhysicalD]
  refine ⟨?_,?_,?_,?_⟩
  · have hi : 1<1/F := (lt_div_iff₀ hF).mpr (by linarith)
    linarith
  · have hi : 1/F<4/3 := (div_lt_iff₀ hF).mpr (by linarith)
    linarith
  · apply (lt_div_iff₀ hDn).mpr
    apply (mul_lt_mul_iff_of_pos_right hF).mp
    have he : (1/F-1)*(-D)*F=(1-F)*(-D) := by field_simp
    rw [he]
    nlinarith
  · exact (div_lt_one hDn).mpr (by linarith)

theorem wedgeEnergyScale_pos {D F : ℝ} (hD : D<0) (hF : 0<F) :
    0<wedgeEnergyScale D F := div_pos (neg_pos.mpr hD) hF

theorem wedgePotential_t_form (a d : ℝ) {u : ℝ} (hu : 0<u) :
    wedgePotential a d u = u^2*(d/2+(1-d)/(1-a)*lowerT a u+1/(2*a)*(lowerT a u)^2) := by
  obtain ⟨h1,h2,h3,h4,h5⟩ := lower_rpow_identities a hu
  unfold wedgePotential
  rw [h2,h3]
  ring

theorem wedgePhysical_potential_at_w (D F w : ℝ)
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2)) (hw : 0<w) :
    potential D F w=wedgeEnergyScale D F*
      wedgePotential (lowerPhysicalA F) (lowerPhysicalD D) (w^F)+zeroEndpointHeight D F := by
  obtain ⟨ha,hau,had,hdu⟩ := wedgePhysical_parameters hF0 hF1 hD0 hD1
  have hF : 0<F := by linarith
  have hd : 0<lowerPhysicalD D := ha.trans had
  have ht : lowerT (lowerPhysicalA F) (w^F)=1/w := by
    unfold lowerT lowerPhysicalA
    rw [←Real.rpow_mul hw.le]
    have he : F*(-(1/F-1)-1)=(-1 : ℝ) := by field_simp
    rw [he,Real.rpow_neg_one,one_div]
  have hp := BoundaryAssembly.potential_minus_endpoint_factorization D F w hw
    (by linarith) (by linarith) (by linarith)
  have he : (w^F)^2=w^(2*F-2)*w^2 := by
    rw [←Real.rpow_two,←Real.rpow_mul hw.le]
    calc
      w^(F*2)=w^((2*F-2)+2) := by congr 1;ring
      _ = _ := by rw [Real.rpow_add hw,Real.rpow_two]
  rw [wedgePotential_t_form _ _ (Real.rpow_pos_of_pos hw _),ht,he]
  have hDn : D≠0 := by linarith
  have h2F : 2*F-1≠0 := by linarith
  have h2Fm : 2*F-2≠0 := by linarith
  have h1F : 1-F≠0 := by linarith
  have hFm : 1-lowerPhysicalA F≠0 := by linarith
  have hak : lowerPhysicalA F=(1-F)/F := by unfold lowerPhysicalA;field_simp
  have hpk : 1-lowerPhysicalA F=(2*F-1)/F := by unfold lowerPhysicalA;field_simp;ring
  have hc0 : wedgeEnergyScale D F*lowerPhysicalD D/2=(D+1)/(2*F) := by
    unfold wedgeEnergyScale lowerPhysicalD
    field_simp [hDn,hF.ne',h2F,h2Fm,h1F]
    <;> ring
  have hc1 : wedgeEnergyScale D F*(1-lowerPhysicalD D)/(1-lowerPhysicalA F)=
      -(2*D+1)/(2*F-1) := by
    rw [hpk]
    unfold wedgeEnergyScale lowerPhysicalD
    field_simp [hDn,hF.ne',h2F,h2Fm,h1F]
    <;> ring
  have hc2 : wedgeEnergyScale D F/(2*lowerPhysicalA F)=D/(2*F-2) := by
    rw [hak]
    unfold wedgeEnergyScale
    field_simp [hF.ne',h1F,h2Fm]
    <;> ring
  have hc : wedgeEnergyScale D F*(w^(2*F-2)*w^2*
      (lowerPhysicalD D/2+(1-lowerPhysicalD D)/(1-lowerPhysicalA F)*(1/w)+
        1/(2*lowerPhysicalA F)*(1/w)^2)) =
      w^(2*F-2)*((D+1)/(2*F)*w^2-(2*D+1)/(2*F-1)*w+D/(2*F-2)) := by
    calc
      _ = w^(2*F-2)*(wedgeEnergyScale D F*lowerPhysicalD D/2*w^2+
          wedgeEnergyScale D F*(1-lowerPhysicalD D)/(1-lowerPhysicalA F)*w+
          wedgeEnergyScale D F/(2*lowerPhysicalA F)) := by
        field_simp [hw.ne']
        <;> ring
      _ = _ := by rw [hc0,hc1,hc2];ring
  rw [hc]
  dsimp only [BoundaryAssembly.exteriorQuadratic] at hp
  linear_combination hp

theorem wedgePhysical_potential_normalization (D F X : ℝ)
    (hF0 : 3/4<F) (hF1 : F<1) (hD0 : -F<D) (hD1 : D< -(1/2))
    (hX : mechanicalDomain F X) :
    potential D F (inversePosition F X)=wedgeEnergyScale D F*
      wedgePotential (lowerPhysicalA F) (lowerPhysicalD D) (1+F*X)+zeroEndpointHeight D F := by
  rw [wedgePhysical_potential_at_w D F _ hF0 hF1 hD0 hD1 (inversePosition_pos F X hX)]
  rw [←RegionalReal.affineAux_eq_rpow F X hX]
  rfl

end LeanVerification.ReflectedWedgeCompletion
