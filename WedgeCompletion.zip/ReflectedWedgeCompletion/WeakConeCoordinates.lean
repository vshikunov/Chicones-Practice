import Mathlib.Data.Real.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity

/-! Two bounded coordinate boxes cover every actual weak-cone secant. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 1200000

theorem weakCone_coordinate_boxes {a f rho : ℝ}
    (ha : 0<a) (hau : a<1/3) (haf : a<f) (hf : f<1)
    (hrho : 0<rho) (hrhou : rho<1) (hcone : 2≤f/a+rho) :
    (∃ t z : ℝ, 0<t ∧ t≤1 ∧ 0≤z ∧ z<1 ∧
      f=a*(1+t) ∧ rho=1-t+t*z) ∨
    (∃ t z : ℝ, 0≤t ∧ t<1 ∧ 0<z ∧ z<1 ∧
      f=2*a+(1-2*a)*t ∧ rho=z) := by
  by_cases hnear : f≤2*a
  · left
    let t := f/a-1
    let z := (rho+t-1)/t
    have ht : 0<t := by
      dsimp only [t]
      exact sub_pos.mpr ((one_lt_div ha).mpr haf)
    have htu : t≤1 := by
      dsimp only [t]
      have hd := (div_le_iff₀ ha).mpr hnear
      linarith
    have hz : 0≤z := div_nonneg (by dsimp only [t]; linarith) ht.le
    have hzu : z<1 := (div_lt_one ht).mpr (by linarith)
    refine ⟨t,z,ht,htu,hz,hzu,?_,?_⟩
    · dsimp only [t]
      field_simp [ha.ne']
      <;> ring
    · dsimp only [z]
      field_simp [ht.ne']
      <;> ring
  · right
    have hden : 0<1-2*a := by linarith
    let t := (f-2*a)/(1-2*a)
    have ht : 0≤t := div_nonneg (by linarith) hden.le
    have htu : t<1 := (div_lt_one hden).mpr (by linarith)
    refine ⟨t,rho,ht,htu,hrho,hrhou,?_,rfl⟩
    dsimp only [t]
    field_simp [hden.ne']
    <;> ring

theorem weakCone_polynomial_nonneg {P : ℝ → ℝ → ℝ → ℝ}
    (hnear : ∀ a t z, 0<a → a<1/3 → 0<t → t≤1 → 0≤z → z<1 →
      0≤P a (a*(1+t)) (1-t+t*z))
    (hfar : ∀ a t z, 0<a → a<1/3 → 0≤t → t<1 → 0<z → z<1 →
      0≤P a (2*a+(1-2*a)*t) z)
    {a f rho : ℝ} (ha : 0<a) (hau : a<1/3) (haf : a<f) (hf : f<1)
    (hrho : 0<rho) (hrhou : rho<1) (hcone : 2≤f/a+rho) : 0≤P a f rho := by
  rcases weakCone_coordinate_boxes ha hau haf hf hrho hrhou hcone with
    ⟨t,z,ht,htu,hz,hzu,hf',hrho'⟩ | ⟨t,z,ht,htu,hz,hzu,hf',hrho'⟩
  · rw [hf',hrho']
    exact hnear a t z ha hau ht htu hz hzu
  · rw [hf',hrho']
    exact hfar a t z ha hau ht htu hz hzu

theorem weakCone_polynomial_pos {P : ℝ → ℝ → ℝ → ℝ}
    (hnear : ∀ a t z, 0<a → a<1/3 → 0<t → t≤1 → 0≤z → z<1 →
      0<P a (a*(1+t)) (1-t+t*z))
    (hfar : ∀ a t z, 0<a → a<1/3 → 0≤t → t<1 → 0<z → z<1 →
      0<P a (2*a+(1-2*a)*t) z)
    {a f rho : ℝ} (ha : 0<a) (hau : a<1/3) (haf : a<f) (hf : f<1)
    (hrho : 0<rho) (hrhou : rho<1) (hcone : 2≤f/a+rho) : 0<P a f rho := by
  rcases weakCone_coordinate_boxes ha hau haf hf hrho hrhou hcone with
    ⟨t,z,ht,htu,hz,hzu,hf',hrho'⟩ | ⟨t,z,ht,htu,hz,hzu,hf',hrho'⟩
  · rw [hf',hrho']
    exact hnear a t z ha hau ht htu hz hzu
  · rw [hf',hrho']
    exact hfar a t z ha hau ht htu hz hzu

end LeanVerification.ReflectedWedgeCompletion
