import LeanVerification.ReflectedWedgeCompletion.SourceCoefficientJets
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate08

/-! Polynomial numerator certificate for source coefficient 5. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 8000000
set_option maxRecDepth 50000

theorem sourceCoefficient5_numerator (a f rho : ℝ) :
    weakNum08 a f rho=
    7*(1+a)*(f-a*rho)*(f-a)*(1+f)*(1-rho)*weakNum03 a f rho-
      f*sourceDAlphaNumerator4 a f rho := by
  unfold weakNum08 weakNum03 sourceDAlphaNumerator4 sourceDAlphaPolynomial4
  ring

end LeanVerification.ReflectedWedgeCompletion
