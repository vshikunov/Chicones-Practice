import LeanVerification.ReflectedWedgeCompletion.RationalSigns
import LeanVerification.ReflectedWedgeCompletion.SourceCoefficientPolynomial01

/-! Exact source identity 1, with one fixed denominator and opaque
polynomial numerators throughout the rational cancellation. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 50000

namespace LowerWeakCone
variable {a f rho : ℝ} (h : LowerWeakCone a f rho)
include h

theorem sourceCoefficient1_identity : modelV1 a f rho=
    2*modelM a f rho*modelAlpha1 a f rho-jetDAlpha1 a f rho := by
  have ha := h.a_pos.ne'
  have hj : 1+f≠0 := by linarith [h.f_pos]
  have hg := h.base_signs.1.ne'
  have hfa := (sub_pos.mpr h.f_lower).ne'
  have hfu := (sub_pos.mpr h.f_upper).ne'
  have hru := (sub_pos.mpr h.rho_upper).ne'
  rw [sourceDAlpha1_fraction]
  unfold modelV1 modelE1 modelM modelAlpha1 
  rw [sourceCoefficient1_numerator]
  unfold sourceDAlphaDenominator1 modelG at *
  generalize weakNum00 a f rho=A1
  generalize sourceDAlphaNumerator1 a f rho=N1
  generalize f-a=q at *
  generalize 1-f=t at *
  generalize 1+f=j at *
  generalize 1-rho=r at *
  generalize 1-a^2*rho=g at *
  field_simp [ha,hj,hg,hfa,hfu,hru]
  <;> ring

end LowerWeakCone
end LeanVerification.ReflectedWedgeCompletion
