import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate00
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate01
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate02
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate03
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate04
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate05
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate06
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate07
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate08
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate09
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate10
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate11
import LeanVerification.ReflectedWedgeCompletion.CompactSourceComparison

/-! Exact rational stiffness and curvature model for the lower-family secants.
The coefficients are explicit rational functions.  Their signs are obtained
from the separately checked finite polynomial certificates. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 16000000
set_option maxRecDepth 50000

def modelG (a rho : ℝ) : ℝ := 1-a^2*rho
def modelA (a f rho : ℝ) : ℝ := f^2-a^2*rho
def modelC (a f rho : ℝ) : ℝ :=
  (f-a)*(2+a+a*rho)+a*(1+a)*(1-rho)
def modelD (a f rho : ℝ) : ℝ := 1+f-a*(1+a)*rho
def modelEll (a f rho : ℝ) : ℝ :=
  a*rho*(1-a*f)/(modelG a rho*(1+f))
def modelSigma (f : ℝ) : ℝ := f/(1+f)
def modelM (a f rho : ℝ) : ℝ :=
  (1+a)*(f-a*rho)/(modelG a rho*(1+f))
def modelL (a f rho omega : ℝ) : ℝ := 1+modelEll a f rho*omega
def modelLambda (a f rho omega : ℝ) : ℝ :=
  (1+modelSigma f*omega)/modelL a f rho omega

def modelAlpha1 (a f rho : ℝ) : ℝ :=
  weakNum00 a f rho/(2*(f-a)*(1-f)*(1+f)*(1-rho)*(modelG a rho)^2)
def modelAlpha2 (a f rho : ℝ) : ℝ :=
  weakNum01 a f rho/(2*(f-a)*(1-f)*(1+f)^2*(1-rho)*(modelG a rho)^2)
def modelAlpha3 (a f rho : ℝ) : ℝ :=
  weakNum02 a f rho/(2*(f-a)*(1-f)*(1+f)^3*(1-rho)*(modelG a rho)^3)
def modelAlpha4 (a f rho : ℝ) : ℝ :=
  weakNum03 a f rho/(2*(f-a)*(1-f)*(1+f)^3*(1-rho)*(modelG a rho)^3)

def modelE1 (a f rho : ℝ) : ℝ :=
  weakNum04 a f rho/(2*a*(f-a)^2*(1-f)*(1+f)^2*(1-rho)^2*(modelG a rho)^3)
def modelE2 (a f rho : ℝ) : ℝ :=
  weakNum05 a f rho/(a*(f-a)^2*(1-f)*(1+f)^3*(1-rho)^2*(modelG a rho)^3)
def modelE3 (a f rho : ℝ) : ℝ :=
  weakNum06 a f rho/(2*a*(f-a)^2*(1-f)*(1+f)^4*(1-rho)^2*(modelG a rho)^4)
def modelE4 (a f rho : ℝ) : ℝ :=
  weakNum07 a f rho/(a*(f-a)^2*(1-f)*(1+f)^5*(1-rho)^2*(modelG a rho)^4)
def modelE5 (a f rho : ℝ) : ℝ :=
  weakNum08 a f rho/(2*(f-a)^2*(1-f)*(1+f)^5*(1-rho)^2*(modelG a rho)^4)

def modelV1 (a f rho : ℝ) : ℝ := modelE1 a f rho-modelM a f rho
def modelV2 (a f rho : ℝ) : ℝ := modelE2 a f rho+modelM a f rho*modelAlpha1 a f rho
def modelV3 (a f rho : ℝ) : ℝ := modelE3 a f rho+modelM a f rho*modelAlpha2 a f rho
def modelV4 (a f rho : ℝ) : ℝ := modelE4 a f rho+modelM a f rho*modelAlpha3 a f rho
def modelV5 (a f rho : ℝ) : ℝ := modelE5 a f rho+modelM a f rho*modelAlpha4 a f rho

def modelPoleFlow (a f rho : ℝ) : ℝ :=
  (1+a)*rho/(modelG a rho^2*(1+f)^2)*
    (a*(1+a)*(f-a*rho)*(1-f)+2*(1-a*f)*(f-a))

def modelTheta (a f rho : ℝ) : ℝ := (f-a)^2/modelA a f rho

def modelKInfinity (a f rho : ℝ) : ℝ :=
  (1+f)/(4*(1-a*f))*(1-a^2-a^2*rho*modelTheta a f rho)
def modelKOne (a f rho : ℝ) : ℝ :=
  (1+f)/(4*a*modelD a f rho)*(1-a^2-modelTheta a f rho)
def modelKTwo (a f rho : ℝ) : ℝ :=
  (1+a)^2*(f-a*rho)^2*(1-f^2)/
    (4*modelA a f rho*(1-a*f)*modelD a f rho)

def modelK (a f rho omega : ℝ) : ℝ :=
  modelKInfinity a f rho+modelKOne a f rho/(1+omega)+
    modelKTwo a f rho/modelL a f rho omega

def modelKZero (a f rho : ℝ) : ℝ :=
  (1+f)*modelC a f rho/(4*modelA a f rho)
def modelFZero (a f rho : ℝ) : ℝ :=
  (1+a)*(1-f)*(f-a)*(1-rho)/(2*modelA a f rho)
def modelChiZero (a f rho : ℝ) : ℝ := modelFZero a f rho/modelKZero a f rho

def modelRZero (a f rho : ℝ) : ℝ :=
  weakNum09 a f rho/(a*(f-a)*(1+f)*(1-rho)*modelG a rho)-a

def modelPsi (a f rho omega : ℝ) : ℝ :=
  compactPsi (modelAlpha1 a f rho) (modelAlpha2 a f rho)
    (modelAlpha3 a f rho) (modelAlpha4 a f rho) omega

def modelF (a f rho omega : ℝ) : ℝ :=
  modelFZero a f rho*modelPsi a f rho omega/((1+omega)*modelL a f rho omega^3)
def modelChi (a f rho omega : ℝ) : ℝ := modelF a f rho omega/modelK a f rho omega

def modelSource (a f rho omega : ℝ) : ℝ :=
  compactSource (modelM a f rho) (modelEll a f rho) (modelSigma f) (modelPoleFlow a f rho)
    (modelAlpha1 a f rho) (modelAlpha2 a f rho) (modelAlpha3 a f rho) (modelAlpha4 a f rho)
    (modelV1 a f rho) (modelV2 a f rho) (modelV3 a f rho) (modelV4 a f rho) (modelV5 a f rho) omega

def modelR (a f rho omega : ℝ) : ℝ :=
  1+modelLambda a f rho omega*(modelRZero a f rho-1)+modelSource a f rho omega

end LeanVerification.ReflectedWedgeCompletion
