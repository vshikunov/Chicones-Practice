import LeanVerification.ReflectedWedgeCompletion.RationalSigns

/-! A global inverse-width comparison on the full weak secant cone.
The proof does not divide the energy range into compact and outer secants. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 18000000
set_option maxRecDepth 50000
namespace LowerWeakCone
variable {a f rho omega : ℝ} (h : LowerWeakCone a f rho)
include h

theorem modelL_bounds (ho : 0≤omega) :
    0<modelL a f rho omega ∧ modelL a f rho omega≤1+omega := by
  have he := h.modelEll_pos
  have heu := h.modelEll_lt_sigma.trans h.modelSigma_lt_one
  unfold modelL
  constructor
  · positivity
  · nlinarith

theorem modelLambda_ge_one (ho : 0≤omega) : 1≤modelLambda a f rho omega := by
  have hL := (h.modelL_bounds ho).1
  unfold modelLambda
  apply (le_div_iff₀ hL).mpr
  dsimp only [modelL]
  nlinarith [h.modelEll_lt_sigma]

theorem modelK_pos (ho : 0≤omega) : 0<modelK a f rho omega := by
  have hI := h.modelKInfinity_pos
  have h1 := h.modelKOne_pos
  have h2 := h.modelKTwo_pos
  have hL := (h.modelL_bounds ho).1
  unfold modelK
  positivity

theorem modelK_lower (ho : 0≤omega) :
    modelKZero a f rho/(1+omega)≤modelK a f rho omega := by
  have hI := h.modelKInfinity_pos
  have h1 := h.modelKOne_pos
  have h2 := h.modelKTwo_pos
  have hL := h.modelL_bounds ho
  have hO : 0<1+omega := by linarith
  have hIl : modelKInfinity a f rho/(1+omega)≤modelKInfinity a f rho := by
    apply (div_le_iff₀ hO).mpr
    nlinarith
  have h2l : modelKTwo a f rho/(1+omega)≤modelKTwo a f rho/modelL a f rho omega :=
    div_le_div_of_nonneg_left h2.le hL.1 hL.2
  calc
    _ = modelKInfinity a f rho/(1+omega)+modelKOne a f rho/(1+omega)+
        modelKTwo a f rho/(1+omega) := by rw [←h.modelKZero_residues];ring
    _ ≤ modelK a f rho omega := by unfold modelK;linarith

theorem modelPsi_le_one (ho : 0≤omega) : modelPsi a f rho omega≤1 := by
  have h1 := mul_nonneg h.modelAlpha1_nonneg ho
  have h2 := mul_nonneg h.modelAlpha2_nonneg (sq_nonneg omega)
  have h3 := mul_nonneg h.modelAlpha3_nonneg (pow_nonneg ho 3)
  have h4 := mul_nonneg h.modelAlpha4_nonneg (pow_nonneg ho 4)
  unfold modelPsi compactPsi
  linarith

theorem modelF_pos (ho : 0≤omega) (hPsi : 0<modelPsi a f rho omega) :
    0<modelF a f rho omega := by
  have hF := h.modelFZero_pos
  have hL := (h.modelL_bounds ho).1
  unfold modelF
  positivity

theorem modelF_upper (ho : 0≤omega) :
    modelF a f rho omega≤modelFZero a f rho/(1+omega) := by
  have hF := h.modelFZero_pos
  have hL := (h.modelL_bounds ho).1
  have hO : 0<1+omega := by linarith
  have hLe : 1≤modelL a f rho omega := by
    dsimp only [modelL]
    nlinarith [h.modelEll_pos]
  have hL3 : 1≤modelL a f rho omega^3 := one_le_pow₀ hLe
  have hP := h.modelPsi_le_one ho
  unfold modelF
  apply (div_le_div_iff₀ (mul_pos hO (pow_pos hL 3)) hO).mpr
  have hh := mul_nonneg (mul_nonneg hF.le hO.le) (sub_nonneg.mpr (hP.trans hL3))
  nlinarith only [hh]

theorem modelChi_le_diagonal (ho : 0≤omega) :
    modelChi a f rho omega≤modelChiZero a f rho := by
  have hK := h.modelK_pos ho
  have hK0 := h.modelKZero_pos
  have hF0 := h.modelFZero_pos
  have hO : 0<1+omega := by linarith
  unfold modelChi modelChiZero
  calc
    _ ≤ (modelFZero a f rho/(1+omega))/modelK a f rho omega :=
      div_le_div_of_nonneg_right (h.modelF_upper ho) hK.le
    _ ≤ (modelFZero a f rho/(1+omega))/(modelKZero a f rho/(1+omega)) :=
      div_le_div_of_nonneg_left (div_pos hF0 hO).le (div_pos hK0 hO) (h.modelK_lower ho)
    _ = _ := by field_simp [hO.ne',hK0.ne']

theorem modelR_ge_diagonal (ho : 0≤omega) (hPsi : 0<modelPsi a f rho omega) :
    modelRZero a f rho≤modelR a f rho omega := by
  by_cases hz : omega=0
  · subst omega
    simp [modelR,modelLambda,modelL,modelSource,compactSource,
      compactSourceNumerator,compactPoleNumerator,compactPsi]
  have hop : 0<omega := lt_of_le_of_ne ho (Ne.symm hz)
  have hM := h.modelM_pos
  have hL := (h.modelL_bounds ho).1
  have hA : modelM a f rho*omega/modelL a f rho omega<modelSource a f rho omega := by
    apply compactSource_lower hM.le h.modelEll_pos.le h.modelSigma_pos.le h.modelPoleFlow_pos.le hop hPsi
    · dsimp only [modelV1]
      linarith [h.modelE1_pos]
    · dsimp only [modelV2]
      linarith [h.modelE2_nonneg]
    · dsimp only [modelV3]
      linarith [h.modelE3_nonneg]
    · dsimp only [modelV4]
      linarith [h.modelE4_nonneg]
    · dsimp only [modelV5]
      linarith [h.modelE5_nonneg]
  have hLam := h.modelLambda_ge_one ho
  have hplus := h.modelRZero_add_a_pos
  have hprod : 0≤(modelLambda a f rho omega-1)*(modelRZero a f rho+a) :=
    mul_nonneg (by linarith) hplus.le
  have hid : 1+modelLambda a f rho omega*(modelRZero a f rho-1)+
      modelM a f rho*omega/modelL a f rho omega-modelRZero a f rho =
      (modelLambda a f rho omega-1)*(modelRZero a f rho+a) := by
    rw [h.modelM_eq_transport]
    unfold modelLambda modelL
    have hLnz : 1+modelEll a f rho*omega≠0 := hL.ne'
    have hLnz' : 1+omega*modelEll a f rho≠0 := by
      simpa only [mul_comm] using hLnz
    field_simp (disch := simp [hLnz,hLnz']) [hLnz,hLnz']
    <;> ring
  unfold modelR
  linarith

theorem modelPsi_pos_of_chi_pos (ho : 0≤omega) (hchi : 0<modelChi a f rho omega) :
    0<modelPsi a f rho omega := by
  have hF : 0<modelF a f rho omega := (div_pos_iff_of_pos_right (h.modelK_pos ho)).mp hchi
  have hden : 0<(1+omega)*modelL a f rho omega^3 := by
    have hL := (h.modelL_bounds ho).1
    positivity
  have hprod : 0<modelFZero a f rho*modelPsi a f rho omega :=
    (div_pos_iff_of_pos_right hden).mp hF
  exact pos_of_mul_pos_right hprod h.modelFZero_pos.le

theorem global_model_half_target (ho : 0≤omega) (hchi : 0<modelChi a f rho omega) :
    0<modelR a f rho omega+(1/2:ℝ)*(1-modelChi a f rho omega)^2 := by
  have hP := h.modelPsi_pos_of_chi_pos ho hchi
  have hR := h.modelR_ge_diagonal ho hP
  have hc := h.modelChi_le_diagonal ho
  have hcu := h.modelChiZero_lt_one
  have hbase := h.diagonal_half_target_pos
  have hsq : (1-modelChiZero a f rho)^2≤(1-modelChi a f rho omega)^2 := by nlinarith
  linarith

end LowerWeakCone
end LeanVerification.ReflectedWedgeCompletion
