import LeanVerification.ReflectedWedgeCompletion.HyperbolicSecants

noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 8000000
set_option maxRecDepth 20000

def transportN (a f rho omega : ℝ) : ℝ :=
  (1-a^2*rho)*(1+f)+a*rho*(1-a*f)*omega
def transportF (a f rho omega : ℝ) : ℝ :=
  (1+a)*(f-a*rho)*(1-f)*(1+f+f*omega)/transportN a f rho omega
def transportRho (a f rho omega : ℝ) : ℝ :=
  -2*(1+a)*(f-a)*rho*(1-a^2*rho)*(1+f+f*omega)/
    (a*(1+f)*transportN a f rho omega)
def transportOmega (a f rho omega : ℝ) : ℝ :=
  -2*(1+a)*(f-a*rho)*omega*(1+omega)/transportN a f rho omega

theorem transportN_pos {a f rho omega : ℝ}
    (ha : 0<a) (ha1 : a<1) (haf : a<f) (hf : f<1)
    (hr : 0<rho) (hru : rho<1) (hw : 0≤omega) :
    0<transportN a f rho omega := by
  have hf0 := ha.trans haf
  have he : 0<1-a*f := by nlinarith [mul_lt_mul_of_pos_left hf ha]
  have hg : 0<1-a^2*rho := by
    have ha2 : a^2<1 := by nlinarith
    have hmul := mul_lt_mul_of_pos_left hru (sq_pos_of_pos ha)
    nlinarith
  unfold transportN
  exact add_pos_of_pos_of_nonneg (mul_pos hg (by linarith)) (by positivity)

theorem solve_secant_transport {a f rho omega lam c z df dr dw : ℝ}
    (ha : a≠0) (hj : 1+f≠0) (hf : 1-f≠0) (hg : 1-a^2*rho≠0)
    (hn : transportN a f rho omega≠0)
    (hlog : (1+a)*lam=z+c)
    (hquad : (1+f+f*omega)*z+omega*df/(1-f)=0)
    (hdf : df=c*(f-a*rho)*(1-f)/(1-a^2*rho))
    (hdr : dr= -2*c*(f-a)*rho/(a*(1+f)))
    (hdw : dw=2*(1+omega)*z) :
    df=lam*transportF a f rho omega ∧
      dr=lam*transportRho a f rho omega ∧
      dw=lam*transportOmega a f rho omega := by
  have hq : (1-a^2*rho)*(1+f+f*omega)*z+omega*(f-a*rho)*c=0 := by
    rw [hdf] at hquad
    field_simp [hg,hf] at hquad
    have he : ((1-a^2*rho)*(1+f+f*omega)*z+omega*(f-a*rho)*c)*(1-f)=0 := by
      linear_combination hquad
    exact (mul_eq_zero.mp he).resolve_right hf
  have hc : c=(1+a)*lam*(1-a^2*rho)*(1+f+f*omega)/transportN a f rho omega := by
    apply (eq_div_iff hn).mpr
    unfold transportN
    linear_combination -(1-a^2*rho)*(1+f+f*omega)*hlog-hq
  have hz : z= -(1+a)*lam*(f-a*rho)*omega/transportN a f rho omega := by
    have he : z=(1+a)*lam-c := by linarith
    rw [he,hc]
    unfold transportN at *
    field_simp [hn]
    <;> ring
  rw [hdf,hdr,hdw,hc,hz]
  unfold transportF transportRho transportOmega
  constructor
  · field_simp [hg,hn]
    <;> ring
  constructor
  · field_simp [ha,hj,hn]
    <;> ring
  · ring

end LeanVerification.ReflectedWedgeCompletion
