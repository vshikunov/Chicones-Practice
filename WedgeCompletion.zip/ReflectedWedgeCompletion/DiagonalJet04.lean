import LeanVerification.ReflectedWedgeCompletion.DiagonalJetModel

noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 48000000
set_option maxRecDepth 50000

theorem jetEll_hasDerivAt {ff rr : ℝ → ℝ} {a h scale : ℝ}
    (ha : a≠0) (hj : 1+ff h≠0) (hg : 1-a^2*rr h≠0)
    (hfa : ff h-a≠0) (hfu : 1-ff h≠0) (hru : 1-rr h≠0)
    (hA : (ff h)^2-a^2*rr h≠0)
    (hff : HasDerivAt ff (scale*diagonalTransportF a (ff h) (rr h)) h)
    (hrr : HasDerivAt rr (scale*diagonalTransportRho a (ff h) (rr h)) h) :
    HasDerivAt (fun x => jetEll a (ff x) (rr x)) (-scale*jetPoleFlow a (ff h) (rr h)) h := by
  have hcalc := (((hasDerivAt_const h a).mul hrr).mul ((((hasDerivAt_const h (1 : ℝ)).add hff).inv (by convert hj using 1 <;> ring)).mul ((((hasDerivAt_const h (1 : ℝ)).add ((hasDerivAt_const h (-1 : ℝ)).mul (hrr.mul (hasDerivAt_const h (a^(2 : ℕ)))))).inv (by convert hg using 1 <;> ring)).mul ((hasDerivAt_const h (1 : ℝ)).add ((hasDerivAt_const h (-1 : ℝ)).mul ((hasDerivAt_const h a).mul hff))))))
  have hfun : (fun x => jetEll a (ff x) (rr x))=(fun x => ((a*(rr x))*((((1 : ℝ)+(ff x)))⁻¹*((((1 : ℝ)+((-1 : ℝ)*((rr x)*(a^(2 : ℕ))))))⁻¹*((1 : ℝ)+((-1 : ℝ)*(a*(ff x)))))))) := by
    funext x
    unfold jetEll 
    ring
  rw [hfun]
  apply hcalc.congr_deriv
  have hNZ0 : ((1 : ℝ)+(ff h))≠0 := (by convert hj using 1 <;> ring)
  have hNZ1 : ((1 : ℝ)+((-1 : ℝ)*((rr h)*(a^(2 : ℕ)))))≠0 := (by convert hg using 1 <;> ring)
  have hNZ2 : ((-1 : ℝ)+((rr h)*(a^(2 : ℕ))))≠0 := (by convert mul_ne_zero (show ((-1 : ℝ) : ℝ)≠0 by norm_num) hg using 1 <;> ring)
  have hC0 : ((1 : ℝ)+(ff h))=(1+ff h) := by ring
  have hC1 : ((1 : ℝ)+((-1 : ℝ)*((rr h)*(a^(2 : ℕ)))))=(1-a^2*rr h) := by ring
  have hC2 : ((-1 : ℝ)+((rr h)*(a^(2 : ℕ))))=(-1 : ℝ)*(1-a^2*rr h) := by ring
  dsimp only [diagonalTransportF,diagonalTransportRho,jetEll,jetPoleFlow]
  simp only [hC0,hC1,hC2]
  norm_num only [Nat.reduceSub, pow_one, zero_mul, mul_zero, zero_add, add_zero, one_mul, mul_one, neg_one_mul, neg_sq]
  field_simp (disch := simp [ha,hj,hg]) [ha,hj,hg]
  <;> ring

end LeanVerification.ReflectedWedgeCompletion
