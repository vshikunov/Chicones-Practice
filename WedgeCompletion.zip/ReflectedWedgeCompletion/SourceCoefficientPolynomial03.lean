import LeanVerification.ReflectedWedgeCompletion.SourceCoefficientJets
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate06

/-! Polynomial numerator certificate for source coefficient 3. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 8000000
set_option maxRecDepth 50000

theorem sourceCoefficient3_numerator (a f rho : ℝ) :
    weakNum06 a f rho=
    6*(1+a)*(f-a*rho)*a*(f-a)*(1-rho)*weakNum02 a f rho-
      sourceDAlphaNumerator3 a f rho+
      3*(1+a)*(f-a*rho)*a*(f-a)*(1+f)*(1-rho)*(1-a^2*rho)*weakNum01 a f rho-
      f*(1-a^2*rho)*sourceDAlphaNumerator2 a f rho := by
  unfold weakNum06 weakNum02 weakNum01 sourceDAlphaNumerator3 sourceDAlphaPolynomial3 sourceDAlphaNumerator2 sourceDAlphaPolynomial2
  ring

end LeanVerification.ReflectedWedgeCompletion
