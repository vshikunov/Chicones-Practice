import LeanVerification.ReflectedWedgeCompletion.DiagonalJetModel
import LeanVerification.ReflectedWedgeCompletion.RationalJetAlgebra

noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion

def diagonalTransportDen (a f rho : ℝ) : ℝ := a*(1+f)*(1-a^2*rho)
def diagonalTransportNumF (a f rho : ℝ) : ℝ :=
  a*(1+f)*(1+a)*(f-a*rho)*(1-f)
def diagonalTransportNumRho (a f rho : ℝ) : ℝ :=
  -2*(1+a)*(f-a)*rho*(1-a^2*rho)

theorem diagonalTransportF_common {a f rho : ℝ}
    (ha : a≠0) (hj : 1+f≠0) (hg : 1-a^2*rho≠0) :
    diagonalTransportF a f rho=diagonalTransportNumF a f rho/diagonalTransportDen a f rho := by
  have he : 1+(-1:ℝ)*(rho*a^2)=1-a^2*rho := by ring
  dsimp only [diagonalTransportF,diagonalTransportNumF,diagonalTransportDen]
  rw [he]
  field_simp (disch := simp [ha,hj,hg]) [ha,hj,hg]
  <;> ring

theorem diagonalTransportRho_common {a f rho : ℝ}
    (ha : a≠0) (hj : 1+f≠0) (hg : 1-a^2*rho≠0) :
    diagonalTransportRho a f rho=diagonalTransportNumRho a f rho/diagonalTransportDen a f rho := by
  dsimp only [diagonalTransportRho,diagonalTransportNumRho,diagonalTransportDen]
  field_simp (disch := simp [ha,hj,hg]) [ha,hj,hg]
  <;> ring

end LeanVerification.ReflectedWedgeCompletion
