import LeanVerification.ReflectedWedgeCompletion.SourceCoefficientJets
import LeanVerification.ReflectedWedgeCompletion.ScalarCertificate04

/-! Polynomial numerator certificate for source coefficient 1. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 8000000
set_option maxRecDepth 50000

theorem sourceCoefficient1_numerator (a f rho : ℝ) :
    weakNum04 a f rho=
    2*(1+a)*(f-a*rho)*a*(f-a)*(1-rho)*weakNum00 a f rho-
      sourceDAlphaNumerator1 a f rho+
      2*(1+a)*(f-a*rho)*a*(f-a)^2*(1-f)*(1+f)*(1-rho)^2*(1-a^2*rho)^2 := by
  unfold weakNum04 weakNum00 sourceDAlphaNumerator1 sourceDAlphaPolynomial1
  ring

end LeanVerification.ReflectedWedgeCompletion
