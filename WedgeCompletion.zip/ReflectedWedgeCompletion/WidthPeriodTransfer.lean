import LeanVerification.ReflectedWedgeCompletion.WidthJetIdentities
import LeanVerification.Loud.InverseWidthAbelPeriod
import LeanVerification.Loud.ParameterCover
import LeanVerification.ZeroOrientation
import LeanVerification.BoundaryAssembly.ZeroInput

/-! Complete width-jet to physical-period transfer, including zero Abel input. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.ReflectedWedgeCompletion
open Loud
set_option maxHeartbeats 6400000

theorem physical_inverse_half_comparison_of_widthjet (D F h : ℝ)
    (hh : AdmissibleEnergy D F h)
    (hjet : 0<1+physicalEnergyWidth D F h*deriv (deriv (physicalEnergyWidth D F)) h/
        (deriv (physicalEnergyWidth D F) h)^2 →
      0<deriv (physicalEnergyWidth D F) h*deriv (deriv (deriv (physicalEnergyWidth D F))) h-
        3*(deriv (deriv (physicalEnergyWidth D F)) h)^2+
        (1/2:ℝ)*(deriv (deriv (physicalEnergyWidth D F)) h)^2*
          (1+physicalEnergyWidth D F h*deriv (deriv (physicalEnergyWidth D F)) h/
            (deriv (physicalEnergyWidth D F) h)^2)) :
    0<1-physicalEnergyWidth D F h*
      deriv (deriv (inverseWidthEnergy D F)) (physicalEnergyWidth D F h)/
        deriv (inverseWidthEnergy D F) (physicalEnergyWidth D F h) →
    deriv (inverseWidthEnergy D F) (physicalEnergyWidth D F h)^2*
      deriv (deriv (deriv (inverseWidthEnergy D F))) (physicalEnergyWidth D F h)≤
        (1/2:ℝ)*(deriv (deriv (inverseWidthEnergy D F)) (physicalEnergyWidth D F h))^2*
          (deriv (inverseWidthEnergy D F) (physicalEnergyWidth D F h)-
            physicalEnergyWidth D F h*deriv (deriv (inverseWidthEnergy D F)) (physicalEnergyWidth D F h)) := by
  obtain ⟨h1,h2,h3⟩ := physical_inverse_width_derivatives D F h hh
  have hw1 := physicalEnergyWidth_deriv_pos_of_width_chart D F h hh
  rw [h1,h2,h3]
  intro hchi
  have hechi : 1-physicalEnergyWidth D F h*
      (-deriv (deriv (physicalEnergyWidth D F)) h/(deriv (physicalEnergyWidth D F) h)^3)/
        (1/deriv (physicalEnergyWidth D F) h)=
      1+physicalEnergyWidth D F h*deriv (deriv (physicalEnergyWidth D F)) h/
        (deriv (physicalEnergyWidth D F) h)^2 := by
    field_simp [hw1.ne']
    <;> ring
  rw [hechi] at hchi
  have hpos := hjet hchi
  apply sub_nonneg.mp
  have he : (1/2:ℝ)*(-deriv (deriv (physicalEnergyWidth D F)) h/(deriv (physicalEnergyWidth D F) h)^3)^2*
      (1/deriv (physicalEnergyWidth D F) h-physicalEnergyWidth D F h*
        (-deriv (deriv (physicalEnergyWidth D F)) h/(deriv (physicalEnergyWidth D F) h)^3))-
      (1/deriv (physicalEnergyWidth D F) h)^2*
        ((3*(deriv (deriv (physicalEnergyWidth D F)) h)^2-
          deriv (physicalEnergyWidth D F) h*deriv (deriv (deriv (physicalEnergyWidth D F))) h)/
            (deriv (physicalEnergyWidth D F) h)^5)=
      (deriv (physicalEnergyWidth D F) h*deriv (deriv (deriv (physicalEnergyWidth D F))) h-
        3*(deriv (deriv (physicalEnergyWidth D F)) h)^2+
          (1/2:ℝ)*(deriv (deriv (physicalEnergyWidth D F)) h)^2*
            (1+physicalEnergyWidth D F h*deriv (deriv (physicalEnergyWidth D F)) h/
              (deriv (physicalEnergyWidth D F) h)^2))/(deriv (physicalEnergyWidth D F) h)^7 := by
    field_simp [hw1.ne']
    <;> ring
  rw [he]
  exact (div_pos hpos (pow_pos hw1 7)).le

theorem scaled_width_chi (L w w1 w2 : ℝ) (hL : L≠0) (hw1 : w1≠0) :
    1+(L*w)*(L*w2)/(L*w1)^2=1+w*w2/w1^2 := by
  field_simp [hL,hw1]
  <;> ring

theorem scaled_width_half_expression (L w w1 w2 w3 : ℝ) (hL : L≠0) (hw1 : w1≠0) :
    (L*w1)*(L*w3)-3*(L*w2)^2+(1/2:ℝ)*(L*w2)^2*(1+(L*w)*(L*w2)/(L*w1)^2)=
      L^2*(w1*w3-3*w2^2+(1/2:ℝ)*w2^2*(1+w*w2/w1^2)) := by
  rw [scaled_width_chi L w w1 w2 hL hw1]
  ring

theorem physical_width_euler_of_scaled_jets (D F h L : ℝ) (hh : AdmissibleEnergy D F h)
    (hL : 0<L) {w : ℝ→ℝ} (he : w=fun t => L*physicalEnergyWidth D F t)
    (hc : deriv (deriv w) h<0)
    (hjet : 0<1+w h*deriv (deriv w) h/(deriv w h)^2 →
      0<deriv w h*deriv (deriv (deriv w)) h-3*(deriv (deriv w) h)^2+
        (1/2:ℝ)*(deriv (deriv w) h)^2*(1+w h*deriv (deriv w) h/(deriv w h)^2))
    (hQ : 0<InverseWidthComparison.widthQ (physicalEnergyWidth D F) h) :
    0<h*deriv (InverseWidthComparison.widthQ (physicalEnergyWidth D F)) h+
      (1/2:ℝ)*InverseWidthComparison.widthQ (physicalEnergyWidth D F) h := by
  have hw1 := physicalEnergyWidth_deriv_pos_of_width_chart D F h hh
  simp only [he,deriv_const_mul_field'] at hc hjet
  have hc0 : deriv (deriv (physicalEnergyWidth D F)) h<0 := neg_of_mul_neg_right hc hL.le
  apply physical_inverse_width_curvature_transfer D F h hh hc0
    (physical_inverse_half_comparison_of_widthjet D F h hh ?_) hQ
  intro hchi
  rw [scaled_width_chi _ _ _ _ hL.ne' hw1.ne'] at hjet
  have hp := hjet hchi
  have hscale := scaled_width_half_expression L (physicalEnergyWidth D F h)
    (deriv (physicalEnergyWidth D F) h) (deriv (deriv (physicalEnergyWidth D F)) h)
    (deriv (deriv (deriv (physicalEnergyWidth D F))) h) hL.ne' hw1.ne'
  rw [scaled_width_chi _ _ _ _ hL.ne' hw1.ne'] at hscale
  rw [hscale] at hp
  exact (mul_pos_iff_of_pos_left (sq_pos_of_pos hL)).mp hp

theorem physical_period_deriv_zero_of_widthQ_zero (D F : ℝ)
    (hQ : ∀s,AdmissibleEnergy D F s → InverseWidthComparison.widthQ (physicalEnergyWidth D F) s=0)
    {h : ℝ} (hh : AdmissibleEnergy D F h) : deriv (periodQuadrature D F) h=0 := by
  obtain ⟨H,hH,hcap⟩ := admissibleEnergy_has_larger D F h hh
  obtain ⟨z,hz,hz0,heq⟩ := exists_physicalInverseAbelInput_extension D F H hH
  have hzz : ∀s∈Icc 0 H,z s=0 := by
    intro s hs
    rcases eq_or_lt_of_le hs.1 with he | hp
    · simpa only [←he] using hz0
    · have hsa := admissibleEnergy_downward D F H s hH hp hs.2
      rw [heq hs,physicalInverseAbelInput_eq_widthQ D F s hsa,hQ s hsa,mul_zero]
  have hi : InverseWidthAbel.angularAbel z h=0 := by
    unfold InverseWidthAbel.angularAbel
    have hzint : (∫θ in (0:ℝ)..Real.pi/2,z (h*Real.sin θ^2))=0 := by
      calc
        _=∫_θ in (0:ℝ)..Real.pi/2,(0:ℝ) := by
          apply intervalIntegral.integral_congr
          intro θ _
          exact hzz _ (RaisedAbel.sin_sq_energy_mem ⟨hh.1.le,hcap.le⟩ θ)
        _=0 := by simp
    rw [hzint,mul_zero]
  have he := angularAbel_physical_period_identity D F H h hH ⟨hh.1,hcap.le⟩ heq
  rw [hi,mul_zero] at he
  exact (mul_eq_zero.mp he.symm).resolve_left (pow_ne_zero _ hh.1.ne')

theorem no_isolated_of_all_period_derivatives_zero {D F : ℝ}
    (hzero : ∀h,AdmissibleEnergy D F h → deriv (periodQuadrature D F) h=0)
    (h : ℝ) : ¬IsolatedCriticalEnergy D F h := by
  rintro ⟨hh,_,ε,hε,hiso⟩
  let δ := min h ε/2
  have hδ : 0<δ := div_pos (lt_min hh.1 hε) (by norm_num)
  have hδh : δ<h := by dsimp [δ];linarith [min_le_left h ε,hh.1]
  have hδε : δ<ε := by dsimp [δ];linarith [min_le_right h ε]
  have hk := admissibleEnergy_downward D F h (h-δ) hh (by linarith) (by linarith)
  have habs : |h-δ-h|<ε := by
    rw [show h-δ-h= -δ by ring,abs_neg,abs_of_pos hδ]
    exact hδε
  exact hiso (h-δ) hk (by linarith) habs (hzero _ hk)

theorem criticalPeriodBound_one_of_width_euler (D F : ℝ)
    (hcomparison : ∀h,AdmissibleEnergy D F h →
      0<InverseWidthComparison.widthQ (physicalEnergyWidth D F) h →
      0≤h*deriv (InverseWidthComparison.widthQ (physicalEnergyWidth D F)) h+
        (1/2:ℝ)*InverseWidthComparison.widthQ (physicalEnergyWidth D F) h) :
    CriticalPeriodBound 1 D F := by
  classical
  by_cases hn : ∃h,AdmissibleEnergy D F h ∧
      InverseWidthComparison.widthQ (physicalEnergyWidth D F) h≠0
  · have hu : ZeroCounting.AtMostOneZeroOn (deriv (periodQuadrature D F))
        {h|AdmissibleEnergy D F h} := by
      apply ZeroOrientation.atMostOneZeroOn_of_deriv_pos_at_zeros
        (ordConnected_admissibleEnergy D F).convex
        (fun h hh => (analyticAt_periodQuadrature_energy D F h hh).deriv.differentiableAt)
      intro h hh hz
      exact physical_inverse_width_abel_curvature_global D F h hh hcomparison hn hz
    intro q hq
    apply Finset.card_le_one.mpr
    intro x hx y hy
    exact hu (hq x hx).1 (hq y hy).1 (hq x hx).2.1 (hq y hy).2.1
  · push_neg at hn
    have hzero (h : ℝ) (hh : AdmissibleEnergy D F h) : deriv (periodQuadrature D F) h=0 :=
      physical_period_deriv_zero_of_widthQ_zero D F hn hh
    intro q hq
    have he : q=∅ := Finset.eq_empty_iff_forall_not_mem.mpr (by
      intro h hh
      exact no_isolated_of_all_period_derivatives_zero hzero h (hq h hh))
    simp [he]

end LeanVerification.ReflectedWedgeCompletion
