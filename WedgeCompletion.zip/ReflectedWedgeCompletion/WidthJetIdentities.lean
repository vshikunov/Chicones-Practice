import LeanVerification.Loud.InverseWidthJets
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith

/-! Differential consequences of the actual energy/width ratio identity. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 6400000

theorem widthjet_stiffness_identity {w E U k : ℝ→ℝ} {c h : ℝ} {S : Set ℝ}
    (hS : IsOpen S) (hh : h∈S) (hw : AnalyticAt ℝ w h) (hw0 : w h≠0)
    (hE : HasDerivAt E c h)
    (hU : HasDerivAt U (deriv w h/w h*(k h-2*U h)) h)
    (he : ∀t∈S,E t=(w t)^2*U t) : c=w h*deriv w h*k h := by
  have hprod : HasDerivAt (fun t => (w t)^2*U t) (w h*deriv w h*k h) h := by
    convert (hw.differentiableAt.hasDerivAt.pow 2).mul hU using 1
    simp only [Nat.cast_ofNat,Nat.reduceSub,pow_one]
    field_simp [hw0]
    <;> ring
  have hevent : E=ᶠ[𝓝 h] fun t => (w t)^2*U t := by
    filter_upwards [hS.mem_nhds hh] with t ht
    exact he t ht
  exact hE.unique (hprod.congr_of_eventuallyEq hevent)

theorem widthjet_curvature_identity {w k Φ : ℝ→ℝ} {c h : ℝ} {S : Set ℝ}
    (hS : IsOpen S) (hh : h∈S) (hw : AnalyticAt ℝ w h) (hw0 : w h≠0)
    (hk : HasDerivAt k (-deriv w h/w h*Φ h) h)
    (he : ∀t∈S,c=w t*deriv w t*k t) :
    ((deriv w h)^2+w h*deriv (deriv w) h)*k h=(deriv w h)^2*Φ h := by
  have hd := ((hw.differentiableAt.hasDerivAt.mul hw.deriv.differentiableAt.hasDerivAt).mul hk)
  have hevent : (fun t => w t*deriv w t*k t)=ᶠ[𝓝 h] fun _ => c := by
    filter_upwards [hS.mem_nhds hh] with t ht
    exact (he t ht).symm
  have hz := (hd.congr_of_eventuallyEq hevent.symm).unique (hasDerivAt_const h c)
  field_simp [hw0] at hz
  apply (mul_right_cancel₀ hw0)
  nlinarith only [hz]

theorem widthjet_third_identity {w k Φ : ℝ→ℝ} {R h : ℝ} {S : Set ℝ}
    (hS : IsOpen S) (hh : h∈S) (hw : AnalyticAt ℝ w h) (hw0 : w h≠0)
    (hk : HasDerivAt k (-deriv w h/w h*Φ h) h)
    (hΦ : HasDerivAt Φ (deriv w h/w h*Φ h*(R-1)) h)
    (he : ∀t∈S,((deriv w t)^2+w t*deriv (deriv w) t)*k t=(deriv w t)^2*Φ t) :
    k h*(3*w h*deriv w h*deriv (deriv w) h+(w h)^2*deriv (deriv (deriv w)) h)=
      Φ h*(3*w h*deriv w h*deriv (deriv w) h+(deriv w h)^3*R) := by
  have h0 := hw.differentiableAt.hasDerivAt
  have h1 := hw.deriv.differentiableAt.hasDerivAt
  have h2 := hw.deriv.deriv.differentiableAt.hasDerivAt
  have hleft := ((h1.pow 2).add (h0.mul h2)).mul hk
  have hright := (h1.pow 2).mul hΦ
  have hevent : (fun t => ((deriv w t)^2+w t*deriv (deriv w) t)*k t)=ᶠ[𝓝 h]
      fun t => (deriv w t)^2*Φ t := by
    filter_upwards [hS.mem_nhds hh] with t ht
    exact he t ht
  have hd := hleft.unique (hright.congr_of_eventuallyEq hevent)
  simp only [Nat.cast_ofNat,Nat.reduceSub,pow_one] at hd
  field_simp [hw0] at hd
  nlinarith only [hd]

theorem widthjet_chi_eq {w w1 w2 k Φ : ℝ} (hw1 : w1≠0) (hk : k≠0)
    (he : (w1^2+w*w2)*k=w1^2*Φ) : Φ/k=1+w*w2/w1^2 := by
  field_simp [hk,hw1]
  nlinarith only [he]

theorem widthjet_rchi_eq {w w1 w2 w3 k Φ R : ℝ} (hw1 : w1≠0) (hk : k≠0)
    (hsecond : (w1^2+w*w2)*k=w1^2*Φ)
    (hthird : k*(3*w*w1*w2+w^2*w3)=Φ*(3*w*w1*w2+w1^3*R)) :
    (Φ/k)*R=w^2*(w1*w3-3*w2^2)/w1^4 := by
  field_simp [hk,hw1]
  linear_combination -w1*hthird+3*w*w2*hsecond

theorem widthjet_concave {w w1 w2 k Φ : ℝ} (hw : 0<w) (hw1 : 0<w1) (hk : 0<k)
    (he : (w1^2+w*w2)*k=w1^2*Φ) (hchi : Φ/k<1) : w2<0 := by
  rw [widthjet_chi_eq hw1.ne' hk.ne' he] at hchi
  have hprod : w*w2<0 := by
    simpa only [zero_mul] using (div_lt_iff₀ (sq_pos_of_pos hw1)).mp (by linarith : w*w2/w1^2<0)
  exact neg_of_mul_neg_right hprod hw.le

theorem widthjet_half_comparison {w w1 w2 w3 k Φ R : ℝ}
    (hw : 0<w) (hw1 : 0<w1) (hk : 0<k) (hchi : 0<Φ/k)
    (hsecond : (w1^2+w*w2)*k=w1^2*Φ)
    (hthird : k*(3*w*w1*w2+w^2*w3)=Φ*(3*w*w1*w2+w1^3*R))
    (hhalf : 0<R+(1/2:ℝ)*(1-Φ/k)^2) :
    0<w1*w3-3*w2^2+(1/2:ℝ)*w2^2*(1+w*w2/w1^2) := by
  have hc := widthjet_chi_eq hw1.ne' hk.ne' hsecond
  have hrc := widthjet_rchi_eq hw1.ne' hk.ne' hsecond hthird
  have hp := mul_pos hchi hhalf
  have he : (Φ/k)*(R+(1/2:ℝ)*(1-Φ/k)^2)=
      w^2/w1^4*(w1*w3-3*w2^2+(1/2:ℝ)*w2^2*(1+w*w2/w1^2)) := by
    rw [mul_add,hrc,hc]
    field_simp [hw1.ne']
    <;> ring
  rw [he] at hp
  exact (mul_pos_iff_of_pos_left (div_pos (sq_pos_of_pos hw) (pow_pos hw1 4))).mp hp

end LeanVerification.ReflectedWedgeCompletion
