import Mathlib.Data.Real.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.LinearCombination

/-! Rational assembly with denominator factors kept independent.
The parameter-polynomial identities are checked separately. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 4000000
set_option maxRecDepth 30000

theorem stiffness_fraction_assembly
    (a e d j g A W N u t v q n : ℝ)
    (ha : a≠0) (he : e≠0) (hd : d≠0) (hj : j≠0)
    (hg : g≠0) (hA : A≠0) (hW : W≠0) (hN : N≠0)
    (hp : a*e*d*n =
      a*d*j*(A*v-t*u^2)*W*N+e*j*(A*v-u^2)*N+a*q*g*j*W) :
    n/(4*W*A*N) =
      j/(4*e)*(v-t*u^2/A)+
      j/(4*a*d)*(v-u^2/A)/W+
      q/(4*A*e*d)/(N/(g*j)) := by
  field_simp (disch := simp [ha,he,hd,hj,hg,hA,hW,hN])
    [ha,he,hd,hj,hg,hA,hW,hN]
  linear_combination (64*e*A^3*d*W*N)*hp

theorem curvature_fraction_assembly
    (B j g A W N m w n0 n1 n2 n3 : ℝ)
    (hB : B≠0) (hj : j≠0) (hg : g≠0) (hA : A≠0)
    (hW : W≠0) (hN : N≠0) :
    m*B/(4*A)*
      (1-n0/(B*j*g^2)*w-n1/(B*j^2*g^2)*w^2-
        n2/(B*j^3*g^3)*w^3-n3/(B*j^3*g^3)*w^4)/
      (W*(N/(g*j))^3) =
    m*(B*j^3*g^3-n0*j^2*g*w-n1*j*g*w^2-n2*w^3-n3*w^4)/
      (4*W*A*N^3) := by
  field_simp (disch := simp [hB,hj,hg,hA,hW,hN]) [hB,hj,hg,hA,hW,hN]
  ring

theorem residue_fraction_assembly
    (a e d j A v t u q c : ℝ)
    (ha : a≠0) (he : e≠0) (hd : d≠0) (hA : A≠0)
    (hp : a*d*j*(A*v-t*u^2)+e*j*(A*v-u^2)+a*q=a*e*d*j*c) :
    j/(4*e)*(v-t*u^2/A)+j/(4*a*d)*(v-u^2/A)+q/(4*A*e*d)=j*c/(4*A) := by
  have hz : (4:ℝ)*a*A*e*d≠0 := by positivity
  apply mul_left_cancel₀ hz
  calc
    (4*a*A*e*d)*(j/(4*e)*(v-t*u^2/A)+j/(4*a*d)*(v-u^2/A)+q/(4*A*e*d)) =
        a*d*j*(A*v-t*u^2)+e*j*(A*v-u^2)+a*q := by
      field_simp [ha,he,hd,hA]
      <;> ring
    _ = a*e*d*j*c := hp
    _ = (4*a*A*e*d)*(j*c/(4*A)) := by
      field_simp [hA]
      <;> ring

theorem chi_gap_fraction_assembly (A B j c : ℝ)
    (hA : A≠0) (hj : j≠0) (hc : c≠0) :
    1-(B/(2*A))/(j*c/(4*A))=(j*c-2*B)/(j*c) := by
  field_simp [hA,hj,hc]
  <;> ring

theorem half_target_fraction_assembly (a q j r g c n9 n10 : ℝ)
    (ha : a≠0) (hq : q≠0) (hj : j≠0) (hr : r≠0) (hg : g≠0) (hc : c≠0) :
    n9/(a*q*j*r*g)-a+(1/2:ℝ)*(n10/(j*c))^2 =
      (2*j*c^2*n9-2*a^2*q*j^2*r*g*c^2+a*q*r*g*n10^2)/(2*a*q*j^2*r*g*c^2) := by
  field_simp [ha,hq,hj,hr,hg,hc]
  <;> ring

end LeanVerification.ReflectedWedgeCompletion
