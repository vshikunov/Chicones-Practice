import LeanVerification.ReflectedWedgeCompletion.WeakConeCoordinates

/-! Exact Bernstein certificates for one lower-family rational numerator.
Every coefficient and polynomial identity is checked by the Lean kernel. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 12000000
set_option maxRecDepth 50000

def weakNum10 (a f rho : ℝ) : ℝ :=
  -2 * a ^ 2 * f +
  -4 * a ^ 2 * rho +
  2 * a ^ 2 +
  -a * f ^ 2 * rho +
  3 * a * f ^ 2 +
  4 * a * f * rho +
  -4 * a * f +
  -3 * a * rho +
  a +
  -2 * f ^ 2 * rho +
  4 * f ^ 2 +
  2 * f * rho

def weakNum10NearCertificate (a t z : ℝ) : ℝ :=
  (3*a) ^ 3 * ((t) ^ 3 * ((z) * (40) +
        (1-z) * (47)) +
      (t) ^ 2 * (1-t) * ((z) * (72) +
        (1-z) * (88)) +
      (t) * (1-t) ^ 2 * ((z) * (32) +
        (1-z) * (48))) +
    (3*a) ^ 2 * (1-3*a) * ((t) ^ 3 * ((z) * (54) +
        (1-z) * (48)) +
      (t) ^ 2 * (1-t) * ((z) * (102) +
        (1-z) * (114)) +
      (t) * (1-t) ^ 2 * ((z) * (48) +
        (1-z) * (72))) +
    (3*a) * (1-3*a) ^ 2 * ((t) ^ 3 * ((z) * (18) +
        (1-z) * (9)) +
      (t) ^ 2 * (1-t) * ((z) * (36) +
        (1-z) * (36)) +
      (t) * (1-t) ^ 2 * ((z) * (18) +
        (1-z) * (27)))

theorem weakNum10NearCertificate_identity (a t z : ℝ) :
    27 * weakNum10 a (a*(1+t)) (1-t+t*z) = weakNum10NearCertificate a t z := by
  unfold weakNum10 weakNum10NearCertificate
  ring

theorem weakNum10_near_nonneg (a t z : ℝ)
    (ha : 0<a) (hau : a<1/3) (ht : 0<t) (htu : t≤1) (hz : 0≤z) (hzu : z<1) : 0≤weakNum10 a (a*(1+t)) (1-t+t*z) := by
  have hga : 0<1-3*a := by linarith
  have hgt : 0≤1-t := by linarith
  have hgz : 0<1-z := by linarith
  have hc : 0≤weakNum10NearCertificate a t z := by
    unfold weakNum10NearCertificate
    positivity
  have hi := weakNum10NearCertificate_identity a t z
  nlinarith only [hc,hi]

theorem weakNum10_near_pos (a t z : ℝ)
    (ha : 0<a) (hau : a<1/3) (ht : 0<t) (htu : t≤1) (hz : 0≤z) (hzu : z<1) : 0<weakNum10 a (a*(1+t)) (1-t+t*z) := by
  have hga : 0<1-3*a := by linarith
  have hgt : 0≤1-t := by linarith
  have hgz : 0<1-z := by linarith
  
  have hc : 0<weakNum10NearCertificate a t z := by
    unfold weakNum10NearCertificate
    positivity
  have hi := weakNum10NearCertificate_identity a t z
  nlinarith only [hc,hi]

def weakNum10FarCertificate (a t z : ℝ) : ℝ :=
  (3*a) ^ 3 * ((t) ^ 2 * ((z) * (96) +
        (1-z) * (108)) +
      (t) * (1-t) * ((z) * (128) +
        (1-z) * (140)) +
      (1-t) ^ 2 * ((z) * (40) +
        (1-z) * (47))) +
    (3*a) ^ 2 * (1-3*a) * ((t) ^ 2 * ((z) * (312) +
        (1-z) * (324)) +
      (t) * (1-t) * ((z) * (312) +
        (1-z) * (270)) +
      (1-t) ^ 2 * ((z) * (54) +
        (1-z) * (48))) +
    (3*a) * (1-3*a) ^ 2 * ((t) ^ 2 * ((z) * (324) +
        (1-z) * (324)) +
      (t) * (1-t) * ((z) * (234) +
        (1-z) * (126)) +
      (1-t) ^ 2 * ((z) * (18) +
        (1-z) * (9))) +
    (1-3*a) ^ 3 * ((t) ^ 2 * ((z) * (108) +
        (1-z) * (108)) +
      (t) * (1-t) * ((z) * (54)))

theorem weakNum10FarCertificate_identity (a t z : ℝ) :
    27 * weakNum10 a (2*a+(1-2*a)*t) z = weakNum10FarCertificate a t z := by
  unfold weakNum10 weakNum10FarCertificate
  ring

theorem weakNum10_far_nonneg (a t z : ℝ)
    (ha : 0<a) (hau : a<1/3) (ht : 0≤t) (htu : t<1) (hz : 0<z) (hzu : z<1) : 0≤weakNum10 a (2*a+(1-2*a)*t) z := by
  have hga : 0<1-3*a := by linarith
  have hgt : 0≤1-t := by linarith
  have hgz : 0<1-z := by linarith
  have hc : 0≤weakNum10FarCertificate a t z := by
    unfold weakNum10FarCertificate
    positivity
  have hi := weakNum10FarCertificate_identity a t z
  nlinarith only [hc,hi]

theorem weakNum10_far_pos (a t z : ℝ)
    (ha : 0<a) (hau : a<1/3) (ht : 0≤t) (htu : t<1) (hz : 0<z) (hzu : z<1) : 0<weakNum10 a (2*a+(1-2*a)*t) z := by
  have hga : 0<1-3*a := by linarith
  have hgt : 0≤1-t := by linarith
  have hgz : 0<1-z := by linarith
  have hgtp : 0<1-t := by linarith
  have hc : 0<weakNum10FarCertificate a t z := by
    unfold weakNum10FarCertificate
    positivity
  have hi := weakNum10FarCertificate_identity a t z
  nlinarith only [hc,hi]

theorem weakNum10_nonneg {a f rho : ℝ} (ha : 0<a) (hau : a<1/3)
    (haf : a<f) (hf : f<1) (hrho : 0<rho) (hrhou : rho<1)
    (hcone : 2≤f/a+rho) : 0≤weakNum10 a f rho :=
  weakCone_polynomial_nonneg weakNum10_near_nonneg weakNum10_far_nonneg
    ha hau haf hf hrho hrhou hcone

theorem weakNum10_pos {a f rho : ℝ} (ha : 0<a) (hau : a<1/3)
    (haf : a<f) (hf : f<1) (hrho : 0<rho) (hrhou : rho<1)
    (hcone : 2≤f/a+rho) : 0<weakNum10 a f rho :=
  weakCone_polynomial_pos weakNum10_near_pos weakNum10_far_pos
    ha hau haf hf hrho hrhou hcone

end LeanVerification.ReflectedWedgeCompletion
