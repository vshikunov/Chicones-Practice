import LeanVerification.ReflectedWedgeCompletion.DiagonalJetModel

noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 48000000
set_option maxRecDepth 50000

theorem jetFZero_hasDerivAt {ff rr : ℝ → ℝ} {a h scale : ℝ}
    (ha : a≠0) (hj : 1+ff h≠0) (hg : 1-a^2*rr h≠0)
    (hfa : ff h-a≠0) (hfu : 1-ff h≠0) (hru : 1-rr h≠0)
    (hA : (ff h)^2-a^2*rr h≠0)
    (hff : HasDerivAt ff (scale*diagonalTransportF a (ff h) (rr h)) h)
    (hrr : HasDerivAt rr (scale*diagonalTransportRho a (ff h) (rr h)) h) :
    HasDerivAt (fun x => jetFZero a (ff x) (rr x)) (scale*jetFZero a (ff h) (rr h)*(jetRZero a (ff h) (rr h)-1)) h := by
  have hcalc := ((((((hasDerivAt_const h (2 : ℝ)).mul (hff.pow 2)).add ((hasDerivAt_const h (-2 : ℝ)).mul (hrr.mul (hasDerivAt_const h (a^(2 : ℕ)))))).inv (by convert mul_ne_zero (show ((2 : ℝ) : ℝ)≠0 by norm_num) hA using 1 <;> ring)).mul (hasDerivAt_const h ((1 : ℝ)+a))).mul (((hasDerivAt_const h (1 : ℝ)).add ((hasDerivAt_const h (-1 : ℝ)).mul hff)).mul (((hasDerivAt_const h (1 : ℝ)).add ((hasDerivAt_const h (-1 : ℝ)).mul hrr)).mul (hff.add (hasDerivAt_const h ((-1 : ℝ)*a))))))
  have hfun : (fun x => jetFZero a (ff x) (rr x))=(fun x => ((((((2 : ℝ)*((ff x)^(2 : ℕ)))+((-2 : ℝ)*((rr x)*(a^(2 : ℕ))))))⁻¹*((1 : ℝ)+a))*(((1 : ℝ)+((-1 : ℝ)*(ff x)))*(((1 : ℝ)+((-1 : ℝ)*(rr x)))*((ff x)+((-1 : ℝ)*a)))))) := by
    funext x
    unfold jetFZero 
    ring
  rw [hfun]
  apply hcalc.congr_deriv
  have hNZ0 : (((2 : ℝ)*((ff h)^(2 : ℕ)))+((-2 : ℝ)*((rr h)*(a^(2 : ℕ)))))≠0 := (by convert mul_ne_zero (show ((2 : ℝ) : ℝ)≠0 by norm_num) hA using 1 <;> ring)
  have hNZ1 : ((1 : ℝ)+(ff h))≠0 := (by convert hj using 1 <;> ring)
  have hNZ2 : ((-1 : ℝ)+((rr h)*(a^(2 : ℕ))))≠0 := (by convert mul_ne_zero (show ((-1 : ℝ) : ℝ)≠0 by norm_num) hg using 1 <;> ring)
  have hNZ3 : (((-1 : ℝ)*((ff h)^(2 : ℕ)))+((rr h)*(a^(2 : ℕ))))≠0 := (by convert mul_ne_zero (show ((-1 : ℝ) : ℝ)≠0 by norm_num) hA using 1 <;> ring)
  have hNZ4 : ((1 : ℝ)+((-1 : ℝ)*((rr h)*(a^(2 : ℕ)))))≠0 := (by convert hg using 1 <;> ring)
  have hC0 : (((2 : ℝ)*((ff h)^(2 : ℕ)))+((-2 : ℝ)*((rr h)*(a^(2 : ℕ)))))=(2 : ℝ)*((ff h)^2-a^2*rr h) := by ring
  have hC1 : ((1 : ℝ)+(ff h))=(1+ff h) := by ring
  have hC2 : ((-1 : ℝ)+((rr h)*(a^(2 : ℕ))))=(-1 : ℝ)*(1-a^2*rr h) := by ring
  have hC3 : (((-1 : ℝ)*((ff h)^(2 : ℕ)))+((rr h)*(a^(2 : ℕ))))=(-1 : ℝ)*((ff h)^2-a^2*rr h) := by ring
  have hC4 : ((1 : ℝ)+((-1 : ℝ)*((rr h)*(a^(2 : ℕ)))))=(1-a^2*rr h) := by ring
  dsimp only [diagonalTransportF,diagonalTransportRho,jetFZero,jetRZero,weakNum09]
  simp only [hC0,hC1,hC2,hC3,hC4]
  norm_num only [Nat.reduceSub,pow_one,zero_mul,mul_zero,zero_add,add_zero,one_mul,mul_one,neg_one_mul,neg_sq]
  field_simp (disch := simp [ha,hj,hg,hfa,hfu,hru,hA,hNZ0,hNZ1,hNZ2,hNZ3,hNZ4]) [ha,hj,hg,hfa,hfu,hru,hA,hNZ0,hNZ1,hNZ2,hNZ3,hNZ4]
  <;> ring

end LeanVerification.ReflectedWedgeCompletion
