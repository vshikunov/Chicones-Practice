import LeanVerification.ReflectedWedgeCompletion.WidthJetApplication
import LeanVerification.ReflectedCompletion.ReflectedRowSix
import LeanVerification.ReflectedCompletion.CompleteRowSeven
import LeanVerification.RegionalReal.AffineRegions

/-! The entire lower-wedge row, with all three closed edges. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
open Loud

theorem full_regional_row8 (D F : ℝ) (hp : parameterRegion 8 D F) :
    CriticalPeriodBound (parameterRegionBound 8) D F := by
  change 3/4≤F ∧ F<1 ∧ -F≤D ∧ D≤ -(1/2) at hp
  change CriticalPeriodBound 1 D F
  by_cases hDhalf : D= -(1/2)
  · have hb := RegionalReal.parameter_region_four_bound D F (Or.inr hDhalf)
    intro q hq
    exact (hb q hq).trans (by norm_num [parameterRegionBound])
  have hD1 : D< -(1/2) := lt_of_le_of_ne hp.2.2.2 hDhalf
  by_cases hDedge : D= -F
  · have hb := ReflectedCompletion.full_regional_row6 D F
      ⟨by linarith [hp.1],hp.2.1,hDedge.le⟩
    intro q hq
    exact (hb q hq).trans (by norm_num [parameterRegionBound])
  have hD0 : -F<D := lt_of_le_of_ne hp.2.2.1 (Ne.symm hDedge)
  by_cases hFedge : F=3/4
  · exact ReflectedCompletion.criticalPeriodBound_one_reflected_middle
      (by linarith [hp.1]) hFedge.le hD0 hD1
  exact criticalPeriodBound_one_reflected_wedge D F
    (lt_of_le_of_ne hp.1 (Ne.symm hFedge)) hp.2.1 hD0 hD1

end LeanVerification.ReflectedWedgeCompletion
