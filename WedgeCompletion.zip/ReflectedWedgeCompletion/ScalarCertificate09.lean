import LeanVerification.ReflectedWedgeCompletion.WeakConeCoordinates

/-! Exact Bernstein certificates for one lower-family rational numerator.
Every coefficient and polynomial identity is checked by the Lean kernel. -/
noncomputable section
namespace LeanVerification.ReflectedWedgeCompletion
set_option maxHeartbeats 12000000
set_option maxRecDepth 50000

def weakNum09 (a f rho : ℝ) : ℝ :=
  -a ^ 5 * f * rho ^ 2 +
  a ^ 5 * f * rho +
  -a ^ 5 * rho ^ 2 +
  -a ^ 5 * rho +
  a ^ 4 * f ^ 2 * rho ^ 2 +
  -a ^ 4 * f ^ 2 * rho +
  a ^ 4 * f * rho ^ 2 +
  3 * a ^ 4 * f * rho +
  -2 * a ^ 4 * rho +
  -a ^ 3 * f ^ 2 * rho ^ 2 +
  -a ^ 3 * f ^ 2 +
  a ^ 3 * f * rho ^ 2 +
  3 * a ^ 3 * f * rho +
  2 * a ^ 3 * rho ^ 2 +
  -a ^ 3 * rho +
  a ^ 3 +
  -2 * a ^ 2 * f ^ 2 * rho ^ 2 +
  a ^ 2 * f ^ 2 * rho +
  -a ^ 2 * f ^ 2 +
  -a ^ 2 * f * rho ^ 2 +
  -3 * a ^ 2 * f * rho +
  a ^ 2 * rho ^ 2 +
  a ^ 2 +
  2 * a * f ^ 2 * rho +
  -4 * a * f * rho +
  2 * f ^ 2 * rho

def weakNum09NearCertificate (a t z : ℝ) : ℝ :=
  (3*a) ^ 6 * ((t) ^ 4 * ((z) ^ 2 * (192) +
        (z) * (1-z) * (232) +
        (1-z) ^ 2 * (60)) +
      (t) ^ 3 * (1-t) * ((z) ^ 2 * (384) +
        (z) * (1-z) * (648) +
        (1-z) ^ 2 * (400)) +
      (t) ^ 2 * (1-t) ^ 2 * ((z) ^ 2 * (192) +
        (z) * (1-z) * (416) +
        (1-z) ^ 2 * (320))) +
    (3*a) ^ 5 * (1-3*a) * ((t) ^ 4 * ((z) ^ 2 * (768) +
        (z) * (1-z) * (882) +
        (1-z) ^ 2 * (321)) +
      (t) ^ 3 * (1-t) * ((z) ^ 2 * (1536) +
        (z) * (1-z) * (2514) +
        (1-z) ^ 2 * (1608)) +
      (t) ^ 2 * (1-t) ^ 2 * ((z) ^ 2 * (768) +
        (z) * (1-z) * (1632) +
        (1-z) ^ 2 * (1248))) +
    (3*a) ^ 4 * (1-3*a) ^ 2 * ((t) ^ 4 * ((z) ^ 2 * (1116) +
        (z) * (1-z) * (1215) +
        (1-z) ^ 2 * (531)) +
      (t) ^ 3 * (1-t) * ((z) ^ 2 * (2232) +
        (z) * (1-z) * (3537) +
        (1-z) ^ 2 * (2313)) +
      (t) ^ 2 * (1-t) ^ 2 * ((z) ^ 2 * (1116) +
        (z) * (1-z) * (2322) +
        (1-z) ^ 2 * (1764))) +
    (3*a) ^ 3 * (1-3*a) ^ 3 * ((t) ^ 4 * ((z) ^ 2 * (702) +
        (z) * (1-z) * (729) +
        (1-z) ^ 2 * (351)) +
      (t) ^ 3 * (1-t) * ((z) ^ 2 * (1404) +
        (z) * (1-z) * (2160) +
        (1-z) ^ 2 * (1431)) +
      (t) ^ 2 * (1-t) ^ 2 * ((z) ^ 2 * (702) +
        (z) * (1-z) * (1431) +
        (1-z) ^ 2 * (1080))) +
    (3*a) ^ 2 * (1-3*a) ^ 4 * ((t) ^ 4 * ((z) ^ 2 * (162) +
        (z) * (1-z) * (162) +
        (1-z) ^ 2 * (81)) +
      (t) ^ 3 * (1-t) * ((z) ^ 2 * (324) +
        (z) * (1-z) * (486) +
        (1-z) ^ 2 * (324)) +
      (t) ^ 2 * (1-t) ^ 2 * ((z) ^ 2 * (162) +
        (z) * (1-z) * (324) +
        (1-z) ^ 2 * (243)))

theorem weakNum09NearCertificate_identity (a t z : ℝ) :
    729 * weakNum09 a (a*(1+t)) (1-t+t*z) = weakNum09NearCertificate a t z := by
  unfold weakNum09 weakNum09NearCertificate
  ring

theorem weakNum09_near_nonneg (a t z : ℝ)
    (ha : 0<a) (hau : a<1/3) (ht : 0<t) (htu : t≤1) (hz : 0≤z) (hzu : z<1) : 0≤weakNum09 a (a*(1+t)) (1-t+t*z) := by
  have hga : 0<1-3*a := by linarith
  have hgt : 0≤1-t := by linarith
  have hgz : 0<1-z := by linarith
  have hc : 0≤weakNum09NearCertificate a t z := by
    unfold weakNum09NearCertificate
    positivity
  have hi := weakNum09NearCertificate_identity a t z
  nlinarith only [hc,hi]

theorem weakNum09_near_pos (a t z : ℝ)
    (ha : 0<a) (hau : a<1/3) (ht : 0<t) (htu : t≤1) (hz : 0≤z) (hzu : z<1) : 0<weakNum09 a (a*(1+t)) (1-t+t*z) := by
  have hga : 0<1-3*a := by linarith
  have hgt : 0≤1-t := by linarith
  have hgz : 0<1-z := by linarith
  
  have hc : 0<weakNum09NearCertificate a t z := by
    unfold weakNum09NearCertificate
    positivity
  have hi := weakNum09NearCertificate_identity a t z
  nlinarith only [hc,hi]

def weakNum09FarCertificate (a t z : ℝ) : ℝ :=
  (3*a) ^ 6 * ((t) ^ 2 * ((z) ^ 2 * (768) +
        (z) * (1-z) * (864)) +
      (t) * (1-t) * ((z) ^ 2 * (768) +
        (z) * (1-z) * (896) +
        (1-z) ^ 2 * (72)) +
      (1-t) ^ 2 * ((z) ^ 2 * (192) +
        (z) * (1-z) * (232) +
        (1-z) ^ 2 * (60))) +
    (3*a) ^ 5 * (1-3*a) * ((t) ^ 2 * ((z) ^ 2 * (5376) +
        (z) * (1-z) * (5832)) +
      (t) * (1-t) * ((z) ^ 2 * (4224) +
        (z) * (1-z) * (4728) +
        (1-z) ^ 2 * (414)) +
      (1-t) ^ 2 * ((z) ^ 2 * (768) +
        (z) * (1-z) * (882) +
        (1-z) ^ 2 * (321))) +
    (3*a) ^ 4 * (1-3*a) ^ 2 * ((t) ^ 2 * ((z) ^ 2 * (15408) +
        (z) * (1-z) * (16200)) +
      (t) * (1-t) * ((z) ^ 2 * (9072) +
        (z) * (1-z) * (9774) +
        (1-z) ^ 2 * (774)) +
      (1-t) ^ 2 * ((z) ^ 2 * (1116) +
        (z) * (1-z) * (1215) +
        (1-z) ^ 2 * (531))) +
    (3*a) ^ 3 * (1-3*a) ^ 3 * ((t) ^ 2 * ((z) ^ 2 * (23112) +
        (z) * (1-z) * (23706)) +
      (t) * (1-t) * ((z) ^ 2 * (9504) +
        (z) * (1-z) * (9909) +
        (1-z) ^ 2 * (594)) +
      (1-t) ^ 2 * ((z) ^ 2 * (702) +
        (z) * (1-z) * (729) +
        (1-z) ^ 2 * (351))) +
    (3*a) ^ 2 * (1-3*a) ^ 4 * ((t) ^ 2 * ((z) ^ 2 * (19116) +
        (z) * (1-z) * (19278)) +
      (t) * (1-t) * ((z) ^ 2 * (4860) +
        (z) * (1-z) * (4941) +
        (1-z) ^ 2 * (162)) +
      (1-t) ^ 2 * ((z) ^ 2 * (162) +
        (z) * (1-z) * (162) +
        (1-z) ^ 2 * (81))) +
    (3*a) * (1-3*a) ^ 5 * ((t) ^ 2 * ((z) ^ 2 * (8262) +
        (z) * (1-z) * (8262)) +
      (t) * (1-t) * ((z) ^ 2 * (972) +
        (z) * (1-z) * (972))) +
    (1-3*a) ^ 6 * ((t) ^ 2 * ((z) ^ 2 * (1458) +
        (z) * (1-z) * (1458)))

theorem weakNum09FarCertificate_identity (a t z : ℝ) :
    729 * weakNum09 a (2*a+(1-2*a)*t) z = weakNum09FarCertificate a t z := by
  unfold weakNum09 weakNum09FarCertificate
  ring

theorem weakNum09_far_nonneg (a t z : ℝ)
    (ha : 0<a) (hau : a<1/3) (ht : 0≤t) (htu : t<1) (hz : 0<z) (hzu : z<1) : 0≤weakNum09 a (2*a+(1-2*a)*t) z := by
  have hga : 0<1-3*a := by linarith
  have hgt : 0≤1-t := by linarith
  have hgz : 0<1-z := by linarith
  have hc : 0≤weakNum09FarCertificate a t z := by
    unfold weakNum09FarCertificate
    positivity
  have hi := weakNum09FarCertificate_identity a t z
  nlinarith only [hc,hi]

theorem weakNum09_far_pos (a t z : ℝ)
    (ha : 0<a) (hau : a<1/3) (ht : 0≤t) (htu : t<1) (hz : 0<z) (hzu : z<1) : 0<weakNum09 a (2*a+(1-2*a)*t) z := by
  have hga : 0<1-3*a := by linarith
  have hgt : 0≤1-t := by linarith
  have hgz : 0<1-z := by linarith
  have hgtp : 0<1-t := by linarith
  have hc : 0<weakNum09FarCertificate a t z := by
    unfold weakNum09FarCertificate
    positivity
  have hi := weakNum09FarCertificate_identity a t z
  nlinarith only [hc,hi]

theorem weakNum09_nonneg {a f rho : ℝ} (ha : 0<a) (hau : a<1/3)
    (haf : a<f) (hf : f<1) (hrho : 0<rho) (hrhou : rho<1)
    (hcone : 2≤f/a+rho) : 0≤weakNum09 a f rho :=
  weakCone_polynomial_nonneg weakNum09_near_nonneg weakNum09_far_nonneg
    ha hau haf hf hrho hrhou hcone

theorem weakNum09_pos {a f rho : ℝ} (ha : 0<a) (hau : a<1/3)
    (haf : a<f) (hf : f<1) (hrho : 0<rho) (hrhou : rho<1)
    (hcone : 2≤f/a+rho) : 0<weakNum09 a f rho :=
  weakCone_polynomial_pos weakNum09_near_pos weakNum09_far_pos
    ha hau haf hf hrho hrhou hcone

end LeanVerification.ReflectedWedgeCompletion
