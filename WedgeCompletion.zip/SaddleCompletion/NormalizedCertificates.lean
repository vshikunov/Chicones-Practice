import LeanVerification.RegionalReal.Schaaf.Identities
import Mathlib.Analysis.Calculus.Deriv.MeanValue

/-! Exact polynomial certificates for the logarithmically separated saddle
potential.  No physical period conclusion or contour hypothesis is assumed. -/

noncomputable section
open Set
namespace LeanVerification.SaddleCompletion
set_option maxHeartbeats 2400000

def normQuad (b z : ℝ) : ℝ := z^2-b*z+1
def normRadius (b z : ℝ) : ℝ := 2-b*z
def normDiscriminant (b : ℝ) : ℝ := 4-b^2
def coefficientFour (b z : ℝ) : ℝ :=
  -b^3*z^3+4*b^2*z^4-20*b*z^3-24*b*z+64*z^2+16
def coefficientSix (b z : ℝ) : ℝ :=
  -11*b^3*z^5-3*b^3*z^3+2*b^2*z^6+112*b^2*z^4-110*b^2*z^2-
    44*b*z^5-84*b*z^3+280*b*z-32*z^2-176
def coefficientSixSlope (b z : ℝ) : ℝ :=
  -33*b^2*z^5-9*b^2*z^3+4*b*z^6+224*b*z^4-220*b*z^2-
    44*z^5-84*z^3+280*z
def crossingFactor (b z : ℝ) : ℝ := 4-3*b*z+b*z^3

theorem normQuad_pos {b z : ℝ} (hb : b≤2) (hz : 0<z) (hz1 : z<1) :
    0<normQuad b z := by
  have h := sq_pos_of_ne_zero (show z-1≠0 by linarith)
  have hn := mul_nonneg (show 0≤2-b by linarith) hz.le
  dsimp only [normQuad]
  nlinarith

theorem normRadius_pos {b z : ℝ} (hb : b≤2) (hz : 0<z) (hz1 : z<1) :
    0<normRadius b z := by
  have ht := mul_le_mul_of_nonneg_right hb hz.le
  dsimp only [normRadius]
  linarith

theorem normDiscriminant_nonneg {b : ℝ} (hb : 0≤b) (hb2 : b≤2) :
    0≤normDiscriminant b := by
  dsimp only [normDiscriminant]
  nlinarith

theorem crossingFactor_pos {b z : ℝ} (hb : b≤2) (hz : 0<z) (hz1 : z<1) :
    0<crossingFactor b z := by
  have hz2 : z^2<1 := by nlinarith
  have hb' : 0≤2-b := sub_nonneg.mpr hb
  have hz' : 0<3-z^2 := by linarith
  have hp : 0<2*(z-1)^2*(z+2) := by
    exact mul_pos (mul_pos (by norm_num) (sq_pos_of_ne_zero (by linarith))) (by linarith)
  have hn : 0≤(2-b)*z*(3-z^2) := by positivity
  have he : crossingFactor b z=2*(z-1)^2*(z+2)+(2-b)*z*(3-z^2) := by
    dsimp only [crossingFactor];ring
  linarith

theorem coefficientFour_endpoint (z : ℝ) :
    coefficientFour 2 z=16*(z-1)^2*(z^2-z+1) := by
  dsimp only [coefficientFour];ring

theorem coefficientFour_pos {b z : ℝ} (hb : 0≤b) (hb2 : b≤2)
    (hz : 0<z) (hz1 : z<1) : 0<coefficientFour b z := by
  have hb' : 0≤2-b := sub_nonneg.mpr hb2
  have hz' : 0<1-z := sub_pos.mpr hz1
  have hcoef : 0<(b-1)^2+15+4*(b+2)*(1-z) := by positivity
  have hf : 0≤(2-b)*z*(((b-1)^2+15+4*(b+2)*(1-z))*z^2+24) := by positivity
  have hlast : 0<16*(z-1)^2*(z^2-z+1) := by
    have hzq : 0<z^2-z+1 := by nlinarith [sq_nonneg (z-1/2)]
    exact mul_pos (mul_pos (by norm_num) (sq_pos_of_ne_zero (by linarith))) hzq
  have he : coefficientFour b z=16*(z-1)^2*(z^2-z+1)+
      (2-b)*z*(((b-1)^2+15+4*(b+2)*(1-z))*z^2+24) := by
    dsimp only [coefficientFour];ring
  linarith

theorem coefficientSixSlope_pos {b z : ℝ} (hb : 0≤b) (hb2 : b≤2)
    (hz : 0<z) (hz1 : z<1) : 0<coefficientSixSlope b z := by
  have hb' : 0≤2-b := sub_nonneg.mpr hb2
  have hz2 : z^2≤1 := by nlinarith
  have hz4 : z^4≤1 := by nlinarith [sq_nonneg (z^2-1)]
  have hp0 : 0< -4*z*(11*z^4+21*z^2-70) := by
    exact mul_pos_of_neg_of_neg (by linarith) (by linarith)
  have hp2 : 0<8*z*(z-1)^2*(z^3-20*z^2+15*z+35) := by
    have hpol : 0<z^3-20*z^2+15*z+35 := by
      have h3 : 0<z^3 := pow_pos hz 3
      nlinarith
    exact mul_pos (mul_pos (mul_pos (by norm_num) hz)
      (sq_pos_of_ne_zero (by linarith))) hpol
  have he : coefficientSixSlope b z=
      ((2-b)/2)*(-4*z*(11*z^4+21*z^2-70))+
      (b/2)*(8*z*(z-1)^2*(z^3-20*z^2+15*z+35))+
      3*b*(2-b)*z^3*(11*z^2+3) := by
    dsimp only [coefficientSixSlope];ring
  have hn : 0≤3*b*(2-b)*z^3*(11*z^2+3) := by positivity
  have hfirst : 0<((2-b)/2)*(-4*z*(11*z^4+21*z^2-70))+
      (b/2)*(8*z*(z-1)^2*(z^3-20*z^2+15*z+35)) := by
    rcases lt_or_eq_of_le hb2 with hb2'|hb2'
    · have ht := mul_pos (show 0<(2-b)/2 by linarith) hp0
      have hu := mul_nonneg (show 0≤b/2 by positivity) hp2.le
      linarith
    · rw [hb2'];norm_num;exact hp2
  linarith

theorem hasDerivAt_coefficientSix (b z : ℝ) :
    HasDerivAt (fun t => coefficientSix t z) (coefficientSixSlope b z) b := by
  have h := hasDerivAt_id b
  have h2 := h.pow 2
  have h3 := h.pow 3
  have hd := (((((((((h3.const_mul (-11*z^5)).sub (h3.const_mul (3*z^3))).add
    (h2.const_mul (2*z^6))).add (h2.const_mul (112*z^4))).sub
    (h2.const_mul (110*z^2))).sub (h.const_mul (44*z^5))).sub
    (h.const_mul (84*z^3))).add (h.const_mul (280*z))).sub_const (32*z^2)).sub_const 176
  convert hd using 1
  · funext t; dsimp only [coefficientSix,id_eq]; ring
  · dsimp only [coefficientSixSlope,id_eq]; norm_num; ring

theorem coefficientSix_endpoint (z : ℝ) :
    coefficientSix 2 z=8*(z-1)^4*(z^2-18*z-22) := by
  dsimp only [coefficientSix];ring

theorem coefficientSix_neg {b z : ℝ} (hb : 0≤b) (hb2 : b≤2)
    (hz : 0<z) (hz1 : z<1) : coefficientSix b z<0 := by
  have hm : MonotoneOn (fun t => coefficientSix t z) (Icc 0 2) := by
    apply monotoneOn_of_deriv_nonneg (convex_Icc _ _)
    · intro t ht; exact (hasDerivAt_coefficientSix t z).continuousAt.continuousWithinAt
    · intro t ht; exact (hasDerivAt_coefficientSix t z).differentiableAt.differentiableWithinAt
    · intro t ht
      rw [(hasDerivAt_coefficientSix t z).deriv]
      exact (coefficientSixSlope_pos (interior_subset ht).1 (interior_subset ht).2 hz hz1).le
  have hl := hm ⟨hb,hb2⟩ ⟨by norm_num,le_rfl⟩ hb2
  change coefficientSix b z≤coefficientSix 2 z at hl
  rw [coefficientSix_endpoint] at hl
  have hn : z^2-18*z-22<0 := by nlinarith
  have hs : 0<(z-1)^2 := sq_pos_of_ne_zero (by linarith)
  have h4 : 0<(z-1)^4 := by nlinarith [sq_pos_of_pos hs]
  have hp : 0<8*(z-1)^4 := mul_pos (by norm_num) h4
  exact hl.trans_lt (mul_neg_of_pos_of_neg hp hn)

end LeanVerification.SaddleCompletion
