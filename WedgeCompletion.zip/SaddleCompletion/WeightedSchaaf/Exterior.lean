import LeanVerification.SaddleCompletion.WeightedSchaaf.HalfWell

/-! The possible outer nonconvex piece preserves the center comparison. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion.WeightedSchaaf
open RegionalReal.Schaaf
set_option maxHeartbeats 2000000

variable {ω V g g₁ g₂ g₃ φ : ℝ → ℝ} {c b : ℝ}

theorem HalfWell.g₂_neg_at_g₁_zero (h : HalfWell ω V g g₁ g₂ g₃ φ c b)
    {x : ℝ} (hx : x∈Icc c b) (hz : g₁ x=0) : g₂ x<0 := by
  have hxp : c<x := lt_of_le_of_ne hx.1 (by intro he; subst x; exact h.g₁_zero_pos.ne' hz)
  have hgp := h.g_pos x ⟨hxp,hx.2⟩
  have hn := h.crossing_neg x hx hz
  by_contra hnp
  exact (not_le_of_gt hn) (mul_nonneg hgp.le (le_of_not_gt hnp))

theorem HalfWell.g₁_zero_unique (h : HalfWell ω V g g₁ g₂ g₃ φ c b) :
    ZeroCounting.AtMostOneZeroOn g₁ (Icc c b) := by
  have hz := ZeroOrientation.atMostOneZeroOn_of_deriv_pos_at_zeros (convex_Icc c b)
    (f:=fun x => -g₁ x)
    (fun x hx => (h.g₁_deriv x hx).neg.differentiableAt)
    (fun x hx he => by
      rw [((h.g₁_deriv x hx).neg).deriv]
      exact neg_pos.mpr (div_neg_of_neg_of_pos
        (h.g₂_neg_at_g₁_zero hx (neg_eq_zero.mp he)) (h.weight_pos x hx)))
  intro x y hx hy hzx hzy
  exact hz hx hy (by simp only [hzx,neg_zero]) (by simp only [hzy,neg_zero])

theorem HalfWell.exists_g₁_zero_before_nonpos (h : HalfWell ω V g g₁ g₂ g₃ φ c b)
    {x : ℝ} (hx : x∈Icc c b) (hn : g₁ x≤0) :
    ∃ d∈Icc c x,g₁ d=0 := by
  apply intermediate_value_Icc' hx.1
    (fun t ht => (h.g₁_deriv t ⟨ht.1,ht.2.trans hx.2⟩).continuousAt.continuousWithinAt)
  exact ⟨hn,h.g₁_zero_pos.le⟩

theorem HalfWell.g₁_pos_before_zero (h : HalfWell ω V g g₁ g₂ g₃ φ c b)
    {d : ℝ} (hc : d∈Icc c b) (hcz : g₁ d=0) :
    ∀ x∈Ioo c d,0<g₁ x := by
  intro x hx
  by_contra hn
  obtain ⟨d,hd,hdz⟩ := h.exists_g₁_zero_before_nonpos
    ⟨hx.1.le,hx.2.le.trans hc.2⟩ (le_of_not_gt hn)
  have he := h.g₁_zero_unique ⟨hd.1,(hd.2.trans hx.2.le).trans hc.2⟩ hc hdz hcz
  exact (not_le_of_gt hx.2) (he ▸ hd.2)

theorem HalfWell.g₁_nonpos_after_zero (h : HalfWell ω V g g₁ g₂ g₃ φ c b)
    {d : ℝ} (hc : d∈Icc c b) (hcz : g₁ d=0) :
    ∀ x∈Icc d b,g₁ x≤0 := by
  have hn := ZeroOrientation.nonneg_on_Icc_of_deriv_pos_at_zeros
    (f:=fun x => -g₁ x)
    (fun x hx => (h.g₁_deriv x ⟨hc.1.trans hx.1,hx.2⟩).neg.differentiableAt)
    (fun x hx hz => by
      rw [((h.g₁_deriv x ⟨hc.1.trans hx.1,hx.2⟩).neg).deriv]
      exact neg_pos.mpr (div_neg_of_neg_of_pos
        (h.g₂_neg_at_g₁_zero ⟨hc.1.trans hx.1,hx.2⟩ (neg_eq_zero.mp hz))
        (h.weight_pos x ⟨hc.1.trans hx.1,hx.2⟩)))
    (by simp only [hcz,neg_zero,le_refl])
  intro x hx
  exact neg_nonneg.mp (hn x hx)

theorem HalfWell.profile_ge_at_outer_endpoint (h : HalfWell ω V g g₁ g₂ g₃ φ c b)
    {d : ℝ} (hcp : c<d) (hcb : d≤b) (hcz : g₁ d=0) : φ d≤φ b := by
  have hc : d∈Icc c b := ⟨hcp.le,hcb⟩
  have hnonpos := h.g₁_nonpos_after_zero hc hcz
  have hg : AntitoneOn g (Icc d b) := by
    apply antitoneOn_of_deriv_nonpos (convex_Icc d b)
      (fun x hx => (h.g_deriv x ⟨hcp.le.trans hx.1,hx.2⟩).continuousAt.continuousWithinAt)
      (fun x hx => (h.g_deriv x ⟨hcp.le.trans (interior_subset hx).1,(interior_subset hx).2⟩).differentiableAt.differentiableWithinAt)
    intro x hx
    have hxi : x∈Icc d b := interior_subset hx
    rw [(h.g_deriv x ⟨hcp.le.trans hxi.1,hxi.2⟩).deriv]
    exact div_nonpos_of_nonpos_of_nonneg (hnonpos x hxi)
      (h.weight_pos x ⟨hcp.le.trans hxi.1,hxi.2⟩).le
  have hgb : 0<g b := h.g_pos b ⟨h.endpoint_pos,le_rfl⟩
  have hgc : 0<g d := h.g_pos d ⟨hcp,hcb⟩
  have hgcgb : g b≤g d := hg ⟨le_rfl,hcb⟩ ⟨hcb,le_rfl⟩ hcb
  have hpbc : 1/g d≤1/g b := one_div_le_one_div_of_le hgb hgcgb
  have hpc : φ d=1/g d := by
    rw [h.profile_eq d ⟨hcp,hcb⟩]
    dsimp only [profile]
    rw [hcz,mul_zero,sub_zero]
    field_simp
    ring
  have hpb : 1/g b≤φ b := by
    rw [h.profile_eq b ⟨h.endpoint_pos,le_rfl⟩]
    dsimp only [profile]
    apply (le_div_iff₀ (pow_pos hgb 3)).mpr
    have hn : 2*V b*g₁ b≤0 := mul_nonpos_of_nonneg_of_nonpos
      (mul_nonneg (by norm_num) h.V_pos.le) (hnonpos b ⟨hcb,le_rfl⟩)
    have he : (1/g b)*(g b)^3=(g b)^2 := by field_simp; ring
    rw [he]
    linarith
  rw [hpc]
  exact hpbc.trans hpb

theorem HalfWell.profile_above_center (h : HalfWell ω V g g₁ g₂ g₃ φ c b) : φ c<φ b := by
  by_cases hz : ∃ d∈Icc c b,g₁ d=0
  · obtain ⟨d,hc,hcz⟩ := hz
    have hcp : c<d := lt_of_le_of_ne hc.1 (by intro he; subst d; exact h.g₁_zero_pos.ne' hcz)
    have hcentral := (h.restrict hcp hc.2).central_profile_pos (h.g₁_pos_before_zero hc hcz)
    exact hcentral.trans_le (h.profile_ge_at_outer_endpoint hcp hc.2 hcz)
  · apply h.central_profile_pos
    intro x hx
    by_contra hn
    obtain ⟨d,hc,hcz⟩ := h.exists_g₁_zero_before_nonpos ⟨hx.1.le,hx.2.le⟩ (le_of_not_gt hn)
    exact hz ⟨d,⟨hc.1,hc.2.trans hx.2.le⟩,hcz⟩

end LeanVerification.SaddleCompletion.WeightedSchaaf
