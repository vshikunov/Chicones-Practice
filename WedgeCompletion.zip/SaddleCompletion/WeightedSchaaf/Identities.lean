import LeanVerification.RegionalReal.Schaaf.Identities

/-! Schaaf identities for the spatial derivative ω(x) d/dx. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion.WeightedSchaaf
open RegionalReal.Schaaf
set_option maxHeartbeats 2400000

theorem hasDerivAt_A {ω g g₁ g₂ g₃ : ℝ → ℝ} {x : ℝ}
    (h0 : HasDerivAt g (g₁ x/ω x) x) (h1 : HasDerivAt g₁ (g₂ x/ω x) x)
    (h2 : HasDerivAt g₂ (g₃ x/ω x) x) :
    HasDerivAt (A g g₁ g₂) ((5*g₁ x*g₂ x-g x*g₃ x)/ω x) x := by
  have hd := ((h1.pow 2).const_mul 3).sub (h0.mul h2)
  convert hd using 1 <;> dsimp only [A] <;> ring

theorem A_deriv_at_zero {ω g g₁ g₂ g₃ : ℝ → ℝ} {x : ℝ}
    (h0 : HasDerivAt g (g₁ x/ω x) x) (h1 : HasDerivAt g₁ (g₂ x/ω x) x)
    (h2 : HasDerivAt g₂ (g₃ x/ω x) x) (ha : A g g₁ g₂ x=0)
    (hp : g₁ x≠0) :
    deriv (A g g₁ g₂) x = (g x*S g₁ g₂ g₃ x/(3*g₁ x))/ω x := by
  rw [(hasDerivAt_A h0 h1 h2).deriv]
  congr 1
  apply (eq_div_iff (mul_ne_zero (by norm_num) hp)).mpr
  dsimp only [A] at ha
  dsimp only [S]
  linear_combination 5*g₂ x*ha

theorem hasDerivAt_N {ω V g g₁ g₂ g₃ : ℝ → ℝ} {x : ℝ}
    (hV : HasDerivAt V (g x/ω x) x) (h0 : HasDerivAt g (g₁ x/ω x) x)
    (h1 : HasDerivAt g₁ (g₂ x/ω x) x) (h2 : HasDerivAt g₂ (g₃ x/ω x) x) :
    HasDerivAt (N V g g₁ g₂)
      ((2*V x*(5*g₁ x*g₂ x-g x*g₃ x)-5*(g x)^2*g₂ x)/ω x) x := by
  have hd := ((hV.const_mul 2).mul (hasDerivAt_A h0 h1 h2)).sub
    (((h0.pow 2).const_mul 3).mul h1)
  convert hd using 1 <;> dsimp only [A,N] <;> ring

theorem hasDerivAt_N_div_A {ω V g g₁ g₂ g₃ : ℝ → ℝ} {x : ℝ}
    (hV : HasDerivAt V (g x/ω x) x) (h0 : HasDerivAt g (g₁ x/ω x) x)
    (h1 : HasDerivAt g₁ (g₂ x/ω x) x) (h2 : HasDerivAt g₂ (g₃ x/ω x) x)
    (ha : A g g₁ g₂ x≠0) :
    HasDerivAt (fun t => N V g g₁ g₂ t/A g g₁ g₂ t)
      (((g x)^3*S g₁ g₂ g₃ x/(A g g₁ g₂ x)^2)/ω x) x := by
  have hd := (hasDerivAt_N hV h0 h1 h2).div (hasDerivAt_A h0 h1 h2) ha
  convert hd using 1
  dsimp only [N,A,S]
  ring

theorem hasDerivAt_profile {ω V g g₁ g₂ : ℝ → ℝ} {x : ℝ}
    (hV : HasDerivAt V (g x/ω x) x) (h0 : HasDerivAt g (g₁ x/ω x) x)
    (h1 : HasDerivAt g₁ (g₂ x/ω x) x) (hg : g x≠0) :
    HasDerivAt (profile V g g₁) ((N V g g₁ g₂ x/(g x)^4)/ω x) x := by
  have hd := ((h0.pow 2).sub ((hV.const_mul 2).mul h1)).div
    (h0.pow 3) (pow_ne_zero _ hg)
  convert hd using 1
  dsimp only [profile,N,A]
  by_cases hw : ω x=0
  · simp [hw]
  · field_simp [hg,hw]
    <;> ring

end LeanVerification.SaddleCompletion.WeightedSchaaf
