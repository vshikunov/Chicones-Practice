import LeanVerification.SaddleCompletion.WeightedSchaaf.Exterior

/-! The weighted center comparison on both sides of an arbitrary center. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion.WeightedSchaaf
open RegionalReal.Schaaf
set_option maxHeartbeats 2400000

structure Well (ω V g g₁ g₂ g₃ φ : ℝ → ℝ) (c a b : ℝ) : Prop where
  left_lt : a<c
  right_lt : c<b
  weight_pos : ∀ x∈Icc a b, 0<ω x
  V_deriv : ∀ x∈Icc a b, HasDerivAt V (g x/ω x) x
  g_deriv : ∀ x∈Icc a b, HasDerivAt g (g₁ x/ω x) x
  g₁_deriv : ∀ x∈Icc a b, HasDerivAt g₁ (g₂ x/ω x) x
  g₂_deriv : ∀ x∈Icc a b, HasDerivAt g₂ (g₃ x/ω x) x
  V_zero : V c=0
  g_zero : g c=0
  g₁_center_pos : 0<g₁ c
  g_right : ∀ x∈Ioc c b, 0<g x
  g_left : ∀ x∈Ico a c, g x<0
  schaaf_pos : ∀ x∈Icc a b, 0<g₁ x → 0<S g₁ g₂ g₃ x
  crossing_neg : ∀ x∈Icc a b, g₁ x=0 → g x*g₂ x<0
  profile_cont : ContinuousOn φ (Icc a b)
  profile_eq : ∀ x∈Icc a b, x≠c → φ x=profile V g g₁ x

variable {ω V g g₁ g₂ g₃ φ : ℝ → ℝ} {c a b : ℝ}

theorem Well.right_half (h : Well ω V g g₁ g₂ g₃ φ c a b) :
    HalfWell ω V g g₁ g₂ g₃ φ c b where
  endpoint_pos := h.right_lt
  weight_pos x hx := h.weight_pos x ⟨h.left_lt.le.trans hx.1,hx.2⟩
  V_deriv x hx := h.V_deriv x ⟨h.left_lt.le.trans hx.1,hx.2⟩
  g_deriv x hx := h.g_deriv x ⟨h.left_lt.le.trans hx.1,hx.2⟩
  g₁_deriv x hx := h.g₁_deriv x ⟨h.left_lt.le.trans hx.1,hx.2⟩
  g₂_deriv x hx := h.g₂_deriv x ⟨h.left_lt.le.trans hx.1,hx.2⟩
  V_zero := h.V_zero
  g_zero := h.g_zero
  g₁_zero_pos := h.g₁_center_pos
  g_pos := h.g_right
  schaaf_pos x hx := h.schaaf_pos x ⟨h.left_lt.le.trans hx.1,hx.2⟩
  crossing_neg x hx := h.crossing_neg x ⟨h.left_lt.le.trans hx.1,hx.2⟩
  profile_cont := h.profile_cont.mono (fun _ hx => ⟨h.left_lt.le.trans hx.1,hx.2⟩)
  profile_eq x hx := h.profile_eq x ⟨h.left_lt.le.trans hx.1.le,hx.2⟩ hx.1.ne'

theorem Well.reflected_half (h : Well ω V g g₁ g₂ g₃ φ c a b) :
    HalfWell (fun x => ω (c-x)) (fun x => V (c-x))
      (fun x => -g (c-x)) (fun x => g₁ (c-x)) (fun x => -g₂ (c-x))
      (fun x => g₃ (c-x)) (fun x => -φ (c-x)) 0 (c-a) := by
  have hmap : ∀ x∈Icc 0 (c-a), c-x∈Icc a b := by
    intro x hx
    constructor <;> linarith [h.right_lt,hx.1,hx.2]
  have hd (x : ℝ) : HasDerivAt (fun t:ℝ => c-t) (-1) x := by
    simpa using (hasDerivAt_id x).const_sub c
  refine ⟨sub_pos.mpr h.left_lt,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_⟩
  · intro x hx
    exact h.weight_pos (c-x) (hmap x hx)
  · intro x hx
    simpa [neg_div] using (h.V_deriv (c-x) (hmap x hx)).comp x (hd x)
  · intro x hx
    simpa using ((h.g_deriv (c-x) (hmap x hx)).comp x (hd x)).neg
  · intro x hx
    simpa [neg_div] using (h.g₁_deriv (c-x) (hmap x hx)).comp x (hd x)
  · intro x hx
    simpa using ((h.g₂_deriv (c-x) (hmap x hx)).comp x (hd x)).neg
  · simpa only [sub_zero] using h.V_zero
  · simp only [sub_zero,h.g_zero,neg_zero]
  · simpa only [sub_zero] using h.g₁_center_pos
  · intro x hx
    exact neg_pos.mpr (h.g_left (c-x) ⟨by linarith [hx.2],by linarith [hx.1]⟩)
  · intro x hx hgp
    simpa only [S,neg_sq] using h.schaaf_pos (c-x) (hmap x hx) hgp
  · intro x hx hz
    simpa only [neg_mul_neg] using h.crossing_neg (c-x) (hmap x hx) hz
  · exact (h.profile_cont.comp (continuous_const.sub continuous_id).continuousOn hmap).neg
  · intro x hx
    rw [h.profile_eq (c-x) (hmap x ⟨hx.1.le,hx.2⟩) (by linarith [hx.1])]
    dsimp only [profile]
    rw [neg_sq,show (-g (c-x))^3=-(g (c-x)^3) by ring,div_neg]

theorem Well.profile_gt_center_of_pos (h : Well ω V g g₁ g₂ g₃ φ c a b)
    {x : ℝ} (hx : x∈Ioc c b) : φ c<φ x :=
  (h.right_half.restrict hx.1 hx.2).profile_above_center

theorem Well.profile_lt_center_of_neg (h : Well ω V g g₁ g₂ g₃ φ c a b)
    {x : ℝ} (hx : x∈Ico a c) : φ x<φ c := by
  have hc := (h.reflected_half.restrict (sub_pos.mpr hx.2)
    (sub_le_sub_left hx.1 c)).profile_above_center
  simpa only [sub_zero,sub_sub_cancel,neg_lt_neg_iff] using hc

theorem positive_left_of_neg_deriv_at_zeros {f : ℝ → ℝ} {a c : ℝ}
    (hf : ∀ x∈Icc a c, DifferentiableAt ℝ f x)
    (hz : ∀ x∈Icc a c, f x=0 → deriv f x<0) (hc : 0<f c) :
    ∀ x∈Icc a c, 0<f x := by
  have hmap : ∀ t∈Icc 0 (c-a),c-t∈Icc a c := by
    intro t ht
    constructor <;> linarith [ht.1,ht.2]
  have hd (t : ℝ) (ht : t∈Icc 0 (c-a)) :
      HasDerivAt (fun u => f (c-u)) (-deriv f (c-t)) t := by
    simpa using (hf (c-t) (hmap t ht)).hasDerivAt.comp t
      ((hasDerivAt_id t).const_sub c)
  have hp := positive_on_Icc_of_positive_zero_orientation
    (fun t ht => (hd t ht).differentiableAt)
    (fun t ht he => by
      rw [(hd t ht).deriv]
      exact neg_pos.mpr (hz (c-t) (hmap t ht) he))
    (by simpa only [sub_zero] using hc)
  intro x hx
  have hmem : c-x∈Icc 0 (c-a) := ⟨sub_nonneg.mpr hx.2,sub_le_sub_left hx.1 c⟩
  simpa only [sub_sub_cancel] using hp (c-x) hmem

end LeanVerification.SaddleCompletion.WeightedSchaaf
