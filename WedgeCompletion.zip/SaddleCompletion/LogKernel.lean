import LeanVerification.SaddleCompletion.WidthCriterion
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.SpecialFunctions.Sqrt

/-! The strictly increasing scalar factor in the logarithmic energy change. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion
open Loud
set_option maxHeartbeats 2600000

def logAmplitude (H r : ℝ) : ℝ := Real.sqrt (-Real.log (1-r^2/(2*H)))
def logKernel (H r : ℝ) : ℝ := r/(logAmplitude H r*Real.sqrt (2*H-r^2))

theorem logAmplitude_radicand_pos {H r : ℝ} (hH : 0<H) (hr : 0<r)
    (hrH : r^2<2*H) : 0< -Real.log (1-r^2/(2*H)) := by
  have hden : 0<2*H := by positivity
  have hx : 0<r^2/(2*H) := div_pos (sq_pos_of_pos hr) hden
  have hx1 : r^2/(2*H)<1 := (div_lt_one hden).mpr hrH
  exact neg_pos.mpr (Real.log_neg (by linarith) (by linarith))

theorem logAmplitude_pos {H r : ℝ} (hH : 0<H) (hr : 0<r)
    (hrH : r^2<2*H) : 0<logAmplitude H r :=
  Real.sqrt_pos.mpr (logAmplitude_radicand_pos hH hr hrH)

theorem logAmplitude_sq {H r : ℝ} (hH : 0<H) (hr : 0<r)
    (hrH : r^2<2*H) : (logAmplitude H r)^2= -Real.log (1-r^2/(2*H)) :=
  Real.sq_sqrt (logAmplitude_radicand_pos hH hr hrH).le

theorem logAmplitude_strict_comparison {H r : ℝ} (hH : 0<H) (hr : 0<r)
    (hrH : r^2<2*H) : r^2<2*H*(logAmplitude H r)^2 := by
  have hden : 0<2*H := by positivity
  have hx : 0<r^2/(2*H) := div_pos (sq_pos_of_pos hr) hden
  have hx1 : r^2/(2*H)<1 := (div_lt_one hden).mpr hrH
  have hlog := Real.log_lt_sub_one_of_pos (show 0<1-r^2/(2*H) by linarith)
    (show 1-r^2/(2*H)≠1 by linarith)
  rw [logAmplitude_sq hH hr hrH]
  have ht : r^2/(2*H)< -Real.log (1-r^2/(2*H)) := by linarith
  have he := (div_lt_iff₀ hden).mp ht
  nlinarith

theorem logKernel_pos {H r : ℝ} (hH : 0<H) (hr : 0<r)
    (hrH : r^2<2*H) : 0<logKernel H r :=
  div_pos hr (mul_pos (logAmplitude_pos hH hr hrH) (Real.sqrt_pos.mpr (sub_pos.mpr hrH)))

theorem hasDerivAt_logAmplitude {H r : ℝ} (hH : 0<H) (hr : 0<r)
    (hrH : r^2<2*H) :
    HasDerivAt (logAmplitude H) (r/((2*H-r^2)*logAmplitude H r)) r := by
  have hden : 0<2*H := by positivity
  have hx1 : r^2/(2*H)<1 := (div_lt_one hden).mpr hrH
  have hx : 1-r^2/(2*H)≠0 := ne_of_gt (by linarith)
  have hl : -Real.log (1-r^2/(2*H))≠0 := (logAmplitude_radicand_pos hH hr hrH).ne'
  have hd := ((((hasDerivAt_id r).pow 2).div_const (2*H)).const_sub 1).log hx
  have hs := (Real.hasDerivAt_sqrt hl).comp r hd.neg
  convert hs using 1
  simp only [Nat.cast_ofNat,Nat.reduceSub,pow_one,mul_one,id_eq]
  change r/((2*H-r^2)*logAmplitude H r)=
    1/(2*logAmplitude H r)* -(-(2*r/(2*H))/(1-r^2/(2*H)))
  generalize logAmplitude H r=u
  by_cases hu : u=0
  · simp [hu]
  · field_simp [hH.ne',hx,hu,(sub_pos.mpr hrH).ne']
    <;> ring

theorem logAmplitude_deriv_pos {H r : ℝ} (hH : 0<H) (hr : 0<r)
    (hrH : r^2<2*H) : 0<deriv (logAmplitude H) r := by
  rw [(hasDerivAt_logAmplitude hH hr hrH).deriv]
  exact div_pos hr (mul_pos (sub_pos.mpr hrH) (logAmplitude_pos hH hr hrH))

theorem hasDerivAt_logKernel {H r : ℝ} (hH : 0<H) (hr : 0<r)
    (hrH : r^2<2*H) :
    HasDerivAt (logKernel H)
      ((2*H*(logAmplitude H r)^2-r^2)/
        ((Real.sqrt (2*H-r^2))^3*(logAmplitude H r)^3)) r := by
  have hu := logAmplitude_pos hH hr hrH
  have hs : 0<Real.sqrt (2*H-r^2) := Real.sqrt_pos.mpr (sub_pos.mpr hrH)
  have hsq := Real.sq_sqrt (sub_pos.mpr hrH).le
  have hsd : HasDerivAt (fun x:ℝ => Real.sqrt (2*H-x^2))
      (-r/Real.sqrt (2*H-r^2)) r := by
    have h := (Real.hasDerivAt_sqrt (sub_pos.mpr hrH).ne').comp r
      (((hasDerivAt_id r).pow 2).const_sub (2*H))
    convert h using 1 <;> simp only [Nat.cast_ofNat,Nat.reduceSub,pow_one,mul_one,id_eq]
    ring
  have hd := (hasDerivAt_id r).div ((hasDerivAt_logAmplitude hH hr hrH).mul hsd)
    (mul_ne_zero hu.ne' hs.ne')
  convert hd using 1
  simp only [id_eq,mul_one,one_mul]
  generalize logAmplitude H r=u at *
  generalize Real.sqrt (2*H-r^2)=s at *
  have he : 2*H=s^2+r^2 := by linarith [hsq]
  rw [he]
  simp only [add_sub_cancel_right]
  field_simp [hu.ne',hs.ne']
  <;> ring

theorem logKernel_deriv_pos {H r : ℝ} (hH : 0<H) (hr : 0<r)
    (hrH : r^2<2*H) : 0<deriv (logKernel H) r := by
  rw [(hasDerivAt_logKernel hH hr hrH).deriv]
  exact div_pos (sub_pos.mpr (logAmplitude_strict_comparison hH hr hrH))
    (mul_pos (pow_pos (Real.sqrt_pos.mpr (sub_pos.mpr hrH)) 3)
      (pow_pos (logAmplitude_pos hH hr hrH) 3))

end LeanVerification.SaddleCompletion
