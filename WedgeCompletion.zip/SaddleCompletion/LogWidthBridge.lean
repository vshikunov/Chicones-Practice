import LeanVerification.SaddleCompletion.LogKernel

/-! A genuine identity for the inverse velocities transfers the weighted
comparison to the actual physical width. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion
open Loud
set_option maxHeartbeats 2000000

theorem physical_width_second_pos_of_log_bridge (D F H c r : ℝ) (R : ℝ → ℝ)
    (hH : 0<H) (hr : 0<r) (hrH : r^2<2*H) (hc : 0<c)
    (hu : r∈morseRange D F) (hn : -r∈morseRange D F)
    (hRp : DifferentiableAt ℝ R (logAmplitude H r))
    (hRn : DifferentiableAt ℝ R (-logAmplitude H r))
    (hpos : 0<R (logAmplitude H r)+R (-logAmplitude H r))
    (hcomp : deriv R (-logAmplitude H r)<deriv R (logAmplitude H r))
    (heq : physicalWidthJet D F 1 =ᶠ[𝓝 r]
      fun t => c*logKernel H t*(R (logAmplitude H t)+R (-logAmplitude H t))) :
    0<physicalWidthJet D F 2 r := by
  have hu' := (hasDerivAt_logAmplitude hH hr hrH).differentiableAt.hasDerivAt
  have hB' := (hasDerivAt_logKernel hH hr hrH).differentiableAt.hasDerivAt
  have hR' := (hRp.hasDerivAt.comp r hu').add (hRn.hasDerivAt.comp r hu'.neg)
  have hd := (hB'.const_mul c).mul hR'
  have he := (hd.congr_of_eventuallyEq heq).unique
    (hasDerivAt_physicalWidthJet D F r 1 hu hn)
  have hp : 0<c*(deriv (logKernel H) r*
      (R (logAmplitude H r)+R (-logAmplitude H r))+
      logKernel H r*(deriv R (logAmplitude H r)-deriv R (-logAmplitude H r))*
        deriv (logAmplitude H) r) := by
    exact mul_pos hc (add_pos
      (mul_pos (logKernel_deriv_pos hH hr hrH) hpos)
      (mul_pos (mul_pos (logKernel_pos hH hr hrH) (sub_pos.mpr hcomp))
        (logAmplitude_deriv_pos hH hr hrH)))
  have hid : c*(deriv (logKernel H) r*
      (R (logAmplitude H r)+R (-logAmplitude H r))+
      logKernel H r*(deriv R (logAmplitude H r)-deriv R (-logAmplitude H r))*
        deriv (logAmplitude H) r)=physicalWidthJet D F 2 r := by
    convert he using 1 <;> simp only [Function.comp_apply] <;> ring
  exact hid ▸ hp

end LeanVerification.SaddleCompletion
