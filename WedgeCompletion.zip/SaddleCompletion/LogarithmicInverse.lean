import LeanVerification.SaddleCompletion.LogarithmicWell

/-! The selected inverse of the normalized signed Morse coordinate and its
positive weighted velocity. Every object is constructed from the potential. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion
open GeneralMechanical
set_option maxHeartbeats 2400000

def logMorse (m b c z : ℝ) : ℝ :=
  signedMorseCoordinate (liftedLogPotential m b c) (0,z-c)
def logRange (m b c s : ℝ) : Set ℝ :=
  {u | (0,u)∈AnalyticWell.amplitudeDomain (F := liftedLogPotential m b c) (liftedLogDomain c s)}
def logInverse (m b c s u : ℝ) : ℝ :=
  c+AnalyticWell.morseInverse (F := liftedLogPotential m b c) (liftedLogDomain c s) (0,u)
def logVelocity (m b c s u : ℝ) : ℝ :=
  deriv (logInverse m b c s) u/normWeight b (logInverse m b c s u)
def logProfile (m b c s z : ℝ) : ℝ :=
  deriv (logVelocity m b c s) (logMorse m b c z)

variable {m b c s : ℝ} (h : LogModel m b c s)
include h

theorem LogModel.shift_mem {z : ℝ} (hz : z∈Ioo 0 s) :
    (0,z-c)∈liftedLogDomain c s := by
  rw [h.lifted_mem_iff]
  simpa only [add_sub_cancel] using hz

theorem LogModel.morse_mem {z : ℝ} (hz : z∈Ioo 0 s) :
    logMorse m b c z∈logRange m b c s :=
  ⟨z-c,h.shift_mem hz,rfl⟩

theorem LogModel.inverse_mem {u : ℝ} (hu : u∈logRange m b c s) :
    logInverse m b c s u∈Ioo 0 s := by
  have hm := h.analyticWell.morseInverse_mem (q := (0,u)) hu
  exact (h.lifted_mem_iff _).mp hm

theorem LogModel.inverse_morse {z : ℝ} (hz : z∈Ioo 0 s) :
    logInverse m b c s (logMorse m b c z)=z := by
  have he := h.analyticWell.morseInverse_left (h.shift_mem hz)
  dsimp only [logInverse,logMorse]
  rw [he]
  ring

theorem LogModel.morse_inverse {u : ℝ} (hu : u∈logRange m b c s) :
    logMorse m b c (logInverse m b c s u)=u := by
  have he := h.analyticWell.morseInverse_right (q := (0,u)) hu
  simpa only [logMorse,logInverse,add_sub_cancel_left] using he

theorem LogModel.morse_center : logMorse m b c c=0 := by
  simp only [logMorse,sub_self,signedMorseCoordinate,zero_mul]

theorem LogModel.range_zero : 0∈logRange m b c s := by
  simpa only [h.morse_center] using h.morse_mem h.center_mem

theorem LogModel.inverse_zero : logInverse m b c s 0=c := by
  simpa only [h.morse_center] using h.inverse_morse h.center_mem

theorem LogModel.isOpen_range : IsOpen (logRange m b c s) :=
  h.analyticWell.isOpen_amplitudeDomain.preimage (continuous_const.prodMk continuous_id)

theorem LogModel.analytic_morse {z : ℝ} (hz : z∈Ioo 0 s) :
    AnalyticAt ℝ (logMorse m b c) z :=
  (h.analyticWell.analytic_signedMorseCoordinate _ (h.shift_mem hz)).comp_of_eq
    (analyticAt_const.prod (analyticAt_id.sub analyticAt_const)) rfl

theorem LogModel.analytic_inverse {u : ℝ} (hu : u∈logRange m b c s) :
    AnalyticAt ℝ (logInverse m b c s) u :=
  analyticAt_const.add (h.analyticWell.analytic_morseInverse (0,u) hu).curry_right

theorem LogModel.inverse_deriv_pos {u : ℝ} (hu : u∈logRange m b c s) :
    0<deriv (logInverse m b c s) u := by
  have hd := (h.analyticWell.analytic_morseInverse (0,u) hu).curry_right.differentiableAt.hasDerivAt.const_add c
  change HasDerivAt (logInverse m b c s)
    (deriv (fun y => AnalyticWell.morseInverse (F := liftedLogPotential m b c)
      (liftedLogDomain c s) (0,y)) u) u at hd
  rw [hd.deriv]
  exact h.analyticWell.morseInverse_deriv_pos hu

theorem LogModel.inverse_energy {u : ℝ} (hu : u∈logRange m b c s) :
    normPotential m b c (logInverse m b c s u)=u^2/2 := by
  have he := h.analyticWell.morseInverse_energy (q := (0,u)) hu
  simpa only [liftedLogPotential,add_zero,h.potential_center,sub_zero,logInverse] using he

theorem LogModel.morse_square {z : ℝ} (hz : z∈Ioo 0 s) :
    (logMorse m b c z)^2=2*normPotential m b c z := by
  have he := h.inverse_energy (h.morse_mem hz)
  rw [h.inverse_morse hz] at he
  linarith

theorem LogModel.morse_sign {z : ℝ} (hz : z∈Ioo 0 s) :
    (0<logMorse m b c z ↔ c<z) ∧ (logMorse m b c z<0 ↔ z<c) := by
  have hp := h.analyticWell.morseQuadraticFactor_pos (h.shift_mem hz)
  have hs := Real.sqrt_pos.mpr hp
  dsimp only [logMorse,signedMorseCoordinate]
  exact ⟨by rw [mul_pos_iff_of_pos_right hs,sub_pos],
    by constructor <;> intro ht <;> nlinarith⟩

theorem LogModel.inverse_sign {u : ℝ} (hu : u∈logRange m b c s) :
    (0<u ↔ c<logInverse m b c s u) ∧ (u<0 ↔ logInverse m b c s u<c) := by
  simpa only [h.morse_inverse hu] using h.morse_sign (h.inverse_mem hu)

theorem LogModel.analytic_velocity {u : ℝ} (hu : u∈logRange m b c s) :
    AnalyticAt ℝ (logVelocity m b c s) u := by
  have hi := h.analytic_inverse hu
  have hQ := h.quad_pos (h.inverse_mem hu)
  exact hi.deriv.div ((analyticAt_normWeight hQ).comp hi) (normWeight_pos hQ).ne'

theorem LogModel.velocity_pos {u : ℝ} (hu : u∈logRange m b c s) :
    0<logVelocity m b c s u :=
  div_pos (h.inverse_deriv_pos hu) (normWeight_pos (h.quad_pos (h.inverse_mem hu)))

theorem LogModel.analytic_profile {z : ℝ} (hz : z∈Ioo 0 s) :
    AnalyticAt ℝ (logProfile m b c s) z :=
  (h.analytic_velocity (h.morse_mem hz)).deriv.comp (h.analytic_morse hz)

theorem LogModel.velocity_force {u : ℝ} (hu : u∈logRange m b c s) :
    logVelocity m b c s u*normFirst m b (logInverse m b c s u)=u := by
  have hz := h.inverse_mem hu
  have hi := h.analytic_inverse hu
  have hp := hasDerivAt_normPotential (m := m) hz.1.ne' h.center_pos.ne'
    (h.quad_pos hz) (h.quad_pos h.center_mem).ne'
  have hd := hp.comp u hi.differentiableAt.hasDerivAt
  have he : (fun v => normPotential m b c (logInverse m b c s v)) =ᶠ[𝓝 u]
      (fun v => v^2/2) := by
    filter_upwards [h.isOpen_range.mem_nhds hu] with v hv
    exact h.inverse_energy hv
  have huq := (hd.congr_of_eventuallyEq he.symm).unique
    (((hasDerivAt_id u).pow 2).div_const 2)
  dsimp only [Function.comp_apply,id_eq] at huq
  norm_num at huq
  dsimp only [logVelocity]
  convert huq using 1 <;> ring

theorem LogModel.profile_eq {z : ℝ} (hz : z∈Ioo 0 s) (hzc : z≠c) :
    logProfile m b c s z=RegionalReal.Schaaf.profile (normPotential m b c)
      (normFirst m b) (normSecond m b) z := by
  let u := logMorse m b c z
  have hu := h.morse_mem hz
  have he : logInverse m b c s u=z := h.inverse_morse hz
  have hR := h.analytic_velocity hu
  have hi := h.analytic_inverse hu
  have hg := hasDerivAt_normFirst (m := m) hz.1.ne' (h.quad_pos hz)
  have hd := hR.differentiableAt.hasDerivAt.mul
    (hg.comp_of_eq u hi.differentiableAt.hasDerivAt he.symm)
  have hiProd : (fun v => logVelocity m b c s v*normFirst m b (logInverse m b c s v))
      =ᶠ[𝓝 u] id := by
    filter_upwards [h.isOpen_range.mem_nhds hu] with v hv
    exact h.velocity_force hv
  have hj := (hd.congr_of_eventuallyEq hiProd.symm).unique (hasDerivAt_id u)
  change deriv (logVelocity m b c s) u*normFirst m b (logInverse m b c s u)+
    logVelocity m b c s u*(normSecond m b z/normWeight b z*deriv (logInverse m b c s) u)=1 at hj
  rw [he] at hj
  have hrel := h.velocity_force hu
  rw [he] at hrel
  have hsq := congrArg (fun x:ℝ => x^2) hrel
  have henergy := h.morse_square hz
  have hw := normWeight_pos (h.quad_pos hz)
  have hvel : deriv (logInverse m b c s) u=normWeight b z*logVelocity m b c s u := by
    dsimp only [logVelocity]
    rw [he]
    field_simp
  rw [hvel] at hj
  have hgn : normFirst m b z≠0 := by
    rcases lt_or_gt_of_ne hzc with hn|hp
    · exact (h.first_neg ⟨hz.1,hn⟩).ne
    · exact (h.first_pos ⟨hp,hz.2⟩).ne'
  change deriv (logVelocity m b c s) u=
    ((normFirst m b z)^2-2*normPotential m b c z*normSecond m b z)/(normFirst m b z)^3
  apply (eq_div_iff (pow_ne_zero _ hgn)).mpr
  have hj' : deriv (logVelocity m b c s) u*normFirst m b z+
      (logVelocity m b c s u)^2*normSecond m b z=1 := by
    convert hj using 1
    field_simp
    ring
  linear_combination (normFirst m b z)^2*hj'-normSecond m b z*hsq-
    normSecond m b z*henergy

end LeanVerification.SaddleCompletion
