import LeanVerification.SaddleCompletion.NormalizedCertificates

/-! The exact second derivative and the Schaaf certificate of the normalized
logarithmic saddle potential. The spatial derivative is sqrt(2 Q) d/dz. -/
noncomputable section
namespace LeanVerification.SaddleCompletion
set_option maxHeartbeats 3200000
set_option maxRecDepth 2500

def normSecond (m b z : ℝ) : ℝ :=
  m*normRadius b z/(2*z^2)-normDiscriminant b/(2*normQuad b z)
def normSecondSlope (m b z : ℝ) : ℝ :=
  m*(b*z-4)/(2*z^3)+normDiscriminant b*(2*z-b)/(2*(normQuad b z)^2)
def normSecondSlopeSlope (m b z : ℝ) : ℝ :=
  m*(6-b*z)/z^4+normDiscriminant b/(normQuad b z)^2-
    normDiscriminant b*(2*z-b)^2/(normQuad b z)^3
def normSchaaf (m b z : ℝ) : ℝ :=
  10*normQuad b z*(normSecondSlope m b z)^2-
    3*normSecond m b z*((2*z-b)*normSecondSlope m b z+
      2*normQuad b z*normSecondSlopeSlope m b z)
def thresholdExponent (b z : ℝ) : ℝ :=
  normDiscriminant b*z^2/(normRadius b z*normQuad b z)

def secondNumerator (m b z : ℝ) : ℝ :=
  m*normRadius b z*normQuad b z-normDiscriminant b*z^2
def secondSlopeNumerator (m b z : ℝ) : ℝ :=
  m*(b*z-4)*(normQuad b z)^2+normDiscriminant b*z^3*(2*z-b)
def secondSlopeSlopeNumerator (m b z : ℝ) : ℝ :=
  m*(6-b*z)*(normQuad b z)^3+normDiscriminant b*z^4*normQuad b z-
    normDiscriminant b*z^4*(2*z-b)^2

theorem normSecond_factorization (m b z : ℝ) (hz : z≠0)
    (hQ : normQuad b z≠0) (hr : normRadius b z≠0) :
    normSecond m b z=normRadius b z/(2*z^2)*(m-thresholdExponent b z) := by
  dsimp only [normSecond,thresholdExponent]
  field_simp [hz,hQ,hr]
  <;> ring

theorem normSchaaf_numerator (m b z : ℝ) (hz : z≠0)
    (hQ : normQuad b z≠0) :
    normSchaaf m b z=(10*(secondSlopeNumerator m b z)^2-
      3*secondNumerator m b z*((2*z-b)*z*secondSlopeNumerator m b z+
        4*secondSlopeSlopeNumerator m b z))/(4*z^6*(normQuad b z)^3) := by
  dsimp only [normSchaaf,normSecond,normSecondSlope,normSecondSlopeSlope,
    secondNumerator,secondSlopeNumerator,secondSlopeSlopeNumerator]
  field_simp [hz,hQ]
  ring

theorem normSchaaf_coefficient_identity (m b z : ℝ) (hz : z≠0)
    (hQ : normQuad b z≠0) (hr : normRadius b z≠0) :
    normSchaaf m b z=
      5*(normDiscriminant b)^2*(crossingFactor b z)^2/
        (2*z^2*(normRadius b z)^2*(normQuad b z)^3)-
      normDiscriminant b*coefficientSix b z*(m-thresholdExponent b z)/
        (4*z^4*normRadius b z*(normQuad b z)^2)+
      coefficientFour b z*(m-thresholdExponent b z)^2/(4*z^6) := by
  generalize hμ : m-thresholdExponent b z=μ
  have he : m*normRadius b z*normQuad b z-normDiscriminant b*z^2-
      μ*normRadius b z*normQuad b z=0 := by
    dsimp only [thresholdExponent] at hμ
    field_simp [hr,hQ] at hμ
    nlinarith [hμ]
  rw [normSchaaf_numerator m b z hz hQ]
  field_simp [hz,hQ,hr]
  dsimp only [secondNumerator,secondSlopeNumerator,secondSlopeSlopeNumerator]
  have hi :
      (normRadius b z)^2*(10*(secondSlopeNumerator m b z)^2-
        3*secondNumerator m b z*((2*z-b)*z*secondSlopeNumerator m b z+
          4*secondSlopeSlopeNumerator m b z))-
      (10*(normDiscriminant b)^2*(crossingFactor b z)^2*z^4-
        normDiscriminant b*coefficientSix b z*μ*z^2*normRadius b z*normQuad b z+
        coefficientFour b z*μ^2*(normRadius b z)^2*(normQuad b z)^3)=0 := by
    dsimp only [secondNumerator,secondSlopeNumerator,secondSlopeSlopeNumerator]
    linear_combination (norm := skip)
      (coefficientFour b z*normRadius b z*(normQuad b z)^2*(m+μ)-
        coefficientFour b z*normDiscriminant b*z^2*normQuad b z-
        normDiscriminant b*coefficientSix b z*z^2)*he
    dsimp only [normQuad,normRadius,normDiscriminant,coefficientFour,coefficientSix,crossingFactor]
    ring
  dsimp only [secondNumerator,secondSlopeNumerator,secondSlopeSlopeNumerator] at hi
  linear_combination 32*z^12*normRadius b z*(normQuad b z)^5*hi

theorem normSchaaf_pos {m b z : ℝ} (hb : 0≤b) (hb2 : b≤2)
    (hz : 0<z) (hz1 : z<1) (hR : 0<normSecond m b z) :
    0<normSchaaf m b z := by
  have hQ := normQuad_pos hb2 hz hz1
  have hr := normRadius_pos hb2 hz hz1
  have hd := normDiscriminant_nonneg hb hb2
  have hm : 0<m-thresholdExponent b z := by
    rw [normSecond_factorization m b z hz.ne' hQ.ne' hr.ne'] at hR
    exact pos_of_mul_pos_right hR (div_pos hr (mul_pos (by norm_num) (sq_pos_of_pos hz))).le
  have hp4 := coefficientFour_pos hb hb2 hz hz1
  have hp6 := coefficientSix_neg hb hb2 hz hz1
  rw [normSchaaf_coefficient_identity m b z hz.ne' hQ.ne' hr.ne']
  have hfirst : 0≤5*(normDiscriminant b)^2*(crossingFactor b z)^2/
      (2*z^2*(normRadius b z)^2*(normQuad b z)^3) := by positivity
  have hsecond : normDiscriminant b*coefficientSix b z*(m-thresholdExponent b z)/
      (4*z^4*normRadius b z*(normQuad b z)^2)≤0 := by
    exact div_nonpos_of_nonpos_of_nonneg
      (mul_nonpos_of_nonpos_of_nonneg (mul_nonpos_of_nonneg_of_nonpos hd hp6.le) hm.le)
      (by positivity)
  have hthird : 0<coefficientFour b z*(m-thresholdExponent b z)^2/(4*z^6) := by positivity
  linarith

theorem normSecondSlope_at_zero {m b z : ℝ} (hz : z≠0)
    (hQ : normQuad b z≠0) (hr : normRadius b z≠0) (hR : normSecond m b z=0) :
    normSecondSlope m b z=
      -normDiscriminant b*crossingFactor b z/(2*z*normRadius b z*(normQuad b z)^2) := by
  have hm : m=thresholdExponent b z := by
    rw [normSecond_factorization m b z hz hQ hr] at hR
    exact sub_eq_zero.mp ((mul_eq_zero.mp hR).resolve_left
      (div_ne_zero hr (mul_ne_zero (by norm_num) (pow_ne_zero _ hz))))
  rw [hm]
  dsimp only [normSecondSlope,thresholdExponent]
  field_simp [hz,hQ,hr]
  dsimp only [normQuad,normRadius,normDiscriminant,crossingFactor]
  ring

theorem normSecondSlope_neg_at_zero {m b z : ℝ} (hm : 0<m)
    (hb : 0≤b) (hb2 : b≤2) (hz : 0<z) (hz1 : z<1)
    (hR : normSecond m b z=0) : normSecondSlope m b z<0 := by
  have hQ := normQuad_pos hb2 hz hz1
  have hr := normRadius_pos hb2 hz hz1
  have hd : 0<normDiscriminant b := by
    have he : normDiscriminant b/(2*normQuad b z)=m*normRadius b z/(2*z^2) := by
      dsimp only [normSecond] at hR
      linarith
    have hp : 0<normDiscriminant b/(2*normQuad b z) := by rw [he];positivity
    exact (div_pos_iff_of_pos_right (mul_pos (by norm_num) hQ)).mp hp
  rw [normSecondSlope_at_zero hz.ne' hQ.ne' hr.ne' hR]
  exact div_neg_of_neg_of_pos
    (mul_neg_of_neg_of_pos (neg_neg_of_pos hd) (crossingFactor_pos hb2 hz hz1))
    (by positivity)

end LeanVerification.SaddleCompletion
