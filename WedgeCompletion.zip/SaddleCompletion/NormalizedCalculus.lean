import LeanVerification.SaddleCompletion.NormalizedJets
import LeanVerification.Loud.AnalyticCoordinates
import LeanVerification.GeneralMechanical.TurnClockFactors
import Mathlib.Analysis.SpecialFunctions.Sqrt

/-! Derivatives of the actual normalized logarithmic potential, with the
positive spatial weight retained explicitly. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 2000

def normWeight (b z : ℝ) : ℝ := Real.sqrt (2*normQuad b z)
def normPotential (m b c z : ℝ) : ℝ :=
  -(m*Real.log (z/c)+Real.log (normQuad b z/normQuad b c))/2
def normFirst (m b z : ℝ) : ℝ :=
  -(m*normQuad b z+z*(2*z-b))/(z*normWeight b z)
def normThird (m b z : ℝ) : ℝ := normWeight b z*normSecondSlope m b z
def normFourth (m b z : ℝ) : ℝ :=
  (2*z-b)*normSecondSlope m b z+2*normQuad b z*normSecondSlopeSlope m b z

theorem normWeight_pos {b z : ℝ} (hQ : 0<normQuad b z) : 0<normWeight b z :=
  Real.sqrt_pos.mpr (mul_pos (by norm_num) hQ)

theorem normWeight_sq {b z : ℝ} (hQ : 0≤normQuad b z) :
    (normWeight b z)^2=2*normQuad b z := by
  exact Real.sq_sqrt (mul_nonneg (by norm_num) hQ)

theorem hasDerivAt_normQuad (b z : ℝ) :
    HasDerivAt (normQuad b) (2*z-b) z := by
  convert ((((hasDerivAt_id z).pow 2).sub ((hasDerivAt_id z).const_mul b)).add_const 1) using 1
  norm_num

theorem hasDerivAt_normWeight {b z : ℝ} (hQ : 0<normQuad b z) :
    HasDerivAt (normWeight b) ((2*z-b)/normWeight b z) z := by
  have hd := ((hasDerivAt_normQuad b z).const_mul 2).sqrt
    (mul_ne_zero (by norm_num) hQ.ne')
  convert hd using 1
  dsimp only [normWeight]
  ring

theorem hasDerivAt_normPotential {m b c z : ℝ}
    (hz : z≠0) (hc : c≠0) (hQ : 0<normQuad b z) (hQc : normQuad b c≠0) :
    HasDerivAt (normPotential m b c) (normFirst m b z/normWeight b z) z := by
  have hlog1 := ((hasDerivAt_id z).div_const c).log (div_ne_zero hz hc)
  have hlog2 := ((hasDerivAt_normQuad b z).div_const (normQuad b c)).log
    (div_ne_zero hQ.ne' hQc)
  have hd := (((hlog1.const_mul m).add hlog2).neg).div_const 2
  convert hd using 1
  dsimp only [normFirst]
  have hw := normWeight_pos hQ
  field_simp
  linear_combination z*(z*(2*z-b)+m*normQuad b z)*(normWeight_sq hQ.le)

theorem hasDerivAt_normFirst {m b z : ℝ} (hz : z≠0) (hQ : 0<normQuad b z) :
    HasDerivAt (normFirst m b) (normSecond m b z/normWeight b z) z := by
  have hnum := ((hasDerivAt_normQuad b z).const_mul m).add
    ((hasDerivAt_id z).mul (((hasDerivAt_id z).const_mul 2).sub_const b))
  have hden := (hasDerivAt_id z).mul (hasDerivAt_normWeight hQ)
  have hw := normWeight_pos hQ
  have hd := hnum.neg.div hden (mul_ne_zero hz hw.ne')
  convert hd using 1
  dsimp only [normSecond]
  field_simp
  have hcube : (normWeight b z)^3=2*normQuad b z*normWeight b z := by
    linear_combination normWeight b z*(normWeight_sq hQ.le)
  ring_nf
  rw [hcube]
  dsimp only [normQuad,normRadius,normDiscriminant]
  ring

theorem hasDerivAt_normSecond {m b z : ℝ} (hz : z≠0) (hQ : normQuad b z≠0) :
    HasDerivAt (normSecond m b) (normSecondSlope m b z) z := by
  have hr := (((hasDerivAt_id z).const_mul b).const_sub 2).const_mul m
  have hden := ((hasDerivAt_id z).pow 2).const_mul 2
  have hd := (hr.div hden (mul_ne_zero (by norm_num) (pow_ne_zero _ hz))).sub
    ((hasDerivAt_const z (normDiscriminant b)).div
      ((hasDerivAt_normQuad b z).const_mul 2) (mul_ne_zero (by norm_num) hQ))
  convert hd using 1
  dsimp only [normSecondSlope,normRadius]
  field_simp
  ring

theorem hasDerivAt_normSecondSlope {m b z : ℝ} (hz : z≠0) (hQ : normQuad b z≠0) :
    HasDerivAt (normSecondSlope m b) (normSecondSlopeSlope m b z) z := by
  have hnum := (((hasDerivAt_id z).const_mul b).sub_const 4).const_mul m
  have hden := ((hasDerivAt_id z).pow 3).const_mul 2
  have hnum2 := (((hasDerivAt_id z).const_mul 2).sub_const b).const_mul (normDiscriminant b)
  have hden2 := ((hasDerivAt_normQuad b z).pow 2).const_mul 2
  have hd := (hnum.div hden (mul_ne_zero (by norm_num) (pow_ne_zero _ hz))).add
    (hnum2.div hden2 (mul_ne_zero (by norm_num) (pow_ne_zero _ hQ)))
  convert hd using 1
  dsimp only [normSecondSlopeSlope]
  field_simp
  ring

theorem hasDerivAt_normThird {m b z : ℝ} (hz : z≠0) (hQ : 0<normQuad b z) :
    HasDerivAt (normThird m b) (normFourth m b z/normWeight b z) z := by
  have hd := (hasDerivAt_normWeight hQ).mul (hasDerivAt_normSecondSlope (m := m) hz hQ.ne')
  convert hd using 1
  dsimp only [normFourth]
  have hw := normWeight_pos hQ
  field_simp
  linear_combination -normSecondSlopeSlope m b z*(normWeight_sq hQ.le)

theorem normSchaaf_eq_force_jets {m b z : ℝ} (hQ : 0≤normQuad b z) :
    normSchaaf m b z=5*(normThird m b z)^2-3*normSecond m b z*normFourth m b z := by
  dsimp only [normSchaaf,normThird,normFourth]
  rw [mul_pow,normWeight_sq hQ]
  ring

theorem analyticAt_normQuad (b z : ℝ) : AnalyticAt ℝ (normQuad b) z := by
  exact ((analyticAt_id.pow 2).sub (analyticAt_const.mul analyticAt_id)).add analyticAt_const

theorem analyticAt_normWeight {b z : ℝ} (hQ : 0<normQuad b z) :
    AnalyticAt ℝ (normWeight b) z :=
  GeneralMechanical.analyticAt_sqrt_comp (analyticAt_const.mul (analyticAt_normQuad b z)) (by positivity)

theorem analyticAt_normPotential {m b c z : ℝ}
    (hz : 0<z) (hc : 0<c) (hQ : 0<normQuad b z) (hQc : 0<normQuad b c) :
    AnalyticAt ℝ (normPotential m b c) z := by
  have ha1 : AnalyticAt ℝ (fun x:ℝ => x/c) z :=
    analyticAt_id.div analyticAt_const hc.ne'
  have hlog1 : AnalyticAt ℝ (fun x:ℝ => Real.log (x/c)) z :=
    (analyticAt_log (div_pos hz hc)).comp_of_eq ha1 rfl
  have ha2 : AnalyticAt ℝ (fun x:ℝ => normQuad b x/normQuad b c) z :=
    (analyticAt_normQuad b z).div analyticAt_const hQc.ne'
  have hlog2 : AnalyticAt ℝ (fun x:ℝ => Real.log (normQuad b x/normQuad b c)) z :=
    (analyticAt_log (div_pos hQ hQc)).comp_of_eq ha2 rfl
  exact ((analyticAt_const.mul hlog1).add hlog2).neg.div analyticAt_const (by norm_num)

end LeanVerification.SaddleCompletion
