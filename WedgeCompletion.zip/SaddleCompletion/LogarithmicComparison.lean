import LeanVerification.SaddleCompletion.LogarithmicInverse
import LeanVerification.SaddleCompletion.WeightedSchaaf.TwoSided

/-! All Schaaf hypotheses of the constructed logarithmic well, and the
strict comparison of its actual inverse velocities. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion
open RegionalReal.Schaaf
set_option maxHeartbeats 2400000

variable {m b c s : ℝ} (h : LogModel m b c s)
include h

theorem LogModel.second_pos_left {z : ℝ} (hz : z∈Ioc 0 c) : 0<normSecond m b z := by
  have hm : ∀ x∈Icc z c, x∈Ioo 0 s := by
    intro x hx;exact ⟨hz.1.trans_le hx.1,hx.2.trans_lt h.center_lt_saddle⟩
  have hp := WeightedSchaaf.positive_left_of_neg_deriv_at_zeros
    (f := normSecond m b) (a := z) (c := c)
    (fun x hx => (hasDerivAt_normSecond (m := m) (hm x hx).1.ne'
      (h.quad_pos (hm x hx)).ne').differentiableAt)
    (fun x hx he => by
      rw [(hasDerivAt_normSecond (m := m) (hm x hx).1.ne'
        (h.quad_pos (hm x hx)).ne').deriv]
      exact normSecondSlope_neg_at_zero h.exponent_pos h.shape_nonneg h.shape_le_two
        (hm x hx).1 ((hm x hx).2.trans_le h.saddle_le_one) he)
    h.second_center_pos
  exact hp z ⟨le_rfl,hz.2⟩

theorem LogModel.slope_zero_right {z : ℝ} (hz : z∈Ioo 0 s)
    (he : normSecond m b z=0) : c<z := by
  by_contra hn
  exact (h.second_pos_left ⟨hz.1,le_of_not_gt hn⟩).ne' he

theorem LogModel.schaaf_crossing {z : ℝ} (hz : z∈Ioo 0 s)
    (he : normSecond m b z=0) : normFirst m b z*normThird m b z<0 := by
  have hpos := h.first_pos ⟨h.slope_zero_right hz he,hz.2⟩
  have hneg := normSecondSlope_neg_at_zero h.exponent_pos h.shape_nonneg h.shape_le_two
    hz.1 (hz.2.trans_le h.saddle_le_one) he
  exact mul_neg_of_pos_of_neg hpos
    (mul_neg_of_pos_of_neg (normWeight_pos (h.quad_pos hz)) hneg)

theorem LogModel.weightedWell {a d : ℝ} (ha : 0<a) (hac : a<c)
    (hcd : c<d) (hds : d<s) :
    WeightedSchaaf.Well (normWeight b) (normPotential m b c)
      (normFirst m b) (normSecond m b) (normThird m b) (normFourth m b)
      (logProfile m b c s) c a d := by
  have hmem : ∀ z∈Icc a d,z∈Ioo 0 s := by
    intro z hz;exact ⟨ha.trans_le hz.1,hz.2.trans_lt hds⟩
  refine ⟨hac,hcd,?_,?_,?_,?_,?_,h.potential_center,h.first_center,
    h.second_center_pos,?_,?_,?_,?_,?_,?_⟩
  · intro z hz;exact normWeight_pos (h.quad_pos (hmem z hz))
  · intro z hz
    exact hasDerivAt_normPotential (hmem z hz).1.ne' h.center_pos.ne'
      (h.quad_pos (hmem z hz)) (h.quad_pos h.center_mem).ne'
  · intro z hz
    exact hasDerivAt_normFirst (hmem z hz).1.ne' (h.quad_pos (hmem z hz))
  · intro z hz
    have hw := normWeight_pos (h.quad_pos (hmem z hz))
    simpa only [normThird,mul_div_cancel_left₀ _ hw.ne'] using
      hasDerivAt_normSecond (m := m) (hmem z hz).1.ne' (h.quad_pos (hmem z hz)).ne'
  · intro z hz
    exact hasDerivAt_normThird (hmem z hz).1.ne' (h.quad_pos (hmem z hz))
  · intro z hz;exact h.first_pos ⟨hz.1,hz.2.trans_lt hds⟩
  · intro z hz;exact h.first_neg ⟨ha.trans_le hz.1,hz.2⟩
  · intro z hz hR
    change 0<5*(normThird m b z)^2-3*normSecond m b z*normFourth m b z
    rw [← normSchaaf_eq_force_jets (h.quad_pos (hmem z hz)).le]
    exact normSchaaf_pos h.shape_nonneg h.shape_le_two (hmem z hz).1
      ((hmem z hz).2.trans_le h.saddle_le_one) hR
  · intro z hz he;exact h.schaaf_crossing (hmem z hz) he
  · intro z hz;exact (h.analytic_profile (hmem z hz)).continuousAt.continuousWithinAt
  · intro z hz he;exact h.profile_eq (hmem z hz) he

theorem LogModel.velocity_derivative_comparison {u : ℝ} (hu : 0<u)
    (hp : u∈logRange m b c s) (hn : -u∈logRange m b c s) :
    deriv (logVelocity m b c s) (-u)<deriv (logVelocity m b c s) u := by
  have hzp := h.inverse_mem hp
  have hzn := h.inverse_mem hn
  have hp0 := (h.inverse_sign hp).1.mp hu
  have hn0 := (h.inverse_sign hn).2.mp (neg_neg_of_pos hu)
  have hw := h.weightedWell hzn.1 hn0 hp0 hzp.2
  have hc1 := hw.profile_lt_center_of_neg (x := logInverse m b c s (-u)) ⟨le_rfl,hn0⟩
  have hc2 := hw.profile_gt_center_of_pos (x := logInverse m b c s u) ⟨hp0,le_rfl⟩
  have hc := hc1.trans hc2
  simpa only [logProfile,h.morse_inverse hp,h.morse_inverse hn] using hc

end LeanVerification.SaddleCompletion
