import LeanVerification.Loud.RaisedKernel
import LeanVerification.RegionalReal.PhysicalNonstationarity

/-! The actual folded period integral preserves strict width convexity. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.SaddleCompletion
open Loud
set_option maxHeartbeats 1800000

theorem physical_period_deriv_pos_of_width_second (D F h : ℝ)
    (hh : AdmissibleEnergy D F h)
    (hp : ∀ u∈Ioc 0 (Real.sqrt (2*h)),0<physicalWidthJet D F 2 u) :
    0<deriv (periodQuadrature D F) h := by
  let r := Real.sqrt (2*h)
  have hr : 0<r := Real.sqrt_pos.mpr (by linarith [hh.1])
  let K : ℝ → ℝ := fun θ => physicalWidthJet D F 2 (r*Real.sin θ)*Real.sin θ
  have hc : Continuous K :=
    (continuous_physicalWidthJet_angle D F h r hh
      (by rw [abs_of_pos hr]) 2).mul Real.continuous_sin
  have hnonneg : ∀ θ∈Icc 0 (Real.pi/2),0≤K θ := by
    intro θ hθ
    have hs : 0≤Real.sin θ := Real.sin_nonneg_of_nonneg_of_le_pi hθ.1
      (by linarith [hθ.2,Real.pi_pos])
    by_cases hz : Real.sin θ=0
    · simp only [K,hz,mul_zero,le_refl]
    · have hs' : 0<Real.sin θ := lt_of_le_of_ne hs (Ne.symm hz)
      have hu : r*Real.sin θ∈Ioc 0 r :=
        ⟨mul_pos hr hs',mul_le_of_le_one_right hr.le (Real.sin_le_one θ)⟩
      exact (mul_pos (hp _ hu) hs').le
  have hstrict : 0<K (Real.pi/2) := by
    simpa only [K,Real.sin_pi_div_two,mul_one] using hp r ⟨hr,le_rfl⟩
  have hint := intervalIntegral.integral_lt_integral_of_continuousOn_of_le_of_exists_lt
    (show (0:ℝ)<Real.pi/2 by linarith [Real.pi_pos])
    (continuous_const.continuousOn : ContinuousOn (fun _:ℝ => (0:ℝ)) (Icc 0 (Real.pi/2)))
    hc.continuousOn (fun θ hθ => hnonneg θ ⟨hθ.1.le,hθ.2⟩) ⟨Real.pi/2,⟨by linarith [Real.pi_pos],le_rfl⟩,hstrict⟩
  simp only [intervalIntegral.integral_zero] at hint
  rw [(hasDerivAt_periodQuadrature_physicalWidth D F h hh).deriv]
  exact mul_pos (div_pos (by norm_num) hr) hint

theorem criticalPeriodBound_zero_of_width_second (D F : ℝ)
    (hp : ∀ h,AdmissibleEnergy D F h →
      ∀ u∈Ioc 0 (Real.sqrt (2*h)),0<physicalWidthJet D F 2 u) :
    CriticalPeriodBound 0 D F := by
  apply RegionalReal.criticalPeriodBound_zero_of_deriv_ne_zero
  intro h hh
  exact (physical_period_deriv_pos_of_width_second D F h hh (hp h hh)).ne'

end LeanVerification.SaddleCompletion
