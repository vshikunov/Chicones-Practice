import LeanVerification.SaddleCompletion.NormalizedCalculus
import LeanVerification.SaddleCompletion.ParameterGeometry
import LeanVerification.GeneralMechanical.AnalyticWell

/-! The logarithmic potential is an actual analytic mechanical well in its
signed Morse coordinate. The inverse is constructed, not postulated. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion
open GeneralMechanical
set_option maxHeartbeats 2400000

structure LogModel (m b c s : ℝ) : Prop where
  exponent_pos : 0<m
  shape_nonneg : 0≤b
  shape_le_two : b≤2
  center_pos : 0<c
  center_lt_saddle : c<s
  saddle_le_one : s≤1
  roots_sum : (m+2)*(c+s)=(m+1)*b
  roots_product : (m+2)*c*s=m

theorem physical_logModel {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    LogModel (separationExponent F) (separationShape D F)
      (separationScale D F) (separationSaddle D F) := by
  obtain ⟨hc,hcs,hs⟩ := separation_roots_order hF hDF
  exact ⟨by dsimp only [separationExponent];linarith,
    (separationShape_pos hF hDF).le,separationShape_le_two hF hDF,hc,hcs,hs,
    separation_roots_sum hF hDF,separation_roots_product hF hDF⟩

variable {m b c s : ℝ} (h : LogModel m b c s)
include h

theorem LogModel.quad_pos {z : ℝ} (hz : z∈Ioo 0 s) : 0<normQuad b z :=
  normQuad_pos h.shape_le_two hz.1 (hz.2.trans_le h.saddle_le_one)

theorem LogModel.center_mem : c∈Ioo 0 s := ⟨h.center_pos,h.center_lt_saddle⟩

theorem LogModel.first_numerator (z : ℝ) :
    m*normQuad b z+z*(2*z-b)=(m+2)*(z-c)*(z-s) := by
  dsimp only [normQuad]
  linear_combination z*h.roots_sum-h.roots_product

theorem LogModel.first_factorization (z : ℝ) :
    normFirst m b z=-(m+2)*(z-c)*(z-s)/(z*normWeight b z) := by
  rw [normFirst,h.first_numerator]
  ring

theorem LogModel.first_center : normFirst m b c=0 := by
  rw [h.first_factorization]
  simp

theorem LogModel.first_pos {z : ℝ} (hz : z∈Ioo c s) : 0<normFirst m b z := by
  have hz0 : 0<z := h.center_pos.trans hz.1
  rw [h.first_factorization]
  exact div_pos
    (mul_pos_of_neg_of_neg (mul_neg_of_neg_of_pos (by linarith [h.exponent_pos])
      (sub_pos.mpr hz.1)) (sub_neg.mpr hz.2))
    (mul_pos hz0 (normWeight_pos (h.quad_pos ⟨hz0,hz.2⟩)))

theorem LogModel.first_neg {z : ℝ} (hz : z∈Ioo 0 c) : normFirst m b z<0 := by
  have hzs : z<s := hz.2.trans h.center_lt_saddle
  rw [h.first_factorization]
  exact div_neg_of_neg_of_pos
    (mul_neg_of_pos_of_neg (mul_pos_of_neg_of_neg (by linarith [h.exponent_pos])
      (sub_neg.mpr hz.2)) (sub_neg.mpr hzs))
    (mul_pos hz.1 (normWeight_pos (h.quad_pos ⟨hz.1,hzs⟩)))

theorem LogModel.potential_center : normPotential m b c c=0 := by
  simp only [normPotential,div_self h.center_pos.ne',div_self (h.quad_pos h.center_mem).ne',
    Real.log_one,mul_zero,add_zero,neg_zero,zero_div]

omit h in
theorem normSecond_force_identity {m b z : ℝ} (hz : z≠0) (hQ : normQuad b z≠0) :
    normSecond m b z=-(2*(m+2)*z-(m+1)*b)/z+
      (m*normQuad b z+z*(2*z-b))*(2*normQuad b z+z*(2*z-b))/(2*z^2*normQuad b z) := by
  dsimp only [normSecond]
  field_simp [hz,hQ]
  dsimp only [normQuad,normRadius,normDiscriminant]
  ring

theorem LogModel.second_center : normSecond m b c=(m+2)*(s-c)/c := by
  rw [normSecond_force_identity h.center_pos.ne' (h.quad_pos h.center_mem).ne',
    h.first_numerator]
  simp only [sub_self,mul_zero,zero_mul,zero_div,add_zero]
  rw [← h.roots_sum]
  ring

theorem LogModel.second_center_pos : 0<normSecond m b c := by
  rw [h.second_center]
  exact div_pos (mul_pos (by linarith [h.exponent_pos])
    (sub_pos.mpr h.center_lt_saddle)) h.center_pos

def liftedLogPotential (m b c : ℝ) (q : ℝ × ℝ) : ℝ := normPotential m b c (c+q.2)
def liftedLogDomain (c s : ℝ) : Set (ℝ × ℝ) := univ ×ˢ Ioo (-c) (s-c)

theorem LogModel.lifted_mem_iff (q : ℝ × ℝ) :
    q∈liftedLogDomain c s ↔ c+q.2∈Ioo 0 s := by
  simp only [liftedLogDomain,mem_prod,mem_univ,true_and,mem_Ioo]
  constructor <;> rintro ⟨h1,h2⟩ <;> constructor <;> linarith

theorem LogModel.lifted_center_mem (p : ℝ) : (p,0)∈liftedLogDomain c s := by
  rw [h.lifted_mem_iff]
  simpa only [add_zero] using h.center_mem

theorem LogModel.hasDerivAt_lifted (p x : ℝ) (hx : (p,x)∈liftedLogDomain c s) :
    HasDerivAt (fun t => liftedLogPotential m b c (p,t))
      (normFirst m b (c+x)/normWeight b (c+x)) x := by
  have hz := (h.lifted_mem_iff (p,x)).mp hx
  have hd := (hasDerivAt_normPotential (m := m) hz.1.ne' h.center_pos.ne'
    (h.quad_pos hz) (h.quad_pos h.center_mem).ne').comp x ((hasDerivAt_id x).const_add c)
  simpa only [liftedLogPotential,Function.comp_def,id_eq,mul_one] using hd

theorem LogModel.analytic_lifted {q : ℝ × ℝ} (hq : q∈liftedLogDomain c s) :
    AnalyticAt ℝ (liftedLogPotential m b c) q := by
  have hz := (h.lifted_mem_iff q).mp hq
  exact (analyticAt_normPotential (m := m) hz.1 h.center_pos
    (h.quad_pos hz) (h.quad_pos h.center_mem)).comp_of_eq
      (analyticAt_const.add analyticAt_snd) rfl

theorem LogModel.lifted_curvature_pos (p : ℝ) :
    0<deriv (deriv (fun x => liftedLogPotential m b c (p,x))) 0 := by
  have he : deriv (fun x => liftedLogPotential m b c (p,x)) =ᶠ[𝓝 (0:ℝ)]
      (fun x => normFirst m b (c+x)/normWeight b (c+x)) := by
    have hi : (0:ℝ)∈Ioo (-c) (s-c) := by
      constructor <;> linarith [h.center_pos,h.center_lt_saddle]
    filter_upwards [isOpen_Ioo.mem_nhds hi] with x hx
    exact (h.hasDerivAt_lifted p x ⟨mem_univ _,hx⟩).deriv
  rw [he.deriv_eq]
  have hQ := h.quad_pos h.center_mem
  have hw := normWeight_pos hQ
  have hd := ((hasDerivAt_normFirst (m := m) h.center_pos.ne' hQ).div
    (hasDerivAt_normWeight hQ) hw.ne').comp_of_eq (0:ℝ)
      ((hasDerivAt_id 0).const_add c) (by simp)
  dsimp only [Function.comp_def,id_eq,mul_one] at hd
  have hval : deriv (fun x => normFirst m b (c+x)/normWeight b (c+x)) 0=
      normSecond m b c/(normWeight b c)^2 := by
    rw [hd.deriv]
    rw [h.first_center]
    field_simp
  rw [hval]
  exact div_pos h.second_center_pos (sq_pos_of_pos hw)

theorem LogModel.analyticWell :
    AnalyticWell (liftedLogPotential m b c) (liftedLogDomain c s) := by
  refine ⟨isOpen_univ.prod isOpen_Ioo,?_,?_,?_,?_,?_,?_⟩
  · intro p
    have he : fiberDomain (liftedLogDomain c s) p=Ioo (-c) (s-c) := by
      ext x;simp only [fiberDomain,liftedLogDomain,mem_setOf_eq,mem_prod,mem_univ,true_and]
    rw [he];exact convex_Ioo _ _
  · intro q hq;exact h.lifted_center_mem q.1
  · intro q hq;exact h.analytic_lifted hq
  · intro q hq
    rw [(h.hasDerivAt_lifted q.1 0 (h.lifted_center_mem q.1)).deriv]
    simp only [add_zero,h.first_center,zero_div]
  · intro q hq;exact h.lifted_curvature_pos q.1
  · intro q hq hne
    have hz := (h.lifted_mem_iff q).mp hq
    rw [(h.hasDerivAt_lifted q.1 q.2 hq).deriv]
    rw [← mul_div_assoc]
    apply div_pos _ (normWeight_pos (h.quad_pos hz))
    rcases lt_or_gt_of_ne hne with hn|hp
    · exact mul_pos_of_neg_of_neg hn (h.first_neg ⟨hz.1,by linarith⟩)
    · exact mul_pos hp (h.first_pos ⟨by linarith,hz.2⟩)

end LeanVerification.SaddleCompletion
