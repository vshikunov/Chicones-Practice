import LeanVerification.SaddleCompletion.PhysicalSeparation
import LeanVerification.SaddleCompletion.LogarithmicInverse

/-! Identification of the constructed logarithmic inverse at the actual
Loud turning points, followed by an exact original-time velocity identity. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion
open Loud BoundaryAssembly RegionalReal
set_option maxHeartbeats 2800000

def saddleVelocity (D F : ℝ) : ℝ → ℝ :=
  logVelocity (separationExponent F) (separationShape D F)
    (separationScale D F) (separationSaddle D F)
def saddleLogMorse (D F v : ℝ) : ℝ :=
  logMorse (separationExponent F) (separationShape D F) (separationScale D F)
    (separationScale D F*morseInverse D F v)
def saddleVelocityScale (D F : ℝ) : ℝ :=
  (separationScale D F*Real.sqrt (separationC D F))⁻¹

theorem saddleVelocityScale_pos {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    0<saddleVelocityScale D F :=
  inv_pos.mpr (mul_pos (separationScale_pos hF hDF)
    (Real.sqrt_pos.mpr (separation_coefficients_pos hF hDF).2.2))

theorem saddleLogMorse_square {D F v : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hv : v∈morseRange D F) :
    (saddleLogMorse D F v)^2= -Real.log (1-v^2/(2*zeroEndpointHeight D F)) := by
  have hm := physical_logModel hF hDF
  have hw := morseInverse_central D F v hv
  have he := hm.morse_square (physical_normalized_position_mem hF hDF hw)
  rw [physical_logPotential_identity hF hDF hw,potential_morseInverse D F v hv] at he
  change (saddleLogMorse D F v)^2=_ at he
  convert he using 1 <;> congr 2 <;> ring

theorem saddleLogMorse_pos {D F v : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hv : v∈morseRange D F) (hv0 : 0<v) : 0<saddleLogMorse D F v := by
  have hm := physical_logModel hF hDF
  have hw := morseInverse_central D F v hv
  have hx : 1<morseInverse D F v := by
    simpa only [morseInverse_zero] using
      strictMonoOn_morseInverse D F (morseRange_zero D F) hv hv0
  apply (hm.morse_sign (physical_normalized_position_mem hF hDF hw)).1.mpr
  simpa only [mul_one] using mul_lt_mul_of_pos_left hx (separationScale_pos hF hDF)

theorem saddleLogMorse_neg {D F v : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hv : v∈morseRange D F) (hv0 : v<0) : saddleLogMorse D F v<0 := by
  have hm := physical_logModel hF hDF
  have hw := morseInverse_central D F v hv
  have hx : morseInverse D F v<1 := by
    simpa only [morseInverse_zero] using
      strictMonoOn_morseInverse D F hv (morseRange_zero D F) hv0
  apply (hm.morse_sign (physical_normalized_position_mem hF hDF hw)).2.mpr
  simpa only [mul_one] using mul_lt_mul_of_pos_left hx (separationScale_pos hF hDF)

theorem saddleLogMorse_eq_logAmplitude {D F r : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hr : 0<r) (hrH : r^2<2*zeroEndpointHeight D F) (hrange : r∈morseRange D F) :
    saddleLogMorse D F r=logAmplitude (zeroEndpointHeight D F) r := by
  have h1 := saddleLogMorse_square hF hDF hrange
  have h2 := logAmplitude_sq (separation_height_pos hF hDF) hr hrH
  have hp := saddleLogMorse_pos hF hDF hrange hr
  have hp2 := logAmplitude_pos (separation_height_pos hF hDF) hr hrH
  nlinarith

theorem saddleLogMorse_neg_eq_logAmplitude {D F r : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hr : 0<r) (hrH : r^2<2*zeroEndpointHeight D F) (hrange : -r∈morseRange D F) :
    saddleLogMorse D F (-r)= -logAmplitude (zeroEndpointHeight D F) r := by
  have h1 := saddleLogMorse_square hF hDF hrange
  rw [neg_sq] at h1
  have h2 := logAmplitude_sq (separation_height_pos hF hDF) hr hrH
  have hp := saddleLogMorse_neg hF hDF hrange (neg_neg_of_pos hr)
  have hp2 := logAmplitude_pos (separation_height_pos hF hDF) hr hrH
  nlinarith

theorem physical_log_amplitudes_mem {D F r : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hr : 0<r) (hrH : r^2<2*zeroEndpointHeight D F)
    (hp : r∈morseRange D F) (hn : -r∈morseRange D F) :
    logAmplitude (zeroEndpointHeight D F) r∈
        logRange (separationExponent F) (separationShape D F) (separationScale D F) (separationSaddle D F) ∧
      -logAmplitude (zeroEndpointHeight D F) r∈
        logRange (separationExponent F) (separationShape D F) (separationScale D F) (separationSaddle D F) := by
  have hm := physical_logModel hF hDF
  constructor
  · rw [← saddleLogMorse_eq_logAmplitude hF hDF hr hrH hp]
    exact hm.morse_mem (physical_normalized_position_mem hF hDF (morseInverse_central D F r hp))
  · rw [← saddleLogMorse_neg_eq_logAmplitude hF hDF hr hrH hn]
    exact hm.morse_mem (physical_normalized_position_mem hF hDF (morseInverse_central D F (-r) hn))

theorem physical_log_velocity_product {D F v : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hv : v∈morseRange D F) :
    deriv (morsePosition D F) v*(saddleLogMorse D F v*
      separationScale D F*Real.sqrt (separationC D F)*
      Real.sqrt (2*zeroEndpointHeight D F-v^2))=
        v*saddleVelocity D F (saddleLogMorse D F v) := by
  have hm := physical_logModel hF hDF
  have hw := morseInverse_central D F v hv
  have hz := physical_normalized_position_mem hF hDF hw
  have hmz := hm.morse_mem hz
  have hvel := hm.velocity_force hmz
  rw [hm.inverse_morse hz] at hvel
  change saddleVelocity D F (saddleLogMorse D F v)*
    normFirst (separationExponent F) (separationShape D F)
      (separationScale D F*morseInverse D F v)=saddleLogMorse D F v at hvel
  have hf := separation_force_identity hF hDF hw
  rw [potential_morseInverse D F v hv] at hf
  rw [show 2*(zeroEndpointHeight D F-v^2/2)=2*zeroEndpointHeight D F-v^2 by ring] at hf
  have hp : deriv (morsePosition D F) v*force D F (morseInverse D F v)=v := by
    have he := force_morsePosition D F v hv
    dsimp only [forceInPosition,morsePosition] at he
    rw [inverse_position F _ hw.1] at he
    rw [he]
    field_simp [(morsePosition_deriv_pos D F v hv).ne']
  rw [hf] at hp
  calc
    _ = deriv (morsePosition D F) v*(
        (saddleVelocity D F (saddleLogMorse D F v)*
          normFirst (separationExponent F) (separationShape D F)
            (separationScale D F*morseInverse D F v))*
        separationScale D F*Real.sqrt (separationC D F)*
        Real.sqrt (2*zeroEndpointHeight D F-v^2)) := by rw [hvel]
    _ = _ := by linear_combination saddleVelocity D F (saddleLogMorse D F v)*hp

theorem physical_log_velocity_pos_identity {D F r : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hr : 0<r) (hrH : r^2<2*zeroEndpointHeight D F) (hp : r∈morseRange D F) :
    deriv (morsePosition D F) r=saddleVelocityScale D F*logKernel (zeroEndpointHeight D F) r*
      saddleVelocity D F (logAmplitude (zeroEndpointHeight D F) r) := by
  have he := physical_log_velocity_product hF hDF hp
  rw [saddleLogMorse_eq_logAmplitude hF hDF hr hrH hp] at he
  have hu := logAmplitude_pos (separation_height_pos hF hDF) hr hrH
  have hk := separationScale_pos hF hDF
  have hc := Real.sqrt_pos.mpr (separation_coefficients_pos hF hDF).2.2
  have hs := Real.sqrt_pos.mpr (sub_pos.mpr hrH)
  dsimp only [saddleVelocityScale,logKernel]
  field_simp [hu.ne',hk.ne',hc.ne',hs.ne']
  linear_combination he

theorem physical_log_velocity_neg_identity {D F r : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hr : 0<r) (hrH : r^2<2*zeroEndpointHeight D F) (hn : -r∈morseRange D F) :
    deriv (morsePosition D F) (-r)=saddleVelocityScale D F*logKernel (zeroEndpointHeight D F) r*
      saddleVelocity D F (-logAmplitude (zeroEndpointHeight D F) r) := by
  have he := physical_log_velocity_product hF hDF hn
  rw [saddleLogMorse_neg_eq_logAmplitude hF hDF hr hrH hn,neg_sq] at he
  have hu := logAmplitude_pos (separation_height_pos hF hDF) hr hrH
  have hk := separationScale_pos hF hDF
  have hc := Real.sqrt_pos.mpr (separation_coefficients_pos hF hDF).2.2
  have hs := Real.sqrt_pos.mpr (sub_pos.mpr hrH)
  dsimp only [saddleVelocityScale,logKernel]
  field_simp [hu.ne',hk.ne',hc.ne',hs.ne']
  linear_combination -he

end LeanVerification.SaddleCompletion
