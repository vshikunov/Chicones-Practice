import LeanVerification.BoundaryAssembly.ExteriorCutoff
import LeanVerification.RegionalReal.NegativeSaddle
import LeanVerification.SaddleCompletion.NormalizedCertificates

/-! The normalized logarithmic model is constructed from the actual Loud
potential throughout the whole saddle-limited region. -/
noncomputable section
open Set
namespace LeanVerification.SaddleCompletion
open Loud BoundaryAssembly RegionalReal
set_option maxHeartbeats 2200000

def separationA (D F : ℝ) : ℝ := -(D+1)/(2*F)
def separationB (D F : ℝ) : ℝ := -(2*D+1)/(2*F-1)
def separationC (D F : ℝ) : ℝ := -D/(2*(F-1))
def separationScale (D F : ℝ) : ℝ := Real.sqrt (separationA D F/separationC D F)
def separationShape (D F : ℝ) : ℝ :=
  separationB D F/(separationC D F*separationScale D F)
def separationExponent (F : ℝ) : ℝ := 2*F-2
def separationSaddle (D F : ℝ) : ℝ := separationScale D F*(D/(D+1))

theorem separation_coefficients_pos {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    0<separationA D F ∧ 0<separationB D F ∧ 0<separationC D F := by
  dsimp only [separationA,separationB,separationC]
  exact ⟨div_pos (by linarith) (by linarith),
    div_pos (by linarith) (by linarith),div_pos (by linarith) (by linarith)⟩

theorem separationScale_pos {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    0<separationScale D F :=
  Real.sqrt_pos.mpr (div_pos (separation_coefficients_pos hF hDF).1
    (separation_coefficients_pos hF hDF).2.2)

theorem separationScale_sq {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    (separationScale D F)^2=separationA D F/separationC D F := by
  exact Real.sq_sqrt (div_pos (separation_coefficients_pos hF hDF).1
    (separation_coefficients_pos hF hDF).2.2).le

theorem separationShape_pos {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    0<separationShape D F :=
  div_pos (separation_coefficients_pos hF hDF).2.1
    (mul_pos (separation_coefficients_pos hF hDF).2.2 (separationScale_pos hF hDF))

theorem separation_discriminant (D F : ℝ) (hF : 1<F) :
    (separationB D F)^2-4*separationA D F*separationC D F=
      (D+F)*(F-D-1)/(F*(F-1)*(2*F-1)^2) := by
  dsimp only [separationA,separationB,separationC]
  have h0 : F≠0 := by linarith
  have h1 : F-1≠0 := by linarith
  have h2 : 2*F-1≠0 := by linarith
  field_simp [h0,h1,h2]
  ring

theorem separationShape_le_two {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    separationShape D F≤2 := by
  obtain ⟨hA,hB,hC⟩ := separation_coefficients_pos hF hDF
  have hk := separationScale_pos hF hDF
  have hs := separationScale_sq hF hDF
  have hsq : separationC D F*(separationScale D F)^2=separationA D F := by
    rw [hs];field_simp
  have hdisc : (separationB D F)^2-4*separationA D F*separationC D F≤0 := by
    rw [separation_discriminant D F hF]
    exact div_nonpos_of_nonpos_of_nonneg
      (mul_nonpos_of_nonpos_of_nonneg hDF (by linarith))
      (mul_nonneg (mul_nonneg (by linarith) (by linarith)) (sq_nonneg _))
  have hb : separationB D F≤2*(separationC D F*separationScale D F) := by
    nlinarith [sq_nonneg (separationB D F-2*(separationC D F*separationScale D F)),
      mul_nonneg hC.le (show 0≤4*separationA D F-(4*separationC D F)*(separationScale D F)^2 by nlinarith)]
  exact (div_le_iff₀ (mul_pos hC hk)).mpr hb

theorem separation_roots_product {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    (separationExponent F+2)*separationScale D F*separationSaddle D F=
      separationExponent F := by
  have hD : D≠0 := by linarith
  have hD1 : D+1≠0 := by linarith
  have hF0 : F≠0 := by linarith
  have hF1 : F-1≠0 := by linarith
  have he : (separationExponent F+2)*separationScale D F*separationSaddle D F=
      (separationExponent F+2)*(separationScale D F)^2*(D/(D+1)) := by
    dsimp only [separationSaddle];ring
  rw [he,separationScale_sq hF hDF]
  dsimp only [separationExponent,separationA,separationC]
  field_simp [hD,hD1,hF0,hF1]
  ring

theorem separation_roots_sum {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    (separationExponent F+2)*(separationScale D F+separationSaddle D F)=
      (separationExponent F+1)*separationShape D F := by
  have hD : D≠0 := by linarith
  have hD1 : D+1≠0 := by linarith
  have hF0 : F≠0 := by linarith
  have hF1 : F-1≠0 := by linarith
  have hF2 : 2*F-1≠0 := by linarith
  have hk := separationScale_pos hF hDF
  have hC := (separation_coefficients_pos hF hDF).2.2
  dsimp only [separationShape]
  rw [← mul_div_assoc]
  apply (eq_div_iff (mul_ne_zero hC.ne' hk.ne')).mpr
  change (separationExponent F+2)*(separationScale D F+separationSaddle D F)*
      (separationC D F*separationScale D F)=
    (separationExponent F+1)*separationB D F
  have he : (separationExponent F+2)*(separationScale D F+separationSaddle D F)*
      (separationC D F*separationScale D F)=
    (separationExponent F+2)*(1+D/(D+1))*separationC D F*(separationScale D F)^2 := by
    dsimp only [separationSaddle];ring
  rw [he,separationScale_sq hF hDF]
  dsimp only [separationExponent,separationA,separationB,separationC]
  field_simp [hD,hD1,hF0,hF1,hF2]
  ring

theorem separation_roots_order {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    0<separationScale D F ∧ separationScale D F<separationSaddle D F ∧
      separationSaddle D F≤1 := by
  have hk := separationScale_pos hF hDF
  have hD : D< -1 := by linarith
  have hs := extra_root_gt_one_of_lt_neg_one D hD
  have hcs : separationScale D F<separationSaddle D F := by
    simpa only [mul_one,separationSaddle] using mul_lt_mul_of_pos_left hs hk
  have hsp : 0<separationSaddle D F := lt_trans hk hcs
  have hd0 : D≠0 := by linarith
  have hd1 : D+1≠0 := by linarith
  have hf0 : F≠0 := by linarith
  have hf1 : F-1≠0 := by linarith
  have he : (separationSaddle D F)^2-1=(-D-F)/(F*(D+1)) := by
    dsimp only [separationSaddle]
    rw [mul_pow,separationScale_sq hF hDF]
    dsimp only [separationA,separationC]
    field_simp [hd0,hd1,hf0,hf1]
    ring
  have hn : (separationSaddle D F)^2-1≤0 := by
    rw [he]
    exact div_nonpos_of_nonneg_of_nonpos (by linarith)
      (mul_nonpos_of_nonneg_of_nonpos (by linarith) (by linarith))
  exact ⟨hk,hcs,by nlinarith⟩

theorem physical_normalized_position_mem {D F w : ℝ}
    (hF : 1<F) (hDF : D+F≤0) (hw : inCentralInterval D w) :
    separationScale D F*w ∈ Ioo 0 (separationSaddle D F) := by
  have hb := (inCentralInterval_iff_of_lt_neg_one D w (by linarith)).mp hw
  exact ⟨mul_pos (separationScale_pos hF hDF) hw.1,
    mul_lt_mul_of_pos_left hb.2 (separationScale_pos hF hDF)⟩

theorem normalized_quadratic_identity {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) (w : ℝ) :
    separationC D F*normQuad (separationShape D F) (separationScale D F*w)=
      separationA D F*w^2-separationB D F*w+separationC D F := by
  have hC := (separation_coefficients_pos hF hDF).2.2
  have hk := separationScale_pos hF hDF
  dsimp only [normQuad,separationShape]
  field_simp [hC.ne',hk.ne']
  have hs := separationScale_sq hF hDF
  have hsq : separationC D F*(separationScale D F)^2=separationA D F := by
    rw [hs];field_simp
  linear_combination separationC D F*separationScale D F*w^2*hsq

theorem separation_height (D F : ℝ) :
    zeroEndpointHeight D F=separationA D F-separationB D F+separationC D F := by
  dsimp only [zeroEndpointHeight,separationA,separationB,separationC]
  congr 1 <;> ring

theorem physical_separation_identity {D F : ℝ} (hF : 1<F) (hDF : D+F≤0)
    {w : ℝ} (hw : 0<w) :
    zeroEndpointHeight D F-potential D F w=
      w^(separationExponent F)*separationC D F*
        normQuad (separationShape D F) (separationScale D F*w) := by
  rw [mul_assoc,normalized_quadratic_identity hF hDF w]
  have he := potential_minus_endpoint_factorization D F w hw
    (by linarith) (by linarith) (by linarith)
  dsimp only [separationExponent,separationA,separationB,separationC,exteriorQuadratic] at *
  rw [show 2*(F-1)=2*F-2 by ring]
  linear_combination -he

end LeanVerification.SaddleCompletion
