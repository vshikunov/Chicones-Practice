import LeanVerification.SaddleCompletion.LogarithmicWell
import LeanVerification.SaddleCompletion.LogWidthBridge

/-! Exact potential, force, and spatial-metric identities connecting the
normalized logarithmic well to the original Loud mechanical system. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion
open Loud BoundaryAssembly RegionalReal
set_option maxHeartbeats 2600000

theorem separation_height_quad {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    zeroEndpointHeight D F=separationC D F*
      normQuad (separationShape D F) (separationScale D F) := by
  simpa only [potential_one,sub_zero,Real.one_rpow,one_mul,mul_one] using
    physical_separation_identity hF hDF (show (0:ℝ)<1 by norm_num)

theorem separation_height_pos {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) :
    0<zeroEndpointHeight D F := by
  rw [separation_height_quad hF hDF]
  exact mul_pos (separation_coefficients_pos hF hDF).2.2
    ((physical_logModel hF hDF).quad_pos (physical_logModel hF hDF).center_mem)

theorem separation_gap_pos {D F w : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hw : inCentralInterval D w) : 0<zeroEndpointHeight D F-potential D F w := by
  rw [physical_separation_identity hF hDF hw.1]
  exact mul_pos (mul_pos (Real.rpow_pos_of_pos hw.1 _)
    (separation_coefficients_pos hF hDF).2.2)
    ((physical_logModel hF hDF).quad_pos (physical_normalized_position_mem hF hDF hw))

theorem physical_logPotential_identity {D F w : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hw : inCentralInterval D w) :
    normPotential (separationExponent F) (separationShape D F) (separationScale D F)
      (separationScale D F*w)= -Real.log (1-potential D F w/zeroEndpointHeight D F)/2 := by
  have hm := physical_logModel hF hDF
  have hQ := hm.quad_pos (physical_normalized_position_mem hF hDF hw)
  have hQc := hm.quad_pos hm.center_mem
  have hC := (separation_coefficients_pos hF hDF).2.2
  have hk := separationScale_pos hF hDF
  have hH := separation_height_pos hF hDF
  have hratio : 1-potential D F w/zeroEndpointHeight D F=
      w^(separationExponent F)*(normQuad (separationShape D F) (separationScale D F*w)/
        normQuad (separationShape D F) (separationScale D F)) := by
    calc
      _ = (zeroEndpointHeight D F-potential D F w)/zeroEndpointHeight D F := by field_simp
      _ = (w^(separationExponent F)*separationC D F*
          normQuad (separationShape D F) (separationScale D F*w))/
          (separationC D F*normQuad (separationShape D F) (separationScale D F)) := by
        rw [physical_separation_identity hF hDF hw.1,separation_height_quad hF hDF]
      _ = _ := by field_simp;ring
  have harg : separationScale D F*w/separationScale D F=w := by field_simp
  rw [normPotential,harg,hratio,
    Real.log_mul (Real.rpow_pos_of_pos hw.1 _).ne' (div_pos hQ hQc).ne',
    Real.log_rpow hw.1]

theorem separation_force_numerator {D F : ℝ} (hF : 1<F) (hDF : D+F≤0) (w : ℝ) :
    separationC D F*(separationExponent F*normQuad (separationShape D F)
      (separationScale D F*w)+(separationScale D F*w)*(2*(separationScale D F*w)-
        separationShape D F))=-(w-1)*((D+1)*w-D) := by
  have hC := (separation_coefficients_pos hF hDF).2.2
  have hk := separationScale_pos hF hDF
  have hs : separationC D F*(separationScale D F)^2=separationA D F := by
    rw [separationScale_sq hF hDF];field_simp
  have hb : separationC D F*separationShape D F*separationScale D F=separationB D F := by
    dsimp only [separationShape];field_simp;ring
  have hlin : (separationExponent F+2)*separationA D F*w^2-
      (separationExponent F+1)*separationB D F*w+
      separationExponent F*separationC D F=-(w-1)*((D+1)*w-D) := by
    dsimp only [separationExponent,separationA,separationB,separationC]
    have hf0 : F≠0 := by linarith
    have hf1 : F-1≠0 := by linarith
    have hf2 : 2*F-1≠0 := by linarith
    field_simp [hf0,hf1,hf2]
    ring
  dsimp only [normQuad]
  linear_combination (separationExponent F+2)*w^2*hs-
    (separationExponent F+1)*w*hb+hlin

theorem separation_force_algebra {D F w : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hw : inCentralInterval D w) :
    normFirst (separationExponent F) (separationShape D F) (separationScale D F*w)*
      (separationC D F*separationScale D F*w*
        normWeight (separationShape D F) (separationScale D F*w))=(w-1)*((D+1)*w-D) := by
  have hm := physical_logModel hF hDF
  have hQ := hm.quad_pos (physical_normalized_position_mem hF hDF hw)
  have hweight := normWeight_pos hQ
  have hk := separationScale_pos hF hDF
  have he := separation_force_numerator hF hDF w
  have hc : normFirst (separationExponent F) (separationShape D F) (separationScale D F*w)*
      (separationC D F*separationScale D F*w*
        normWeight (separationShape D F) (separationScale D F*w))=
      -separationC D F*(separationExponent F*normQuad (separationShape D F)
        (separationScale D F*w)+(separationScale D F*w)*(2*(separationScale D F*w)-
          separationShape D F)) := by
    dsimp only [normFirst]
    field_simp [hw.1.ne',hk.ne',hweight.ne']
    ring
  rw [hc]
  linear_combination -he

theorem separation_metric_identity {D F w : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hw : inCentralInterval D w) :
    Real.sqrt (2*(zeroEndpointHeight D F-potential D F w))=
      w^(F-1)*Real.sqrt (separationC D F)*
        normWeight (separationShape D F) (separationScale D F*w) := by
  have hm := physical_logModel hF hDF
  have hQ := hm.quad_pos (physical_normalized_position_mem hF hDF hw)
  have hC := (separation_coefficients_pos hF hDF).2.2
  have hgap := separation_gap_pos hF hDF hw
  have hleft := Real.sqrt_pos.mpr (mul_pos (by norm_num : (0:ℝ)<2) hgap)
  have hright : 0<w^(F-1)*Real.sqrt (separationC D F)*
      normWeight (separationShape D F) (separationScale D F*w) := by
    exact mul_pos (mul_pos (Real.rpow_pos_of_pos hw.1 _) (Real.sqrt_pos.mpr hC))
      (normWeight_pos hQ)
  have hp : (w^(F-1))^2=w^(separationExponent F) := by
    rw [← Real.rpow_two,← Real.rpow_mul hw.1.le]
    congr 1
    dsimp only [separationExponent];ring
  have hs : (w^(F-1)*Real.sqrt (separationC D F)*
      normWeight (separationShape D F) (separationScale D F*w))^2=
      2*(zeroEndpointHeight D F-potential D F w) := by
    rw [mul_pow,mul_pow,hp,Real.sq_sqrt hC.le,normWeight_sq hQ.le,
      physical_separation_identity hF hDF hw.1]
    ring
  nlinarith [Real.sq_sqrt (mul_pos (by norm_num : (0:ℝ)<2) hgap).le]

theorem separation_force_identity {D F w : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hw : inCentralInterval D w) :
    force D F w=separationScale D F*Real.sqrt (separationC D F)*
      Real.sqrt (2*(zeroEndpointHeight D F-potential D F w))*
      normFirst (separationExponent F) (separationShape D F) (separationScale D F*w) := by
  rw [separation_metric_identity hF hDF hw]
  have hC := (separation_coefficients_pos hF hDF).2.2
  have hs := Real.sq_sqrt hC.le
  have he := separation_force_algebra hF hDF hw
  have hp : w^(F-1)=w^(F-2)*w := by
    rw [show F-1=(F-2)+1 by ring,Real.rpow_add hw.1,Real.rpow_one]
  dsimp only [force]
  rw [hp]
  linear_combination -w^(F-2)*he-
    (separationScale D F*w^(F-2)*w*
      normWeight (separationShape D F) (separationScale D F*w)*
      normFirst (separationExponent F) (separationShape D F) (separationScale D F*w))*hs

end LeanVerification.SaddleCompletion
