import LeanVerification.SaddleCompletion.PhysicalInverse
import LeanVerification.SaddleCompletion.LogarithmicComparison

/-! Unconditional original-time period increase on the entire Loud saddle
region F>1, D≤-F. The proof includes the full maximal annulus and D=-F. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.SaddleCompletion
open Loud RegionalReal
set_option maxHeartbeats 2400000

theorem physical_width_one_log_identity {D F r : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hr : 0<r) (hrH : r^2<2*zeroEndpointHeight D F)
    (hp : r∈morseRange D F) (hn : -r∈morseRange D F) :
    physicalWidthJet D F 1 r=saddleVelocityScale D F*logKernel (zeroEndpointHeight D F) r*
      (saddleVelocity D F (logAmplitude (zeroEndpointHeight D F) r)+
        saddleVelocity D F (-logAmplitude (zeroEndpointHeight D F) r)) := by
  simp only [physicalWidthJet,iteratedDeriv_one,pow_one,neg_one_mul,sub_neg_eq_add]
  rw [physical_log_velocity_pos_identity hF hDF hr hrH hp,
    physical_log_velocity_neg_identity hF hDF hr hrH hn]
  ring

theorem physical_width_one_log_eventually {D F r : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hr : 0<r) (hrH : r^2<2*zeroEndpointHeight D F)
    (hp : r∈morseRange D F) (hn : -r∈morseRange D F) :
    physicalWidthJet D F 1 =ᶠ[𝓝 r] fun t =>
      saddleVelocityScale D F*logKernel (zeroEndpointHeight D F) t*
        (saddleVelocity D F (logAmplitude (zeroEndpointHeight D F) t)+
          saddleVelocity D F (-logAmplitude (zeroEndpointHeight D F) t)) := by
  have hpos : ∀ᶠ t in 𝓝 r,0<t := Ioi_mem_nhds hr
  have hs : ∀ᶠ t in 𝓝 r,t^2<2*zeroEndpointHeight D F :=
    (continuousAt_id.pow 2).eventually (Iio_mem_nhds hrH)
  have hnp : ∀ᶠ t in 𝓝 r,-t∈morseRange D F :=
    continuousAt_neg.eventually ((isOpen_morseRange D F).mem_nhds hn)
  filter_upwards [hpos,hs,(isOpen_morseRange D F).mem_nhds hp,hnp] with t ht htH htp htn
  exact physical_width_one_log_identity hF hDF ht htH htp htn

theorem physical_width_second_pos_saddle {D F r : ℝ} (hF : 1<F) (hDF : D+F≤0)
    (hr : 0<r) (hrH : r^2<2*zeroEndpointHeight D F)
    (hp : r∈morseRange D F) (hn : -r∈morseRange D F) : 0<physicalWidthJet D F 2 r := by
  have hm := physical_logModel hF hDF
  have hH := separation_height_pos hF hDF
  have hu := logAmplitude_pos hH hr hrH
  obtain ⟨hup,hun⟩ := physical_log_amplitudes_mem hF hDF hr hrH hp hn
  apply physical_width_second_pos_of_log_bridge D F (zeroEndpointHeight D F)
    (saddleVelocityScale D F) r (saddleVelocity D F) hH hr hrH
    (saddleVelocityScale_pos hF hDF) hp hn
  · exact (hm.analytic_velocity hup).differentiableAt
  · exact (hm.analytic_velocity hun).differentiableAt
  · exact add_pos (hm.velocity_pos hup) (hm.velocity_pos hun)
  · exact hm.velocity_derivative_comparison hu hup hun
  · exact physical_width_one_log_eventually hF hDF hr hrH hp hn

theorem physical_saddle_width_positive (D F h : ℝ) (hF : 1<F) (hDF : D+F≤0)
    (hh : AdmissibleEnergy D F h) :
    ∀ r∈Ioc 0 (Real.sqrt (2*h)),0<physicalWidthJet D F 2 r := by
  intro r hr
  have hs : 0<Real.sqrt (2*h) := Real.sqrt_pos.mpr (by linarith [hh.1])
  have hH := admissibleEnergy_lt_zeroEndpointHeight D F h (by linarith) hF hh
  have hr2 : r^2≤2*h := by
    nlinarith [hr.1,hr.2,Real.sq_sqrt (by linarith [hh.1] : 0≤2*h)]
  have hp : r∈morseRange D F :=
    morse_amplitude_in_range D F h hh ⟨by linarith [hr.1],hr.2⟩
  have hn : -r∈morseRange D F :=
    morse_amplitude_in_range D F h hh ⟨by linarith [hr.2],by linarith [hr.1]⟩
  exact physical_width_second_pos_saddle hF hDF hr.1 (by linarith) hp hn

theorem physical_period_deriv_pos_saddle (D F h : ℝ) (hF : 1<F) (hDF : D+F≤0)
    (hh : AdmissibleEnergy D F h) : 0<deriv (periodQuadrature D F) h :=
  physical_period_deriv_pos_of_width_second D F h hh (physical_saddle_width_positive D F h hF hDF hh)

theorem criticalPeriodBound_zero_saddle (D F : ℝ) (hF : 1<F) (hDF : D+F≤0) :
    CriticalPeriodBound 0 D F :=
  criticalPeriodBound_zero_of_width_second D F (fun h hh => physical_saddle_width_positive D F h hF hDF hh)

theorem parameter_region_eleven_bound (D F : ℝ) (hp : parameterRegion 11 D F) :
    CriticalPeriodBound (parameterRegionBound 11) D F := by
  change 1<F ∧ D≤-F at hp
  change CriticalPeriodBound 0 D F
  exact criticalPeriodBound_zero_saddle D F hp.1 (by linarith [hp.2])

end LeanVerification.SaddleCompletion
