import LeanVerification.RegionalComplex.RayAngles
import Mathlib.Analysis.SpecialFunctions.Trigonometric.ArctanDeriv
import Mathlib.Data.Real.Pi.Bounds

/-! Exact analytic and rational bounds for the two actual ray barriers. -/

noncomputable section
namespace LeanVerification.RegionalComplex

theorem arctan_le_self_nonneg {x : ℝ} (hx : 0 ≤ x) : Real.arctan x ≤ x := by
  have hd (t : ℝ) : HasDerivAt (fun y : ℝ => y-Real.arctan y) (t^2/(1+t^2)) t := by
    convert (hasDerivAt_id t).sub (Real.hasDerivAt_arctan t) using 1
    have ht : 1+t^2 ≠ 0 := ne_of_gt (by positivity)
    field_simp
  have hm := monotone_of_hasDerivAt_nonneg hd (fun t => by positivity)
  have hh := hm hx
  simpa only [Real.arctan_zero,sub_self,sub_nonneg] using hh

theorem arctan_cubic_lower {x : ℝ} (hx : 0 ≤ x) :
    x-x^3/3 ≤ Real.arctan x := by
  have hd (t : ℝ) : HasDerivAt (fun y : ℝ => Real.arctan y-(y-y^3/3)) (t^4/(1+t^2)) t := by
    convert (Real.hasDerivAt_arctan t).sub
      ((hasDerivAt_id t).sub (((hasDerivAt_id t).pow 3).div_const 3)) using 1
    have ht : 1+t^2 ≠ 0 := ne_of_gt (by positivity)
    field_simp
    ring
  have hm := monotone_of_hasDerivAt_nonneg hd (fun t => by positivity)
  have hh := hm hx
  simp only [Real.arctan_zero,zero_pow (by norm_num : (3 : ℕ) ≠ 0),zero_div,sub_zero,zero_sub] at hh
  linarith

theorem arctan_seventh_lower {x : ℝ} (hx : 0 ≤ x) :
    x-x^3/3+x^5/5-x^7/7 ≤ Real.arctan x := by
  have hd (t : ℝ) : HasDerivAt
      (fun y : ℝ => Real.arctan y-(y-y^3/3+y^5/5-y^7/7)) (t^8/(1+t^2)) t := by
    convert (Real.hasDerivAt_arctan t).sub
      ((((hasDerivAt_id t).sub (((hasDerivAt_id t).pow 3).div_const 3)).add
        (((hasDerivAt_id t).pow 5).div_const 5)).sub
          (((hasDerivAt_id t).pow 7).div_const 7)) using 1
    have ht : 1+t^2 ≠ 0 := ne_of_gt (by positivity)
    field_simp
    ring
  have hm := monotone_of_hasDerivAt_nonneg hd (fun t => by positivity)
  have hh := hm hx
  norm_num only [Real.arctan_zero,zero_pow,zero_div,sub_zero,zero_sub,add_zero] at hh
  linarith

theorem large_cone_arctan_margin :
    0 < Real.arctan (5/8 : ℝ)-(14/25)*Real.arctan (3/44 : ℝ)-(4/25)*Real.pi := by
  have h₁ := arctan_cubic_lower (show (0 : ℝ) ≤ 5/8 by norm_num)
  have h₂ := arctan_le_self_nonneg (show (0 : ℝ) ≤ 3/44 by norm_num)
  have hp : Real.pi < 22/7 := by linarith [Real.pi_lt_d4]
  norm_num at h₁
  linarith

theorem universal_cone_arctan_margin :
    0 < Real.arctan (4*Real.sqrt 10/19)-(14/25)*
      Real.arctan (23/(50*Real.sqrt 10))-(4/25)*Real.pi := by
  have hs := Real.sq_sqrt (show (0 : ℝ) ≤ 10 by norm_num)
  have hsn := Real.sqrt_nonneg 10
  have hslo : (79/25 : ℝ) < Real.sqrt 10 := by nlinarith
  have hspos : 0 < Real.sqrt 10 := by positivity
  have harg : (316/475 : ℝ) ≤ 4*Real.sqrt 10/19 := by linarith
  have h₁ := (arctan_seventh_lower (show (0 : ℝ) ≤ 316/475 by norm_num)).trans
    (Real.arctan_le_arctan harg)
  have h₂ := arctan_le_self_nonneg (show 0 ≤ 23/(50*Real.sqrt 10) by positivity)
  have hratio : 23/(50*Real.sqrt 10) < (23/158 : ℝ) := by
    apply (div_lt_iff₀ (show 0 < 50*Real.sqrt 10 by positivity)).2
    nlinarith
  have hp : Real.pi < 22/7 := by linarith [Real.pi_lt_d4]
  norm_num at h₁
  linarith

end LeanVerification.RegionalComplex
