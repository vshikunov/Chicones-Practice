import LeanVerification.RegionalComplex.RayInverse

/-! Reflection and continuation through the positive real inverse.
The enlarged logarithmic strip contains the real axis, so its inverse
is an actual analytic extension of the constructed upper branch. -/

noncomputable section
open Set Filter
open scoped Topology ComplexConjugate
namespace LeanVerification.RegionalComplex

def fullLogRayStrip : Set ℂ := {z | -Real.pi < z.im ∧ z.im < Real.pi}

theorem fullLogRayStrip_open : IsOpen fullLogRayStrip :=
  isOpen_Ioo.preimage Complex.continuous_im

theorem shifted_exp_slitPlane_full {s : ℝ} (hs : 0 < s) {z : ℂ}
    (hz : z ∈ fullLogRayStrip) : Complex.exp z+(s : ℂ) ∈ Complex.slitPlane := by
  by_cases hzero : z.im=0
  · exact shifted_exp_slitPlane_closed hs (by linarith) hz.2
  apply Complex.mem_slitPlane_iff.mpr
  right
  simp only [Complex.add_im,Complex.ofReal_im,add_zero,Complex.exp_im]
  apply mul_ne_zero (Real.exp_ne_zero _)
  rcases lt_or_gt_of_ne hzero with hneg | hpos
  · have hh := Real.sin_pos_of_pos_of_lt_pi (neg_pos.mpr hneg) (by linarith [hz.1] : -z.im < Real.pi)
    rw [Real.sin_neg] at hh
    linarith
  · exact ne_of_gt (Real.sin_pos_of_pos_of_lt_pi hpos hz.2)

theorem logRayMap_conj (p : ℝ) {s₁ s₂ : ℝ} (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {z : ℂ} (hz : z ∈ fullLogRayStrip) :
    logRayMap p s₁ s₂ (conj z)=conj (logRayMap p s₁ s₂ z) := by
  have hc (s : ℝ) (hs : 0 < s) :
      Complex.log (Complex.exp (conj z)+(s : ℂ))=
        conj (Complex.log (Complex.exp z+(s : ℂ))) := by
    have ha := (Complex.mem_slitPlane_iff_arg.mp (shifted_exp_slitPlane_full hs hz)).1
    simpa only [Complex.exp_conj,map_add,Complex.conj_ofReal] using
      Complex.log_conj (Complex.exp z+(s : ℂ)) ha
  simp only [logRayMap,hc s₁ hs₁,hc s₂ hs₂,map_add,map_mul,Complex.conj_ofReal]

theorem logRayDeriv_conj (p s₁ s₂ : ℝ) (z : ℂ) :
    logRayDeriv p s₁ s₂ (conj z)=conj (logRayDeriv p s₁ s₂ z) := by
  simp only [logRayDeriv,Complex.exp_conj,map_add,map_div₀,Complex.conj_ofReal]

theorem logRayMap_im_neg {p s₁ s₂ : ℝ} (hp : 0 < p)
    (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {z : ℂ}
    (hz : z ∈ fullLogRayStrip) (hneg : z.im < 0) :
    (logRayMap p s₁ s₂ z).im < 0 := by
  have hh := logRayMap_im_pos s₁ s₂ hp
    (show conj z ∈ logRayStrip by simp only [logRayStrip,mem_setOf_eq,Complex.conj_im]; constructor <;> linarith [hz.1])
  rw [logRayMap_conj p hs₁ hs₂ hz,Complex.conj_im] at hh
  linarith

theorem hasDerivAt_logRayMap_full (p : ℝ) {s₁ s₂ : ℝ}
    (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {z : ℂ} (hz : z ∈ fullLogRayStrip) :
    HasDerivAt (logRayMap p s₁ s₂) (logRayDeriv p s₁ s₂ z) z := by
  simpa only [logRayMap,logRayDeriv,mul_one] using
    (((hasDerivAt_id z).const_mul (p : ℂ)).add
      (((Complex.hasDerivAt_exp z).add_const (s₁ : ℂ)).clog
        (shifted_exp_slitPlane_full hs₁ hz))).add
      (((Complex.hasDerivAt_exp z).add_const (s₂ : ℂ)).clog
        (shifted_exp_slitPlane_full hs₂ hz))

theorem logRayDeriv_real (p s₁ s₂ x : ℝ) :
    logRayDeriv p s₁ s₂ (x : ℂ)=
      ((p+Real.exp x/(Real.exp x+s₁)+Real.exp x/(Real.exp x+s₂) : ℝ) : ℂ) := by
  simp only [logRayDeriv,Complex.ofReal_exp,Complex.ofReal_add,Complex.ofReal_div]

theorem logRayMap_real_strictMono {p s₁ s₂ : ℝ} (hp : 0 < p)
    (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) :
    StrictMono (fun x : ℝ => (logRayMap p s₁ s₂ (x : ℂ)).re) := by
  apply strictMono_of_deriv_pos
  intro x
  have hd := (hasDerivAt_logRayMap_full p hs₁ hs₂
    (show (x : ℂ) ∈ fullLogRayStrip by simpa [fullLogRayStrip] using Real.pi_pos)).comp_ofReal
  have hre := Complex.reCLM.hasFDerivAt.comp_hasDerivAt x hd
  have hre' : HasDerivAt (fun x : ℝ => (logRayMap p s₁ s₂ (x : ℂ)).re)
      (logRayDeriv p s₁ s₂ (x : ℂ)).re x := by simpa using hre
  rw [hre'.deriv,logRayDeriv_real]
  change 0 < p+Real.exp x/(Real.exp x+s₁)+Real.exp x/(Real.exp x+s₂)
  positivity

theorem logRayMap_full_injective {p s₁ s₂ : ℝ} (hp : 0 < p)
    (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) :
    Set.InjOn (logRayMap p s₁ s₂) fullLogRayStrip := by
  classical
  intro x hx y hy hxy
  have he := congrArg Complex.im hxy
  rcases lt_trichotomy x.im 0 with hxneg | hxzero | hxpos
  · have hyneg : y.im < 0 := by
      by_contra hh
      rcases lt_or_eq_of_le (le_of_not_gt hh) with hypos | hyzero
      · have hi := logRayMap_im_pos s₁ s₂ hp (show y ∈ logRayStrip from ⟨hypos,hy.2⟩)
        have hj := logRayMap_im_neg hp hs₁ hs₂ hx hxneg
        linarith
      · rw [logRayMap_im_of_im_zero p hs₁ hs₂ hyzero.symm] at he
        have hj := logRayMap_im_neg hp hs₁ hs₂ hx hxneg
        linarith
    have hcx : conj x ∈ logRayStrip := by simp only [logRayStrip,mem_setOf_eq,Complex.conj_im]; constructor <;> linarith [hx.1]
    have hcy : conj y ∈ logRayStrip := by simp only [logRayStrip,mem_setOf_eq,Complex.conj_im]; constructor <;> linarith [hy.1]
    have hc : logRayMap p s₁ s₂ (conj x)=logRayMap p s₁ s₂ (conj y) := by
      rw [logRayMap_conj p hs₁ hs₂ hx,logRayMap_conj p hs₁ hs₂ hy,hxy]
    simpa only [Complex.conj_conj] using congrArg conj
      (logRayMap_injective p hs₁ hs₂ hcx hcy hc)
  · have hyzero : y.im=0 := by
      rw [logRayMap_im_of_im_zero p hs₁ hs₂ hxzero] at he
      rcases lt_trichotomy y.im 0 with hneg | heq | hpos
      · have hh := logRayMap_im_neg hp hs₁ hs₂ hy hneg
        linarith
      · exact heq
      · have hh := logRayMap_im_pos s₁ s₂ hp (show y ∈ logRayStrip from ⟨hpos,hy.2⟩)
        linarith
    have hxx : (x.re : ℂ)=x := by apply Complex.ext <;> simp [hxzero]
    have hyy : (y.re : ℂ)=y := by apply Complex.ext <;> simp [hyzero]
    have hr := (logRayMap_real_strictMono hp hs₁ hs₂).injective
      (show (logRayMap p s₁ s₂ (x.re : ℂ)).re=(logRayMap p s₁ s₂ (y.re : ℂ)).re by rw [hxx,hyy,hxy])
    apply Complex.ext
    · exact hr
    · rw [hxzero,hyzero]
  · have hypos : 0 < y.im := by
      apply lt_of_not_ge
      intro hh
      rcases lt_or_eq_of_le hh with hyneg | hyzero
      · have hi := logRayMap_im_neg hp hs₁ hs₂ hy hyneg
        have hj := logRayMap_im_pos s₁ s₂ hp (show x ∈ logRayStrip from ⟨hxpos,hx.2⟩)
        linarith
      · rw [logRayMap_im_of_im_zero p hs₁ hs₂ hyzero] at he
        have hj := logRayMap_im_pos s₁ s₂ hp (show x ∈ logRayStrip from ⟨hxpos,hx.2⟩)
        linarith
    exact logRayMap_injective p hs₁ hs₂ ⟨hxpos,hx.2⟩ ⟨hypos,hy.2⟩ hxy

end LeanVerification.RegionalComplex
