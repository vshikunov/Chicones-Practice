import LeanVerification.RegionalComplex.LogRayClosure
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.Deriv
import Mathlib.Analysis.Calculus.FDeriv.Analytic
import Mathlib.Analysis.Convex.Topology

/-! Actual coverage of the complete logarithmic target strip.  The image is
open by the inverse theorem and closed relative to the target by the proved
compactness bounds.  No global inverse or sector-surjectivity premise occurs. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalComplex

theorem logRayMap_strictDeriv (p s₁ s₂ : ℝ) {z : ℂ} (hz : z ∈ logRayStrip) :
    HasStrictDerivAt (logRayMap p s₁ s₂) (logRayDeriv p s₁ s₂ z) z := by
  have hh := (logRayMap_analytic p s₁ s₂ z hz).hasStrictFDerivAt.hasStrictDerivAt
  have he := hh.hasDerivAt.unique (hasDerivAt_logRayMap p s₁ s₂ hz)
  rw [he] at hh
  exact hh

theorem logRayMap_image_open (p : ℝ) {s₁ s₂ : ℝ} (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) :
    IsOpen (logRayMap p s₁ s₂ '' logRayStrip) := by
  rw [isOpen_iff_mem_nhds]
  rintro w ⟨z,hz,rfl⟩
  rw [← (logRayMap_strictDeriv p s₁ s₂ hz).map_nhds_eq
    (logRayMap_deriv_ne_zero p hs₁ hs₂ hz)]
  exact Filter.image_mem_map (logRayStrip_open.mem_nhds hz)

theorem logRayMap_image_inter_target_nonempty {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) :
    (logRayTarget p ∩ (logRayMap p s₁ s₂ '' logRayStrip)).Nonempty := by
  have hF := (hasDerivAt_logRayMap_closed p hs₁ hs₂
    (show (0 : ℝ) ≤ (0 : ℂ).im by norm_num)
    (show (0 : ℂ).im < Real.pi by simpa using Real.pi_pos)).continuousAt
  have hzero := logRayMap_im_of_im_zero p hs₁ hs₂ (show (0 : ℂ).im=0 by rfl)
  have hlt : (logRayMap p s₁ s₂ 0).im < p*Real.pi := by rw [hzero]; positivity
  have hn : (fun z : ℂ => (logRayMap p s₁ s₂ z).im) ⁻¹' Iio (p*Real.pi) ∈ 𝓝 0 :=
    (Complex.continuous_im.continuousAt.comp hF).preimage_mem_nhds (Iio_mem_nhds hlt)
  obtain ⟨ε,hε,hsub⟩ := Metric.mem_nhds_iff.mp hn
  let t := min (ε/2) (Real.pi/2)
  have ht : 0 < t := lt_min (by positivity) (by positivity)
  have hte : t < ε := lt_of_le_of_lt (min_le_left _ _) (by linarith)
  have htp : t < Real.pi := lt_of_le_of_lt (min_le_right _ _) (by linarith [Real.pi_pos])
  let z : ℂ := (t : ℂ)*Complex.I
  have hzi : z.im=t := by simp [z]
  have hz : z ∈ logRayStrip := by exact ⟨hzi ▸ ht,hzi ▸ htp⟩
  have hzball : z ∈ Metric.ball (0 : ℂ) ε := by
    rw [Metric.mem_ball,dist_zero_right]
    simpa only [z,norm_mul,Complex.norm_real,Real.norm_of_nonneg ht.le,
      Complex.norm_I,mul_one] using hte
  exact ⟨logRayMap p s₁ s₂ z,⟨logRayMap_im_pos s₁ s₂ hp hz,hsub hzball⟩,⟨z,hz,rfl⟩⟩

theorem logRayMap_covers_target {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) :
    logRayTarget p ⊆ logRayMap p s₁ s₂ '' logRayStrip := by
  have hconv : Convex ℝ (logRayTarget p) :=
    (convex_Ioo (0 : ℝ) (p*Real.pi)).linear_preimage Complex.imCLM.toLinearMap
  apply hconv.isPreconnected.subset_of_closure_inter_subset
    (logRayMap_image_open p hs₁ hs₂) (logRayMap_image_inter_target_nonempty hp hs₁ hs₂)
  rintro w ⟨hcl,hw⟩
  obtain ⟨v,hv,hlim⟩ := mem_closure_iff_seq_limit.mp hcl
  let u : ℕ → ℂ := fun n => (hv n).choose
  have hu : ∀ n, u n ∈ logRayStrip := fun n => (hv n).choose_spec.1
  have he : ∀ n, logRayMap p s₁ s₂ (u n)=v n := fun n => (hv n).choose_spec.2
  have hlim' : Tendsto (fun n => logRayMap p s₁ s₂ (u n)) atTop (𝓝 w) := by
    convert hlim using 1
    funext n
    exact he n
  exact logRayMap_image_limit hp hs₁ hs₂ hu hw hlim'

end LeanVerification.RegionalComplex
