import LeanVerification.RegionalComplex.LogRayBounds
import Mathlib.Topology.Sequences

/-! Compactness of inverse sequences over the actual logarithmic target strip. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalComplex

def logRayTarget (p : ℝ) : Set ℂ := {w | 0 < w.im ∧ w.im < p*Real.pi}

theorem logRayMap_image_limit {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {u : ℕ → ℂ} (hu : ∀ n, u n ∈ logRayStrip) {w : ℂ}
    (hw : w ∈ logRayTarget p)
    (hlim : Tendsto (fun n => logRayMap p s₁ s₂ (u n)) atTop (𝓝 w)) :
    w ∈ logRayMap p s₁ s₂ '' logRayStrip := by
  let B := (w.im+p*Real.pi)/2
  have hwB : w.im < B := by dsimp [B]; linarith [hw.2]
  have hBpi : B < p*Real.pi := by dsimp [B]; linarith [hw.2]
  have hBdiv : B/p < Real.pi := (div_lt_iff₀ hp).2 (by linarith)
  let a := w.re-1
  let b := w.re+1
  let lo := min 0 ((a-Real.log (1+s₁)-Real.log (1+s₂))/p)
  let hi := max (logRayRealThreshold s₁ s₂) ((b+2*Real.log 2)/(p+2))
  let K : Set ℂ := (Icc lo hi) ×ℂ (Icc 0 (B/p))
  have hK : IsCompact K := isCompact_Icc.reProdIm isCompact_Icc
  have hre : Tendsto (fun n => (logRayMap p s₁ s₂ (u n)).re) atTop (𝓝 w.re) :=
    Complex.continuous_re.continuousAt.tendsto.comp hlim
  have him : Tendsto (fun n => (logRayMap p s₁ s₂ (u n)).im) atTop (𝓝 w.im) :=
    Complex.continuous_im.continuousAt.tendsto.comp hlim
  have hevent : ∀ᶠ n in atTop, u n ∈ K := by
    filter_upwards [hre (Ioo_mem_nhds (show a < w.re by dsimp [a]; linarith)
      (show w.re < b by dsimp [b]; linarith)),him (Iio_mem_nhds hwB)] with n hn hm
    have hreal := logRayMap_preimage_re_bounds hp hs₁ hs₂ (hu n) hn.1.le hn.2.le
    have hImag := logRayMap_preimage_im_bound hp (hu n) hm.le
    exact ⟨hreal,⟨(hu n).1.le,hImag⟩⟩
  obtain ⟨z,hz,φ,hφ,hconv⟩ := hK.tendsto_subseq' hevent.frequently
  have hz0 : 0 ≤ z.im := hz.2.1
  have hzpi : z.im < Real.pi := hz.2.2.trans_lt hBdiv
  have hFconv := (hasDerivAt_logRayMap_closed p hs₁ hs₂ hz0 hzpi).continuousAt.tendsto.comp hconv
  have hsub := hlim.comp hφ.tendsto_atTop
  have heq : logRayMap p s₁ s₂ z = w := tendsto_nhds_unique hFconv hsub
  have hzpos : 0 < z.im := by
    by_contra h
    have hzero : z.im = 0 := le_antisymm (le_of_not_gt h) hz0
    have hh := logRayMap_im_of_im_zero p hs₁ hs₂ hzero
    rw [heq] at hh
    linarith [hw.1]
  exact ⟨z,⟨hzpos,hzpi⟩,heq⟩

end LeanVerification.RegionalComplex
