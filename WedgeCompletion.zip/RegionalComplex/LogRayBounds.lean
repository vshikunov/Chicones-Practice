import LeanVerification.RegionalComplex.LogRayMap
import Mathlib.Analysis.SpecialFunctions.Log.Basic

/-! Uniform escape bounds for the actual logarithmic inverse construction. -/

noncomputable section
open Set
namespace LeanVerification.RegionalComplex

theorem logRayMap_im_lower (p s₁ s₂ : ℝ) {z : ℂ} (hz : z ∈ logRayStrip) :
    p*z.im ≤ (logRayMap p s₁ s₂ z).im := by
  have harg (s : ℝ) : 0 ≤ (Complex.exp z+(s : ℂ)).arg := by
    apply Complex.arg_nonneg_iff.mpr
    simpa only [Complex.add_im,Complex.ofReal_im,add_zero] using
      (exp_im_pos_of_logRayStrip hz).le
  simp only [logRayMap,Complex.add_im,Complex.mul_im,Complex.ofReal_re,
    Complex.ofReal_im,zero_mul,add_zero,Complex.log_im]
  linarith [harg s₁,harg s₂]

theorem logRayMap_im_pos {p : ℝ} (s₁ s₂ : ℝ) (hp : 0 < p)
    {z : ℂ} (hz : z ∈ logRayStrip) : 0 < (logRayMap p s₁ s₂ z).im :=
  lt_of_lt_of_le (mul_pos hp hz.1) (logRayMap_im_lower p s₁ s₂ hz)

theorem logRayMap_re (p s₁ s₂ : ℝ) (z : ℂ) :
    (logRayMap p s₁ s₂ z).re = p*z.re +
      Real.log ‖Complex.exp z+(s₁ : ℂ)‖ + Real.log ‖Complex.exp z+(s₂ : ℂ)‖ := by
  simp only [logRayMap,Complex.add_re,Complex.mul_re,Complex.ofReal_re,
    Complex.ofReal_im,zero_mul,sub_zero,Complex.log_re]

theorem shifted_log_re_upper {s : ℝ} (hs : 0 < s) {z : ℂ}
    (hz : z ∈ logRayStrip) (hx : z.re ≤ 0) :
    Real.log ‖Complex.exp z+(s : ℂ)‖ ≤ Real.log (1+s) := by
  have hn : Complex.exp z+(s : ℂ) ≠ 0 :=
    Complex.slitPlane_ne_zero (shifted_exp_slitPlane s hz)
  have ht := norm_add_le (Complex.exp z) (s : ℂ)
  rw [Complex.norm_exp,Complex.norm_real,Real.norm_of_nonneg hs.le] at ht
  have he : Real.exp z.re ≤ 1 := Real.exp_le_one_iff.mpr hx
  exact Real.log_le_log (norm_pos_iff.mpr hn) (by linarith)

theorem logRayMap_re_upper {p s₁ s₂ : ℝ} (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {z : ℂ} (hz : z ∈ logRayStrip) (hx : z.re ≤ 0) :
    (logRayMap p s₁ s₂ z).re ≤ p*z.re + Real.log (1+s₁)+Real.log (1+s₂) := by
  rw [logRayMap_re]
  linarith [shifted_log_re_upper hs₁ hz hx,shifted_log_re_upper hs₂ hz hx]

theorem shifted_log_re_lower {s : ℝ} (hs : 0 < s) {z : ℂ}
    (hx : 2*s ≤ Real.exp z.re) :
    z.re-Real.log 2 ≤ Real.log ‖Complex.exp z+(s : ℂ)‖ := by
  have ht := norm_add_le (Complex.exp z+(s : ℂ)) (-(s : ℂ))
  simp only [add_neg_cancel_right,norm_neg,Complex.norm_exp,
    Complex.norm_real,Real.norm_of_nonneg hs.le] at ht
  have hh : Real.exp z.re/2 ≤ ‖Complex.exp z+(s : ℂ)‖ := by linarith
  have hp : 0 < Real.exp z.re/2 := by positivity
  have hl := Real.log_le_log hp hh
  rw [Real.log_div (Real.exp_ne_zero _) (by norm_num : (2 : ℝ) ≠ 0),Real.log_exp] at hl
  exact hl

theorem logRayMap_re_lower {p s₁ s₂ : ℝ} (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {z : ℂ} (hx₁ : 2*s₁ ≤ Real.exp z.re) (hx₂ : 2*s₂ ≤ Real.exp z.re) :
    (p+2)*z.re-2*Real.log 2 ≤ (logRayMap p s₁ s₂ z).re := by
  rw [logRayMap_re]
  linarith [shifted_log_re_lower hs₁ hx₁,shifted_log_re_lower hs₂ hx₂]

theorem logRayMap_im_of_im_zero (p : ℝ) {s₁ s₂ : ℝ} (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {z : ℂ} (hz : z.im = 0) : (logRayMap p s₁ s₂ z).im = 0 := by
  have he : Complex.exp z = (Real.exp z.re : ℂ) := by
    apply Complex.ext <;> simp [Complex.exp_re,Complex.exp_im,hz]
  have harg (s : ℝ) (hs : 0 < s) : (Complex.exp z+(s : ℂ)).arg = 0 := by
    rw [he,← Complex.ofReal_add]
    exact Complex.arg_ofReal_of_nonneg (by positivity)
  simp only [logRayMap,Complex.add_im,Complex.mul_im,Complex.ofReal_re,
    Complex.ofReal_im,hz,mul_zero,zero_mul,add_zero,Complex.log_im,harg s₁ hs₁,harg s₂ hs₂]

theorem shifted_exp_slitPlane_closed {s : ℝ} (hs : 0 < s) {z : ℂ}
    (hz0 : 0 ≤ z.im) (hzpi : z.im < Real.pi) :
    Complex.exp z+(s : ℂ) ∈ Complex.slitPlane := by
  by_cases hh : 0 < z.im
  · exact shifted_exp_slitPlane s ⟨hh,hzpi⟩
  have he : z.im = 0 := le_antisymm (le_of_not_gt hh) hz0
  apply Complex.mem_slitPlane_iff.mpr
  left
  simp only [Complex.add_re,Complex.ofReal_re,Complex.exp_re,he,Real.cos_zero,mul_one]
  positivity

theorem hasDerivAt_logRayMap_closed (p : ℝ) {s₁ s₂ : ℝ}
    (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {z : ℂ}
    (hz0 : 0 ≤ z.im) (hzpi : z.im < Real.pi) :
    HasDerivAt (logRayMap p s₁ s₂) (logRayDeriv p s₁ s₂ z) z := by
  simpa only [logRayMap,logRayDeriv,mul_one] using
    (((hasDerivAt_id z).const_mul (p : ℂ)).add
      (((Complex.hasDerivAt_exp z).add_const (s₁ : ℂ)).clog
        (shifted_exp_slitPlane_closed hs₁ hz0 hzpi))).add
      (((Complex.hasDerivAt_exp z).add_const (s₂ : ℂ)).clog
        (shifted_exp_slitPlane_closed hs₂ hz0 hzpi))

def logRayRealThreshold (s₁ s₂ : ℝ) : ℝ :=
  max (Real.log (2*s₁)) (Real.log (2*s₂))

theorem logRayMap_preimage_re_bounds {p s₁ s₂ a b : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {z : ℂ}
    (hz : z ∈ logRayStrip) (ha : a ≤ (logRayMap p s₁ s₂ z).re)
    (hb : (logRayMap p s₁ s₂ z).re ≤ b) :
    min 0 ((a-Real.log (1+s₁)-Real.log (1+s₂))/p) ≤ z.re ∧
      z.re ≤ max (logRayRealThreshold s₁ s₂) ((b+2*Real.log 2)/(p+2)) := by
  constructor
  · by_cases hx : z.re ≤ 0
    · have hh := logRayMap_re_upper (p:=p) hs₁ hs₂ hz hx
      have hdiv : (a-Real.log (1+s₁)-Real.log (1+s₂))/p ≤ z.re := by
        apply (div_le_iff₀ hp).2
        linarith
      exact (min_le_right _ _).trans hdiv
    · exact (min_le_left _ _).trans (le_of_lt (lt_of_not_ge hx))
  · by_cases hx : logRayRealThreshold s₁ s₂ ≤ z.re
    · have hexp (s : ℝ) (hs : 0 < s) (hl : Real.log (2*s) ≤ z.re) :
          2*s ≤ Real.exp z.re := by
        calc
          2*s = Real.exp (Real.log (2*s)) := (Real.exp_log (by positivity)).symm
          _ ≤ Real.exp z.re := Real.exp_le_exp.mpr hl
      have hx₁ : Real.log (2*s₁) ≤ z.re := (le_max_left _ _).trans hx
      have hx₂ : Real.log (2*s₂) ≤ z.re := (le_max_right _ _).trans hx
      have hh := logRayMap_re_lower (p:=p) hs₁ hs₂ (hexp s₁ hs₁ hx₁) (hexp s₂ hs₂ hx₂)
      have hdiv : z.re ≤ (b+2*Real.log 2)/(p+2) := by
        apply (le_div_iff₀ (by positivity : 0 < p+2)).2
        linarith
      exact hdiv.trans (le_max_right _ _)
    · exact (le_of_lt (lt_of_not_ge hx)).trans (le_max_left _ _)

theorem logRayMap_preimage_im_bound {p s₁ s₂ B : ℝ}
    (hp : 0 < p) {z : ℂ} (hz : z ∈ logRayStrip)
    (hB : (logRayMap p s₁ s₂ z).im ≤ B) : z.im ≤ B/p := by
  apply (le_div_iff₀ hp).2
  have hh := logRayMap_im_lower p s₁ s₂ hz
  linarith

end LeanVerification.RegionalComplex
