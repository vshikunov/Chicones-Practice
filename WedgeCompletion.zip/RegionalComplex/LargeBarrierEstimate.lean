import LeanVerification.RegionalComplex.LargeBarrierMinimum

noncomputable section
open Set
namespace LeanVerification.RegionalComplex

theorem largeBarrierZ_arg_antitone : AntitoneOn (fun v => (largeBarrierZ v).arg) (Ioi 0) := by
  apply antitoneOn_of_deriv_nonpos (convex_Ioi 0)
  · intro v hv
    exact (hasDerivAt_largeBarrierZ_arg hv).continuousAt.continuousWithinAt
  · intro v hv
    exact (hasDerivAt_largeBarrierZ_arg (interior_subset hv)).differentiableAt.differentiableWithinAt
  · intro v hv
    rw [(hasDerivAt_largeBarrierZ_arg (interior_subset hv)).deriv]
    exact div_nonpos_of_nonpos_of_nonneg (by norm_num) (Complex.normSq_nonneg _)

theorem largeBarrierQ_arg_monotone : MonotoneOn (fun v => (largeBarrierQ v).arg) (Ioi 0) := by
  apply monotoneOn_of_deriv_nonneg (convex_Ioi 0)
  · intro v hv
    exact (hasDerivAt_largeBarrierQ_arg hv).continuousAt.continuousWithinAt
  · intro v hv
    exact (hasDerivAt_largeBarrierQ_arg (interior_subset hv)).differentiableAt.differentiableWithinAt
  · intro v hv
    rw [(hasDerivAt_largeBarrierQ_arg (interior_subset hv)).deriv]
    have hv0 : 0 < v := interior_subset hv
    have hq := Complex.normSq_nonneg (largeBarrierQ v)
    positivity

theorem largeBarrierG_left_antitone : AntitoneOn largeBarrierG (Ioc 0 (109/100)) := by
  apply antitoneOn_of_deriv_nonpos (convex_Ioc 0 (109/100))
  · intro v hv
    exact (hasDerivAt_largeBarrierG hv.1).continuousAt.continuousWithinAt
  · intro v hv
    exact (hasDerivAt_largeBarrierG (interior_subset hv).1).differentiableAt.differentiableWithinAt
  · intro v hv
    have hv' := interior_subset hv
    rw [(hasDerivAt_largeBarrierG hv'.1).deriv]
    have hc := largeBarrierC_neg hv'.1.le hv'.2
    have hz := Complex.normSq_nonneg (largeBarrierZ v)
    have hq := Complex.normSq_nonneg (largeBarrierQ v)
    exact div_nonpos_of_nonpos_of_nonneg
      (mul_nonpos_of_nonneg_of_nonpos (mul_nonneg (by norm_num) hv'.1.le) hc.le) (by positivity)

theorem largeBarrierG_right_monotone : MonotoneOn largeBarrierG (Ici (11/10)) := by
  apply monotoneOn_of_deriv_nonneg (convex_Ici (11/10))
  · intro v hv
    exact (hasDerivAt_largeBarrierG (by have hh : (11/10 : ℝ) ≤ v := hv; linarith)).continuousAt.continuousWithinAt
  · intro v hv
    exact (hasDerivAt_largeBarrierG (by have hh : (11/10 : ℝ) ≤ v := interior_subset hv; linarith)).differentiableAt.differentiableWithinAt
  · intro v hv
    have hv' : (11/10 : ℝ) ≤ v := interior_subset hv
    have hv0 : 0 < v := by linarith
    rw [(hasDerivAt_largeBarrierG hv0).deriv]
    have hc := largeBarrierC_pos hv'
    have hz := Complex.normSq_nonneg (largeBarrierZ v)
    have hq := Complex.normSq_nonneg (largeBarrierQ v)
    positivity

theorem largeBarrierG_bracket_lower {v : ℝ} (hvlo : 109/100 ≤ v) (hvhi : v ≤ 11/10) :
    (14/25)*(largeBarrierZ (11/10)).arg+(largeBarrierQ (109/100)).arg ≤ largeBarrierG v := by
  have hv : 0 < v := by linarith
  have hz := largeBarrierZ_arg_antitone hv (show (0 : ℝ) < 11/10 by norm_num) hvhi
  have hq := largeBarrierQ_arg_monotone (show (0 : ℝ) < 109/100 by norm_num) hv hvlo
  unfold largeBarrierG
  linarith

theorem largeBarrierG_lower {v : ℝ} (hv : 0 < v) :
    (14/25)*(largeBarrierZ (11/10)).arg+(largeBarrierQ (109/100)).arg ≤ largeBarrierG v := by
  rcases le_total v (109/100) with hlo | hlo
  · have hh := largeBarrierG_left_antitone ⟨hv,hlo⟩
      (show (109/100 : ℝ) ∈ Ioc 0 (109/100) by norm_num) hlo
    exact (largeBarrierG_bracket_lower (v:=109/100) (by norm_num) (by norm_num)).trans hh
  · rcases le_total v (11/10) with hhi | hhi
    · exact largeBarrierG_bracket_lower hlo hhi
    · have hh := largeBarrierG_right_monotone (show (11/10 : ℝ) ∈ Ici (11/10) by norm_num) hhi hhi
      exact (largeBarrierG_bracket_lower (v:=11/10) (by norm_num) (by norm_num)).trans hh

theorem arg_eq_arctan_of_re_pos {z : ℂ} (hz : 0 < z.re) :
    z.arg=Real.arctan (z.im/z.re) := by
  have hh := abs_lt.mp (Complex.abs_arg_lt_pi_div_two_iff.mpr (Or.inl hz))
  exact (Real.arctan_eq_of_tan_eq (Complex.tan_arg z) hh).symm

theorem largeBarrierZ_bracket_angle :
    (largeBarrierZ (11/10)).arg=Real.pi/2-Real.arctan (3/44 : ℝ) := by
  have hre : 0 < (largeBarrierZ (11/10)).re := by rw [(largeBarrierZ_parts _).1]; norm_num
  rw [arg_eq_arctan_of_re_pos hre,(largeBarrierZ_parts _).1,(largeBarrierZ_parts _).2]
  have hh := Real.arctan_inv_of_pos (show (0 : ℝ) < 3/44 by norm_num)
  norm_num at hh ⊢
  exact hh

theorem largeBarrierQ_bracket_angle :
    Real.arctan (5/8 : ℝ) < (largeBarrierQ (109/100)).arg := by
  have hre : 0 < (largeBarrierQ (109/100)).re := by rw [(largeBarrierQ_parts _).1]; norm_num
  rw [arg_eq_arctan_of_re_pos hre]
  apply Real.arctan_lt_arctan
  rw [(largeBarrierQ_parts _).1,(largeBarrierQ_parts _).2]
  norm_num

theorem largeBarrierG_strict_physical_bound {v : ℝ} (hv : 0 < v) :
    (11/25)*Real.pi < largeBarrierG v := by
  have hh := largeBarrierG_lower hv
  rw [largeBarrierZ_bracket_angle] at hh
  have hq := largeBarrierQ_bracket_angle
  have hm := large_cone_arctan_margin
  linarith

end LeanVerification.RegionalComplex
