import LeanVerification.RegionalComplex.PhysicalRay
import LeanVerification.RegionalComplex.LargeBarrierParameters
import LeanVerification.RegionalComplex.SharpConeElasticity

/-! The sharper cone is proved on the actual physical inverse ray,
and the actual elasticity signs are then instantiated there. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalComplex

theorem sharp_cone_boundary_parameterization {r : ℂ} {h : ℝ}
    (hr : 0 < r.im) (hh : 0 < h)
    (harg : (r+(h : ℂ)).arg=Real.arctan (4/3 : ℝ)) :
    ∃ v : ℝ, 0 < v ∧ r=(h : ℂ)*largeBarrierZ v := by
  have him : 0 < (r+(h : ℂ)).im := by simpa using hr
  have hangle : (r+(h : ℂ)).arg < Real.pi/2 := by
    rw [harg]
    exact Real.arctan_lt_pi_div_two _
  have hre : 0 < (r+(h : ℂ)).re := by
    rcases Complex.arg_lt_pi_div_two_iff.mp hangle with he | he | he
    · exact he
    · linarith
    · simp [he] at him
  have hx : 0 < r.re+h := by simpa using hre
  have ht := Complex.tan_arg (r+(h : ℂ))
  rw [harg,Real.tan_arctan] at ht
  simp only [Complex.add_im,Complex.ofReal_im,add_zero,Complex.add_re,Complex.ofReal_re] at ht
  have hy : r.im=4*(r.re+h)/3 := by
    have he := (eq_div_iff (ne_of_gt hx)).mp ht
    linarith
  refine ⟨(r.re+h)/h,div_pos hx hh,?_⟩
  apply Complex.ext
  · simp only [largeBarrierZ,Complex.mul_re,Complex.mul_im,Complex.add_re,Complex.sub_re,
      Complex.add_im,Complex.sub_im,Complex.ofReal_re,Complex.ofReal_im,Complex.one_re,
      Complex.one_im,Complex.I_re,Complex.I_im]
    norm_num
    field_simp
    <;> ring
  · simp only [largeBarrierZ,Complex.mul_re,Complex.mul_im,Complex.add_re,Complex.sub_re,
      Complex.add_im,Complex.sub_im,Complex.ofReal_re,Complex.ofReal_im,Complex.one_re,
      Complex.one_im,Complex.I_re,Complex.I_im]
    norm_num
    rw [hy]
    field_simp
    <;> ring

theorem sharp_boundary_polynomial {p c : ℝ} (hp : 0 < p)
    (hc : 0 < c) (hcq : c ≤ 1/4) (v : ℝ) :
    (((rayRootSmall p c : ℂ)*largeBarrierZ v)^2+
      (rayRootSmall p c : ℂ)*largeBarrierZ v+(c : ℂ))=
      (rayRootSmall p c : ℂ)*largeConeQ p (rayRootSmall p c) v := by
  have he := rayRoots_coefficient_identity hp hc hcq
  have heC : (c : ℂ)=(rayRootSmall p c : ℂ)*
      (((p : ℂ)+1)-((p : ℂ)+2)*(rayRootSmall p c : ℂ))/(p : ℂ) := by exact_mod_cast he
  have hpC : (p : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (ne_of_gt hp)
  rw [heC]
  simp only [largeConeQ,largeConeA,largeConeB,largeBarrierZ,Complex.ofReal_add,
    Complex.ofReal_div,Complex.ofReal_mul,Complex.ofReal_one,Complex.ofReal_ofNat]
  field_simp
  <;> ring

theorem physicalRay_ne_sharp_boundary {p c : ℝ}
    (hp : 14/25 ≤ p) (hp2 : p ≤ 2/3) (hc : 21/100 ≤ c) (hcq : c ≤ 1/4) (x : ℝ) :
    (physicalRay p c x+(rayRootSmall p c : ℂ)).arg ≠ Real.arctan (4/3 : ℝ) := by
  have hp0 : 0 < p := by linarith
  have hpHalf : 1/2 < p := by linarith
  have hp1 : p < 1 := by linarith
  have hc0 : 0 < c := by linarith
  have hh := rayRootSmall_pos hp0 hc0 hcq
  have hhlo := rayRootSmall_large_coefficient hp hc hcq
  have hhu := rayRootSmall_upper hp0 hc0 hcq
  have hh2 : rayRootSmall p c < 1/2 := by
    have he := (le_div_iff₀ (show 0 < 2*(p+2) by positivity)).mp hhu
    nlinarith
  intro heq
  obtain ⟨v,hv,hr⟩ := sharp_cone_boundary_parameterization
    (physicalRay_mem_upper hpHalf hp1 hc0 hcq x) hh heq
  have hphase := physicalRay_phase hpHalf hp1 hc0 hcq x
  have hpoly := sharp_boundary_polynomial hp0 hc0 hcq v
  have harg : (physicalRay p c x).arg=(largeBarrierZ v).arg := by
    rw [hr]
    exact Complex.arg_real_mul _ hh
  have hParg : ((physicalRay p c x)^2+physicalRay p c x+(c : ℂ)).arg=
      (largeConeQ p (rayRootSmall p c) v).arg := by
    rw [hr,hpoly]
    exact Complex.arg_real_mul _ hh
  rw [harg,hParg] at hphase
  have hb := largeCone_phase_bound hp hhlo.le hh2 hv
  nlinarith [Real.pi_pos]

theorem physicalRay_sharp_cone {p c : ℝ}
    (hp : 14/25 ≤ p) (hp2 : p ≤ 2/3) (hc : 21/100 ≤ c) (hcq : c ≤ 1/4) (x : ℝ) :
    0 < (physicalRay p c x+(rayRootSmall p c : ℂ)).arg ∧
      (physicalRay p c x+(rayRootSmall p c : ℂ)).arg < Real.arctan (4/3 : ℝ) := by
  have hp0 : 0 < p := by linarith
  have hpHalf : 1/2 < p := by linarith
  have hp1 : p < 1 := by linarith
  have hc0 : 0 < c := by linarith
  have hh := rayRootSmall_pos hp0 hc0 hcq
  have hapos : 0 < Real.arctan (4/3 : ℝ) := by
    simpa only [Real.arctan_zero] using Real.arctan_lt_arctan (show (0 : ℝ) < 4/3 by norm_num)
  constructor
  · apply arg_pos_of_im_pos
    simpa using physicalRay_mem_upper hpHalf hp1 hc0 hcq x
  · apply lt_of_not_ge
    intro hx
    have hevent := (physicalRay_shift_arg_tendsto_zero hpHalf hp1 hc0 hcq hh).eventually
      (gt_mem_nhds hapos)
    obtain ⟨a,ha⟩ := hevent.exists
    obtain ⟨b,hb⟩ := intermediate_value_univ a x
      (physicalRay_shift_arg_continuous (h:=rayRootSmall p c) hpHalf hp1 hc0 hcq)
      (show Real.arctan (4/3 : ℝ) ∈ Icc
        (physicalRay p c a+(rayRootSmall p c : ℂ)).arg
        (physicalRay p c x+(rayRootSmall p c : ℂ)).arg from ⟨ha.le,hx⟩)
    exact physicalRay_ne_sharp_boundary hp hp2 hc hcq b hb

theorem physicalRay_sharp_cone_squared {p c : ℝ}
    (hp : 14/25 ≤ p) (hp2 : p ≤ 2/3) (hc : 21/100 ≤ c) (hcq : c ≤ 1/4) (x : ℝ) :
    9*(physicalRay p c x).im^2 <
      16*((physicalRay p c x).re+rayRootSmall p c)^2 := by
  have hangle := (physicalRay_sharp_cone hp hp2 hc hcq x).2
  have him : 0 < (physicalRay p c x).im := physicalRay_mem_upper
    (by linarith : 1/2 < p) (by linarith : p < 1) (by linarith : 0 < c) hcq x
  have hshiftim : 0 < (physicalRay p c x+(rayRootSmall p c : ℂ)).im := by simpa using him
  have hre : 0 < (physicalRay p c x+(rayRootSmall p c : ℂ)).re := by
    rcases Complex.arg_lt_pi_div_two_iff.mp (hangle.trans (Real.arctan_lt_pi_div_two _)) with he | he | he
    · exact he
    · linarith
    · simp [he] at hshiftim
  rw [arg_eq_arctan_of_re_pos hre] at hangle
  have hratio := Real.arctan_strictMono.lt_iff_lt.mp hangle
  have hy := (div_lt_iff₀ hre).mp hratio
  simp only [Complex.add_im,Complex.ofReal_im,add_zero,Complex.add_re,Complex.ofReal_re] at hy hre
  have hprod : 0 < (4*((physicalRay p c x).re+rayRootSmall p c)-3*(physicalRay p c x).im)*
      (4*((physicalRay p c x).re+rayRootSmall p c)+3*(physicalRay p c x).im) := by
    apply mul_pos <;> linarith
  nlinarith

theorem physicalRayElasticity_signs_right {p c : ℝ}
    (hp : 14/25 ≤ p) (hp2 : p ≤ 2/3) (hc : 21/100 ≤ c) (hcq : c ≤ 1/4)
    (x : ℝ) (hx : 0 ≤ (physicalRay p c x).re) :
    0 < (rayElasticity p c (physicalRay p c x)).re ∧
      (rayElasticity p c (physicalRay p c x)).im < 0 := by
  exact rayElasticity_signs_in_sharp_cone hp (by linarith) (by linarith) hcq hx
    (physicalRay_mem_upper (by linarith) (by linarith) (by linarith) hcq x)
    (physicalRay_sharp_cone_squared hp hp2 hc hcq x)

end LeanVerification.RegionalComplex
