import LeanVerification.RegionalComplex.PhysicalSharpCone
import LeanVerification.RegionalComplex.PositiveRayContinuation

/-! The actual Loud parameter normalization used by the upper-left ray,
including the normalized coefficient and the original positive scalings. -/

noncomputable section
namespace LeanVerification.RegionalComplex

def upperLeftRayP (F : ℝ) : ℝ := 2*F-2
def upperLeftRayLambda (D F : ℝ) : ℝ := -2*(D+1)/upperLeftRayP F
def normalizedRayCoefficient (p l : ℝ) : ℝ :=
  l*(2+p*l)*(p+1)^2/(4*(p+2)*(1+p*l)^2)
def loudNormalizedRayCoefficient (D F : ℝ) : ℝ :=
  normalizedRayCoefficient (upperLeftRayP F) (upperLeftRayLambda D F)

theorem upperLeftRay_parameters {D F : ℝ}
    (hF : 32/25 ≤ F) (hFu : F ≤ 4/3) (hD : -F < D) (hDu : D < -1) :
    14/25 ≤ upperLeftRayP F ∧ upperLeftRayP F ≤ 2/3 ∧
      0 < upperLeftRayLambda D F ∧ upperLeftRayLambda D F < 1 := by
  have hp : 0 < upperLeftRayP F := by unfold upperLeftRayP; linarith
  refine ⟨?_,?_,?_,?_⟩
  · unfold upperLeftRayP
    linarith
  · unfold upperLeftRayP
    linarith
  · exact div_pos (by linarith) hp
  · apply (div_lt_iff₀ hp).2
    unfold upperLeftRayP
    linarith

theorem normalizedRayCoefficient_pos {p l : ℝ} (hp : 0 < p) (hl : 0 < l) :
    0 < normalizedRayCoefficient p l := by
  unfold normalizedRayCoefficient
  positivity

theorem normalizedRayCoefficient_complement {p l : ℝ} (hp : 0 < p) (hl : 0 ≤ l) :
    1/4-normalizedRayCoefficient p l=
      (1-l)*(l*p+p+2)/(4*(p+2)*(l*p+1)^2) := by
  have hp2 : p+2 ≠ 0 := ne_of_gt (by positivity)
  have hpl : l*p+1 ≠ 0 := ne_of_gt (by positivity)
  have hpl' : 1+p*l ≠ 0 := ne_of_gt (by positivity)
  unfold normalizedRayCoefficient
  field_simp
  <;> ring

theorem normalizedRayCoefficient_lt_quarter {p l : ℝ}
    (hp : 0 < p) (hl : 0 < l) (hlu : l < 1) : normalizedRayCoefficient p l < 1/4 := by
  have he := normalizedRayCoefficient_complement hp hl.le
  have hpos : 0 < (1-l)*(l*p+p+2)/(4*(p+2)*(l*p+1)^2) := by
    have h1 : 0 < 1-l := sub_pos.mpr hlu
    positivity
  linarith

theorem normalizedRayCoefficient_actual_scaling {p l : ℝ}
    (hp : 0 < p) (hl : 0 < l) :
    (p*l/(2*(p+2)))*(1/p+l/2)/((1+p*l)/(p+1))^2=normalizedRayCoefficient p l := by
  have hp1 : p+1 ≠ 0 := ne_of_gt (by positivity)
  have hp2 : p+2 ≠ 0 := ne_of_gt (by positivity)
  have hpl : 1+p*l ≠ 0 := ne_of_gt (by positivity)
  have hpn : p ≠ 0 := ne_of_gt hp
  unfold normalizedRayCoefficient
  field_simp
  <;> ring

theorem loudNormalizedRayCoefficient_bounds {D F : ℝ}
    (hF : 32/25 ≤ F) (hFu : F ≤ 4/3) (hD : -F < D) (hDu : D < -1) :
    0 < loudNormalizedRayCoefficient D F ∧ loudNormalizedRayCoefficient D F < 1/4 := by
  obtain ⟨hp,hpu,hl,hlu⟩ := upperLeftRay_parameters hF hFu hD hDu
  have hp0 : 0 < upperLeftRayP F := by linarith
  exact ⟨normalizedRayCoefficient_pos hp0 hl,normalizedRayCoefficient_lt_quarter hp0 hl hlu⟩

theorem loud_physical_ray_sharp_cone {D F : ℝ}
    (hF : 32/25 ≤ F) (hFu : F ≤ 4/3) (hD : -F < D) (hDu : D < -1)
    (hc : 21/100 ≤ loudNormalizedRayCoefficient D F) (x : ℝ) :
    0 < (physicalRay (upperLeftRayP F) (loudNormalizedRayCoefficient D F) x+
      (rayRootSmall (upperLeftRayP F) (loudNormalizedRayCoefficient D F) : ℂ)).arg ∧
    (physicalRay (upperLeftRayP F) (loudNormalizedRayCoefficient D F) x+
      (rayRootSmall (upperLeftRayP F) (loudNormalizedRayCoefficient D F) : ℂ)).arg <
        Real.arctan (4/3 : ℝ) := by
  obtain ⟨hp,hpu,hl,hlu⟩ := upperLeftRay_parameters hF hFu hD hDu
  exact physicalRay_sharp_cone hp hpu hc
    (loudNormalizedRayCoefficient_bounds hF hFu hD hDu).2.le x

theorem loud_physical_ray_elasticity_signs {D F : ℝ}
    (hF : 32/25 ≤ F) (hFu : F ≤ 4/3) (hD : -F < D) (hDu : D < -1)
    (hc : 21/100 ≤ loudNormalizedRayCoefficient D F) (x : ℝ)
    (hx : 0 ≤ (physicalRay (upperLeftRayP F) (loudNormalizedRayCoefficient D F) x).re) :
    0 < (rayElasticity (upperLeftRayP F) (loudNormalizedRayCoefficient D F)
      (physicalRay (upperLeftRayP F) (loudNormalizedRayCoefficient D F) x)).re ∧
    (rayElasticity (upperLeftRayP F) (loudNormalizedRayCoefficient D F)
      (physicalRay (upperLeftRayP F) (loudNormalizedRayCoefficient D F) x)).im < 0 := by
  obtain ⟨hp,hpu,hl,hlu⟩ := upperLeftRay_parameters hF hFu hD hDu
  exact physicalRayElasticity_signs_right hp hpu hc
    (loudNormalizedRayCoefficient_bounds hF hFu hD hDu).2.le x hx

end LeanVerification.RegionalComplex
