import LeanVerification.RegionalComplex.LogRayCoverage
import Mathlib.Analysis.SpecialFunctions.Pow.Complex

/-! A constructed holomorphic branch for the actual principal-power map
r ↦ r^p (r+s₁)(r+s₂), throughout 0 < arg u < p π, 0 < p ≤ 1. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalComplex

def logRayInverse (p s₁ s₂ : ℝ) : ℂ → ℂ :=
  Function.invFunOn (logRayMap p s₁ s₂) logRayStrip

theorem logRayInverse_mem {p s₁ s₂ : ℝ} {w : ℂ}
    (hw : w ∈ logRayMap p s₁ s₂ '' logRayStrip) :
    logRayInverse p s₁ s₂ w ∈ logRayStrip := Function.invFunOn_mem hw

theorem logRayMap_inverse {p s₁ s₂ : ℝ} {w : ℂ}
    (hw : w ∈ logRayMap p s₁ s₂ '' logRayStrip) :
    logRayMap p s₁ s₂ (logRayInverse p s₁ s₂ w)=w := Function.invFunOn_eq hw

theorem logRayInverse_map (p : ℝ) {s₁ s₂ : ℝ} (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {z : ℂ} (hz : z ∈ logRayStrip) :
    logRayInverse p s₁ s₂ (logRayMap p s₁ s₂ z)=z :=
  (logRayMap_injective p hs₁ hs₂).leftInvOn_invFunOn hz

theorem hasStrictDerivAt_logRayInverse (p : ℝ) {s₁ s₂ : ℝ}
    (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {w : ℂ}
    (hw : w ∈ logRayMap p s₁ s₂ '' logRayStrip) :
    HasStrictDerivAt (logRayInverse p s₁ s₂)
      (logRayDeriv p s₁ s₂ (logRayInverse p s₁ s₂ w))⁻¹ w := by
  let z := logRayInverse p s₁ s₂ w
  have hz : z ∈ logRayStrip := logRayInverse_mem hw
  have hleft : ∀ᶠ x in 𝓝 z, logRayInverse p s₁ s₂ (logRayMap p s₁ s₂ x)=x := by
    filter_upwards [logRayStrip_open.mem_nhds hz] with x hx
    exact logRayInverse_map p hs₁ hs₂ hx
  have hh := (logRayMap_strictDeriv p s₁ s₂ hz).to_local_left_inverse
    (logRayMap_deriv_ne_zero p hs₁ hs₂ hz) hleft
  rw [logRayMap_inverse hw] at hh
  exact hh

theorem logRayInverse_analytic (p : ℝ) {s₁ s₂ : ℝ}
    (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) :
    AnalyticOnNhd ℂ (logRayInverse p s₁ s₂)
      (logRayMap p s₁ s₂ '' logRayStrip) := by
  have hh : DifferentiableOn ℂ (logRayInverse p s₁ s₂)
      (logRayMap p s₁ s₂ '' logRayStrip) :=
    fun w hw => (hasStrictDerivAt_logRayInverse p hs₁ hs₂ hw).hasDerivAt.differentiableAt.differentiableWithinAt
  exact hh.analyticOnNhd (logRayMap_image_open p hs₁ hs₂)

def raySector (p : ℝ) : Set ℂ := {u | 0 < u.arg ∧ u.arg < p*Real.pi}
def rayPower (p s₁ s₂ : ℝ) (r : ℂ) : ℂ := r^(p : ℂ)*(r+(s₁ : ℂ))*(r+(s₂ : ℂ))
def rayInverse (p s₁ s₂ : ℝ) (u : ℂ) : ℂ :=
  Complex.exp (logRayInverse p s₁ s₂ (Complex.log u))

theorem raySector_ne_zero {p : ℝ} {u : ℂ} (hu : u ∈ raySector p) : u ≠ 0 := by
  intro h
  simpa only [h,Complex.arg_zero,lt_self_iff_false] using hu.1

theorem raySector_slitPlane {p : ℝ} (hp : p ≤ 1) {u : ℂ} (hu : u ∈ raySector p) :
    u ∈ Complex.slitPlane := by
  apply Complex.mem_slitPlane_iff_arg.mpr
  exact ⟨ne_of_lt (hu.2.trans_le (by nlinarith [Real.pi_pos])),raySector_ne_zero hu⟩

theorem log_mem_target {p : ℝ} {u : ℂ} (hu : u ∈ raySector p) :
    Complex.log u ∈ logRayTarget p := by
  simpa only [logRayTarget,mem_setOf_eq,Complex.log_im] using hu

theorem logRayMap_exp_identity (p s₁ s₂ : ℝ) {z : ℂ} (hz : z ∈ logRayStrip) :
    Complex.exp (logRayMap p s₁ s₂ z)=rayPower p s₁ s₂ (Complex.exp z) := by
  have h₁ : Complex.exp z+(s₁ : ℂ) ≠ 0 := Complex.slitPlane_ne_zero (shifted_exp_slitPlane s₁ hz)
  have h₂ : Complex.exp z+(s₂ : ℂ) ≠ 0 := Complex.slitPlane_ne_zero (shifted_exp_slitPlane s₂ hz)
  have hlog : Complex.log (Complex.exp z)=z :=
    Complex.log_exp (by linarith [Real.pi_pos,hz.1]) hz.2.le
  simp only [logRayMap,rayPower,Complex.exp_add,Complex.exp_log h₁,Complex.exp_log h₂,
    Complex.cpow_def_of_ne_zero (Complex.exp_ne_zero z),hlog,mul_comm (p : ℂ) z]

theorem rayInverse_log_coordinate_mem {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {u : ℂ} (hu : u ∈ raySector p) :
    logRayInverse p s₁ s₂ (Complex.log u) ∈ logRayStrip :=
  logRayInverse_mem (logRayMap_covers_target hp hs₁ hs₂ (log_mem_target hu))

theorem rayPower_inverse {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {u : ℂ} (hu : u ∈ raySector p) :
    rayPower p s₁ s₂ (rayInverse p s₁ s₂ u)=u := by
  have himage := logRayMap_covers_target hp hs₁ hs₂ (log_mem_target hu)
  rw [rayInverse,←logRayMap_exp_identity p s₁ s₂ (logRayInverse_mem himage),
    logRayMap_inverse himage,Complex.exp_log (raySector_ne_zero hu)]

theorem rayInverse_im_pos {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {u : ℂ} (hu : u ∈ raySector p) :
    0 < (rayInverse p s₁ s₂ u).im :=
  exp_im_pos_of_logRayStrip (rayInverse_log_coordinate_mem hp hs₁ hs₂ hu)

theorem rayInverse_analyticAt {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hp1 : p ≤ 1) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {u : ℂ} (hu : u ∈ raySector p) : AnalyticAt ℂ (rayInverse p s₁ s₂) u := by
  have hi := logRayInverse_analytic p hs₁ hs₂ _
    (logRayMap_covers_target hp hs₁ hs₂ (log_mem_target hu))
  have hlogOn : DifferentiableOn ℂ Complex.log Complex.slitPlane :=
    fun z hz => (Complex.hasDerivAt_log hz).differentiableAt.differentiableWithinAt
  have hlog := hlogOn.analyticOnNhd Complex.isOpen_slitPlane u (raySector_slitPlane hp1 hu)
  exact (Complex.differentiable_exp.analyticAt _).comp (hi.comp hlog)

theorem rayInverse_argument {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {u : ℂ} (hu : u ∈ raySector p) :
    (rayInverse p s₁ s₂ u).arg=(logRayInverse p s₁ s₂ (Complex.log u)).im := by
  have hz := rayInverse_log_coordinate_mem hp hs₁ hs₂ hu
  have he := Complex.log_exp (by linarith [Real.pi_pos,hz.1]) hz.2.le
  simpa only [rayInverse,Complex.log_im] using congrArg Complex.im he

end LeanVerification.RegionalComplex
