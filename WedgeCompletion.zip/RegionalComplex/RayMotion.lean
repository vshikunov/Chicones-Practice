import LeanVerification.RegionalComplex.RayAngles

/-! Energy-radius motion of the actual complex inverse along a fixed ray. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalComplex

def rayLogPath (p s₁ s₂ β : ℝ) (x : ℝ) : ℂ :=
  logRayInverse p s₁ s₂ ((x : ℂ)+(β : ℂ)*Complex.I)

theorem rayLogPath_mem {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) (x : ℝ) :
    rayLogPath p s₁ s₂ β x ∈ logRayStrip := by
  apply logRayInverse_mem
  apply logRayMap_covers_target hp hs₁ hs₂
  simpa only [logRayTarget,mem_setOf_eq,Complex.add_im,Complex.mul_im,
    Complex.ofReal_im,Complex.ofReal_re,Complex.I_im,Complex.I_re,
    zero_mul,mul_one,add_zero,zero_add] using And.intro hβ hβp

theorem hasDerivAt_rayLogPath {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) (x : ℝ) :
    HasDerivAt (rayLogPath p s₁ s₂ β)
      (logRayDeriv p s₁ s₂ (rayLogPath p s₁ s₂ β x))⁻¹ x := by
  have hw : (x : ℂ)+(β : ℂ)*Complex.I ∈ logRayTarget p := by
    simpa [logRayTarget] using And.intro hβ hβp
  have hd := (hasStrictDerivAt_logRayInverse p hs₁ hs₂
    (logRayMap_covers_target hp hs₁ hs₂ hw)).hasDerivAt
  have hc := hd.comp (x : ℂ) ((hasDerivAt_id (x : ℂ)).add_const ((β : ℂ)*Complex.I))
  simpa only [rayLogPath,mul_one] using hc.comp_ofReal

theorem hasDerivAt_rayLogAngle {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) (x : ℝ) :
    HasDerivAt (fun t => (rayLogPath p s₁ s₂ β t).im)
      (-(logRayDeriv p s₁ s₂ (rayLogPath p s₁ s₂ β x)).im /
        Complex.normSq (logRayDeriv p s₁ s₂ (rayLogPath p s₁ s₂ β x))) x := by
  simpa only [Complex.inv_im] using hasDerivAt_im_of_complex_real
    (hasDerivAt_rayLogPath hp hs₁ hs₂ hβ hβp x)

theorem rayLogAngle_strictAnti {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) :
    StrictAnti (fun x => (rayLogPath p s₁ s₂ β x).im) := by
  apply strictAnti_of_deriv_neg
  intro x
  rw [(hasDerivAt_rayLogAngle hp hs₁ hs₂ hβ hβp x).deriv]
  have hm := rayLogPath_mem hp hs₁ hs₂ hβ hβp x
  exact div_neg_of_neg_of_pos (neg_neg_of_pos (logRayDeriv_im_pos p hs₁ hs₂ hm))
    (Complex.normSq_pos.mpr (logRayMap_deriv_ne_zero p hs₁ hs₂ hm))

theorem rayInverse_angle_on_log_ray {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hp1 : p ≤ 1) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) (x : ℝ) :
    (rayInverse p s₁ s₂ (Complex.exp ((x : ℂ)+(β : ℂ)*Complex.I))).arg =
      (rayLogPath p s₁ s₂ β x).im := by
  have hlog : Complex.log (Complex.exp ((x : ℂ)+(β : ℂ)*Complex.I)) =
      (x : ℂ)+(β : ℂ)*Complex.I := by
    apply Complex.log_exp <;> simp only [Complex.add_im,Complex.ofReal_im,
      Complex.mul_im,Complex.ofReal_re,Complex.I_im,Complex.I_re,mul_one,zero_mul,add_zero,zero_add]
    · linarith [Real.pi_pos]
    · nlinarith [Real.pi_pos]
  have harg : (Complex.exp ((x : ℂ)+(β : ℂ)*Complex.I)).arg = β := by
    simpa only [Complex.log_im,Complex.add_im,Complex.ofReal_im,Complex.mul_im,
      Complex.ofReal_re,Complex.I_im,Complex.I_re,mul_one,zero_mul,add_zero,zero_add]
      using congrArg Complex.im hlog
  have hu : Complex.exp ((x : ℂ)+(β : ℂ)*Complex.I) ∈ raySector p := by
    simpa only [raySector,mem_setOf_eq,harg] using And.intro hβ hβp
  rw [rayInverse_argument hp hs₁ hs₂ hu,hlog]
  rfl

theorem rayInverse_angle_strictAnti {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hp1 : p ≤ 1) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) :
    StrictAnti (fun x : ℝ =>
      (rayInverse p s₁ s₂ (Complex.exp ((x : ℂ)+(β : ℂ)*Complex.I))).arg) := by
  have he : (fun x : ℝ =>
      (rayInverse p s₁ s₂ (Complex.exp ((x : ℂ)+(β : ℂ)*Complex.I))).arg) =
      (fun x => (rayLogPath p s₁ s₂ β x).im) :=
    funext (rayInverse_angle_on_log_ray hp hp1 hs₁ hs₂ hβ hβp)
  rw [he]
  exact rayLogAngle_strictAnti hp hs₁ hs₂ hβ hβp

end LeanVerification.RegionalComplex
