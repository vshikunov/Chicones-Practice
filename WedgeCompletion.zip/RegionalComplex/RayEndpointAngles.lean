import LeanVerification.RegionalComplex.RayEndpoints

/-! The complete endpoint-angle statement for the actual inverse branch. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalComplex

theorem rayLogAngle_tendsto_atBot {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) :
    Tendsto (fun x => (rayLogPath p s₁ s₂ β x).im) atBot (𝓝 (β/p)) := by
  have hr := rayLogPath_exp_tendsto_zero hp hs₁ hs₂ hβ hβp
  have ha (s : ℝ) (hs : 0 < s) :
      Tendsto (fun x => (Complex.exp (rayLogPath p s₁ s₂ β x)+(s : ℂ)).arg) atBot (𝓝 0) := by
    have hslit : (s : ℂ) ∈ Complex.slitPlane := Complex.mem_slitPlane_iff.mpr (Or.inl hs)
    have ht : Tendsto (fun x => Complex.exp (rayLogPath p s₁ s₂ β x)+(s : ℂ)) atBot (𝓝 (s : ℂ)) :=
      by simpa only [zero_add] using hr.add_const (s : ℂ)
    have hh := (Complex.continuousAt_arg hslit).tendsto.comp ht
    simpa only [zero_add,Complex.arg_ofReal_of_nonneg hs.le] using hh
  have he : (fun x => (rayLogPath p s₁ s₂ β x).im)=
      (fun x => (β-(Complex.exp (rayLogPath p s₁ s₂ β x)+(s₁ : ℂ)).arg-
        (Complex.exp (rayLogPath p s₁ s₂ β x)+(s₂ : ℂ)).arg)/p) := by
    funext x
    apply (eq_div_iff (ne_of_gt hp)).2
    have hh := rayLogPath_phase hp hs₁ hs₂ hβ hβp x
    linarith
  rw [he]
  simpa only [sub_zero] using ((tendsto_const_nhds.sub (ha s₁ hs₁)).sub (ha s₂ hs₂)).div_const p

theorem shifted_arg_difference {r : ℂ} {s : ℝ}
    (hr : 0 < r.im) (hs : 0 < s) :
    (1+(s : ℂ)/r).arg=(r+(s : ℂ)).arg-r.arg := by
  have hrn : r ≠ 0 := by intro h; simp [h] at hr
  have hsn : r+(s : ℂ) ≠ 0 := by
    intro h
    have hh := congrArg Complex.im h
    simp only [Complex.add_im,Complex.ofReal_im,add_zero,Complex.zero_im] at hh
    linarith
  have ha := shifted_arg_bounds hr hs
  have harglt : r.arg < Real.pi := by
    have hslit : r ∈ Complex.slitPlane := Complex.mem_slitPlane_iff.mpr (Or.inr (ne_of_gt hr))
    exact lt_of_le_of_ne (Complex.arg_le_pi r) (Complex.slitPlane_arg_ne_pi hslit)
  have hi : (r⁻¹).arg = -r.arg := by rw [Complex.arg_inv,if_neg (ne_of_lt harglt)]
  have hh := Complex.arg_mul hsn (inv_ne_zero hrn)
    (show (r+(s : ℂ)).arg+(r⁻¹).arg ∈ Ioc (-Real.pi) Real.pi by
      rw [hi]
      constructor <;> linarith [Real.pi_pos])
  have he : 1+(s : ℂ)/r=(r+(s : ℂ))*r⁻¹ := by field_simp <;> ring
  rw [he,hh,hi]
  ring

theorem rayLogAngle_tendsto_atTop {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) :
    Tendsto (fun x => (rayLogPath p s₁ s₂ β x).im) atTop (𝓝 (β/(p+2))) := by
  have hr := rayLogPath_exp_neg_tendsto_zero hp hs₁ hs₂ hβ hβp
  have ha (s : ℝ) :
      Tendsto (fun x => (1+(s : ℂ)*Complex.exp (-rayLogPath p s₁ s₂ β x)).arg) atTop (𝓝 0) := by
    have hslit : (1 : ℂ) ∈ Complex.slitPlane := Complex.mem_slitPlane_iff.mpr (Or.inl (by norm_num))
    have ht : Tendsto (fun x => 1+(s : ℂ)*Complex.exp (-rayLogPath p s₁ s₂ β x)) atTop (𝓝 (1 : ℂ)) :=
      by simpa only [mul_zero,add_zero] using (hr.const_mul (s : ℂ)).const_add 1
    have hh := (Complex.continuousAt_arg hslit).tendsto.comp ht
    simpa only [mul_zero,add_zero,Complex.arg_one] using hh
  have hd (s : ℝ) (hs : 0 < s) (x : ℝ) :
      (1+(s : ℂ)*Complex.exp (-rayLogPath p s₁ s₂ β x)).arg=
      (Complex.exp (rayLogPath p s₁ s₂ β x)+(s : ℂ)).arg-(rayLogPath p s₁ s₂ β x).im := by
    have hz := rayLogPath_mem hp hs₁ hs₂ hβ hβp x
    have he := Complex.log_exp (by linarith [Real.pi_pos,hz.1]) hz.2.le
    have he' : (Complex.exp (rayLogPath p s₁ s₂ β x)).arg=(rayLogPath p s₁ s₂ β x).im :=
      by simpa only [Complex.log_im] using congrArg Complex.im he
    simpa only [Complex.exp_neg,div_eq_mul_inv,he'] using
      shifted_arg_difference (exp_im_pos_of_logRayStrip hz) hs
  have he : (fun x => (rayLogPath p s₁ s₂ β x).im)=
      (fun x => (β-(1+(s₁ : ℂ)*Complex.exp (-rayLogPath p s₁ s₂ β x)).arg-
        (1+(s₂ : ℂ)*Complex.exp (-rayLogPath p s₁ s₂ β x)).arg)/(p+2)) := by
    funext x
    rw [hd s₁ hs₁ x,hd s₂ hs₂ x]
    apply (eq_div_iff (ne_of_gt (show 0 < p+2 by positivity))).2
    have hh := rayLogPath_phase hp hs₁ hs₂ hβ hβp x
    linarith
  rw [he]
  simpa only [sub_zero] using ((tendsto_const_nhds.sub (ha s₁)).sub (ha s₂)).div_const (p+2)

theorem rayInverse_angle_endpoints {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hp1 : p ≤ 1) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) :
    Tendsto (fun x : ℝ =>
      (rayInverse p s₁ s₂ (Complex.exp ((x : ℂ)+(β : ℂ)*Complex.I))).arg)
        atBot (𝓝 (β/p)) ∧
    Tendsto (fun x : ℝ =>
      (rayInverse p s₁ s₂ (Complex.exp ((x : ℂ)+(β : ℂ)*Complex.I))).arg)
        atTop (𝓝 (β/(p+2))) := by
  have he : (fun x : ℝ =>
      (rayInverse p s₁ s₂ (Complex.exp ((x : ℂ)+(β : ℂ)*Complex.I))).arg)=
      (fun x => (rayLogPath p s₁ s₂ β x).im) :=
    funext (rayInverse_angle_on_log_ray hp hp1 hs₁ hs₂ hβ hβp)
  rw [he]
  exact ⟨rayLogAngle_tendsto_atBot hp hs₁ hs₂ hβ hβp,
    rayLogAngle_tendsto_atTop hp hs₁ hs₂ hβ hβp⟩

end LeanVerification.RegionalComplex
