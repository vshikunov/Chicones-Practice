import Mathlib.Data.Complex.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-! The actual grouped complex rational terms in the upper-left ray
elasticity.  The real-part estimate is proved throughout the stated cone;
the imaginary part has a strict sign throughout the first quadrant. -/

noncomputable section
namespace LeanVerification.RegionalComplex

def elasticityGroup (p : ℝ) (z : ℂ) : ℂ :=
  z⁻¹ + ((2 / p : ℝ) : ℂ) * (z⁻¹)^2

theorem elasticityGroup_re (p : ℝ) (z : ℂ) :
    (elasticityGroup p z).re =
      z.re / Complex.normSq z + (2 / p) *
        ((z.re)^2 - (z.im)^2) / (Complex.normSq z)^2 := by
  simp only [elasticityGroup, Complex.add_re, Complex.mul_re,
    Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero,
    pow_two, Complex.inv_re, Complex.inv_im]
  ring

theorem elasticityGroup_im (p : ℝ) (z : ℂ) :
    (elasticityGroup p z).im =
      -z.im / Complex.normSq z - 4 * z.re * z.im / (p * (Complex.normSq z)^2) := by
  simp only [elasticityGroup, Complex.add_im, Complex.mul_im,
    Complex.ofReal_re, Complex.ofReal_im, zero_mul, add_zero,
    pow_two, Complex.inv_re, Complex.inv_im]
  ring

theorem elasticityGroup_im_neg {p : ℝ} {z : ℂ}
    (hp : 0 < p) (ha : 0 < z.re) (hb : 0 < z.im) :
    (elasticityGroup p z).im < 0 := by
  have hz : z ≠ 0 := by intro h; norm_num [h] at ha
  have hd : 0 < Complex.normSq z := Complex.normSq_pos.mpr hz
  rw [elasticityGroup_im]
  have hfirst : 0 < z.im / Complex.normSq z := div_pos hb hd
  have hsecond : 0 < 4*z.re*z.im/(p*(Complex.normSq z)^2) := by positivity
  rw [neg_div]
  linarith

theorem elasticityGroup_numerator_pos {p a b : ℝ}
    (hp : 14/25 ≤ p) (hp2 : p < 2) (ha : 1 ≤ a)
    (hcone : 9*b^2 < 16*a^2) :
    0 < p*a*(a^2+b^2)+2*(a^2-b^2) := by
  have hp0 : 0 < p := by linarith
  have ha0 : 0 < a := by linarith
  have hc : 0 < (2-p)*(16*a^2-9*b^2) := mul_pos (by linarith) (by linarith)
  have hbase : 0 ≤ (25*p-14)*a^2 := mul_nonneg (by linarith) (sq_nonneg a)
  have ham : 0 ≤ a-1 := by linarith
  have hx : 0 ≤ p*(a-1)*(a^2+b^2) := by positivity
  nlinarith only [hc,hbase,hx]

theorem elasticityGroup_re_pos {p : ℝ} {z : ℂ}
    (hp : 14/25 ≤ p) (hp2 : p < 2) (ha : 1 ≤ z.re)
    (hcone : 9*z.im^2 < 16*z.re^2) :
    0 < (elasticityGroup p z).re := by
  have hp0 : 0 < p := by linarith
  have hz : z ≠ 0 := by intro h; norm_num [h] at ha
  have hd : 0 < Complex.normSq z := Complex.normSq_pos.mpr hz
  have hnum := elasticityGroup_numerator_pos hp hp2 ha hcone
  rw [elasticityGroup_re]
  have he : z.re / Complex.normSq z + (2/p)*(z.re^2-z.im^2)/(Complex.normSq z)^2 =
      (p*z.re*(z.re^2+z.im^2)+2*(z.re^2-z.im^2))/(p*(Complex.normSq z)^2) := by
    have hdn : Complex.normSq z ≠ 0 := ne_of_gt hd
    have hpn : p ≠ 0 := ne_of_gt hp0
    have hdv : z.re^2+z.im^2 ≠ 0 := by simpa only [Complex.normSq_apply, ← pow_two] using hdn
    simp only [Complex.normSq_apply, ← pow_two]
    field_simp [hdv,hpn]
    <;> ring
  rw [he]
  exact div_pos hnum (by positivity)

theorem elasticityGroup_signs {p : ℝ} {z : ℂ}
    (hp : 14/25 ≤ p) (hp2 : p < 2) (ha : 1 ≤ z.re)
    (hb : 0 < z.im) (hcone : 9*z.im^2 < 16*z.re^2) :
    0 < (elasticityGroup p z).re ∧ (elasticityGroup p z).im < 0 := by
  exact ⟨elasticityGroup_re_pos hp hp2 ha hcone,
    elasticityGroup_im_neg (by linarith) (by linarith) hb⟩

end LeanVerification.RegionalComplex
