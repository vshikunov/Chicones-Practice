import LeanVerification.RegionalComplex.ElasticityGroup
import LeanVerification.RegionalComplex.RayRoots

/-! The exact partial-fraction identity for the actual normalized
ray elasticity, with the actual roots of its derivative polynomial. -/

noncomputable section
namespace LeanVerification.RegionalComplex

def rayH (p c : ℝ) (r : ℂ) : ℂ :=
  ((p+2 : ℝ) : ℂ)*r^2+((p+1 : ℝ) : ℂ)*r+((p*c : ℝ) : ℂ)

def rayJ (p c : ℝ) (r : ℂ) : ℂ :=
  (p : ℂ)*r^3+((2*c*p-4*c+p+1 : ℝ) : ℂ)*r^2+
    ((3*c*p : ℝ) : ℂ)*r+((2*c^2*p : ℝ) : ℂ)

def rayElasticity (p c : ℝ) (r : ℂ) : ℂ := rayJ p c r/(2*(rayH p c r)^2)

theorem rayH_factorization {p c : ℝ} (hp : 0 < p) (hcq : c ≤ 1/4) (r : ℂ) :
    rayH p c r=((p+2 : ℝ) : ℂ)*(r+(rayRootSmall p c : ℂ))*(r+(rayRootLarge p c : ℂ)) := by
  have hp2 : p+2 ≠ 0 := ne_of_gt (by positivity)
  have hs := rayRoots_sum (c:=c) hp
  have ht := rayRoots_product hp hcq
  have hs' : (p+2)*(rayRootSmall p c+rayRootLarge p c)=p+1 := by
    rw [hs]; field_simp
  have ht' : (p+2)*(rayRootSmall p c*rayRootLarge p c)=p*c := by
    rw [ht]; field_simp
  have hsC : ((p+2 : ℝ) : ℂ)*((rayRootSmall p c : ℂ)+(rayRootLarge p c : ℂ))=((p+1 : ℝ) : ℂ) := by exact_mod_cast hs'
  have htC : ((p+2 : ℝ) : ℂ)*((rayRootSmall p c : ℂ)*(rayRootLarge p c : ℂ))=((p*c : ℝ) : ℂ) := by exact_mod_cast ht'
  unfold rayH
  linear_combination -r*hsC-htC

theorem elasticityGroup_scaled {p h : ℝ} (hh : h ≠ 0) (r : ℂ) :
    elasticityGroup p (1+r/(h : ℂ))=
      (h : ℂ)/(r+(h : ℂ))+((2/p : ℝ) : ℂ)*((h : ℂ)/(r+(h : ℂ)))^2 := by
  unfold elasticityGroup
  have hhC : (h : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hh
  have hi : (1+r/(h : ℂ))⁻¹=(h : ℂ)/(r+(h : ℂ)) := by
    rw [one_add_div hhC,inv_div]
    ring_nf
  rw [hi]

set_option maxHeartbeats 1000000 in
theorem rational_elasticity_decomposition (p c h₁ h₂ r : ℂ)
    (hp : p ≠ 0) (hp2 : p+2 ≠ 0)
    (h₁n : r+h₁ ≠ 0) (h₂n : r+h₂ ≠ 0)
    (hs : h₁+h₂=(p+1)/(p+2)) (ht : h₁*h₂=p*c/(p+2)) :
    2*(h₂-h₁)*(p+1)*(p+2)*
      ((p*r^3+(2*c*p-4*c+p+1)*r^2+3*c*p*r+2*c^2*p)/
        (2*((p+2)*(r+h₁)*(r+h₂))^2)) =
      ((p+2)*h₂-p*h₁)*(h₁/(r+h₁)+(2/p)*(h₁/(r+h₁))^2)+
      (p*h₂-(p+2)*h₁)*(h₂/(r+h₂)+(2/p)*(h₂/(r+h₂))^2) := by
  have hs0 : (p+2)*(h₁+h₂)-(p+1)=0 := by
    rw [hs]
    field_simp
  have ht0 : p*c-(p+2)*h₁*h₂=0 := by
    have hh := (eq_div_iff hp2).mp ht
    linear_combination -hh
  set a := r+h₁
  set b := r+h₂
  set j := p*r^3+(2*c*p-4*c+p+1)*r^2+3*c*p*r+2*c^2*p
  have ha : a ≠ 0 := h₁n
  have hb : b ≠ 0 := h₂n
  have hl : 2*(h₂-h₁)*(p+1)*(p+2)*(j/(2*((p+2)*a*b)^2))=
      (p*(h₂-h₁)*(p+1)*j)/(p*(p+2)*a^2*b^2) := by
    field_simp [hp,hp2,ha,hb]
    <;> ring
  have hr : ((p+2)*h₂-p*h₁)*(h₁/a+(2/p)*(h₁/a)^2)+
      (p*h₂-(p+2)*h₁)*(h₂/b+(2/p)*(h₂/b)^2)=
      ((p+2)*(((p+2)*h₂-p*h₁)*h₁*(p*a+2*h₁)*b^2+
        (p*h₂-(p+2)*h₁)*h₂*(p*b+2*h₂)*a^2))/(p*(p+2)*a^2*b^2) := by
    field_simp [hp,hp2,ha,hb]
    <;> ring
  rw [hl,hr]
  congr 1
  dsimp only [a,b,j]
  linear_combination
    (-(h₁-h₂)*(p+1)*(2*h₁*h₂*p+4*h₁*h₂+2*c*p+2*p*r^2+3*p*r-4*r^2))*ht0+
    (p*r*(h₁-h₂)*(3*h₁*h₂*p+6*h₁*h₂+h₁*p*r+2*h₁*r+h₂*p*r+2*h₂*r+p*r^2+p*r+r))*hs0

theorem rayElasticity_decomposition {p c : ℝ}
    (hp : 0 < p) (hc : 0 < c) (hcq : c ≤ 1/4) {r : ℂ}
    (h₁n : r+(rayRootSmall p c : ℂ) ≠ 0)
    (h₂n : r+(rayRootLarge p c : ℂ) ≠ 0) :
    ((2*(rayRootLarge p c-rayRootSmall p c)*(p+1)*(p+2) : ℝ) : ℂ)*
      rayElasticity p c r =
      (((p+2)*rayRootLarge p c-p*rayRootSmall p c : ℝ) : ℂ)*
        elasticityGroup p (1+r/(rayRootSmall p c : ℂ))+
      ((p*rayRootLarge p c-(p+2)*rayRootSmall p c : ℝ) : ℂ)*
        elasticityGroup p (1+r/(rayRootLarge p c : ℂ)) := by
  have h₁ := ne_of_gt (rayRootSmall_pos hp hc hcq)
  have h₂ := ne_of_gt (rayRootLarge_pos (c:=c) hp)
  have hs : (rayRootSmall p c : ℂ)+(rayRootLarge p c : ℂ)=((p : ℂ)+1)/((p : ℂ)+2) := by
    exact_mod_cast rayRoots_sum (c:=c) hp
  have ht : (rayRootSmall p c : ℂ)*(rayRootLarge p c : ℂ)=(p : ℂ)*(c : ℂ)/((p : ℂ)+2) := by
    exact_mod_cast rayRoots_product hp hcq
  have hh := rational_elasticity_decomposition (p : ℂ) (c : ℂ)
    (rayRootSmall p c : ℂ) (rayRootLarge p c : ℂ) r
    (Complex.ofReal_ne_zero.mpr (ne_of_gt hp))
    (by exact_mod_cast (ne_of_gt (show 0 < p+2 by positivity))) h₁n h₂n hs ht
  rw [elasticityGroup_scaled h₁,elasticityGroup_scaled h₂,rayElasticity,rayH_factorization hp hcq]
  simpa only [rayJ,Complex.ofReal_add,Complex.ofReal_sub,Complex.ofReal_mul,
    Complex.ofReal_div,Complex.ofReal_pow,Complex.ofReal_ofNat] using hh

end LeanVerification.RegionalComplex
