import LeanVerification.RegionalComplex.ComplexUnivalence
import Mathlib.Analysis.SpecialFunctions.Complex.LogDeriv
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Complex.CauchyIntegral

/-! The actual logarithmic lift of r^p(r+s₁)(r+s₂), without an assumed
inverse or univalence hypothesis. -/

noncomputable section
open Set
namespace LeanVerification.RegionalComplex

def logRayStrip : Set ℂ := {z | 0 < z.im ∧ z.im < Real.pi}

def logRayMap (p s₁ s₂ : ℝ) (z : ℂ) : ℂ :=
  (p : ℂ)*z + Complex.log (Complex.exp z + (s₁ : ℂ)) +
    Complex.log (Complex.exp z + (s₂ : ℂ))

def logRayDeriv (p s₁ s₂ : ℝ) (z : ℂ) : ℂ :=
  (p : ℂ) + Complex.exp z/(Complex.exp z+(s₁ : ℂ)) +
    Complex.exp z/(Complex.exp z+(s₂ : ℂ))

theorem logRayStrip_convex : Convex ℝ logRayStrip := by
  exact (convex_Ioo (0 : ℝ) Real.pi).linear_preimage Complex.imCLM.toLinearMap

theorem logRayStrip_open : IsOpen logRayStrip := by
  exact isOpen_Ioo.preimage Complex.continuous_im

theorem exp_im_pos_of_logRayStrip {z : ℂ} (hz : z ∈ logRayStrip) :
    0 < (Complex.exp z).im := by
  rw [Complex.exp_im]
  exact mul_pos (Real.exp_pos _) (Real.sin_pos_of_pos_of_lt_pi hz.1 hz.2)

theorem shifted_exp_slitPlane (s : ℝ) {z : ℂ} (hz : z ∈ logRayStrip) :
    Complex.exp z+(s : ℂ) ∈ Complex.slitPlane := by
  apply Complex.mem_slitPlane_iff.mpr
  right
  simpa only [Complex.add_im,Complex.ofReal_im,add_zero] using
    ne_of_gt (exp_im_pos_of_logRayStrip hz)

theorem hasDerivAt_logRayMap (p s₁ s₂ : ℝ) {z : ℂ} (hz : z ∈ logRayStrip) :
    HasDerivAt (logRayMap p s₁ s₂) (logRayDeriv p s₁ s₂ z) z := by
  simpa only [logRayMap,logRayDeriv,mul_one] using
    (((hasDerivAt_id z).const_mul (p : ℂ)).add
      (((Complex.hasDerivAt_exp z).add_const (s₁ : ℂ)).clog
        (shifted_exp_slitPlane s₁ hz))).add
      (((Complex.hasDerivAt_exp z).add_const (s₂ : ℂ)).clog
        (shifted_exp_slitPlane s₂ hz))

theorem shifted_quotient_im (s : ℝ) (r : ℂ) :
    (r/(r+(s : ℂ))).im = s*r.im/Complex.normSq (r+(s : ℂ)) := by
  simp only [Complex.div_im,Complex.add_im,Complex.add_re,Complex.ofReal_re,
    Complex.ofReal_im,add_zero]
  ring

theorem shifted_quotient_im_pos {s : ℝ} {r : ℂ} (hs : 0 < s) (hr : 0 < r.im) :
    0 < (r/(r+(s : ℂ))).im := by
  have hn : r+(s : ℂ) ≠ 0 := by
    intro h
    have he := congrArg Complex.im h
    simp only [Complex.add_im,Complex.ofReal_im,add_zero,Complex.zero_im] at he
    linarith
  rw [shifted_quotient_im]
  exact div_pos (mul_pos hs hr) (Complex.normSq_pos.mpr hn)

theorem logRayDeriv_im_pos (p : ℝ) {s₁ s₂ : ℝ} (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {z : ℂ} (hz : z ∈ logRayStrip) : 0 < (logRayDeriv p s₁ s₂ z).im := by
  have h₁ := shifted_quotient_im_pos hs₁ (exp_im_pos_of_logRayStrip hz)
  have h₂ := shifted_quotient_im_pos hs₂ (exp_im_pos_of_logRayStrip hz)
  simpa only [logRayDeriv,Complex.add_im,Complex.ofReal_im,zero_add] using add_pos h₁ h₂

theorem logRayMap_injective (p : ℝ) {s₁ s₂ : ℝ} (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) :
    Set.InjOn (logRayMap p s₁ s₂) logRayStrip := by
  exact injectiveOn_of_im_deriv_pos logRayStrip_convex
    (fun z hz => hasDerivAt_logRayMap p s₁ s₂ hz)
    (fun z hz => logRayDeriv_im_pos p hs₁ hs₂ hz)

theorem logRayMap_deriv_ne_zero (p : ℝ) {s₁ s₂ : ℝ}
    (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {z : ℂ} (hz : z ∈ logRayStrip) :
    logRayDeriv p s₁ s₂ z ≠ 0 := by
  intro h
  have hh := logRayDeriv_im_pos p hs₁ hs₂ hz
  simpa only [h,Complex.zero_im,lt_self_iff_false] using hh

theorem logRayMap_analytic (p s₁ s₂ : ℝ) :
    AnalyticOnNhd ℂ (logRayMap p s₁ s₂) logRayStrip := by
  have hh : DifferentiableOn ℂ (logRayMap p s₁ s₂) logRayStrip :=
    fun z hz => (hasDerivAt_logRayMap p s₁ s₂ hz).differentiableAt.differentiableWithinAt
  exact hh.analyticOnNhd logRayStrip_open

end LeanVerification.RegionalComplex
