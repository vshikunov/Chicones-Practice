import LeanVerification.RegionalComplex.RayMotion
import Mathlib.Topology.Order.Compact

/-! Actual radial escape and angular endpoint limits for the selected
inverse ray. No asymptotic expansion or endpoint behavior is assumed. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalComplex

theorem rayLogPath_image {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) (x : ℝ) :
    logRayMap p s₁ s₂ (rayLogPath p s₁ s₂ β x)=(x : ℂ)+(β : ℂ)*Complex.I := by
  apply logRayMap_inverse
  apply logRayMap_covers_target hp hs₁ hs₂
  simpa [logRayTarget] using And.intro hβ hβp

theorem rayLogPath_phase {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) (x : ℝ) :
    β=p*(rayLogPath p s₁ s₂ β x).im+
      (Complex.exp (rayLogPath p s₁ s₂ β x)+(s₁ : ℂ)).arg+
      (Complex.exp (rayLogPath p s₁ s₂ β x)+(s₂ : ℂ)).arg := by
  have he := congrArg Complex.im (rayLogPath_image hp hs₁ hs₂ hβ hβp x)
  simpa [logRayMap,Complex.log_im] using he.symm

theorem rayLogPath_angle_bounds {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) (x : ℝ) :
    β/(p+2)<(rayLogPath p s₁ s₂ β x).im ∧
      (rayLogPath p s₁ s₂ β x).im<β/p := by
  have hz := rayLogPath_mem hp hs₁ hs₂ hβ hβp x
  have he := Complex.log_exp (by linarith [Real.pi_pos,hz.1]) hz.2.le
  have harg : (Complex.exp (rayLogPath p s₁ s₂ β x)).arg=(rayLogPath p s₁ s₂ β x).im :=
    by simpa only [Complex.log_im] using congrArg Complex.im he
  have h₁ := shifted_arg_bounds (exp_im_pos_of_logRayStrip hz) hs₁
  have h₂ := shifted_arg_bounds (exp_im_pos_of_logRayStrip hz) hs₂
  rw [harg] at h₁ h₂
  have hphase := rayLogPath_phase hp hs₁ hs₂ hβ hβp x
  constructor
  · apply (div_lt_iff₀ (by positivity : 0 < p+2)).2
    linarith
  · apply (lt_div_iff₀ hp).2
    linarith

theorem sin_lower_on_compact_angle {a b : ℝ}
    (ha : 0 < a) (hb : b < Real.pi) :
    ∃ m : ℝ, 0 < m ∧ ∀ y ∈ Icc a b, m ≤ Real.sin y := by
  apply isCompact_Icc.exists_forall_le' Real.continuous_sin.continuousOn
  intro y hy
  exact Real.sin_pos_of_pos_of_lt_pi (ha.trans_le hy.1) (hy.2.trans_lt hb)

theorem shifted_log_re_lower_angle {m : ℝ} (hm : 0 < m) (s : ℝ) {z : ℂ}
    (hz : m ≤ Real.sin z.im) :
    z.re+Real.log m ≤ Real.log ‖Complex.exp z+(s : ℂ)‖ := by
  have hh := Complex.im_le_norm (Complex.exp z+(s : ℂ))
  simp only [Complex.add_im,Complex.ofReal_im,add_zero,Complex.exp_im] at hh
  have hl := Real.log_le_log (mul_pos (Real.exp_pos z.re) hm)
    ((mul_le_mul_of_nonneg_left hz (Real.exp_pos _).le).trans hh)
  rwa [Real.log_mul (Real.exp_ne_zero _) (ne_of_gt hm),Real.log_exp] at hl

theorem rayLogPath_re_tendsto_atBot {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) :
    Tendsto (fun x => (rayLogPath p s₁ s₂ β x).re) atBot atBot := by
  have ha : 0 < β/(p+2) := div_pos hβ (by positivity)
  have hb : β/p < Real.pi := (div_lt_iff₀ hp).2 (by nlinarith)
  obtain ⟨m,hm,hml⟩ := sin_lower_on_compact_angle ha hb
  have hl (x : ℝ) : (p+2)*(rayLogPath p s₁ s₂ β x).re+2*Real.log m ≤ x := by
    have hangle := rayLogPath_angle_bounds hp hs₁ hs₂ hβ hβp x
    have hmz := hml _ ⟨hangle.1.le,hangle.2.le⟩
    have h₁ := shifted_log_re_lower_angle hm s₁ hmz
    have h₂ := shifted_log_re_lower_angle hm s₂ hmz
    have he := congrArg Complex.re (rayLogPath_image hp hs₁ hs₂ hβ hβp x)
    rw [logRayMap_re] at he
    simp only [Complex.add_re,Complex.ofReal_re,Complex.mul_re,Complex.ofReal_im,
      Complex.I_re,Complex.I_im,mul_zero,zero_mul,sub_self,add_zero] at he
    linarith
  apply tendsto_atBot.2
  intro a
  filter_upwards [eventually_le_atBot ((p+2)*a+2*Real.log m)] with x hx
  have hh := hl x
  have hp2 : 0 < p+2 := by positivity
  nlinarith

theorem rayLogPath_re_tendsto_atTop {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) :
    Tendsto (fun x => (rayLogPath p s₁ s₂ β x).re) atTop atTop := by
  apply tendsto_atTop.2
  intro a
  let C := p*a+Real.log (Real.exp a+s₁)+Real.log (Real.exp a+s₂)
  filter_upwards [eventually_ge_atTop (C+1)] with x hx
  apply le_of_not_gt
  intro hlt
  have hu (s : ℝ) (hs : 0 < s) :
      Real.log ‖Complex.exp (rayLogPath p s₁ s₂ β x)+(s : ℂ)‖ ≤ Real.log (Real.exp a+s) := by
    have hz := rayLogPath_mem hp hs₁ hs₂ hβ hβp x
    have hn := Complex.slitPlane_ne_zero (shifted_exp_slitPlane s hz)
    apply Real.log_le_log (norm_pos_iff.mpr hn)
    have ht := norm_add_le (Complex.exp (rayLogPath p s₁ s₂ β x)) (s : ℂ)
    rw [Complex.norm_exp,Complex.norm_real,Real.norm_of_nonneg hs.le] at ht
    exact ht.trans (add_le_add_right (Real.exp_le_exp.mpr hlt.le) s)
  have he := congrArg Complex.re (rayLogPath_image hp hs₁ hs₂ hβ hβp x)
  rw [logRayMap_re] at he
  simp only [Complex.add_re,Complex.ofReal_re,Complex.mul_re,Complex.ofReal_im,
    Complex.I_re,Complex.I_im,mul_zero,zero_mul,sub_self,add_zero] at he
  have h₁ := hu s₁ hs₁
  have h₂ := hu s₂ hs₂
  dsimp [C] at hx
  nlinarith

theorem rayLogPath_exp_tendsto_zero {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) :
    Tendsto (fun x => Complex.exp (rayLogPath p s₁ s₂ β x)) atBot (𝓝 0) := by
  apply Complex.tendsto_exp_comap_re_atBot.comp
  exact tendsto_comap_iff.mpr (rayLogPath_re_tendsto_atBot hp hs₁ hs₂ hβ hβp)

theorem rayLogPath_exp_neg_tendsto_zero {p s₁ s₂ β : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    (hβ : 0 < β) (hβp : β < p*Real.pi) :
    Tendsto (fun x => Complex.exp (-rayLogPath p s₁ s₂ β x)) atTop (𝓝 0) := by
  apply Complex.tendsto_exp_comap_re_atBot.comp
  apply tendsto_comap_iff.mpr
  exact tendsto_neg_atTop_atBot.comp (rayLogPath_re_tendsto_atTop hp hs₁ hs₂ hβ hβp)

end LeanVerification.RegionalComplex
