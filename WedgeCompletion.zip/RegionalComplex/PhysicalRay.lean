import LeanVerification.RegionalComplex.NormalizedRay
import LeanVerification.RegionalComplex.RayEndpointAngles

/-! The actual normalized inverse on the physical angle π(1-p). -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalComplex

def physicalRay (p c x : ℝ) : ℂ :=
  Complex.exp (rayLogPath p (rayFactorSmall c) (rayFactorLarge c) (Real.pi*(1-p)) x)

theorem physical_ray_angle_admissible {p : ℝ} (hp : 1/2 < p) (hp1 : p < 1) :
    0 < Real.pi*(1-p) ∧ Real.pi*(1-p) < p*Real.pi := by
  constructor
  · exact mul_pos Real.pi_pos (sub_pos.mpr hp1)
  · nlinarith [Real.pi_pos]

theorem physicalRay_eq_normalizedInverse {p c : ℝ} (hp : 1/2 < p) (hp1 : p < 1) (x : ℝ) :
    physicalRay p c x=normalizedRayInverse p c
      (Complex.exp ((x : ℂ)+((Real.pi*(1-p) : ℝ) : ℂ)*Complex.I)) := by
  have ha := physical_ray_angle_admissible hp hp1
  have hp0 : 0 < p := by linarith
  have he : Complex.log (Complex.exp ((x : ℂ)+((Real.pi*(1-p) : ℝ) : ℂ)*Complex.I))=
      (x : ℂ)+((Real.pi*(1-p) : ℝ) : ℂ)*Complex.I := by
    apply Complex.log_exp <;> simp only [Complex.add_im,Complex.ofReal_im,Complex.mul_im,
      Complex.ofReal_re,Complex.I_re,Complex.I_im,mul_one,zero_mul,add_zero,zero_add]
    · nlinarith [Real.pi_pos]
    · nlinarith [Real.pi_pos]
  simp only [physicalRay,normalizedRayInverse,rayInverse,rayLogPath,he]

theorem physicalRay_mem_upper {p c : ℝ}
    (hp : 1/2 < p) (hp1 : p < 1) (hc : 0 < c) (hcq : c ≤ 1/4) (x : ℝ) :
    0 < (physicalRay p c x).im := by
  have ha := physical_ray_angle_admissible hp hp1
  exact exp_im_pos_of_logRayStrip
    (rayLogPath_mem (by linarith : 0 < p) (rayFactorSmall_pos hc hcq) (rayFactorLarge_pos c) ha.1 ha.2 x)

theorem physicalRay_continuous {p c : ℝ}
    (hp : 1/2 < p) (hp1 : p < 1) (hc : 0 < c) (hcq : c ≤ 1/4) :
    Continuous (physicalRay p c) := by
  have ha := physical_ray_angle_admissible hp hp1
  apply continuous_iff_continuousAt.mpr
  intro x
  exact Complex.continuous_exp.continuousAt.comp
    (hasDerivAt_rayLogPath (by linarith : 0 < p)
      (rayFactorSmall_pos hc hcq) (rayFactorLarge_pos c) ha.1 ha.2 x).continuousAt

theorem physicalRay_tendsto_zero {p c : ℝ}
    (hp : 1/2 < p) (hp1 : p < 1) (hc : 0 < c) (hcq : c ≤ 1/4) :
    Tendsto (physicalRay p c) atBot (𝓝 0) := by
  have ha := physical_ray_angle_admissible hp hp1
  exact rayLogPath_exp_tendsto_zero (by linarith : 0 < p)
    (rayFactorSmall_pos hc hcq) (rayFactorLarge_pos c) ha.1 ha.2

theorem physicalRay_phase {p c : ℝ}
    (hp : 1/2 < p) (hp1 : p < 1) (hc : 0 < c) (hcq : c ≤ 1/4) (x : ℝ) :
    Real.pi*(1-p)=p*(physicalRay p c x).arg+
      ((physicalRay p c x)^2+physicalRay p c x+(c : ℂ)).arg := by
  have hp0 : 0 < p := by linarith
  have ha := physical_ray_angle_admissible hp hp1
  have hsmall := rayFactorSmall_pos hc hcq
  have hlarge := rayFactorLarge_pos c
  have hz := rayLogPath_mem hp0 hsmall hlarge ha.1 ha.2 x
  have hlog := Complex.log_exp (by linarith [Real.pi_pos,hz.1]) hz.2.le
  have harg : (physicalRay p c x).arg=
      (rayLogPath p (rayFactorSmall c) (rayFactorLarge c) (Real.pi*(1-p)) x).im := by
    simpa only [physicalRay,Complex.log_im] using congrArg Complex.im hlog
  have hphase := rayLogPath_phase hp0 hsmall hlarge ha.1 ha.2 x
  change Real.pi*(1-p)=p* _+(physicalRay p c x+(rayFactorSmall c : ℂ)).arg+
    (physicalRay p c x+(rayFactorLarge c : ℂ)).arg at hphase
  rw [←harg] at hphase
  have hargpos := arg_pos_of_im_pos (physicalRay_mem_upper hp hp1 hc hcq x)
  have hshift (s : ℝ) : 0 < (physicalRay p c x+(s : ℂ)).im := by
    simpa using physicalRay_mem_upper hp hp1 hc hcq x
  have h₁ := arg_pos_of_im_pos (hshift (rayFactorSmall c))
  have h₂ := arg_pos_of_im_pos (hshift (rayFactorLarge c))
  have hn (s : ℝ) : physicalRay p c x+(s : ℂ) ≠ 0 := by
    intro he
    have hh := hshift s
    simp [he] at hh
  have hsum : (physicalRay p c x+(rayFactorSmall c : ℂ)).arg+
      (physicalRay p c x+(rayFactorLarge c : ℂ)).arg ∈ Ioc (-Real.pi) Real.pi := by
    have hppos := mul_pos hp0 hargpos
    constructor <;> nlinarith [Real.pi_pos]
  have he := Complex.arg_mul (hn (rayFactorSmall c)) (hn (rayFactorLarge c)) hsum
  rw [rayFactors_complex hcq] at he
  rw [he]
  simpa only [add_assoc] using hphase

theorem physicalRay_shift_arg_continuous {p c h : ℝ}
    (hp : 1/2 < p) (hp1 : p < 1) (hc : 0 < c) (hcq : c ≤ 1/4) :
    Continuous (fun x => (physicalRay p c x+(h : ℂ)).arg) := by
  apply continuous_iff_continuousAt.mpr
  intro x
  have hs : physicalRay p c x+(h : ℂ) ∈ Complex.slitPlane := by
    apply Complex.mem_slitPlane_iff.mpr
    right
    simpa using ne_of_gt (physicalRay_mem_upper hp hp1 hc hcq x)
  have hc' : ContinuousAt (fun y => physicalRay p c y+(h : ℂ)) x :=
    ((physicalRay_continuous hp hp1 hc hcq).add continuous_const).continuousAt
  exact (Complex.continuousAt_arg hs).tendsto.comp hc'

theorem physicalRay_shift_arg_tendsto_zero {p c h : ℝ}
    (hp : 1/2 < p) (hp1 : p < 1) (hc : 0 < c) (hcq : c ≤ 1/4) (hh : 0 < h) :
    Tendsto (fun x => (physicalRay p c x+(h : ℂ)).arg) atBot (𝓝 0) := by
  have he : Tendsto (fun x => physicalRay p c x+(h : ℂ)) atBot (𝓝 (h : ℂ)) := by
    simpa using (physicalRay_tendsto_zero hp hp1 hc hcq).add_const (h : ℂ)
  have hs : (h : ℂ) ∈ Complex.slitPlane := Complex.mem_slitPlane_iff.mpr (Or.inl hh)
  have ha := (Complex.continuousAt_arg hs).tendsto.comp he
  simpa only [Complex.arg_ofReal_of_nonneg hh.le] using ha

end LeanVerification.RegionalComplex
