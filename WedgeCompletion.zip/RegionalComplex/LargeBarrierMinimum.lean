import LeanVerification.RegionalComplex.ArctanMargins

/-! The actual one-variable phase barrier for the sharper cone.
The full positive ray is covered by a derivative sign on each exterior
interval and monotone argument bounds on the short middle interval. -/

noncomputable section
open Set
namespace LeanVerification.RegionalComplex

def largeBarrierZ (v : ℝ) : ℂ := (v : ℂ)-1+(4/3 : ℂ)*(v : ℂ)*Complex.I
def largeBarrierQ (v : ℝ) : ℂ := (3/2 : ℂ)+
  ((21/25 : ℂ)+(28/25 : ℂ)*Complex.I)*(v : ℂ)+
  ((-14/225 : ℂ)+(16/75 : ℂ)*Complex.I)*(v : ℂ)^2
def largeBarrierG (v : ℝ) : ℝ := (14/25)*(largeBarrierZ v).arg+(largeBarrierQ v).arg
def largeBarrierC (v : ℝ) : ℝ := 49700*v^3+76032*v^2+175527*v-349434

theorem largeBarrierZ_parts (v : ℝ) :
    (largeBarrierZ v).re=v-1 ∧ (largeBarrierZ v).im=4*v/3 := by
  constructor <;> simp [largeBarrierZ] <;> ring

theorem largeBarrierQ_parts (v : ℝ) :
    (largeBarrierQ v).re=3/2+(21/25)*v-(14/225)*v^2 ∧
    (largeBarrierQ v).im=(28/25)*v+(16/75)*v^2 := by
  constructor <;> simp [largeBarrierQ,Complex.mul_re,Complex.mul_im,pow_two] <;> ring

theorem largeBarrier_upper {v : ℝ} (hv : 0 < v) :
    0 < (largeBarrierZ v).im ∧ 0 < (largeBarrierQ v).im := by
  rw [(largeBarrierZ_parts v).2,(largeBarrierQ_parts v).2]
  constructor <;> positivity

theorem hasDerivAt_arg_of_im_pos {f : ℝ → ℂ} {f' : ℂ} {x : ℝ}
    (hf : HasDerivAt f f' x) (him : 0 < (f x).im) :
    HasDerivAt (fun t => (f t).arg) (f'/f x).im x := by
  have hs : f x ∈ Complex.slitPlane := Complex.mem_slitPlane_iff.mpr (Or.inr (ne_of_gt him))
  simpa only [Complex.log_im] using hasDerivAt_im_of_complex_real (hf.clog_real hs)

theorem hasDerivAt_largeBarrierZ (v : ℝ) :
    HasDerivAt largeBarrierZ ((1 : ℂ)+(4/3 : ℂ)*Complex.I) v := by
  simpa only [largeBarrierZ,Complex.ofRealCLM_apply,Complex.ofReal_one,mul_one] using
    (Complex.ofRealCLM.hasDerivAt.sub_const 1).add
      ((Complex.ofRealCLM.hasDerivAt.const_mul (4/3 : ℂ)).mul_const Complex.I)

theorem hasDerivAt_largeBarrierQ (v : ℝ) :
    HasDerivAt largeBarrierQ
      (((21/25 : ℂ)+(28/25 : ℂ)*Complex.I)+
        ((-14/225 : ℂ)+(16/75 : ℂ)*Complex.I)*(2*(v : ℂ))) v := by
  have hid : HasDerivAt (fun x : ℝ => (x : ℂ)) (1 : ℂ) v := by
    simpa using Complex.ofRealCLM.hasDerivAt (x:=v)
  have hsq : HasDerivAt (fun x : ℝ => (x : ℂ)^2) (2*(v : ℂ)) v := by
    simpa using (hasDerivAt_pow 2 (v : ℂ)).comp_ofReal
  convert ((hid.const_mul
    ((21/25 : ℂ)+(28/25 : ℂ)*Complex.I)).const_add (3/2 : ℂ)).add
    (hsq.const_mul
      ((-14/225 : ℂ)+(16/75 : ℂ)*Complex.I)) using 1 <;>
      simp only [largeBarrierQ,Complex.ofRealCLM_apply,Complex.ofReal_one,mul_one,pow_one]

theorem hasDerivAt_largeBarrierZ_arg {v : ℝ} (hv : 0 < v) :
    HasDerivAt (fun t => (largeBarrierZ t).arg)
      (-(4/3)/Complex.normSq (largeBarrierZ v)) v := by
  have hh := hasDerivAt_arg_of_im_pos (hasDerivAt_largeBarrierZ v) (largeBarrier_upper hv).1
  convert hh using 1
  rw [Complex.div_im,(largeBarrierZ_parts v).1,(largeBarrierZ_parts v).2]
  norm_num
  ring

theorem hasDerivAt_largeBarrierQ_arg {v : ℝ} (hv : 0 < v) :
    HasDerivAt (fun t => (largeBarrierQ t).arg)
      ((42/25+(16/25)*v+(56/225)*v^2)/Complex.normSq (largeBarrierQ v)) v := by
  have hh := hasDerivAt_arg_of_im_pos (hasDerivAt_largeBarrierQ v) (largeBarrier_upper hv).2
  convert hh using 1
  rw [Complex.div_im,(largeBarrierQ_parts v).1,(largeBarrierQ_parts v).2]
  simp only [Complex.add_im,Complex.mul_im,Complex.add_re,Complex.mul_re,
    Complex.ofReal_im,Complex.ofReal_re,Complex.I_re,Complex.I_im]
  norm_num
  ring

theorem hasDerivAt_largeBarrierG {v : ℝ} (hv : 0 < v) :
    HasDerivAt largeBarrierG
      (2*v*largeBarrierC v/(151875*Complex.normSq (largeBarrierZ v)*Complex.normSq (largeBarrierQ v))) v := by
  have hh := ((hasDerivAt_largeBarrierZ_arg hv).const_mul (14/25 : ℝ)).add
    (hasDerivAt_largeBarrierQ_arg hv)
  convert hh using 1
  have hnZ : largeBarrierZ v ≠ 0 := by intro h; have hh := (largeBarrier_upper hv).1; simp [h] at hh
  have hnQ : largeBarrierQ v ≠ 0 := by intro h; have hh := (largeBarrier_upper hv).2; simp [h] at hh
  have hZ : Complex.normSq (largeBarrierZ v) ≠ 0 := ne_of_gt (Complex.normSq_pos.mpr hnZ)
  have hQ : Complex.normSq (largeBarrierQ v) ≠ 0 := ne_of_gt (Complex.normSq_pos.mpr hnQ)
  field_simp
  simp only [Complex.normSq_apply,(largeBarrierZ_parts v).1,(largeBarrierZ_parts v).2,
    (largeBarrierQ_parts v).1,(largeBarrierQ_parts v).2,largeBarrierC]
  ring

theorem largeBarrierC_strictMono : StrictMonoOn largeBarrierC (Ici 0) := by
  intro x hx y hy hxy
  have hh : 0 < (y-x)*(49700*(y^2+y*x+x^2)+76032*(y+x)+175527) := by
    apply mul_pos (sub_pos.mpr hxy)
    have hx0 : 0 ≤ x := hx
    have hy0 : 0 ≤ y := hy
    positivity
  unfold largeBarrierC
  nlinarith only [hh]

theorem largeBarrierC_neg {v : ℝ} (hv : 0 ≤ v) (hvlo : v ≤ 109/100) :
    largeBarrierC v < 0 := by
  have hh := largeBarrierC_strictMono.monotoneOn hv (show (0 : ℝ) ≤ 109/100 by norm_num) hvlo
  norm_num [largeBarrierC] at hh ⊢
  linarith

theorem largeBarrierC_pos {v : ℝ} (hvhi : 11/10 ≤ v) : 0 < largeBarrierC v := by
  have hv : 0 ≤ v := by linarith
  have hh := largeBarrierC_strictMono.monotoneOn (show (0 : ℝ) ≤ 11/10 by norm_num) hv hvhi
  norm_num [largeBarrierC] at hh ⊢
  linarith

end LeanVerification.RegionalComplex
