import LeanVerification.RegionalComplex.RayMotion
import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-! The inverse constructor instantiated for the actual normalized
upper-left polynomial r²+r+c, 0<c≤1/4. -/

noncomputable section
open Set
namespace LeanVerification.RegionalComplex

def rayFactorSmall (c : ℝ) : ℝ := (1-Real.sqrt (1-4*c))/2
def rayFactorLarge (c : ℝ) : ℝ := (1+Real.sqrt (1-4*c))/2
def normalizedRayInverse (p c : ℝ) : ℂ → ℂ :=
  rayInverse p (rayFactorSmall c) (rayFactorLarge c)

theorem rayFactorSmall_pos {c : ℝ} (hc : 0 < c) (hcq : c ≤ 1/4) :
    0 < rayFactorSmall c := by
  have hd : 0 ≤ 1-4*c := by linarith
  have hs := Real.sq_sqrt hd
  have hsn := Real.sqrt_nonneg (1-4*c)
  have hh : Real.sqrt (1-4*c) < 1 := by nlinarith
  unfold rayFactorSmall
  linarith

theorem rayFactorLarge_pos (c : ℝ) : 0 < rayFactorLarge c := by
  unfold rayFactorLarge
  positivity

theorem rayFactors_sum (c : ℝ) : rayFactorSmall c+rayFactorLarge c=1 := by
  unfold rayFactorSmall rayFactorLarge
  ring

theorem rayFactors_product {c : ℝ} (hcq : c ≤ 1/4) :
    rayFactorSmall c*rayFactorLarge c=c := by
  have hs := Real.sq_sqrt (show 0 ≤ 1-4*c by linarith)
  unfold rayFactorSmall rayFactorLarge
  nlinarith only [hs]

theorem rayFactors_complex {c : ℝ} (hcq : c ≤ 1/4) (r : ℂ) :
    (r+(rayFactorSmall c : ℂ))*(r+(rayFactorLarge c : ℂ))=r^2+r+(c : ℂ) := by
  have hs : (rayFactorSmall c : ℂ)+(rayFactorLarge c : ℂ)=1 := by
    exact_mod_cast rayFactors_sum c
  have hp : (rayFactorSmall c : ℂ)*(rayFactorLarge c : ℂ)=(c : ℂ) := by
    exact_mod_cast rayFactors_product hcq
  calc
    _ = r^2+r*((rayFactorSmall c : ℂ)+(rayFactorLarge c : ℂ))+
      (rayFactorSmall c : ℂ)*(rayFactorLarge c : ℂ) := by ring
    _ = _ := by rw [hs,hp]; ring

theorem normalizedRayInverse_identity {p c : ℝ}
    (hp : 0 < p) (hc : 0 < c) (hcq : c ≤ 1/4) {u : ℂ} (hu : u ∈ raySector p) :
    (normalizedRayInverse p c u)^(p : ℂ)*
      ((normalizedRayInverse p c u)^2+normalizedRayInverse p c u+(c : ℂ))=u := by
  have hh := rayPower_inverse hp (rayFactorSmall_pos hc hcq) (rayFactorLarge_pos c) hu
  simpa only [rayPower,mul_assoc,rayFactors_complex hcq,normalizedRayInverse] using hh

theorem normalizedRayInverse_analytic {p c : ℝ}
    (hp : 0 < p) (hp1 : p ≤ 1) (hc : 0 < c) (hcq : c ≤ 1/4) :
    AnalyticOnNhd ℂ (normalizedRayInverse p c) (raySector p) :=
  fun _ hu => rayInverse_analyticAt hp hp1 (rayFactorSmall_pos hc hcq) (rayFactorLarge_pos c) hu

theorem normalizedRayInverse_angle_bounds {p c : ℝ}
    (hp : 0 < p) (hc : 0 < c) (hcq : c ≤ 1/4) {u : ℂ} (hu : u ∈ raySector p) :
    u.arg/(p+2) < (normalizedRayInverse p c u).arg ∧
      (normalizedRayInverse p c u).arg < u.arg/p :=
  rayInverse_angle_bounds hp (rayFactorSmall_pos hc hcq) (rayFactorLarge_pos c) hu

theorem normalizedRayInverse_angle_strictAnti {p c β : ℝ}
    (hp : 0 < p) (hp1 : p ≤ 1) (hc : 0 < c) (hcq : c ≤ 1/4)
    (hβ : 0 < β) (hβp : β < p*Real.pi) :
    StrictAnti (fun x : ℝ =>
      (normalizedRayInverse p c (Complex.exp ((x : ℂ)+(β : ℂ)*Complex.I))).arg) :=
  rayInverse_angle_strictAnti hp hp1 (rayFactorSmall_pos hc hcq) (rayFactorLarge_pos c) hβ hβp

end LeanVerification.RegionalComplex
