import LeanVerification.RegionalComplex.PhysicalRay
import LeanVerification.RegionalComplex.ElasticityDecomposition

/-! The rational J/(2H²) is identified with the logarithmic derivative
of the actual holomorphic flight-clock factor, on the actual inverse ray. -/

noncomputable section
namespace LeanVerification.RegionalComplex

def raySqrtPolynomial (c : ℝ) (r : ℂ) : ℂ :=
  Complex.exp ((Complex.log (r+(rayFactorSmall c : ℂ))+
    Complex.log (r+(rayFactorLarge c : ℂ)))/2)
def rayClockFactor (p c : ℝ) (r : ℂ) : ℂ := r*raySqrtPolynomial c r/rayH p c r
def physicalRayClock (p c x : ℝ) : ℂ := rayClockFactor p c (physicalRay p c x)

theorem ray_shift_ne_zero (r : ℂ) (hr : 0 < r.im) (s : ℝ) : r+(s : ℂ) ≠ 0 := by
  intro he
  have hi := congrArg Complex.im he
  simp only [Complex.add_im,Complex.ofReal_im,add_zero,Complex.zero_im] at hi
  linarith

theorem ray_polynomial_ne_zero {c : ℝ} (hcq : c ≤ 1/4) {r : ℂ} (hr : 0 < r.im) :
    r^2+r+(c : ℂ) ≠ 0 := by
  rw [←rayFactors_complex hcq]
  exact mul_ne_zero (ray_shift_ne_zero r hr _) (ray_shift_ne_zero r hr _)

theorem raySqrtPolynomial_square {c : ℝ} (hcq : c ≤ 1/4) {r : ℂ} (hr : 0 < r.im) :
    (raySqrtPolynomial c r)^2=r^2+r+(c : ℂ) := by
  calc
    _ = Complex.exp (Complex.log (r+(rayFactorSmall c : ℂ))+
        Complex.log (r+(rayFactorLarge c : ℂ))) := by
      rw [raySqrtPolynomial,pow_two,←Complex.exp_add]
      congr 1
      ring
    _ = (r+(rayFactorSmall c : ℂ))*(r+(rayFactorLarge c : ℂ)) := by
      rw [Complex.exp_add,Complex.exp_log (ray_shift_ne_zero r hr _),
        Complex.exp_log (ray_shift_ne_zero r hr _)]
    _ = _ := rayFactors_complex hcq r

theorem rayH_ne_zero_upper {p c : ℝ} (hp : 0 < p) (hcq : c ≤ 1/4)
    {r : ℂ} (hr : 0 < r.im) : rayH p c r ≠ 0 := by
  rw [rayH_factorization hp hcq]
  exact mul_ne_zero (mul_ne_zero
    (Complex.ofReal_ne_zero.mpr (ne_of_gt (show 0 < p+2 by positivity)))
      (ray_shift_ne_zero r hr _)) (ray_shift_ne_zero r hr _)

theorem factor_reciprocal_sum {c : ℝ} (hcq : c ≤ 1/4) {r : ℂ} (hr : 0 < r.im) :
    1/(r+(rayFactorSmall c : ℂ))+1/(r+(rayFactorLarge c : ℂ))=
      (2*r+1)/(r^2+r+(c : ℂ)) := by
  have hs : (rayFactorSmall c : ℂ)+(rayFactorLarge c : ℂ)=1 := by exact_mod_cast rayFactors_sum c
  rw [div_add_div 1 1 (ray_shift_ne_zero r hr _) (ray_shift_ne_zero r hr _),rayFactors_complex hcq]
  congr 1
  linear_combination hs

theorem normalized_logRayDeriv_identity {p c : ℝ} (hcq : c ≤ 1/4) {z : ℂ}
    (hz : z ∈ logRayStrip) :
    logRayDeriv p (rayFactorSmall c) (rayFactorLarge c) z=
      rayH p c (Complex.exp z)/((Complex.exp z)^2+Complex.exp z+(c : ℂ)) := by
  let r := Complex.exp z
  have hr : 0 < r.im := exp_im_pos_of_logRayStrip hz
  have hn := ray_polynomial_ne_zero hcq hr
  change (p : ℂ)+r/(r+(rayFactorSmall c : ℂ))+r/(r+(rayFactorLarge c : ℂ))= _
  calc
    _ = (p : ℂ)+r*(1/(r+(rayFactorSmall c : ℂ))+1/(r+(rayFactorLarge c : ℂ))) := by ring
    _ = (p : ℂ)+r*((2*r+1)/(r^2+r+(c : ℂ))) := by rw [factor_reciprocal_sum hcq hr]
    _ = rayH p c r/(r^2+r+(c : ℂ)) := by
      unfold rayH
      simp only [Complex.ofReal_add,Complex.ofReal_mul,Complex.ofReal_one,Complex.ofReal_ofNat]
      field_simp
      <;> ring

theorem hasDerivAt_physicalRay {p c : ℝ}
    (hp : 1/2 < p) (hp1 : p < 1) (hc : 0 < c) (hcq : c ≤ 1/4) (x : ℝ) :
    HasDerivAt (physicalRay p c)
      (physicalRay p c x*((physicalRay p c x)^2+physicalRay p c x+(c : ℂ))/
        rayH p c (physicalRay p c x)) x := by
  have hp0 : 0 < p := by linarith
  have ha := physical_ray_angle_admissible hp hp1
  have hz := rayLogPath_mem hp0 (rayFactorSmall_pos hc hcq) (rayFactorLarge_pos c) ha.1 ha.2 x
  have hd := (hasDerivAt_rayLogPath hp0 (rayFactorSmall_pos hc hcq) (rayFactorLarge_pos c) ha.1 ha.2 x).cexp
  rw [normalized_logRayDeriv_identity hcq hz] at hd
  rw [inv_div] at hd
  simpa only [physicalRay,div_eq_mul_inv,mul_assoc] using hd

theorem hasDerivAt_raySqrtPolynomial {c : ℝ} (hcq : c ≤ 1/4) {r : ℂ} (hr : 0 < r.im) :
    HasDerivAt (raySqrtPolynomial c)
      (raySqrtPolynomial c r*(2*r+1)/(2*(r^2+r+(c : ℂ)))) r := by
  have hs (s : ℝ) : r+(s : ℂ) ∈ Complex.slitPlane :=
    Complex.mem_slitPlane_iff.mpr (Or.inr (by simpa using ne_of_gt hr))
  have hd := ((((hasDerivAt_id r).add_const (rayFactorSmall c : ℂ)).clog (hs _)).add
    (((hasDerivAt_id r).add_const (rayFactorLarge c : ℂ)).clog (hs _))).div_const 2
  have he := hd.cexp
  simp only [id_eq] at he
  convert he using 1
  rw [factor_reciprocal_sum hcq hr]
  change raySqrtPolynomial c r*(2*r+1)/(2*(r^2+r+(c : ℂ)))=
    raySqrtPolynomial c r*((2*r+1)/(r^2+r+(c : ℂ))/2)
  rw [div_div,mul_div_assoc,mul_comm (r^2+r+(c : ℂ)) (2 : ℂ)]

theorem hasDerivAt_rayH (p c : ℝ) (r : ℂ) :
    HasDerivAt (rayH p c) (2*((p+2 : ℝ) : ℂ)*r+((p+1 : ℝ) : ℂ)) r := by
  convert ((((hasDerivAt_id r).pow 2).const_mul ((p+2 : ℝ) : ℂ)).add
    ((hasDerivAt_id r).const_mul ((p+1 : ℝ) : ℂ))).add_const ((p*c : ℝ) : ℂ) using 1 <;>
    simp only [rayH,pow_one,mul_one,id_eq] <;> ring

theorem rayJ_logarithmic_identity (p c : ℝ) (r : ℂ) :
    rayJ p c r=(2*(r^2+r+(c : ℂ))+r*(2*r+1))*rayH p c r-
      2*r*(r^2+r+(c : ℂ))*(2*((p+2 : ℝ) : ℂ)*r+((p+1 : ℝ) : ℂ)) := by
  simp only [rayJ,rayH,Complex.ofReal_add,Complex.ofReal_sub,Complex.ofReal_mul,
    Complex.ofReal_pow,Complex.ofReal_one,Complex.ofReal_ofNat]
  ring

set_option maxHeartbeats 600000 in
theorem hasDerivAt_physicalRayClock {p c : ℝ}
    (hp : 1/2 < p) (hp1 : p < 1) (hc : 0 < c) (hcq : c ≤ 1/4) (x : ℝ) :
    HasDerivAt (physicalRayClock p c)
      (physicalRayClock p c x*rayElasticity p c (physicalRay p c x)) x := by
  let r := physicalRay p c x
  have hr : 0 < r.im := physicalRay_mem_upper hp hp1 hc hcq x
  have hH := rayH_ne_zero_upper (by linarith : 0 < p) hcq hr
  have hP := ray_polynomial_ne_zero hcq hr
  have hd := ((hasDerivAt_id r).mul (hasDerivAt_raySqrtPolynomial hcq hr)).div
    (hasDerivAt_rayH p c r) hH
  have hc' := hd.comp x (hasDerivAt_physicalRay hp hp1 hc hcq x)
  have hrdef : physicalRay p c x=r := rfl
  rw [hrdef] at hc'
  simp only [id_eq,one_mul] at hc'
  convert hc' using 1
  change rayClockFactor p c r*rayElasticity p c r= _
  rw [rayClockFactor,rayElasticity,rayJ_logarithmic_identity]
  field_simp [hH,hP]
  <;> ring

theorem physicalRayClock_ne_zero {p c : ℝ}
    (hp : 1/2 < p) (hp1 : p < 1) (hc : 0 < c) (hcq : c ≤ 1/4) (x : ℝ) :
    physicalRayClock p c x ≠ 0 := by
  have hr := physicalRay_mem_upper hp hp1 hc hcq x
  have hrn : physicalRay p c x ≠ 0 := by intro he; simp [he] at hr
  exact div_ne_zero (mul_ne_zero hrn (Complex.exp_ne_zero _))
    (rayH_ne_zero_upper (by linarith : 0 < p) hcq hr)

theorem physicalRayClock_logarithmic_derivative {p c : ℝ}
    (hp : 1/2 < p) (hp1 : p < 1) (hc : 0 < c) (hcq : c ≤ 1/4) (x : ℝ) :
    deriv (physicalRayClock p c) x/physicalRayClock p c x=
      rayElasticity p c (physicalRay p c x) := by
  rw [(hasDerivAt_physicalRayClock hp hp1 hc hcq x).deriv]
  exact mul_div_cancel_left₀ _ (physicalRayClock_ne_zero hp hp1 hc hcq x)

end LeanVerification.RegionalComplex
