import LeanVerification.RegionalComplex.LargeBarrierEstimate
import LeanVerification.RegionalComplex.RayRoots

/-! The phase barrier is increased from its exact reference parameters
to every actual p,h in the larger-coefficient parameter interval. -/

noncomputable section
open Set
namespace LeanVerification.RegionalComplex

def largeConeA (p v : ℝ) : ℂ := ((1/p+v : ℝ) : ℂ)+((4*v/3 : ℝ) : ℂ)*Complex.I
def largeConeB (p v : ℝ) : ℂ := (largeBarrierZ v)^2-(((p+2)/p : ℝ) : ℂ)
def largeConeQ (p h v : ℝ) : ℂ := largeConeA p v+(h : ℂ)*largeConeB p v

theorem largeConeA_parts (p v : ℝ) :
    (largeConeA p v).re=1/p+v ∧ (largeConeA p v).im=4*v/3 := by
  constructor <;> simp [largeConeA]

theorem largeConeB_parts (p v : ℝ) :
    (largeConeB p v).re=(v-1)^2-(4*v/3)^2-(p+2)/p ∧
      (largeConeB p v).im=8*v*(v-1)/3 := by
  constructor <;>
    simp only [largeConeB,Complex.sub_re,Complex.sub_im,Complex.ofReal_re,Complex.ofReal_im,
      sub_zero,pow_two,Complex.mul_re,Complex.mul_im,(largeBarrierZ_parts v).1,(largeBarrierZ_parts v).2] <;> ring

theorem affine_argument_numerator (A B : ℂ) (h : ℝ) :
    (B/(A+(h : ℂ)*B)).im=(B.im*A.re-B.re*A.im)/Complex.normSq (A+(h : ℂ)*B) := by
  rw [Complex.div_im]
  simp only [Complex.add_re,Complex.add_im,Complex.mul_re,Complex.mul_im,
    Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero,add_zero]
  ring

theorem largeConeQ_im (p h v : ℝ) :
    (largeConeQ p h v).im=(4*v/3)*(1-2*h+2*h*v) := by
  simp [largeConeQ,largeConeA,largeConeB,largeBarrierZ,Complex.mul_im,Complex.mul_re,pow_two]
  ring

theorem largeConeQ_im_pos {p h v : ℝ} (hh : 0 ≤ h) (hh2 : h < 1/2) (hv : 0 < v) :
    0 < (largeConeQ p h v).im := by
  rw [largeConeQ_im]
  apply mul_pos (by positivity)
  have hhx : 0 ≤ h*v := mul_nonneg hh hv.le
  linarith

theorem hasDerivAt_largeConeQ_arg {p h v : ℝ}
    (hp : 0 < p) (hh : 0 ≤ h) (hh2 : h < 1/2) (hv : 0 < v) :
    HasDerivAt (fun t => (largeConeQ p t v).arg)
      (((4/3)*v^2*((25/9)*p*v+2)/p)/Complex.normSq (largeConeQ p h v)) h := by
  have hd : HasDerivAt (fun t : ℝ => largeConeQ p t v) (largeConeB p v) h := by
    simpa only [largeConeQ,Complex.ofRealCLM_apply,Complex.ofReal_one,one_mul] using
      (Complex.ofRealCLM.hasDerivAt.mul_const (largeConeB p v)).const_add (largeConeA p v)
  have him := largeConeQ_im_pos (p:=p) hh hh2 hv
  have he := hasDerivAt_arg_of_im_pos hd him
  convert he using 1
  have hpne : p ≠ 0 := ne_of_gt hp
  change _ = (largeConeB p v/(largeConeA p v+(h : ℂ)*largeConeB p v)).im
  rw [affine_argument_numerator,(largeConeA_parts p v).1,(largeConeA_parts p v).2,
    (largeConeB_parts p v).1,(largeConeB_parts p v).2]
  congr 1
  field_simp
  <;> ring

theorem largeConeQ_arg_h_monotone {p v : ℝ} (hp : 0 < p) (hv : 0 < v) :
    MonotoneOn (fun h => (largeConeQ p h v).arg) (Ioo 0 (1/2)) := by
  apply (strictMonoOn_of_deriv_pos (convex_Ioo 0 (1/2)) ?_ ?_).monotoneOn
  · intro h hh
    exact (hasDerivAt_largeConeQ_arg hp hh.1.le hh.2 hv).continuousAt.continuousWithinAt
  · intro h hh
    have hh' := interior_subset hh
    rw [(hasDerivAt_largeConeQ_arg hp hh'.1.le hh'.2 hv).deriv]
    have hne : largeConeQ p h v ≠ 0 := by
      intro he
      have him := largeConeQ_im_pos (p:=p) hh'.1.le hh'.2 hv
      simp [he] at him
    have hn := Complex.normSq_pos.mpr hne
    positivity

theorem largeConeQ_parameter_difference (p q h v : ℝ) (hp : p ≠ 0) (hq : q ≠ 0) :
    largeConeQ p h v=largeConeQ q h v+
      (((1-2*h)*(1/p-1/q) : ℝ) : ℂ) := by
  apply Complex.ext <;>
    simp [largeConeQ,largeConeA,largeConeB,Complex.mul_re,Complex.mul_im]
  field_simp
  <;> ring

theorem largeConeQ_arg_p_monotone {p q h v : ℝ}
    (hq : 0 < q) (hqp : q ≤ p) (hh : 0 ≤ h) (hh2 : h < 1/2) (hv : 0 < v) :
    (largeConeQ q h v).arg ≤ (largeConeQ p h v).arg := by
  have hp : 0 < p := hq.trans_le hqp
  have hi : 1/p ≤ 1/q := one_div_le_one_div_of_le hq hqp
  have hdelta : (1-2*h)*(1/p-1/q) ≤ 0 :=
    mul_nonpos_of_nonneg_of_nonpos (by linarith) (sub_nonpos.mpr hi)
  have harg := (shift_arg_strictAnti (largeConeQ_im_pos (p:=q) hh hh2 hv)).antitone hdelta
  rw [largeConeQ_parameter_difference p q h v (ne_of_gt hp) (ne_of_gt hq)]
  simpa only [Complex.ofReal_zero,add_zero] using harg

theorem largeConeQ_base (v : ℝ) : largeConeQ (14/25) (2/25) v=largeBarrierQ v := by
  apply Complex.ext <;>
    norm_num [largeConeQ,largeConeA,largeConeB,largeBarrierZ,largeBarrierQ,Complex.mul_re,Complex.mul_im,pow_two] <;> ring

theorem largeCone_phase_bound {p h v : ℝ}
    (hp : 14/25 ≤ p) (hh : 2/25 ≤ h) (hh2 : h < 1/2) (hv : 0 < v) :
    (11/25)*Real.pi < p*(largeBarrierZ v).arg+(largeConeQ p h v).arg := by
  have hh0 : 0 < h := by linarith
  have hq₁ := largeConeQ_arg_h_monotone (show (0 : ℝ) < 14/25 by norm_num) hv
    (show (2/25 : ℝ) ∈ Ioo 0 (1/2) by norm_num) ⟨hh0,hh2⟩ hh
  have hq₂ := largeConeQ_arg_p_monotone (show (0 : ℝ) < 14/25 by norm_num) hp hh0.le hh2 hv
  dsimp only at hq₁
  rw [largeConeQ_base] at hq₁
  have hz := arg_pos_of_im_pos (largeBarrier_upper hv).1
  have hpz : (14/25)*(largeBarrierZ v).arg ≤ p*(largeBarrierZ v).arg :=
    mul_le_mul_of_nonneg_right hp hz.le
  have hb := largeBarrierG_strict_physical_bound hv
  unfold largeBarrierG at hb
  linarith

theorem rayRootSmall_large_coefficient {p c : ℝ}
    (hp : 14/25 ≤ p) (hc : 21/100 ≤ c) (hcq : c ≤ 1/4) :
    2/25 < rayRootSmall p c := by
  have hp0 : 0 < p := by linarith
  have hc0 : 0 < c := by linarith
  have hh := rayRootSmall_pos hp0 hc0 hcq
  have he := rayRoots_coefficient_identity hp0 hc0 hcq
  have hep := (eq_div_iff (ne_of_gt hp0)).mp he
  apply lt_of_not_ge
  intro hu
  have ha : rayRootSmall p c-(rayRootSmall p c)^2 ≤ (46/625 : ℝ) := by
    have hprod : 0 ≤ (2/25-rayRootSmall p c)*(1-2/25-rayRootSmall p c) := by
      apply mul_nonneg (by linarith) (by linarith)
    nlinarith only [hprod]
  have hb : rayRootSmall p c-2*(rayRootSmall p c)^2 ≤ (42/625 : ℝ) := by
    have hprod : 0 ≤ (2/25-rayRootSmall p c)*(1-4/25-2*rayRootSmall p c) := by
      apply mul_nonneg (by linarith) (by linarith)
    nlinarith only [hprod]
  have hpa := mul_le_mul_of_nonneg_left ha hp0.le
  have hpc := mul_le_mul_of_nonneg_right hc hp0.le
  nlinarith

end LeanVerification.RegionalComplex
