import LeanVerification.RegionalComplex.ElasticityDecomposition

/-! Strict signs of the actual J/(2H²) elasticity on the sharper cone.
All root and coefficient signs are derived from p,c, including c=1/4. -/

noncomputable section
namespace LeanVerification.RegionalComplex

theorem ray_elasticity_coefficients {p c : ℝ}
    (hp : 0 < p) (hc : 0 < c) (hcq : c ≤ 1/4) :
    0 < 2*(rayRootLarge p c-rayRootSmall p c)*(p+1)*(p+2) ∧
    0 < (p+2)*rayRootLarge p c-p*rayRootSmall p c ∧
    0 ≤ p*rayRootLarge p c-(p+2)*rayRootSmall p c := by
  have h₁ := rayRootSmall_pos hp hc hcq
  have h₂ := rayRootLarge_pos (c:=c) hp
  have hlt := rayRootSmall_lt_large hp hc hcq
  have hdiff : 0 < rayRootLarge p c-rayRootSmall p c := sub_pos.mpr hlt
  have hu := rayRootSmall_upper hp hc hcq
  have hl := rayRootLarge_lower hp hc hcq
  have hu' := (le_div_iff₀ (show 0 < 2*(p+2) by positivity)).mp hu
  refine ⟨by positivity,?_,?_⟩
  · have hh : 0 < p*(rayRootLarge p c-rayRootSmall p c) := mul_pos hp (sub_pos.mpr hlt)
    nlinarith
  · nlinarith

theorem shifted_scaled_cone_signs {p h : ℝ} {r : ℂ}
    (hp : 14/25 ≤ p) (hp2 : p < 2) (hh : 0 < h)
    (hx : 0 ≤ r.re) (hy : 0 < r.im)
    (hcone : 9*r.im^2 < 16*(r.re+h)^2) :
    0 < (elasticityGroup p (1+r/(h : ℂ))).re ∧
      (elasticityGroup p (1+r/(h : ℂ))).im < 0 := by
  apply elasticityGroup_signs hp hp2
  · simp only [Complex.add_re,Complex.one_re,Complex.div_ofReal_re]
    have hh' : 0 ≤ r.re/h := div_nonneg hx hh.le
    linarith
  · simpa only [Complex.add_im,Complex.one_im,Complex.div_ofReal_im,zero_add] using div_pos hy hh
  · simp only [Complex.add_im,Complex.one_im,Complex.div_ofReal_im,zero_add,
      Complex.add_re,Complex.one_re,Complex.div_ofReal_re]
    have he : 1+r.re/h=(r.re+h)/h := by field_simp; ring
    rw [he,div_pow,div_pow,←mul_div_assoc,←mul_div_assoc]
    exact (div_lt_div_iff_of_pos_right (sq_pos_of_pos hh)).2 hcone

theorem rayElasticity_signs_in_sharp_cone {p c : ℝ}
    (hp : 14/25 ≤ p) (hp2 : p < 2) (hc : 0 < c) (hcq : c ≤ 1/4)
    {r : ℂ} (hx : 0 ≤ r.re) (hy : 0 < r.im)
    (hcone : 9*r.im^2 < 16*(r.re+rayRootSmall p c)^2) :
    0 < (rayElasticity p c r).re ∧ (rayElasticity p c r).im < 0 := by
  have hp0 : 0 < p := by linarith
  have hh₁ := rayRootSmall_pos hp0 hc hcq
  have hh₂ := rayRootLarge_pos (c:=c) hp0
  have hlt := rayRootSmall_lt_large hp0 hc hcq
  have hcone₂ : 9*r.im^2 < 16*(r.re+rayRootLarge p c)^2 := by
    nlinarith
  have h₁ := shifted_scaled_cone_signs hp hp2 hh₁ hx hy hcone
  have h₂ := shifted_scaled_cone_signs hp hp2 hh₂ hx hy hcone₂
  have hn (h : ℝ) : r+(h : ℂ) ≠ 0 := by
    intro he
    have hh := congrArg Complex.im he
    simp only [Complex.add_im,Complex.ofReal_im,add_zero,Complex.zero_im] at hh
    linarith
  have he := rayElasticity_decomposition hp0 hc hcq (hn _) (hn _)
  have hre := congrArg Complex.re he
  have him := congrArg Complex.im he
  simp only [Complex.mul_re,Complex.mul_im,Complex.ofReal_re,Complex.ofReal_im,
    zero_mul,sub_zero,add_zero,Complex.add_re,Complex.add_im] at hre him
  obtain ⟨hC,hA,hB⟩ := ray_elasticity_coefficients hp0 hc hcq
  have hAr := mul_pos hA h₁.1
  have hBr := mul_nonneg hB h₂.1.le
  have hAi := mul_neg_of_pos_of_neg hA h₁.2
  have hBi := mul_nonpos_of_nonneg_of_nonpos hB h₂.2.le
  constructor <;> nlinarith

end LeanVerification.RegionalComplex
