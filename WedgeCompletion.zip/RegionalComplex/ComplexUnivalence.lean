import Mathlib.Analysis.Complex.RealDeriv
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-! An elementary univalence criterion used for the actual logarithmic ray map.
It uses a scalar mean-value argument along a straight line segment. -/

noncomputable section
open Set
namespace LeanVerification.RegionalComplex

theorem injectiveOn_of_im_deriv_pos {S : Set ℂ} {f f' : ℂ → ℂ}
    (hS : Convex ℝ S)
    (hd : ∀ z ∈ S, HasDerivAt f (f' z) z)
    (hpos : ∀ z ∈ S, 0 < (f' z).im) : Set.InjOn f S := by
  intro x hx y hy hxy
  by_contra hne
  have hv : y-x ≠ 0 := sub_ne_zero.mpr (Ne.symm hne)
  let v : ℂ := y-x
  let line : ℂ → ℂ := fun w => x+w*v
  let g : ℂ → ℂ := fun w => -Complex.I*((f (line w)-f x)/v)
  have hmem : ∀ t ∈ Icc (0 : ℝ) 1, line t ∈ S := by
    intro t ht
    have hh := hS hx hy (sub_nonneg.mpr ht.2) ht.1 (show (1-t)+t=1 by ring)
    convert hh using 1
    simp only [line,v,Complex.real_smul]
    push_cast
    ring
  have hgd : ∀ t ∈ Icc (0 : ℝ) 1,
      HasDerivAt (fun t : ℝ => (g t).re) (f' (line t)).im t := by
    intro t ht
    have hl : HasDerivAt line v (t : ℂ) := by
      simpa only [line,one_mul] using ((hasDerivAt_id (t : ℂ)).mul_const v).const_add x
    have hh := ((((hd _ (hmem t ht)).comp (t : ℂ) hl).sub_const (f x)).div_const v).const_mul (-Complex.I)
    have he : -Complex.I*(f' (line t)*v/v) = -Complex.I*f' (line t) := by
      dsimp only [v]
      field_simp
    rw [he] at hh
    simpa only [g,Complex.mul_re,Complex.neg_re,Complex.neg_im,
      Complex.I_re,Complex.I_im,neg_zero,zero_mul,neg_mul,one_mul,zero_sub,neg_neg]
      using hh.real_of_complex
  have hc : ContinuousOn (fun t : ℝ => (g t).re) (Icc 0 1) :=
    fun t ht => (hgd t ht).continuousAt.continuousWithinAt
  have hm : StrictMonoOn (fun t : ℝ => (g t).re) (Icc 0 1) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc _ _) hc
    intro t ht
    have ht' : t ∈ Icc (0 : ℝ) 1 := interior_subset ht
    rw [(hgd t ht').deriv]
    exact hpos _ (hmem t ht')
  have hh := hm (show (0 : ℝ) ∈ Icc 0 1 by norm_num)
    (show (1 : ℝ) ∈ Icc 0 1 by norm_num) (by norm_num : (0 : ℝ)<1)
  have hl0 : line 0 = x := by simp [line]
  have hl1 : line 1 = y := by simp [line,v]
  simp only [Complex.ofReal_zero,Complex.ofReal_one,g,hl0,hl1,hxy,sub_self,
    zero_div,mul_zero,Complex.zero_re] at hh
  exact (lt_irrefl (0 : ℝ)) hh

end LeanVerification.RegionalComplex
