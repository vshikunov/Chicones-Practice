import LeanVerification.RegionalComplex.PhysicalNormalization
import LeanVerification.RegionalComplex.PhysicalRayClock

/-! A final actual-clock statement in the original Loud parameters.
This is a pointwise ray estimate; the complete contour application
to the physical period is a separate remaining obligation. -/

noncomputable section
namespace LeanVerification.RegionalComplex

theorem physicalRayClock_logarithmic_signs {p c : ℝ}
    (hp : 14/25 ≤ p) (hpu : p ≤ 2/3) (hc : 21/100 ≤ c) (hcq : c ≤ 1/4)
    (x : ℝ) (hx : 0 ≤ (physicalRay p c x).re) :
    0 < (deriv (physicalRayClock p c) x/physicalRayClock p c x).re ∧
      (deriv (physicalRayClock p c) x/physicalRayClock p c x).im < 0 := by
  rw [physicalRayClock_logarithmic_derivative (by linarith : 1/2 < p)
    (by linarith : p < 1) (by linarith : 0 < c) hcq x]
  exact physicalRayElasticity_signs_right hp hpu hc hcq x hx

theorem loud_physical_ray_clock_logarithmic_signs {D F : ℝ}
    (hF : 32/25 ≤ F) (hFu : F ≤ 4/3) (hD : -F < D) (hDu : D < -1)
    (hc : 21/100 ≤ loudNormalizedRayCoefficient D F) (x : ℝ)
    (hx : 0 ≤ (physicalRay (upperLeftRayP F) (loudNormalizedRayCoefficient D F) x).re) :
    0 < (deriv (physicalRayClock (upperLeftRayP F) (loudNormalizedRayCoefficient D F)) x/
      physicalRayClock (upperLeftRayP F) (loudNormalizedRayCoefficient D F) x).re ∧
    (deriv (physicalRayClock (upperLeftRayP F) (loudNormalizedRayCoefficient D F)) x/
      physicalRayClock (upperLeftRayP F) (loudNormalizedRayCoefficient D F) x).im < 0 := by
  obtain ⟨hp,hpu,hl,hlu⟩ := upperLeftRay_parameters hF hFu hD hDu
  exact physicalRayClock_logarithmic_signs hp hpu hc
    (loudNormalizedRayCoefficient_bounds hF hFu hD hDu).2.le x hx

end LeanVerification.RegionalComplex
