import LeanVerification.RegionalComplex.LogRayReflection

/-! The sector inverse is the analytic continuation of the actual
positive real inverse, not an independently chosen algebraic sheet. -/

noncomputable section
open Set Filter
open scoped Topology ComplexConjugate
namespace LeanVerification.RegionalComplex

def fullLogRayInverse (p s₁ s₂ : ℝ) : ℂ → ℂ :=
  Function.invFunOn (logRayMap p s₁ s₂) fullLogRayStrip

theorem logRayDeriv_full_ne_zero {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {z : ℂ} (hz : z ∈ fullLogRayStrip) : logRayDeriv p s₁ s₂ z ≠ 0 := by
  rcases lt_trichotomy z.im 0 with hneg | hzero | hpos
  · have hc : conj z ∈ logRayStrip := by
      simp only [logRayStrip,mem_setOf_eq,Complex.conj_im]
      constructor <;> linarith [hz.1]
    intro he
    have hh := logRayMap_deriv_ne_zero p hs₁ hs₂ hc
    rw [logRayDeriv_conj,he,map_zero] at hh
    exact hh rfl
  · have he : (z.re : ℂ)=z := by apply Complex.ext <;> simp [hzero]
    rw [←he,logRayDeriv_real]
    apply Complex.ofReal_ne_zero.mpr
    exact ne_of_gt (by positivity)
  · exact logRayMap_deriv_ne_zero p hs₁ hs₂ ⟨hpos,hz.2⟩

theorem logRayMap_full_analytic (p : ℝ) {s₁ s₂ : ℝ}
    (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) :
    AnalyticOnNhd ℂ (logRayMap p s₁ s₂) fullLogRayStrip := by
  have hd : DifferentiableOn ℂ (logRayMap p s₁ s₂) fullLogRayStrip :=
    fun _ hz => (hasDerivAt_logRayMap_full p hs₁ hs₂ hz).differentiableAt.differentiableWithinAt
  exact hd.analyticOnNhd fullLogRayStrip_open

theorem logRayMap_full_strictDeriv (p : ℝ) {s₁ s₂ : ℝ}
    (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {z : ℂ} (hz : z ∈ fullLogRayStrip) :
    HasStrictDerivAt (logRayMap p s₁ s₂) (logRayDeriv p s₁ s₂ z) z := by
  have hh := (logRayMap_full_analytic p hs₁ hs₂ z hz).hasStrictFDerivAt.hasStrictDerivAt
  have he := hh.hasDerivAt.unique (hasDerivAt_logRayMap_full p hs₁ hs₂ hz)
  exact he ▸ hh

theorem logRayMap_full_image_open {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) :
    IsOpen (logRayMap p s₁ s₂ '' fullLogRayStrip) := by
  apply isOpen_iff_mem_nhds.mpr
  rintro _ ⟨z,hz,rfl⟩
  have hh := (logRayMap_full_strictDeriv p hs₁ hs₂ hz).map_nhds_eq
    (logRayDeriv_full_ne_zero hp hs₁ hs₂ hz)
  rw [←hh]
  exact Filter.image_mem_map (fullLogRayStrip_open.mem_nhds hz)

theorem fullLogRayInverse_map {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {z : ℂ} (hz : z ∈ fullLogRayStrip) :
    fullLogRayInverse p s₁ s₂ (logRayMap p s₁ s₂ z)=z :=
  (logRayMap_full_injective hp hs₁ hs₂).leftInvOn_invFunOn hz

theorem fullLogRayInverse_analytic {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) :
    AnalyticOnNhd ℂ (fullLogRayInverse p s₁ s₂)
      (logRayMap p s₁ s₂ '' fullLogRayStrip) := by
  apply DifferentiableOn.analyticOnNhd _ (logRayMap_full_image_open hp hs₁ hs₂)
  intro w hw
  let z := fullLogRayInverse p s₁ s₂ w
  have hz : z ∈ fullLogRayStrip := Function.invFunOn_mem hw
  have hright : logRayMap p s₁ s₂ z=w := Function.invFunOn_eq hw
  have hleft : ∀ᶠ x in 𝓝 z, fullLogRayInverse p s₁ s₂ (logRayMap p s₁ s₂ x)=x := by
    filter_upwards [fullLogRayStrip_open.mem_nhds hz] with x hx
    exact fullLogRayInverse_map hp hs₁ hs₂ hx
  have hh := (logRayMap_full_strictDeriv p hs₁ hs₂ hz).to_local_left_inverse
    (logRayDeriv_full_ne_zero hp hs₁ hs₂ hz) hleft
  rw [hright] at hh
  exact hh.hasDerivAt.differentiableAt.differentiableWithinAt

theorem fullLogRayInverse_eq_upper {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {w : ℂ} (hw : w ∈ logRayMap p s₁ s₂ '' logRayStrip) :
    fullLogRayInverse p s₁ s₂ w=logRayInverse p s₁ s₂ w := by
  have hz := logRayInverse_mem hw
  have hf : logRayInverse p s₁ s₂ w ∈ fullLogRayStrip :=
    ⟨by linarith [Real.pi_pos,hz.1],hz.2⟩
  have he := fullLogRayInverse_map hp hs₁ hs₂ hf
  rwa [logRayMap_inverse hw] at he

def continuedRayInverse (p s₁ s₂ : ℝ) (u : ℂ) : ℂ :=
  Complex.exp (fullLogRayInverse p s₁ s₂ (Complex.log u))

theorem continuedRayInverse_eq_upper {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂)
    {u : ℂ} (hu : u ∈ raySector p) :
    continuedRayInverse p s₁ s₂ u=rayInverse p s₁ s₂ u := by
  unfold continuedRayInverse rayInverse
  rw [fullLogRayInverse_eq_upper hp hs₁ hs₂ (logRayMap_covers_target hp hs₁ hs₂ (log_mem_target hu))]

theorem logRayMap_exp_identity_full (p : ℝ) {s₁ s₂ : ℝ}
    (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {z : ℂ} (hz : z ∈ fullLogRayStrip) :
    Complex.exp (logRayMap p s₁ s₂ z)=rayPower p s₁ s₂ (Complex.exp z) := by
  have h₁ := Complex.slitPlane_ne_zero (shifted_exp_slitPlane_full hs₁ hz)
  have h₂ := Complex.slitPlane_ne_zero (shifted_exp_slitPlane_full hs₂ hz)
  have he := Complex.log_exp hz.1 hz.2.le
  simp only [logRayMap,rayPower,Complex.exp_add,Complex.exp_log h₁,Complex.exp_log h₂,
    Complex.cpow_def_of_ne_zero (Complex.exp_ne_zero z),he,mul_comm (p : ℂ) z]

theorem continuedRayInverse_real_value {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) (x : ℝ) :
    continuedRayInverse p s₁ s₂ (rayPower p s₁ s₂ (Complex.exp (x : ℂ)))=
      Complex.exp (x : ℂ) := by
  have hx : (x : ℂ) ∈ fullLogRayStrip := by simpa [fullLogRayStrip] using Real.pi_pos
  have hi := logRayMap_im_of_im_zero p hs₁ hs₂ (show (x : ℂ).im=0 by rfl)
  rw [←logRayMap_exp_identity_full p hs₁ hs₂ hx,continuedRayInverse,
    Complex.log_exp (by linarith [Real.pi_pos] : -Real.pi < (logRayMap p s₁ s₂ (x : ℂ)).im)
      (by linarith [Real.pi_pos] : (logRayMap p s₁ s₂ (x : ℂ)).im ≤ Real.pi),
    fullLogRayInverse_map hp hs₁ hs₂ hx]

theorem continuedRayInverse_analytic_real {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) (x : ℝ) :
    AnalyticAt ℂ (continuedRayInverse p s₁ s₂)
      (rayPower p s₁ s₂ (Complex.exp (x : ℂ))) := by
  have hx : (x : ℂ) ∈ fullLogRayStrip := by simpa [fullLogRayStrip] using Real.pi_pos
  have hi := logRayMap_im_of_im_zero p hs₁ hs₂ (show (x : ℂ).im=0 by rfl)
  have he : Complex.log (Complex.exp (logRayMap p s₁ s₂ (x : ℂ)))=
      logRayMap p s₁ s₂ (x : ℂ) := Complex.log_exp (by linarith [Real.pi_pos]) (by linarith [Real.pi_pos])
  have hs : Complex.exp (logRayMap p s₁ s₂ (x : ℂ)) ∈ Complex.slitPlane := by
    apply Complex.mem_slitPlane_iff.mpr
    left
    simp only [Complex.exp_re,hi,Real.cos_zero,mul_one]
    positivity
  have hlogOn : DifferentiableOn ℂ Complex.log Complex.slitPlane :=
    fun z hz => (Complex.hasDerivAt_log hz).differentiableAt.differentiableWithinAt
  have hlog := hlogOn.analyticOnNhd Complex.isOpen_slitPlane _ hs
  have hinv := fullLogRayInverse_analytic hp hs₁ hs₂ _ (mem_image_of_mem _ hx)
  rw [←he] at hinv
  rw [←logRayMap_exp_identity_full p hs₁ hs₂ hx]
  exact (Complex.differentiable_exp.analyticAt _).comp (hinv.comp hlog)

end LeanVerification.RegionalComplex
