import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-! The two actual negative roots of the derivative polynomial for
u(r)=r^p(r^2+r+c), throughout the complete coefficient interval. -/

noncomputable section
namespace LeanVerification.RegionalComplex

def rayDiscriminant (p c : ℝ) : ℝ := (p+1)^2-4*p*(p+2)*c
def rayRootSmall (p c : ℝ) : ℝ := ((p+1)-Real.sqrt (rayDiscriminant p c))/(2*(p+2))
def rayRootLarge (p c : ℝ) : ℝ := ((p+1)+Real.sqrt (rayDiscriminant p c))/(2*(p+2))

theorem rayDiscriminant_ge_one {p c : ℝ}
    (hp : 0 < p) (hc : c ≤ 1/4) : 1 ≤ rayDiscriminant p c := by
  have hcc : 0 ≤ 1-4*c := by linarith
  have hh : 0 ≤ p*(p+2)*(1-4*c) := by positivity
  unfold rayDiscriminant
  nlinarith only [hh]

theorem rayDiscriminant_lt_square {p c : ℝ}
    (hp : 0 < p) (hc : 0 < c) : rayDiscriminant p c < (p+1)^2 := by
  have hh : 0 < 4*p*(p+2)*c := by positivity
  unfold rayDiscriminant
  linarith

theorem sqrt_rayDiscriminant_bounds {p c : ℝ}
    (hp : 0 < p) (hc : 0 < c) (hcq : c ≤ 1/4) :
    1 ≤ Real.sqrt (rayDiscriminant p c) ∧
      Real.sqrt (rayDiscriminant p c) < p+1 := by
  have hge := rayDiscriminant_ge_one hp hcq
  have hlt := rayDiscriminant_lt_square hp hc
  have hnon : 0 ≤ rayDiscriminant p c := by linarith
  have hs := Real.sq_sqrt hnon
  have hsn := Real.sqrt_nonneg (rayDiscriminant p c)
  constructor <;> nlinarith

theorem rayRootSmall_pos {p c : ℝ}
    (hp : 0 < p) (hc : 0 < c) (hcq : c ≤ 1/4) : 0 < rayRootSmall p c := by
  have hs := (sqrt_rayDiscriminant_bounds hp hc hcq).2
  exact div_pos (sub_pos.mpr hs) (by positivity)

theorem rayRootLarge_pos {p c : ℝ}
    (hp : 0 < p) : 0 < rayRootLarge p c := by
  unfold rayRootLarge
  positivity

theorem rayRootSmall_lt_large {p c : ℝ}
    (hp : 0 < p) (hc : 0 < c) (hcq : c ≤ 1/4) :
    rayRootSmall p c < rayRootLarge p c := by
  have hs := (sqrt_rayDiscriminant_bounds hp hc hcq).1
  unfold rayRootSmall rayRootLarge
  apply (div_lt_div_iff_of_pos_right (by positivity : 0 < 2*(p+2))).2
  linarith

theorem rayRootSmall_upper {p c : ℝ}
    (hp : 0 < p) (hc : 0 < c) (hcq : c ≤ 1/4) :
    rayRootSmall p c ≤ p/(2*(p+2)) := by
  have hs := (sqrt_rayDiscriminant_bounds hp hc hcq).1
  unfold rayRootSmall
  apply (div_le_div_iff_of_pos_right (by positivity : 0 < 2*(p+2))).2
  linarith

theorem rayRootLarge_lower {p c : ℝ}
    (hp : 0 < p) (hc : 0 < c) (hcq : c ≤ 1/4) :
    1/2 ≤ rayRootLarge p c := by
  have hs := (sqrt_rayDiscriminant_bounds hp hc hcq).1
  unfold rayRootLarge
  apply (le_div_iff₀ (by positivity : 0 < 2*(p+2))).2
  linarith

theorem rayRoots_sum {p c : ℝ} (hp : 0 < p) :
    rayRootSmall p c + rayRootLarge p c = (p+1)/(p+2) := by
  have hp2 : p+2 ≠ 0 := ne_of_gt (by positivity)
  unfold rayRootSmall rayRootLarge
  field_simp
  <;> ring

theorem rayRoots_product {p c : ℝ}
    (hp : 0 < p) (hcq : c ≤ 1/4) :
    rayRootSmall p c * rayRootLarge p c = p*c/(p+2) := by
  have hd : 0 ≤ rayDiscriminant p c := le_trans (by norm_num) (rayDiscriminant_ge_one hp hcq)
  have hs := Real.sq_sqrt hd
  have hp2 : p+2 ≠ 0 := ne_of_gt (by positivity)
  unfold rayRootSmall rayRootLarge
  unfold rayDiscriminant at *
  field_simp
  linear_combination -(p+2)*hs

theorem rayRoots_coefficient_identity {p c : ℝ}
    (hp : 0 < p) (hc : 0 < c) (hcq : c ≤ 1/4) :
    c = rayRootSmall p c * ((p+1)-(p+2)*rayRootSmall p c)/p := by
  have hs := rayRoots_sum (c:=c) hp
  have hpr := rayRoots_product hp hcq
  have hp2 : p+2 ≠ 0 := ne_of_gt (by positivity)
  have hpn : p ≠ 0 := ne_of_gt hp
  field_simp at hs hpr ⊢
  linear_combination rayRootSmall p c * hs - hpr

end LeanVerification.RegionalComplex
