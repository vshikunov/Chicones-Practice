import LeanVerification.RegionalComplex.RayInverse

/-! The actual phase equation and strict angular bounds on the constructed branch. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalComplex

theorem hasDerivAt_im_of_complex_real {f : ℝ → ℂ} {d : ℂ} {x : ℝ}
    (hf : HasDerivAt f d x) : HasDerivAt (fun t => (f t).im) d.im x := by
  simpa using Complex.imCLM.hasFDerivAt.comp_hasDerivAt x hf

theorem arg_pos_of_im_pos {r : ℂ} (hr : 0 < r.im) : 0 < r.arg := by
  have hn : 0 ≤ r.arg := Complex.arg_nonneg_iff.mpr hr.le
  have hne : r.arg ≠ 0 := by
    intro h
    have he := (Complex.arg_eq_zero_iff.mp h).2
    linarith
  exact lt_of_le_of_ne hn (Ne.symm hne)

theorem hasDerivAt_shift_arg {r : ℂ} (hr : 0 < r.im) (x : ℝ) :
    HasDerivAt (fun t : ℝ => (r+(t : ℂ)).arg)
      (-r.im/Complex.normSq (r+(x : ℂ))) x := by
  have hs : r+(x : ℂ) ∈ Complex.slitPlane := Complex.mem_slitPlane_iff.mpr
    (Or.inr (by simpa using ne_of_gt hr))
  have hh := ((Complex.ofRealCLM.hasDerivAt).const_add r).clog_real hs
  have hi := hasDerivAt_im_of_complex_real hh
  simpa only [Complex.ofRealCLM_apply,Complex.ofReal_one,one_div,Complex.log_im,
    Complex.inv_im,Complex.add_im,Complex.ofReal_im,add_zero] using hi

theorem shift_arg_strictAnti {r : ℂ} (hr : 0 < r.im) :
    StrictAnti (fun x : ℝ => (r+(x : ℂ)).arg) := by
  apply strictAnti_of_deriv_neg
  intro x
  rw [(hasDerivAt_shift_arg hr x).deriv]
  have hn : r+(x : ℂ) ≠ 0 := by
    intro h
    have he := congrArg Complex.im h
    simp only [Complex.add_im,Complex.ofReal_im,add_zero,Complex.zero_im] at he
    linarith
  exact div_neg_of_neg_of_pos (neg_neg_of_pos hr) (Complex.normSq_pos.mpr hn)

theorem shifted_arg_bounds {r : ℂ} {s : ℝ} (hr : 0 < r.im) (hs : 0 < s) :
    0 < (r+(s : ℂ)).arg ∧ (r+(s : ℂ)).arg < r.arg := by
  refine ⟨arg_pos_of_im_pos (by simpa using hr),?_⟩
  simpa using shift_arg_strictAnti hr hs

theorem rayInverse_phase_equation {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {u : ℂ} (hu : u ∈ raySector p) :
    u.arg = p*(rayInverse p s₁ s₂ u).arg +
      (rayInverse p s₁ s₂ u+(s₁ : ℂ)).arg +
      (rayInverse p s₁ s₂ u+(s₂ : ℂ)).arg := by
  have himage := logRayMap_covers_target hp hs₁ hs₂ (log_mem_target hu)
  have he := congrArg Complex.im (logRayMap_inverse himage)
  simp only [logRayMap,Complex.add_im,Complex.mul_im,Complex.ofReal_re,
    Complex.ofReal_im,zero_mul,add_zero,Complex.log_im] at he
  rw [rayInverse_argument hp hs₁ hs₂ hu]
  exact he.symm

theorem rayInverse_angle_bounds {p s₁ s₂ : ℝ}
    (hp : 0 < p) (hs₁ : 0 < s₁) (hs₂ : 0 < s₂) {u : ℂ} (hu : u ∈ raySector p) :
    u.arg/(p+2) < (rayInverse p s₁ s₂ u).arg ∧
      (rayInverse p s₁ s₂ u).arg < u.arg/p := by
  have hr := rayInverse_im_pos hp hs₁ hs₂ hu
  have h₁ := shifted_arg_bounds hr hs₁
  have h₂ := shifted_arg_bounds hr hs₂
  have he := rayInverse_phase_equation hp hs₁ hs₂ hu
  constructor
  · apply (div_lt_iff₀ (by positivity : 0 < p+2)).2
    linarith
  · apply (lt_div_iff₀ hp).2
    linarith

end LeanVerification.RegionalComplex
