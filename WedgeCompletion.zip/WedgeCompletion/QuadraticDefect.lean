import LeanVerification.WedgeCompletion.QuadraticRootRepresentation
import LeanVerification.WedgeCompletion.QuadraticMomentComparison

noncomputable section
open MeasureTheory Set Filter Metric
open scoped Topology

namespace LeanVerification.WedgeCompletion

set_option maxHeartbeats 1000000
set_option maxRecDepth 4000

def quadraticDefect (u v σ:ℝ) (z:ℂ) : ℂ :=
  quadraticRoot u v z-1-z*deriv (quadraticRoot u v) z/(σ:ℂ)

def quadraticDefectKernel (σ:ℝ) (z:ℂ) (t:ℝ) : ℂ :=
  z*(z+((1-σ⁻¹)*t:ℝ))/(z+(t:ℂ))^2

theorem quadraticDefectKernel_split (σ:ℝ) {z:ℂ} {t:ℝ}
    (ht:0<t) (hz:z∈Complex.slitPlane) :
    quadraticDefectKernel σ z t=
      (((1-σ⁻¹:ℝ):ℂ)*z)*(z+(t:ℂ))⁻¹+
        (z^2/(σ:ℂ))*(z+(t:ℂ))⁻¹^2 := by
  have hn := Complex.slitPlane_ne_zero (Cauchy.slitPlane_add_nonnegative hz ht.le)
  unfold quadraticDefectKernel
  simp only [Complex.ofReal_mul,Complex.ofReal_sub,Complex.ofReal_one,Complex.ofReal_inv,
    div_eq_mul_inv]
  rw [←inv_pow]
  linear_combination z*(1-(σ:ℂ)⁻¹)*(z+(t:ℂ))⁻¹*(mul_inv_cancel₀ hn)

theorem quadraticDefectKernel_integrable {u v σ:ℝ} {z:ℂ}
    (hu:0<u) (huv:u≤v) (hz:z∈Complex.slitPlane) :
    Integrable (fun t:ℝ=>(quadraticResolventWeight u v t:ℂ)*quadraticDefectKernel σ z t)
      (quadraticSpectralMeasure u v) := by
  have hi1 := (quadraticResolventWeight_kernel_integrable hu huv hz 1).const_mul
    (((1-σ⁻¹:ℝ):ℂ)*z)
  have hi2 := (quadraticResolventWeight_kernel_integrable hu huv hz 2).const_mul (z^2/(σ:ℂ))
  apply (hi1.add hi2).congr
  filter_upwards [quadraticSpectralMeasure_support huv] with t ht
  rw [quadraticDefectKernel_split σ (lt_of_lt_of_le hu ht.1) hz]
  simp only [pow_one,Pi.add_apply]
  ring

theorem quadraticDefect_cauchy_representation {u v σ:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (huv:u≤v) (hp:u*v=1) (hz:z∈Complex.slitPlane) :
    quadraticDefect u v σ z=(((1-σ⁻¹:ℝ):ℂ)*z)+
      ∫t,(quadraticResolventWeight u v t:ℂ)*quadraticDefectKernel σ z t
        ∂quadraticSpectralMeasure u v := by
  have hi1 := (quadraticResolventWeight_kernel_integrable hu huv hz 1).const_mul
    (((1-σ⁻¹:ℝ):ℂ)*z)
  have hi2 := (quadraticResolventWeight_kernel_integrable hu huv hz 2).const_mul (z^2/(σ:ℂ))
  have he : (fun t:ℝ=>(quadraticResolventWeight u v t:ℂ)*quadraticDefectKernel σ z t)
      =ᵐ[quadraticSpectralMeasure u v]
      (fun t:ℝ=>(((1-σ⁻¹:ℝ):ℂ)*z)*((quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹)+
        (z^2/(σ:ℂ))*((quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹^2)) := by
    filter_upwards [quadraticSpectralMeasure_support huv] with t ht
    rw [quadraticDefectKernel_split σ (lt_of_lt_of_le hu ht.1) hz]
    ring
  simp only [pow_one] at hi1
  have hs := integral_add hi1 hi2
  simp only [Pi.add_apply] at hs
  rw [integral_congr_ae he,hs,integral_const_mul,integral_const_mul,
    quadraticDefect,(quadraticRoot_hasDerivAt_cauchy hu hv huv hp hz).deriv,
    quadraticRoot_cauchy_representation hu hv huv hp hz]
  simp only [Complex.ofReal_sub,Complex.ofReal_one,Complex.ofReal_inv,div_eq_mul_inv]
  ring

theorem quadraticDefect_inverse_cauchy {u v σ:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (huv:u≤v) (hz:z∈Complex.slitPlane) :
    quadraticDefect u v σ z/(quadraticRoot u v z)^2=
      (quadraticRoot u v z)⁻¹-((quadraticRoot u v z)⁻¹)^2-
        (z/(σ:ℂ))*(∫t,(z+(t:ℂ))⁻¹^2∂quadraticSpectralMeasure u v) := by
  have hd1 := ((quadraticRoot_analytic hu hv z hz).differentiableAt.hasDerivAt).inv
    (quadraticRoot_ne_zero u v z)
  have hd2 := quadraticSpectralMeasure_cauchy_derivative hu hv huv hz
  have he := hd1.unique hd2
  have he' : deriv (quadraticRoot u v) z/(quadraticRoot u v z)^2=
      (∫t,(z+(t:ℂ))⁻¹^2∂quadraticSpectralMeasure u v) := by
    simpa only [neg_div,neg_inj] using he
  rw [←he',quadraticDefect]
  simp only [div_eq_mul_inv,inv_pow]
  linear_combination (quadraticRoot u v z)⁻¹*(mul_inv_cancel₀ (quadraticRoot_ne_zero u v z))

theorem quadraticDefect_re_nonneg_half {u v σ:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (huv:u≤v) (hp:u*v=1)
    (hκ:1/2≤1-σ⁻¹) (hz:0≤z.re) (hzs:z∈Complex.slitPlane) :
    0≤(quadraticDefect u v σ z).re := by
  rw [quadraticDefect_cauchy_representation hu hv huv hp hzs,Complex.add_re]
  have hi := quadraticDefectKernel_integrable (σ:=σ) hu huv hzs
  have he := integral_re hi
  change (∫t,((quadraticResolventWeight u v t:ℂ)*quadraticDefectKernel σ z t).re
    ∂quadraticSpectralMeasure u v)=
    (∫t,(quadraticResolventWeight u v t:ℂ)*quadraticDefectKernel σ z t
      ∂quadraticSpectralMeasure u v).re at he
  rw [←he]
  apply add_nonneg
  · simp only [Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero]
    exact mul_nonneg (by linarith) hz
  · apply integral_nonneg_of_ae
    filter_upwards [quadraticSpectralMeasure_support huv] with t ht
    simp only [Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero]
    exact mul_nonneg (quadraticResolventWeight_nonneg hu hp ht)
      (resolvent_kernel_real_nonneg_half hκ (lt_of_lt_of_le hu ht.1) hz)

theorem quadraticDefect_re_nonneg_sector {u v σ:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (huv:u≤v) (hp:u*v=1)
    (hκ:1/3≤1-σ⁻¹) (hκ':1-σ⁻¹≤1/2) (hz:0≤z.re) (hy:z.im^2≤3*z.re^2)
    (hzs:z∈Complex.slitPlane) : 0≤(quadraticDefect u v σ z).re := by
  rw [quadraticDefect_cauchy_representation hu hv huv hp hzs,Complex.add_re]
  have hi := quadraticDefectKernel_integrable (σ:=σ) hu huv hzs
  have he := integral_re hi
  change (∫t,((quadraticResolventWeight u v t:ℂ)*quadraticDefectKernel σ z t).re
    ∂quadraticSpectralMeasure u v)=
    (∫t,(quadraticResolventWeight u v t:ℂ)*quadraticDefectKernel σ z t
      ∂quadraticSpectralMeasure u v).re at he
  rw [←he]
  apply add_nonneg
  · simp only [Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero]
    exact mul_nonneg (by linarith) hz
  · apply integral_nonneg_of_ae
    filter_upwards [quadraticSpectralMeasure_support huv] with t ht
    simp only [Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero]
    exact mul_nonneg (quadraticResolventWeight_nonneg hu hp ht)
      (resolvent_kernel_real_nonneg_sector hκ hκ' (lt_of_lt_of_le hu ht.1) hz hy)

end LeanVerification.WedgeCompletion
