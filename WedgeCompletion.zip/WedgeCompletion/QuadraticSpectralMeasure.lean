import LeanVerification.WedgeCompletion.QuadraticStieltjes

noncomputable section
open MeasureTheory Set Filter Metric
open scoped Topology

namespace LeanVerification.WedgeCompletion
open ContourCompletion

set_option maxHeartbeats 1000000
set_option maxRecDepth 4000

def quadraticBetaWeight (s:ℝ) : ℝ := fractionalWeight (1/2) s / fractionalMass (1/2)

def quadraticBetaMeasure : Measure ℝ :=
  (volume.restrict (Ioi 0)).withDensity (fun s=>ENNReal.ofReal (quadraticBetaWeight s))

def quadraticSpectralMeasure (u v:ℝ) : Measure ℝ :=
  Measure.map (quadraticSpectralPoint u v) quadraticBetaMeasure

theorem quadraticBetaWeight_measurable : Measurable quadraticBetaWeight :=
  (fractionalWeight_measurable (1/2)).div_const _

theorem quadraticBetaWeight_integrable : IntegrableOn quadraticBetaWeight (Ioi 0) :=
  (fractionalWeight_integrable (by norm_num : (0:ℝ)<1/2)
    (by norm_num : (1/2:ℝ)<1)).div_const _

theorem quadraticBetaWeight_pos {s:ℝ} (hs:0<s) : 0<quadraticBetaWeight s := by
  apply div_pos _ (fractionalMass_pos (by norm_num) (by norm_num))
  unfold fractionalWeight
  exact div_pos (Real.rpow_pos_of_pos hs _) (by linarith)

theorem quadraticBetaWeight_integral : (∫s in Ioi (0:ℝ),quadraticBetaWeight s)=1 := by
  unfold quadraticBetaWeight
  rw [integral_div]
  exact div_self (fractionalMass_pos (by norm_num : (0:ℝ)<1/2)
    (by norm_num : (1/2:ℝ)<1)).ne'

instance quadraticBetaMeasure_probability : IsProbabilityMeasure quadraticBetaMeasure := by
  constructor
  rw [quadraticBetaMeasure,withDensity_apply _ MeasurableSet.univ,setLIntegral_univ,
    ←ofReal_integral_eq_lintegral_ofReal quadraticBetaWeight_integrable]
  · rw [quadraticBetaWeight_integral,ENNReal.ofReal_one]
  · filter_upwards [ae_restrict_mem measurableSet_Ioi] with s hs
    exact (quadraticBetaWeight_pos hs).le

theorem quadraticBetaMeasure_pos_ae : ∀ᵐ s∂quadraticBetaMeasure,0<s := by
  apply (withDensity_absolutelyContinuous _ _).ae_le
  exact ae_restrict_mem measurableSet_Ioi

theorem quadraticSpectralPoint_measurable (u v:ℝ) : Measurable (quadraticSpectralPoint u v) := by
  unfold quadraticSpectralPoint
  fun_prop

instance quadraticSpectralMeasure_probability (u v:ℝ) :
    IsProbabilityMeasure (quadraticSpectralMeasure u v) :=
  isProbabilityMeasure_map (quadraticSpectralPoint_measurable u v).aemeasurable

theorem quadraticSpectralMeasure_support {u v:ℝ} (huv:u≤v) :
    ∀ᵐ t∂quadraticSpectralMeasure u v,t∈Icc u v := by
  apply (ae_map_iff (quadraticSpectralPoint_measurable u v).aemeasurable measurableSet_Icc).2
  filter_upwards [quadraticBetaMeasure_pos_ae] with s hs
  exact quadraticSpectralPoint_mem huv hs

/-- Every continuous spectral integrand on the actual compact support is
absolutely integrable; the measurability premise concerns only its values
outside that support. -/
theorem quadraticSpectralMeasure_integrable_continuous
    {E:Type*} [NormedAddCommGroup E] {u v:ℝ} {f:ℝ→E} (huv:u≤v)
    (hf:AEStronglyMeasurable f (quadraticSpectralMeasure u v))
    (hc:ContinuousOn f (Icc u v)) : Integrable f (quadraticSpectralMeasure u v) := by
  obtain ⟨C,hC⟩ := isCompact_Icc.bddAbove_image hc.norm
  apply (integrable_const C).mono' hf
  filter_upwards [quadraticSpectralMeasure_support huv] with t ht
  exact hC (mem_image_of_mem (fun t=>‖f t‖) ht)

theorem quadraticSpectralMeasure_integral {u v:ℝ} {f:ℝ→ℂ} (hf:Measurable f) :
    (∫t,f t∂quadraticSpectralMeasure u v)=
      (fractionalMass (1/2):ℂ)⁻¹ *
        ∫s in Ioi (0:ℝ),(fractionalWeight (1/2) s:ℂ)*f (quadraticSpectralPoint u v s) := by
  rw [quadraticSpectralMeasure,integral_map
    (quadraticSpectralPoint_measurable u v).aemeasurable hf.aestronglyMeasurable,
    quadraticBetaMeasure,integral_withDensity_eq_integral_toReal_smul
      quadraticBetaWeight_measurable.ennreal_ofReal
      (Eventually.of_forall fun _=>ENNReal.ofReal_lt_top),←integral_const_mul]
  apply setIntegral_congr_fun measurableSet_Ioi
  intro s hs
  dsimp only
  rw [ENNReal.toReal_ofReal (quadraticBetaWeight_pos hs).le,quadraticBetaWeight]
  simp only [Complex.real_smul,Complex.ofReal_div,div_eq_mul_inv]
  push_cast
  ring

theorem quadraticSpectralMeasure_stieltjes {u v:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (hz:0≤z.re) :
    (∫t,(z+(t:ℂ))⁻¹∂quadraticSpectralMeasure u v)=(quadraticRoot u v z)⁻¹ := by
  rw [quadraticSpectralMeasure_integral (by fun_prop)]
  convert quadraticStieltjes_eq_inverse hu hv hz using 1

theorem quadraticSpectralMeasure_kernel_integrable {u v:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (hz:0≤z.re) :
    Integrable (fun t:ℝ=>(z+(t:ℂ))⁻¹) (quadraticSpectralMeasure u v) := by
  rw [quadraticSpectralMeasure]
  apply (integrable_map_measure
    (show Measurable (fun t:ℝ=>(z+(t:ℂ))⁻¹) by fun_prop).aestronglyMeasurable
    (quadraticSpectralPoint_measurable u v).aemeasurable).2
  rw [quadraticBetaMeasure,integrable_withDensity_iff_integrable_smul'
    quadraticBetaWeight_measurable.ennreal_ofReal
    (Eventually.of_forall fun _=>ENNReal.ofReal_lt_top)]
  apply ((quadratic_kernel_integrable hu hv hz).const_mul (fractionalMass (1/2):ℂ)⁻¹).congr
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with s hs
  rw [ENNReal.toReal_ofReal (quadraticBetaWeight_pos hs).le,quadraticBetaWeight]
  simp only [Function.comp_apply,Complex.real_smul,Complex.ofReal_div,div_eq_mul_inv]
  push_cast
  ring

theorem quadraticRoot_zero {u v:ℝ} (hu:0<u) (hv:0<v) (huv:u*v=1) :
    quadraticRoot u v 0=1 := by
  have hs := quadraticRoot_square hu hv (show 0≤(0:ℂ).re by norm_num)
  have he : quadraticRoot u v 0^2=1 := by
    simpa only [zero_add,←Complex.ofReal_mul,huv,Complex.ofReal_one] using hs
  have hf : (quadraticRoot u v 0-1)*(quadraticRoot u v 0+1)=0 := by
    linear_combination he
  rcases mul_eq_zero.mp hf with h | h
  · exact sub_eq_zero.mp h
  · have hr := quadraticRoot_re_pos hu hv (show 0≤(0:ℂ).re by norm_num)
    have hi := congrArg Complex.re h
    simp only [Complex.add_re,Complex.one_re,Complex.zero_re] at hi
    linarith

/-- The inverse first moment is proved from the actual transform at zero. -/
theorem quadraticSpectralMeasure_inverse_moment {u v:ℝ}
    (hu:0<u) (hv:0<v) (huv:u*v=1) :
    (∫t,t⁻¹∂quadraticSpectralMeasure u v)=1 := by
  have he := quadraticSpectralMeasure_stieltjes hu hv (show 0≤(0:ℂ).re by norm_num)
  rw [quadraticRoot_zero hu hv huv,inv_one] at he
  have heq : ((∫t,t⁻¹∂quadraticSpectralMeasure u v):ℝ) = 1 := by
    apply Complex.ofReal_injective
    rw [←integral_complex_ofReal]
    convert he using 1 <;> simp
  exact heq

end LeanVerification.WedgeCompletion
