import LeanVerification.WedgeCompletion.QuadraticSpectralMeasure
import LeanVerification.WedgeCompletion.ResolventKernelSigns

noncomputable section
open MeasureTheory Set Filter Metric
open scoped Topology

namespace LeanVerification.WedgeCompletion

set_option maxHeartbeats 1000000
set_option maxRecDepth 4000

/-- Weighted Cauchy--Schwarz for the constructed quadratic spectral measure.
The normalizing inverse moment is the one proved from its actual transform. -/
theorem quadraticSpectralMeasure_weighted_square {u v:ℝ} {f:ℝ→ℝ}
    (hu:0<u) (hv:0<v) (huv:u≤v) (hp:u*v=1)
    (hf:Measurable f) (hc:ContinuousOn f (Icc u v)) :
    (∫t,f t∂quadraticSpectralMeasure u v)^2 ≤
      ∫t,t*f t^2∂quadraticSpectralMeasure u v := by
  let U := ∫t,f t∂quadraticSpectralMeasure u v
  have hif := quadraticSpectralMeasure_integrable_continuous huv hf.aestronglyMeasurable hc
  have hig : Integrable (fun t:ℝ=>t*f t^2) (quadraticSpectralMeasure u v) :=
    quadraticSpectralMeasure_integrable_continuous huv
      (measurable_id.mul (hf.pow_const 2)).aestronglyMeasurable (continuousOn_id.mul (hc.pow 2))
  have hii : Integrable (fun t:ℝ=>t⁻¹) (quadraticSpectralMeasure u v) :=
    quadraticSpectralMeasure_integrable_continuous huv measurable_inv.aestronglyMeasurable
      (fun t ht=>(continuousAt_id.inv₀ (ne_of_gt (lt_of_lt_of_le hu ht.1))).continuousWithinAt)
  have he : (∫t,2*U*f t-U^2*t⁻¹∂quadraticSpectralMeasure u v)=U^2 := by
    have hs := integral_sub (hif.const_mul (2*U)) (hii.const_mul (U^2))
    simp only [Pi.sub_apply] at hs
    rw [hs,integral_const_mul,integral_const_mul,quadraticSpectralMeasure_inverse_moment hu hv hp]
    dsimp [U]
    ring
  rw [show (∫t,f t∂quadraticSpectralMeasure u v)^2=U^2 from rfl,←he]
  apply integral_mono_ae ((hif.const_mul (2*U)).sub (hii.const_mul (U^2))) hig
  filter_upwards [quadraticSpectralMeasure_support huv] with t ht
  have ht0 := lt_of_lt_of_le hu ht.1
  have hcancel : t*(U^2*t⁻¹)=U^2 := by field_simp
  have hn : 0≤t*(t*f t^2-(2*U*f t-U^2*t⁻¹)) := by
    nlinarith [sq_nonneg (t*f t-U)]
  have hd := nonneg_of_mul_nonneg_right hn ht0
  simpa only [Pi.sub_apply] using sub_nonneg.mp hd

theorem inverse_resolvent_real_kernel {σ t:ℝ} {z:ℂ}
    (hσ:σ≠0) (ht:0<t) (hz:0≤z.re) :
    ((z+(t:ℂ))⁻¹).re-t*(((z+(t:ℂ))⁻¹).re)^2-
      ((z/(σ:ℂ))*(z+(t:ℂ))⁻¹^2).re =
        inverseResolventNumerator (1-σ⁻¹) z.re z.im t /
          (Complex.normSq (z+(t:ℂ)))^2 := by
  have hn := shifted_ne_zero ht hz
  have hns := (Complex.normSq_pos.mpr hn).ne'
  have he : ((z/(σ:ℂ))*(z+(t:ℂ))⁻¹^2) = (z*(z+(t:ℂ))⁻¹^2)/(σ:ℂ) := by ring
  rw [he,Complex.div_ofReal_re]
  simp only [pow_two,Complex.mul_re,Complex.mul_im,Complex.inv_re,Complex.inv_im,
    Complex.add_re,Complex.add_im,Complex.ofReal_re,Complex.ofReal_im,add_zero]
  unfold inverseResolventNumerator
  field_simp
  simp only [Complex.normSq_apply,Complex.add_re,Complex.add_im,
    Complex.ofReal_re,Complex.ofReal_im,add_zero]
  ring

theorem integral_pos_of_probability_ae {μ:Measure ℝ} [IsProbabilityMeasure μ]
    {f:ℝ→ℝ} (hi:Integrable f μ) (hp:∀ᵐ t∂μ,0<f t) : 0<∫t,f t∂μ := by
  apply (integral_pos_iff_support_of_nonneg_ae (hp.mono fun _ h=>h.le) hi).2
  have he : Function.support f =ᵐ[μ] (univ:Set ℝ) := by
    filter_upwards [hp] with t ht
    apply propext
    change f t≠0 ↔ True
    exact iff_true_intro ht.ne'
  rw [measure_congr he,measure_univ]
  norm_num

end LeanVerification.WedgeCompletion
