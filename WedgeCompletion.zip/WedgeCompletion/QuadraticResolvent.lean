import LeanVerification.WedgeCompletion.ResolventSectorComparison

noncomputable section
open MeasureTheory Set Filter Metric
open scoped Topology

namespace LeanVerification.WedgeCompletion

set_option maxHeartbeats 1000000
set_option maxRecDepth 4000

def quadraticLowerEndpoint (b:ℝ) : ℝ := (b-Real.sqrt (b^2-4))/2
def quadraticUpperEndpoint (b:ℝ) : ℝ := (b+Real.sqrt (b^2-4))/2

def actualQuadraticRoot (b:ℝ) : ℂ→ℂ :=
  quadraticRoot (quadraticLowerEndpoint b) (quadraticUpperEndpoint b)

def actualQuadraticDefect (b σ:ℝ) : ℂ→ℂ :=
  quadraticDefect (quadraticLowerEndpoint b) (quadraticUpperEndpoint b) σ

theorem quadratic_endpoints {b:ℝ} (hb:2≤b) :
    0<quadraticLowerEndpoint b ∧
      quadraticLowerEndpoint b≤quadraticUpperEndpoint b ∧
      quadraticLowerEndpoint b*quadraticUpperEndpoint b=1 ∧
      quadraticLowerEndpoint b+quadraticUpperEndpoint b=b := by
  have hd:0≤b^2-4 := by nlinarith
  have hs := Real.sq_sqrt hd
  have hn := Real.sqrt_nonneg (b^2-4)
  unfold quadraticLowerEndpoint quadraticUpperEndpoint
  constructor
  · nlinarith
  constructor
  · linarith
  constructor
  · nlinarith
  · ring

theorem actualQuadraticRoot_square {b:ℝ} {z:ℂ} (hb:2≤b) (hz:0≤z.re) :
    actualQuadraticRoot b z^2=z^2+(b:ℂ)*z+1 := by
  obtain ⟨hu,huv,hp,hs⟩ := quadratic_endpoints hb
  have hv := lt_of_lt_of_le hu huv
  rw [actualQuadraticRoot,quadraticRoot_square hu hv hz]
  have hp' : (quadraticLowerEndpoint b:ℂ)*(quadraticUpperEndpoint b:ℂ)=1 := by exact_mod_cast hp
  have hs' : (quadraticLowerEndpoint b:ℂ)+(quadraticUpperEndpoint b:ℂ)=(b:ℂ) := by exact_mod_cast hs
  linear_combination hp'+z*hs'

theorem actualQuadraticRoot_re_pos {b:ℝ} {z:ℂ} (hb:2≤b) (hz:0≤z.re) :
    0<(actualQuadraticRoot b z).re := by
  obtain ⟨hu,huv,-,-⟩ := quadratic_endpoints hb
  exact quadraticRoot_re_pos hu (lt_of_lt_of_le hu huv) hz

theorem actualQuadraticRoot_analytic {b:ℝ} (hb:2≤b) :
    AnalyticOnNhd ℂ (actualQuadraticRoot b) Complex.slitPlane := by
  obtain ⟨hu,huv,-,-⟩ := quadratic_endpoints hb
  exact quadraticRoot_analytic hu (lt_of_lt_of_le hu huv)

theorem quadraticSpectralMeasure_one_one_eq_dirac :
    quadraticSpectralMeasure 1 1=Measure.dirac 1 := by
  unfold quadraticSpectralMeasure
  have he : quadraticSpectralPoint 1 1 =ᵐ[quadraticBetaMeasure] (fun _=>1) := by
    filter_upwards [quadraticBetaMeasure_pos_ae] with s hs
    simp only [quadraticSpectralPoint,one_mul]
    exact div_self (ne_of_gt (by linarith : 0<1+s))
  rw [Measure.map_congr he,Measure.map_const,measure_univ,one_smul]

/-- Both actual resolvent signs, together with every nonnegative shift of
the squared denominator, on the complete allowed half-plane. -/
theorem actual_quadratic_resolvent_half_plane {b σ:ℝ} {z:ℂ}
    (hb:2≤b) (hσ:2≤σ) (hz:0≤z.re) (hz0:z≠0) :
    0≤(actualQuadraticDefect b σ z).re ∧
      0<(actualQuadraticDefect b σ z/(actualQuadraticRoot b z)^2).re ∧
      ∀k:ℝ,0≤k→(k:ℂ)+(actualQuadraticRoot b z)^2≠0 ∧
        0<(actualQuadraticDefect b σ z/((k:ℂ)+(actualQuadraticRoot b z)^2)).re := by
  obtain ⟨hu,huv,hp,-⟩ := quadratic_endpoints hb
  have hv := lt_of_lt_of_le hu huv
  have hσp:0<σ := by linarith
  have hinv : σ⁻¹≤1/2 := by
    rw [←one_div,div_le_iff₀ hσp]
    linarith
  have hκ:1/2≤1-σ⁻¹ := by linarith
  have hzs:z∈Complex.slitPlane := by
    rcases lt_or_eq_of_le hz with h | h
    · exact Or.inl h
    · right
      intro hi
      exact hz0 (Complex.ext h.symm hi)
  have hm := quadraticDefect_re_nonneg_half hu hv huv hp hκ hz hzs
  have hi := quadraticDefect_inverse_pos_half hu hv huv hp hσp.ne' hκ hz hz0
  refine ⟨hm,hi,?_⟩
  intro k hk
  exact positive_real_resolvent_interpolation (pow_ne_zero 2 (quadraticRoot_ne_zero _ _ z)) hk hm hi

/-- The smaller exponent range uses the actual closed sixty-degree cone. -/
theorem actual_quadratic_resolvent_sector {b σ:ℝ} {z:ℂ}
    (hb:2≤b) (hσ:3/2≤σ) (hσ':σ≤2) (hz:0<z.re)
    (hy:|z.im|≤Real.sqrt 3*z.re) :
    0≤(actualQuadraticDefect b σ z).re ∧
      0<(actualQuadraticDefect b σ z/(actualQuadraticRoot b z)^2).re ∧
      ∀k:ℝ,0≤k→(k:ℂ)+(actualQuadraticRoot b z)^2≠0 ∧
        0<(actualQuadraticDefect b σ z/((k:ℂ)+(actualQuadraticRoot b z)^2)).re := by
  obtain ⟨hu,huv,hp,-⟩ := quadratic_endpoints hb
  have hv := lt_of_lt_of_le hu huv
  have hσp:0<σ := by linarith
  have hinv : σ⁻¹≤2/3 := by
    rw [←one_div,div_le_iff₀ hσp]
    linarith
  have hinv' : 1/2≤σ⁻¹ := by
    rw [←one_div,le_div_iff₀ hσp]
    linarith
  have hκ:1/3≤1-σ⁻¹ := by linarith
  have hκ':1-σ⁻¹≤1/2 := by linarith
  have hy' : z.im^2≤3*z.re^2 := by
    have hh := pow_le_pow_left₀ (abs_nonneg z.im) hy 2
    rw [sq_abs,mul_pow,Real.sq_sqrt (by norm_num : (0:ℝ)≤3)] at hh
    exact hh
  have hm := quadraticDefect_re_nonneg_sector hu hv huv hp hκ hκ' hz.le hy' (Or.inl hz)
  have hi := quadraticDefect_inverse_pos_sector hu hv huv hp hσp.ne' hκ hκ' hz hy'
  refine ⟨hm,hi,?_⟩
  intro k hk
  exact positive_real_resolvent_interpolation (pow_ne_zero 2 (quadraticRoot_ne_zero _ _ z)) hk hm hi

end LeanVerification.WedgeCompletion
