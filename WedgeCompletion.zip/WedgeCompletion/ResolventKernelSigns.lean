import LeanVerification.WedgeCompletion.QuadraticStieltjes

noncomputable section
open MeasureTheory Set Filter Metric
open scoped Topology

namespace LeanVerification.WedgeCompletion

set_option maxHeartbeats 1000000
set_option maxRecDepth 4000

def resolventKernelNumerator (κ x y t:ℝ) : ℝ :=
  x*(x+κ*t)*(x+t)^2+y^2*(2*x^2+(κ+2)*t*x+(2*κ-1)*t^2)+y^4

theorem resolventKernelNumerator_nonneg_half {κ x y t:ℝ}
    (hκ:1/2≤κ) (hx:0≤x) (ht:0≤t) : 0≤resolventKernelNumerator κ x y t := by
  have hk0:0≤κ := by linarith
  have hk1:0≤κ+2 := by linarith
  have hk2:0≤2*κ-1 := by linarith
  unfold resolventKernelNumerator
  positivity

theorem resolventKernelNumerator_sector_decomposition (κ x y t:ℝ) :
    resolventKernelNumerator κ x y t =
      κ*t^3*x+(8*κ-2)*t^2*x^2+(κ+2)*t*x^3+x^4+
      2*x^2*y^2+(κ+2)*t*x*y^2+y^4+(1-2*κ)*t^2*(3*x^2-y^2) := by
  unfold resolventKernelNumerator
  ring

theorem resolventKernelNumerator_nonneg_sector {κ x y t:ℝ}
    (hκ:1/3≤κ) (hκ':κ≤1/2) (hx:0≤x) (ht:0≤t) (hy:y^2≤3*x^2) :
    0≤resolventKernelNumerator κ x y t := by
  have hk0:0≤κ := by linarith
  have hk1:0≤8*κ-2 := by linarith
  have hk2:0≤κ+2 := by linarith
  have hk3:0≤1-2*κ := by linarith
  have hy0:0≤3*x^2-y^2 := by linarith
  rw [resolventKernelNumerator_sector_decomposition]
  positivity

theorem resolvent_kernel_real_formula {κ t:ℝ} {z:ℂ} (ht:0<t) (hz:0≤z.re) :
    (z*(z+(κ*t:ℝ))/(z+(t:ℂ))^2).re =
      resolventKernelNumerator κ z.re z.im t / (Complex.normSq (z+(t:ℂ)))^2 := by
  have hn := shifted_ne_zero ht hz
  have hns := (Complex.normSq_pos.mpr hn).ne'
  rw [Complex.div_re,map_pow]
  simp only [Complex.mul_re,Complex.mul_im,Complex.add_re,Complex.add_im,
    Complex.ofReal_re,Complex.ofReal_im,add_zero,pow_two]
  unfold resolventKernelNumerator
  field_simp
  ring

theorem resolvent_kernel_real_nonneg_half {κ t:ℝ} {z:ℂ}
    (hκ:1/2≤κ) (ht:0<t) (hz:0≤z.re) :
    0≤(z*(z+(κ*t:ℝ))/(z+(t:ℂ))^2).re := by
  rw [resolvent_kernel_real_formula ht hz]
  exact div_nonneg (resolventKernelNumerator_nonneg_half hκ hz ht.le) (sq_nonneg _)

theorem resolvent_kernel_real_nonneg_sector {κ t:ℝ} {z:ℂ}
    (hκ:1/3≤κ) (hκ':κ≤1/2) (ht:0<t) (hz:0≤z.re)
    (hy:z.im^2≤3*z.re^2) :
    0≤(z*(z+(κ*t:ℝ))/(z+(t:ℂ))^2).re := by
  rw [resolvent_kernel_real_formula ht hz]
  exact div_nonneg (resolventKernelNumerator_nonneg_sector hκ hκ' hz ht.le hy)
    (sq_nonneg _)

def inverseResolventNumerator (κ x y t:ℝ) : ℝ :=
  κ*x*((x+t)^2+y^2)+(2*κ-1)*t*y^2

theorem inverseResolventNumerator_pos_half {κ x y t:ℝ}
    (hκ:1/2≤κ) (hx:0<x) (ht:0<t) : 0 < inverseResolventNumerator κ x y t := by
  have hk0:0<κ := by linarith
  have hk1:0≤2*κ-1 := by linarith
  have hsum:0<(x+t)^2+y^2 := by nlinarith [sq_pos_of_pos (add_pos hx ht),sq_nonneg y]
  unfold inverseResolventNumerator
  positivity

theorem inverseResolventNumerator_nonneg_half {κ x y t:ℝ}
    (hκ:1/2≤κ) (hx:0≤x) (ht:0≤t) : 0 ≤ inverseResolventNumerator κ x y t := by
  have hk0:0≤κ := by linarith
  have hk1:0≤2*κ-1 := by linarith
  unfold inverseResolventNumerator
  positivity

theorem inverseResolventNumerator_sector_decomposition (κ x y t:ℝ) :
    inverseResolventNumerator κ x y t =
      κ*x*y^2+x*(κ*(x-t)^2+(10*κ-3)*t*x)+(1-2*κ)*t*(3*x^2-y^2) := by
  unfold inverseResolventNumerator
  ring

theorem inverseResolventNumerator_pos_sector {κ x y t:ℝ}
    (hκ:1/3≤κ) (hκ':κ≤1/2) (hx:0<x) (ht:0<t) (hy:y^2≤3*x^2) :
    0 < inverseResolventNumerator κ x y t := by
  have hk0:0<κ := by linarith
  have hk1:0<10*κ-3 := by linarith
  have hk2:0≤1-2*κ := by linarith
  have hy0:0≤3*x^2-y^2 := by linarith
  rw [inverseResolventNumerator_sector_decomposition]
  positivity

/-- The two real-part inequalities imply the entire nonnegative resolvent
family, including strictness and nonvanishing of each denominator. -/
theorem positive_real_resolvent_interpolation {M q:ℂ} {k:ℝ}
    (hq:q≠0) (hk:0≤k) (hM:0≤M.re) (hMq:0<(M/q).re) :
    (k:ℂ)+q≠0 ∧ 0<(M/((k:ℂ)+q)).re := by
  have hn:0<M.re*q.re+M.im*q.im := by
    rw [Complex.div_re,←add_div] at hMq
    exact (div_pos_iff_of_pos_right (Complex.normSq_pos.mpr hq)).mp hMq
  have hnum : 0<M.re*((k:ℂ)+q).re+M.im*((k:ℂ)+q).im := by
    simp only [Complex.add_re,Complex.add_im,Complex.ofReal_re,Complex.ofReal_im,zero_add]
    nlinarith [mul_nonneg hM hk]
  have hd:(k:ℂ)+q≠0 := by
    intro he
    simpa only [he,Complex.zero_re,Complex.zero_im,mul_zero,add_zero,lt_self_iff_false] using hnum
  refine ⟨hd,?_⟩
  rw [Complex.div_re,←add_div]
  exact div_pos hnum (Complex.normSq_pos.mpr hd)

end LeanVerification.WedgeCompletion
