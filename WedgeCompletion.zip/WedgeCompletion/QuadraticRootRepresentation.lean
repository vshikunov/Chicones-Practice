import LeanVerification.WedgeCompletion.QuadraticSpectralMeasure

noncomputable section
open MeasureTheory Set Filter Metric
open scoped Topology

namespace LeanVerification.WedgeCompletion
open ContourCompletion

set_option maxHeartbeats 1000000
set_option maxRecDepth 4000

def quadraticResolventWeight (u v t:ℝ) : ℝ := u+v-t-t⁻¹

theorem quadraticRoot_ne_zero (u v:ℝ) (z:ℂ) : quadraticRoot u v z≠0 := by
  unfold quadraticRoot principalSquareRoot
  exact mul_ne_zero (Complex.exp_ne_zero _) (Complex.exp_ne_zero _)

theorem quadraticRoot_analytic {u v:ℝ} (hu:0<u) (hv:0<v) :
    AnalyticOnNhd ℂ (quadraticRoot u v) Complex.slitPlane := by
  intro z hz
  have hiu:AnalyticAt ℂ (fun w:ℂ=>w+(u:ℂ)) z := analyticAt_id.add analyticAt_const
  have hiv:AnalyticAt ℂ (fun w:ℂ=>w+(v:ℂ)) z := analyticAt_id.add analyticAt_const
  have hau:AnalyticAt ℂ (fun w:ℂ=>principalSquareRoot (w+(u:ℂ))) z :=
    (MiddleStripSpectral.analyticAt_principalSquareRoot
      (Cauchy.slitPlane_add_nonnegative hz hu.le)).comp (f:=fun w:ℂ=>w+(u:ℂ)) hiu
  have hav:AnalyticAt ℂ (fun w:ℂ=>principalSquareRoot (w+(v:ℂ))) z :=
    (MiddleStripSpectral.analyticAt_principalSquareRoot
      (Cauchy.slitPlane_add_nonnegative hz hv.le)).comp (f:=fun w:ℂ=>w+(v:ℂ)) hiv
  exact hau.mul hav

theorem quadraticRoot_square_slit {u v:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (hz:z∈Complex.slitPlane) :
    quadraticRoot u v z^2=(z+(u:ℂ))*(z+(v:ℂ)) := by
  rw [quadraticRoot,mul_pow,principalSquareRoot_square
    (Complex.slitPlane_ne_zero (Cauchy.slitPlane_add_nonnegative hz hu.le)),
    principalSquareRoot_square
      (Complex.slitPlane_ne_zero (Cauchy.slitPlane_add_nonnegative hz hv.le))]

theorem quadraticSpectralMeasure_nonneg_ae {u v:ℝ} (hu:0<u) (huv:u≤v) :
    ∀ᵐ t∂quadraticSpectralMeasure u v,0≤t := by
  filter_upwards [quadraticSpectralMeasure_support huv] with t ht
  exact hu.le.trans ht.1

theorem quadraticSpectralMeasure_cauchy_mass {u v:ℝ} (hu:0<u) (huv:u≤v) :
    Integrable (fun t:ℝ=>(1:ℝ)*(1+t)^(-(1:ℝ))) (quadraticSpectralMeasure u v) := by
  apply (integrable_const (1:ℝ)).mono'
    (show Measurable (fun t:ℝ=>(1:ℝ)*(1+t)^(-(1:ℝ))) by fun_prop).aestronglyMeasurable
  filter_upwards [quadraticSpectralMeasure_nonneg_ae hu huv] with t ht
  simp only [one_mul,Real.rpow_neg_one]
  rw [Real.norm_of_nonneg (inv_nonneg.mpr (by linarith : 0≤1+t))]
  exact inv_le_one_of_one_le₀ (by linarith)

theorem quadraticSpectralMeasure_transform_eq (u v:ℝ) (z:ℂ) :
    Cauchy.complexTransform (quadraticSpectralMeasure u v) (fun _=>1) 1 z =
      ∫t,(z+(t:ℂ))⁻¹∂quadraticSpectralMeasure u v := by
  simp only [Cauchy.complexTransform,Cauchy.complexKernel,Complex.ofReal_one,
    Complex.ofReal_neg,Complex.cpow_neg_one,one_mul]

/-- Holomorphic uniqueness extends the constructed positive spectral
representation to the full principal slit plane. -/
theorem quadraticSpectralMeasure_stieltjes_slit {u v:ℝ}
    (hu:0<u) (hv:0<v) (huv:u≤v) {z:ℂ} (hz:z∈Complex.slitPlane) :
    (∫t,(z+(t:ℂ))⁻¹∂quadraticSpectralMeasure u v)=(quadraticRoot u v z)⁻¹ := by
  rw [←quadraticSpectralMeasure_transform_eq]
  apply RealComplexification.eqOn_of_eqOn_real_slice
    (fun z hz=>Cauchy.analyticAt_complexTransform (by norm_num : (0:ℝ)<1) hz
      measurable_const (quadraticSpectralMeasure_nonneg_ae hu huv)
      (quadraticSpectralMeasure_cauchy_mass hu huv))
    (fun z hz=>(quadraticRoot_analytic hu hv z hz).inv (quadraticRoot_ne_zero u v z))
    Complex.isOpen_slitPlane isPreconnected_slitPlane (r:=1) (by simp) ?_ hz
  intro x hx
  rw [quadraticSpectralMeasure_transform_eq]
  exact quadraticSpectralMeasure_stieltjes hu hv (Complex.ofReal_mem_slitPlane.mp hx).le

theorem quadraticSpectralMeasure_power_integrable {u v:ℝ}
    (hu:0<u) (hv:0<v) (huv:u≤v) {z:ℂ} (hz:z∈Complex.slitPlane) (n:ℕ) :
    Integrable (fun t:ℝ=>(z+(t:ℂ))⁻¹^n) (quadraticSpectralMeasure u v) := by
  apply quadraticSpectralMeasure_integrable_continuous huv
    (show Measurable (fun t:ℝ=>(z+(t:ℂ))⁻¹^n) by fun_prop).aestronglyMeasurable
  intro t ht
  exact ((((continuousAt_const.add Complex.continuous_ofReal.continuousAt).inv₀
    (Complex.slitPlane_ne_zero (Cauchy.slitPlane_add_nonnegative hz (hu.le.trans ht.1)))).pow n).continuousWithinAt)

theorem quadraticSpectralMeasure_cauchy_derivative {u v:ℝ}
    (hu:0<u) (hv:0<v) (huv:u≤v) {z:ℂ} (hz:z∈Complex.slitPlane) :
    HasDerivAt (fun z:ℂ=>(quadraticRoot u v z)⁻¹)
      (-(∫t,(z+(t:ℂ))⁻¹^2∂quadraticSpectralMeasure u v)) z := by
  have hd := Cauchy.hasDerivAt_complexTransform (by norm_num : (0:ℝ)<1) hz
    measurable_const (quadraticSpectralMeasure_nonneg_ae hu huv)
    (quadraticSpectralMeasure_cauchy_mass hu huv)
  have he : (fun z=>Cauchy.complexTransform (quadraticSpectralMeasure u v) (fun _=>1) 1 z)
      =ᶠ[𝓝 z] (fun z:ℂ=>(quadraticRoot u v z)⁻¹) := by
    filter_upwards [Complex.isOpen_slitPlane.mem_nhds hz] with w hw
    rw [quadraticSpectralMeasure_transform_eq]
    exact quadraticSpectralMeasure_stieltjes_slit hu hv huv hw
  convert hd.congr_of_eventuallyEq he.symm using 1
  simp only [Cauchy.complexTransform,Cauchy.complexKernel,Complex.ofReal_one,
    Complex.ofReal_neg,one_mul,neg_one_mul]
  norm_num [Complex.cpow_neg,Complex.cpow_ofNat,inv_pow]

theorem quadraticResolventWeight_nonneg {u v t:ℝ}
    (hu:0<u) (huv:u*v=1) (ht:t∈Icc u v) : 0≤quadraticResolventWeight u v t := by
  have ht0:0<t := lt_of_lt_of_le hu ht.1
  have he : quadraticResolventWeight u v t*t=(t-u)*(v-t) := by
    unfold quadraticResolventWeight
    field_simp
    nlinarith [huv]
  have hn := mul_nonneg (sub_nonneg.mpr ht.1) (sub_nonneg.mpr ht.2)
  exact nonneg_of_mul_nonneg_left (he ▸ hn) ht0

theorem quadraticResolventWeight_measurable (u v:ℝ) : Measurable (quadraticResolventWeight u v) := by
  unfold quadraticResolventWeight
  fun_prop

theorem quadraticResolventWeight_continuous {u v:ℝ} (hu:0<u) :
    ContinuousOn (quadraticResolventWeight u v) (Icc u v) := by
  intro t ht
  exact (continuousAt_const.sub continuousAt_id |>.sub
    (continuousAt_id.inv₀ (ne_of_gt (lt_of_lt_of_le hu ht.1)))).continuousWithinAt

theorem quadraticResolventWeight_kernel_integrable {u v:ℝ} {z:ℂ}
    (hu:0<u) (huv:u≤v) (hz:z∈Complex.slitPlane) (n:ℕ) :
    Integrable (fun t:ℝ=>(quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹^n)
      (quadraticSpectralMeasure u v) := by
  apply quadraticSpectralMeasure_integrable_continuous huv
    (show Measurable (fun t:ℝ=>(quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹^n) by
      exact (Complex.continuous_ofReal.measurable.comp (quadraticResolventWeight_measurable u v)).mul
        (by fun_prop)).aestronglyMeasurable
  intro t ht
  have hw:ContinuousAt (quadraticResolventWeight u v) t :=
    (continuousAt_const.sub continuousAt_id).sub
      (continuousAt_id.inv₀ (ne_of_gt (lt_of_lt_of_le hu ht.1)))
  exact ((Complex.continuous_ofReal.continuousAt.comp
    (f:=quadraticResolventWeight u v) hw).mul
    (((continuousAt_const.add Complex.continuous_ofReal.continuousAt).inv₀
      (Complex.slitPlane_ne_zero (Cauchy.slitPlane_add_nonnegative hz (hu.le.trans ht.1)))).pow n)).continuousWithinAt

/-- The second positive spectral representation of the actual quadratic root. -/
theorem quadraticRoot_cauchy_representation {u v:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (huv:u≤v) (hprod:u*v=1) (hz:z∈Complex.slitPlane) :
    quadraticRoot u v z=1+z+z*
      (∫t,(quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹∂quadraticSpectralMeasure u v) := by
  have hi := quadraticSpectralMeasure_power_integrable hu hv huv hz 1
  simp only [pow_one] at hi
  have hit := quadraticSpectralMeasure_kernel_integrable hu hv (show 0≤(0:ℂ).re by norm_num)
  simp only [zero_add] at hit
  have hinv : (∫t,(t:ℂ)⁻¹∂quadraticSpectralMeasure u v)=1 := by
    simpa [quadraticRoot_zero hu hv hprod] using
      quadraticSpectralMeasure_stieltjes hu hv (show 0≤(0:ℂ).re by norm_num)
  have hp : (u:ℂ)*(v:ℂ)=1 := by exact_mod_cast hprod
  have he : (fun t:ℝ=>z*((quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹)) =ᵐ[quadraticSpectralMeasure u v]
      (fun t:ℝ=>((z+(u:ℂ))*(z+(v:ℂ)))*(z+(t:ℂ))⁻¹-z-(t:ℂ)⁻¹) := by
    filter_upwards [quadraticSpectralMeasure_support huv] with t ht
    have ht0 : (t:ℂ)≠0 := by exact_mod_cast (lt_of_lt_of_le hu ht.1).ne'
    have hz0 := Complex.slitPlane_ne_zero (Cauchy.slitPlane_add_nonnegative hz (hu.le.trans ht.1))
    unfold quadraticResolventWeight
    push_cast
    field_simp
    linear_combination -(z*(t:ℂ)^2+(t:ℂ)^3)*hp
  have hiQ := hi.const_mul ((z+(u:ℂ))*(z+(v:ℂ)))
  have hs1 := integral_sub (hiQ.sub (integrable_const z)) hit
  have hs2 := integral_sub hiQ (integrable_const z)
  simp only [Pi.sub_apply] at hs1 hs2
  rw [←integral_const_mul,integral_congr_ae he,hs1,hs2,integral_const_mul,
    integral_const,measureReal_def,measure_univ,ENNReal.toReal_one,one_smul,hinv,
    quadraticSpectralMeasure_stieltjes_slit hu hv huv hz,
    ←quadraticRoot_square_slit hu hv hz]
  field_simp [quadraticRoot_ne_zero]
  <;> ring

theorem quadraticResolventWeight_cauchy_mass {u v:ℝ}
    (hu:0<u) (huv:u≤v) :
    Integrable (fun t:ℝ=>quadraticResolventWeight u v t*(1+t)^(-(1:ℝ)))
      (quadraticSpectralMeasure u v) := by
  have hi := quadraticResolventWeight_kernel_integrable (z:=1) hu huv
    (show (1:ℂ)∈Complex.slitPlane by simp) 1
  have he : (fun t:ℝ=>(quadraticResolventWeight u v t:ℂ)*(1+(t:ℂ))⁻¹^1)=
      (fun t:ℝ=>((quadraticResolventWeight u v t*(1+t)^(-(1:ℝ)):ℝ):ℂ)) := by
    funext t
    rw [pow_one,Real.rpow_neg_one]
    push_cast
    rfl
  rw [he] at hi
  exact hi.re

theorem quadraticResolventWeight_transform_eq (u v:ℝ) (z:ℂ) :
    Cauchy.complexTransform (quadraticSpectralMeasure u v) (quadraticResolventWeight u v) 1 z =
      ∫t,(quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹∂quadraticSpectralMeasure u v := by
  simp only [Cauchy.complexTransform,Cauchy.complexKernel,Complex.ofReal_one,
    Complex.ofReal_neg,Complex.cpow_neg_one]

theorem quadraticResolventWeight_cauchy_derivative {u v:ℝ} {z:ℂ}
    (hu:0<u) (huv:u≤v) (hz:z∈Complex.slitPlane) :
    HasDerivAt
      (fun z:ℂ=>∫t,(quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹∂quadraticSpectralMeasure u v)
      (-(∫t,(quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹^2∂quadraticSpectralMeasure u v)) z := by
  have hd := Cauchy.hasDerivAt_complexTransform (by norm_num : (0:ℝ)<1) hz
    (quadraticResolventWeight_measurable u v) (quadraticSpectralMeasure_nonneg_ae hu huv)
    (quadraticResolventWeight_cauchy_mass hu huv)
  have he : Cauchy.complexTransform (quadraticSpectralMeasure u v) (quadraticResolventWeight u v) 1 =
      (fun z:ℂ=>∫t,(quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹∂quadraticSpectralMeasure u v) :=
    funext (quadraticResolventWeight_transform_eq u v)
  rw [he] at hd
  convert hd using 1
  simp only [Cauchy.complexTransform,Cauchy.complexKernel,Complex.ofReal_one,
    Complex.ofReal_neg,neg_one_mul]
  norm_num [Complex.cpow_neg,Complex.cpow_ofNat,inv_pow]

theorem quadraticRoot_hasDerivAt_cauchy {u v:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (huv:u≤v) (hprod:u*v=1) (hz:z∈Complex.slitPlane) :
    HasDerivAt (quadraticRoot u v)
      (1+(∫t,(quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹∂quadraticSpectralMeasure u v)-
        z*(∫t,(quadraticResolventWeight u v t:ℂ)*(z+(t:ℂ))⁻¹^2∂quadraticSpectralMeasure u v)) z := by
  have hd := ((hasDerivAt_const z (1:ℂ)).add (hasDerivAt_id z)).add
    ((hasDerivAt_id z).mul (quadraticResolventWeight_cauchy_derivative hu huv hz))
  have he : (quadraticRoot u v)=ᶠ[𝓝 z] (fun w:ℂ=>1+w+w*
      (∫t,(quadraticResolventWeight u v t:ℂ)*(w+(t:ℂ))⁻¹∂quadraticSpectralMeasure u v)) := by
    filter_upwards [Complex.isOpen_slitPlane.mem_nhds hz] with w hw
    exact quadraticRoot_cauchy_representation hu hv huv hprod hw
  convert hd.congr_of_eventuallyEq he using 1
  simp only [id_eq]
  ring

end LeanVerification.WedgeCompletion
