import LeanVerification.WedgeCompletion.QuadraticDefect

noncomputable section
open MeasureTheory Set Filter Metric
open scoped Topology

namespace LeanVerification.WedgeCompletion

set_option maxHeartbeats 1000000
set_option maxRecDepth 4000

def inverseDefectKernel (σ:ℝ) (z:ℂ) (t:ℝ) : ℝ :=
  inverseResolventNumerator (1-σ⁻¹) z.re z.im t/(Complex.normSq (z+(t:ℂ)))^2

theorem quadraticSpectralMeasure_inverse_re_continuous {u v:ℝ} {z:ℂ}
    (hu:0<u) (hz:z∈Complex.slitPlane) :
    ContinuousOn (fun t:ℝ=>((z+(t:ℂ))⁻¹).re) (Icc u v) := by
  intro t ht
  have hi:ContinuousAt (fun t:ℝ=>(z+(t:ℂ))⁻¹) t :=
    (continuousAt_const.add Complex.continuous_ofReal.continuousAt).inv₀
      (Complex.slitPlane_ne_zero (Cauchy.slitPlane_add_nonnegative hz (hu.le.trans ht.1)))
  exact (Complex.continuous_re.continuousAt.comp (f:=fun t:ℝ=>(z+(t:ℂ))⁻¹) hi).continuousWithinAt

theorem inverseDefectKernel_integrable {u v σ:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (huv:u≤v) (hσ:σ≠0) (hz:0≤z.re) (hzs:z∈Complex.slitPlane) :
    Integrable (inverseDefectKernel σ z) (quadraticSpectralMeasure u v) := by
  have hi1 := quadraticSpectralMeasure_power_integrable hu hv huv hzs 1
  simp only [pow_one] at hi1
  have hi2 := quadraticSpectralMeasure_power_integrable hu hv huv hzs 2
  have hm : Measurable (fun t:ℝ=>((z+(t:ℂ))⁻¹).re) :=
    Complex.continuous_re.measurable.comp (show Measurable (fun t:ℝ=>(z+(t:ℂ))⁻¹) by fun_prop)
  have hiG : Integrable (fun t:ℝ=>t*(((z+(t:ℂ))⁻¹).re)^2) (quadraticSpectralMeasure u v) :=
    quadraticSpectralMeasure_integrable_continuous huv
      (measurable_id.mul (hm.pow_const 2)).aestronglyMeasurable
      (continuousOn_id.mul ((quadraticSpectralMeasure_inverse_re_continuous hu hzs).pow 2))
  apply ((hi1.re.sub hiG).sub (hi2.const_mul (z/(σ:ℂ))).re).congr
  filter_upwards [quadraticSpectralMeasure_support huv] with t ht
  exact inverse_resolvent_real_kernel hσ (lt_of_lt_of_le hu ht.1) hz

/-- The actual inverse first moment supplies the weighted-square bound,
and the exact spectral derivative supplies the remaining kernel. -/
theorem quadraticDefect_inverse_lower_bound {u v σ:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (huv:u≤v) (hp:u*v=1) (hσ:σ≠0)
    (hz:0≤z.re) (hzs:z∈Complex.slitPlane) :
    ((quadraticRoot u v z)⁻¹).im^2+
        (∫t,inverseDefectKernel σ z t∂quadraticSpectralMeasure u v) ≤
      (quadraticDefect u v σ z/(quadraticRoot u v z)^2).re := by
  have hi1 := quadraticSpectralMeasure_power_integrable hu hv huv hzs 1
  simp only [pow_one] at hi1
  have hi2 := quadraticSpectralMeasure_power_integrable hu hv huv hzs 2
  have hc := quadraticSpectralMeasure_inverse_re_continuous (v:=v) hu hzs
  have hm : Measurable (fun t:ℝ=>((z+(t:ℂ))⁻¹).re) :=
    Complex.continuous_re.measurable.comp (show Measurable (fun t:ℝ=>(z+(t:ℂ))⁻¹) by fun_prop)
  have hiG : Integrable (fun t:ℝ=>t*(((z+(t:ℂ))⁻¹).re)^2) (quadraticSpectralMeasure u v) :=
    quadraticSpectralMeasure_integrable_continuous huv
      (measurable_id.mul (hm.pow_const 2)).aestronglyMeasurable (continuousOn_id.mul (hc.pow 2))
  have hsq := quadraticSpectralMeasure_weighted_square hu hv huv hp hm hc
  have hRe := integral_re hi1
  change (∫t,((z+(t:ℂ))⁻¹).re∂quadraticSpectralMeasure u v)=
    (∫t,(z+(t:ℂ))⁻¹∂quadraticSpectralMeasure u v).re at hRe
  rw [quadraticSpectralMeasure_stieltjes_slit hu hv huv hzs] at hRe
  rw [hRe] at hsq
  have hRe2 := integral_re (hi2.const_mul (z/(σ:ℂ)))
  change (∫t,((z/(σ:ℂ))*(z+(t:ℂ))⁻¹^2).re∂quadraticSpectralMeasure u v)=
    (∫t,(z/(σ:ℂ))*(z+(t:ℂ))⁻¹^2∂quadraticSpectralMeasure u v).re at hRe2
  rw [integral_const_mul] at hRe2
  have he : inverseDefectKernel σ z =ᵐ[quadraticSpectralMeasure u v]
      (fun t:ℝ=>((z+(t:ℂ))⁻¹).re-t*(((z+(t:ℂ))⁻¹).re)^2-
        ((z/(σ:ℂ))*(z+(t:ℂ))⁻¹^2).re) := by
    filter_upwards [quadraticSpectralMeasure_support huv] with t ht
    exact (inverse_resolvent_real_kernel hσ (lt_of_lt_of_le hu ht.1) hz).symm
  have hs1 := integral_sub (hi1.re.sub hiG) (hi2.const_mul (z/(σ:ℂ))).re
  have hs2 := integral_sub hi1.re hiG
  simp only [Pi.sub_apply,show (RCLike.re:ℂ→ℝ)=Complex.re from rfl] at hs1 hs2
  change (∫t,((z+(t:ℂ))⁻¹).re-t*(((z+(t:ℂ))⁻¹).re)^2-
      ((z/(σ:ℂ))*(z+(t:ℂ))⁻¹^2).re∂quadraticSpectralMeasure u v)=_ at hs1
  change (∫t,((z+(t:ℂ))⁻¹).re-t*(((z+(t:ℂ))⁻¹).re)^2∂quadraticSpectralMeasure u v)=_ at hs2
  rw [integral_congr_ae he,hs1,hs2,hRe,hRe2,quadraticDefect_inverse_cauchy hu hv huv hzs]
  simp only [Complex.sub_re,pow_two,Complex.mul_re] at *
  linarith

theorem quadraticRoot_inverse_im_ne_zero {u v:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (hz:0≤z.re) (hy:z.im≠0) :
    ((quadraticRoot u v z)⁻¹).im≠0 := by
  intro he
  rw [Complex.inv_im] at he
  have hri : (quadraticRoot u v z).im=0 :=
    neg_eq_zero.mp ((div_eq_zero_iff).mp he |>.resolve_right
      (Complex.normSq_pos.mpr (quadraticRoot_ne_zero u v z)).ne')
  have hs := congrArg Complex.im (quadraticRoot_square hu hv hz)
  simp only [pow_two,Complex.mul_im,Complex.add_re,Complex.add_im,
    Complex.ofReal_re,Complex.ofReal_im,add_zero,hri,mul_zero,zero_mul,zero_add] at hs
  have hfactor : z.im*(2*z.re+u+v)=0 := by nlinarith [hs]
  exact hy ((mul_eq_zero.mp hfactor).resolve_right (by linarith))

theorem quadraticDefect_inverse_pos_half {u v σ:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (huv:u≤v) (hp:u*v=1) (hσ:σ≠0)
    (hκ:1/2≤1-σ⁻¹) (hz:0≤z.re) (hz0:z≠0) :
    0<(quadraticDefect u v σ z/(quadraticRoot u v z)^2).re := by
  have hzs:z∈Complex.slitPlane := by
    rcases lt_or_eq_of_le hz with h | h
    · exact Or.inl h
    · right
      intro hi
      apply hz0
      exact Complex.ext h.symm hi
  have hb := quadraticDefect_inverse_lower_bound hu hv huv hp hσ hz hzs
  by_cases hx:0<z.re
  · have hi := inverseDefectKernel_integrable hu hv huv hσ hz hzs
    have hpI : 0<∫t,inverseDefectKernel σ z t∂quadraticSpectralMeasure u v := by
      apply integral_pos_of_probability_ae hi
      filter_upwards [quadraticSpectralMeasure_support huv] with t ht
      exact div_pos (inverseResolventNumerator_pos_half hκ hx (lt_of_lt_of_le hu ht.1))
        (sq_pos_of_pos (Complex.normSq_pos.mpr (shifted_ne_zero (lt_of_lt_of_le hu ht.1) hz)))
    nlinarith [sq_nonneg ((quadraticRoot u v z)⁻¹).im]
  · have hr:z.re=0 := le_antisymm (le_of_not_gt hx) hz
    have hy:z.im≠0 := by intro hi;exact hz0 (Complex.ext hr hi)
    have hpI : 0≤∫t,inverseDefectKernel σ z t∂quadraticSpectralMeasure u v := by
      apply integral_nonneg_of_ae
      filter_upwards [quadraticSpectralMeasure_support huv] with t ht
      exact div_nonneg
        (inverseResolventNumerator_nonneg_half hκ hz (hu.le.trans ht.1)) (sq_nonneg _)
    have hsi := sq_pos_of_ne_zero (quadraticRoot_inverse_im_ne_zero hu hv hz hy)
    linarith

theorem quadraticDefect_inverse_pos_sector {u v σ:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (huv:u≤v) (hp:u*v=1) (hσ:σ≠0)
    (hκ:1/3≤1-σ⁻¹) (hκ':1-σ⁻¹≤1/2) (hz:0<z.re) (hy:z.im^2≤3*z.re^2) :
    0<(quadraticDefect u v σ z/(quadraticRoot u v z)^2).re := by
  have hb := quadraticDefect_inverse_lower_bound hu hv huv hp hσ hz.le (Or.inl hz)
  have hi := inverseDefectKernel_integrable hu hv huv hσ hz.le (Or.inl hz)
  have hpI : 0<∫t,inverseDefectKernel σ z t∂quadraticSpectralMeasure u v := by
    apply integral_pos_of_probability_ae hi
    filter_upwards [quadraticSpectralMeasure_support huv] with t ht
    exact div_pos (inverseResolventNumerator_pos_sector hκ hκ' hz (lt_of_lt_of_le hu ht.1) hy)
      (sq_pos_of_pos (Complex.normSq_pos.mpr (shifted_ne_zero (lt_of_lt_of_le hu ht.1) hz.le)))
  nlinarith [sq_nonneg ((quadraticRoot u v z)⁻¹).im]

end LeanVerification.WedgeCompletion
