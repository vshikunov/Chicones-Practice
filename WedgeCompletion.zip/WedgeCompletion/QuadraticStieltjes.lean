import LeanVerification.ContourCompletion.FractionalStieltjes
import LeanVerification.MiddleStripSpectral.WidthNormalization

/-!
# An actual positive Stieltjes representation for the quadratic resolvent

The beta weight is kept on `(0,∞)` and the finite-interval spectral coordinate
is the fractional-linear map `(u+v*s)/(1+s)`. This proves the integral identity
directly, including the collapsed case `u=v`, without assuming a spectral
representation or a change-of-variables formula at a singular endpoint.
-/

noncomputable section
open MeasureTheory Set Filter Metric
open scoped Topology

namespace LeanVerification.WedgeCompletion
open ContourCompletion

set_option maxHeartbeats 1000000
set_option maxRecDepth 4000

def quadraticSpectralPoint (u v s : ℝ) : ℝ := (u+v*s)/(1+s)

def quadraticRoot (u v : ℝ) (z : ℂ) : ℂ :=
  principalSquareRoot (z+(u:ℂ))*principalSquareRoot (z+(v:ℂ))

def quadraticStieltjes (u v : ℝ) (z : ℂ) : ℂ :=
  (fractionalMass (1/2):ℂ)⁻¹ *
    ∫ s in Ioi (0:ℝ), (fractionalWeight (1/2) s:ℂ)/(z+(quadraticSpectralPoint u v s:ℂ))

theorem quadraticSpectralPoint_pos {u v s : ℝ} (hu:0<u) (hv:0<v) (hs:0<s) :
    0<quadraticSpectralPoint u v s := by
  unfold quadraticSpectralPoint
  positivity

theorem quadraticSpectralPoint_mem {u v s : ℝ} (huv:u≤v) (hs:0<s) :
    quadraticSpectralPoint u v s∈Icc u v := by
  have hd:0<1+s := by linarith
  constructor
  · apply (le_div_iff₀ hd).2
    dsimp [quadraticSpectralPoint]
    nlinarith
  · apply (div_le_iff₀ hd).2
    nlinarith

theorem shifted_ne_zero {u:ℝ} {z:ℂ} (hu:0<u) (hz:0≤z.re) : z+(u:ℂ)≠0 := by
  intro he
  have := congrArg Complex.re he
  simp only [Complex.add_re,Complex.ofReal_re,Complex.zero_re] at this
  linarith

theorem quadratic_ratio_re_pos {u v:ℝ} {z:ℂ} (hu:0<u) (hv:0<v) (hz:0≤z.re) :
    0<((z+(u:ℂ))/(z+(v:ℂ))).re := by
  rw [Complex.div_re,←add_div]
  apply div_pos _ (Complex.normSq_pos.mpr (shifted_ne_zero hv hz))
  simp only [Complex.add_re,Complex.ofReal_re,Complex.add_im,Complex.ofReal_im,add_zero]
  nlinarith [sq_nonneg z.im]

theorem principalSquareRoot_cpow_neg_half {q:ℂ} (hq:q≠0) :
    q^((-((1/2):ℝ):ℝ):ℂ)=(principalSquareRoot q)⁻¹ := by
  rw [Complex.cpow_def_of_ne_zero hq,principalSquareRoot,←Complex.exp_neg]
  congr 1
  push_cast
  ring

theorem principalSquareRoot_product_re_pos {q r:ℂ} (hq:0<q.re) (hr:0<r.re) :
    0<(principalSquareRoot q*principalSquareRoot r).re := by
  have hq' := MiddleStripSpectral.principalSquareRoot_right_quadrant hq
  have hr' := MiddleStripSpectral.principalSquareRoot_right_quadrant hr
  have hq0 := lt_of_le_of_lt (abs_nonneg _) hq'
  have hr0 := lt_of_le_of_lt (abs_nonneg _) hr'
  have hmul := lt_of_le_of_lt
    (mul_le_mul_of_nonneg_right hq'.le (abs_nonneg _))
    (mul_lt_mul_of_pos_left hr' hq0)
  have him := le_abs_self ((principalSquareRoot q).im*(principalSquareRoot r).im)
  rw [abs_mul] at him
  rw [Complex.mul_re]
  linarith

theorem principalSquareRoot_ratio_mul {u v:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (hz:0≤z.re) :
    principalSquareRoot ((z+(u:ℂ))/(z+(v:ℂ)))*principalSquareRoot (z+(v:ℂ)) =
      principalSquareRoot (z+(u:ℂ)) := by
  have hu0 := shifted_ne_zero hu hz
  have hv0 := shifted_ne_zero hv hz
  have hq0 := div_ne_zero hu0 hv0
  have hsq :
      (principalSquareRoot ((z+(u:ℂ))/(z+(v:ℂ)))*principalSquareRoot (z+(v:ℂ)))^2 =
        (principalSquareRoot (z+(u:ℂ)))^2 := by
    rw [mul_pow,principalSquareRoot_square hq0,principalSquareRoot_square hv0,
      principalSquareRoot_square hu0,div_mul_cancel₀ _ hv0]
  have ha := principalSquareRoot_product_re_pos (quadratic_ratio_re_pos hu hv hz)
    (show 0<(z+(v:ℂ)).re by simpa using (add_pos_of_nonneg_of_pos hz hv))
  have hb := principalSquareRoot_re_pos_slit
    (Or.inl (show 0<(z+(u:ℂ)).re by simpa using (add_pos_of_nonneg_of_pos hz hu)))
  have hfactor :
      (principalSquareRoot ((z+(u:ℂ))/(z+(v:ℂ)))*principalSquareRoot (z+(v:ℂ))-
          principalSquareRoot (z+(u:ℂ)))*
        (principalSquareRoot ((z+(u:ℂ))/(z+(v:ℂ)))*principalSquareRoot (z+(v:ℂ))+
          principalSquareRoot (z+(u:ℂ)))=0 := by
    linear_combination hsq
  rcases mul_eq_zero.mp hfactor with h | h
  · exact sub_eq_zero.mp h
  · have he := congrArg Complex.re h
    simp only [Complex.add_re,Complex.zero_re] at he
    linarith

theorem quadraticRoot_square {u v:ℝ} {z:ℂ} (hu:0<u) (hv:0<v) (hz:0≤z.re) :
    quadraticRoot u v z ^ 2=(z+(u:ℂ))*(z+(v:ℂ)) := by
  rw [quadraticRoot,mul_pow,principalSquareRoot_square (shifted_ne_zero hu hz),
    principalSquareRoot_square (shifted_ne_zero hv hz)]

theorem quadraticRoot_re_pos {u v:ℝ} {z:ℂ} (hu:0<u) (hv:0<v) (hz:0≤z.re) :
    0<(quadraticRoot u v z).re := by
  exact principalSquareRoot_product_re_pos
    (show 0<(z+(u:ℂ)).re by simpa using (add_pos_of_nonneg_of_pos hz hu))
    (show 0<(z+(v:ℂ)).re by simpa using (add_pos_of_nonneg_of_pos hz hv))

theorem quadratic_kernel_transform {u v s:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (hz:0≤z.re) (hs:0<s) :
    (fractionalWeight (1/2) s:ℂ)/(z+(quadraticSpectralPoint u v s:ℂ)) =
      ((s^(-((1/2):ℝ)):ℝ)/((z+(u:ℂ))/(z+(v:ℂ))+(s:ℂ)))/(z+(v:ℂ)) := by
  have hd : (1+(s:ℂ))≠0 := by exact_mod_cast (ne_of_gt (by linarith : 0<1+s))
  have hv0 := shifted_ne_zero hv hz
  unfold fractionalWeight quadraticSpectralPoint
  push_cast
  rw [div_div,div_div]
  congr 1
  field_simp
  <;> ring

theorem quadratic_kernel_integrable {u v:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (hz:0≤z.re) :
    IntegrableOn (fun s:ℝ =>
      (fractionalWeight (1/2) s:ℂ)/(z+(quadraticSpectralPoint u v s:ℂ))) (Ioi 0) := by
  have hi := (fractionalStieltjes_integrable (by norm_num : (0:ℝ)<1/2)
    (by norm_num : (1/2:ℝ)<1)
    (Or.inl (quadratic_ratio_re_pos hu hv hz))).div_const (z+(v:ℂ))
  apply hi.congr
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with s hs
  exact (quadratic_kernel_transform hu hv hz hs).symm

/-- The normalized positive beta weight gives the actual reciprocal of the
positive quadratic root throughout the closed right half-plane. -/
theorem quadraticStieltjes_eq_inverse {u v:ℝ} {z:ℂ}
    (hu:0<u) (hv:0<v) (hz:0≤z.re) :
    quadraticStieltjes u v z=(quadraticRoot u v z)⁻¹ := by
  have hm : (fractionalMass (1/2):ℂ)≠0 := by
    exact_mod_cast (fractionalMass_pos (by norm_num : (0:ℝ)<1/2)
      (by norm_num : (1/2:ℝ)<1)).ne'
  have hu0 := shifted_ne_zero hu hz
  have hv0 := shifted_ne_zero hv hz
  have hq0 := div_ne_zero hu0 hv0
  have he : (∫ s in Ioi (0:ℝ),
      (fractionalWeight (1/2) s:ℂ)/(z+(quadraticSpectralPoint u v s:ℂ))) =
      fractionalStieltjes (1/2) ((z+(u:ℂ))/(z+(v:ℂ)))/(z+(v:ℂ)) := by
    rw [fractionalStieltjes,←integral_div]
    apply setIntegral_congr_fun measurableSet_Ioi
    intro s hs
    exact quadratic_kernel_transform hu hv hz hs
  rw [quadraticStieltjes,he,fractionalStieltjes_eq_cpow
    (by norm_num : (0:ℝ)<1/2) (by norm_num : (1/2:ℝ)<1)
    (Or.inl (quadratic_ratio_re_pos hu hv hz)),principalSquareRoot_cpow_neg_half hq0]
  have hvroot : principalSquareRoot (z+(v:ℂ))≠0 := by
    unfold principalSquareRoot
    exact Complex.exp_ne_zero _
  have hqroot : principalSquareRoot ((z+(u:ℂ))/(z+(v:ℂ)))≠0 := by
    unfold principalSquareRoot
    exact Complex.exp_ne_zero _
  have heprod : principalSquareRoot (z+(u:ℂ))*principalSquareRoot (z+(v:ℂ)) =
      principalSquareRoot ((z+(u:ℂ))/(z+(v:ℂ)))*(z+(v:ℂ)) := by
    rw [←principalSquareRoot_ratio_mul hu hv hz,mul_assoc,←pow_two,
      principalSquareRoot_square hv0]
  unfold quadraticRoot
  rw [heprod]
  field_simp

end LeanVerification.WedgeCompletion
