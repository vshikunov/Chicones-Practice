import LeanVerification.RegionalSeamCompletion.UpperEnergy
import LeanVerification.Loud.CompactAnalyticIntegral
import LeanVerification.GeneralMechanical.JointDivision

/-! Transport of an already proved interior period comparison to F=1. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalSeamCompletion
open Loud GeneralMechanical
set_option maxHeartbeats 6400000

theorem tendsto_actual_period_energy_derivative {α : Type*} {l : Filter α}
    {q : α→PeriodParameterSpace} {D F h : ℝ}
    (hq : Tendsto q l (𝓝 ((D,F),h))) (hh : AdmissibleEnergy D F h) :
    Tendsto (fun a => deriv (periodQuadrature (q a).1.1 (q a).1.2) (q a).2) l
      (𝓝 (deriv (periodQuadrature D F) h)) := by
  let P := fun q:PeriodParameterSpace => periodQuadrature q.1.1 q.1.2 q.2
  have ha : AnalyticAt ℝ P ((D,F),h) := analyticAt_periodQuadrature_joint D F h hh
  have hl := (analyticAt_verticalDerivative ha).continuousAt.tendsto.comp hq
  rw [verticalDerivative_eq_deriv ha] at hl
  apply hl.congr'
  filter_upwards [hq.eventually (isOpen_admissibleEnergy_joint.mem_nhds hh)] with a had
  exact verticalDerivative_eq_deriv (analyticAt_periodQuadrature_joint _ _ _ had)

theorem upper_physical_F_one_comparison_limit {d h : ℝ} {c : ℝ→ℝ}
    (hd : 0≤d) (hdu : d≤1/9) (hc : ContinuousAt c 0) (hc0 : c 0=1/9)
    (hh : AdmissibleEnergy (upperSeamD d) 1 h)
    (hcomparison : ∀ᶠ b in 𝓝[>] (0:ℝ),
      upperSeamA b (c b)*deriv (periodQuadrature (upperSeamD (c b)) (upperSeamF b))
        (h*upperSeamA b (c b)/upperSeamA b d)≤
      upperSeamA b d*deriv (periodQuadrature (upperSeamD d) (upperSeamF b)) h) :
    (9/10)*deriv (periodQuadrature (-9/10) 1) ((9/10)*(1+d)*h)≤
      deriv (periodQuadrature (upperSeamD d) 1) h/(1+d) := by
  have hd1 : 0<1+d := by linarith
  have hF : ContinuousAt upperSeamF 0 := by
    unfold upperSeamF
    exact continuousAt_const.div (continuousAt_const.sub continuousAt_id) (by norm_num)
  have hDc : ContinuousAt (fun b => upperSeamD (c b)) 0 := by
    unfold upperSeamD
    exact continuousAt_const.div (continuousAt_const.add hc) (by rw [hc0];norm_num)
  have hAc : ContinuousAt (fun b => upperSeamA b (c b)) 0 := by
    unfold upperSeamA
    exact (continuousAt_const.add (continuousAt_id.mul hc)).div
      (continuousAt_const.add hc) (by rw [hc0];norm_num)
  have hAd : ContinuousAt (fun b => upperSeamA b d) 0 := by
    unfold upperSeamA
    exact (continuousAt_const.add (continuousAt_id.mul continuousAt_const)).div_const _
  have hAcd : upperSeamA 0 (c 0)=(9/10:ℝ) := by norm_num [upperSeamA,hc0]
  have hAdd : upperSeamA 0 d=1/(1+d) := by simp [upperSeamA]
  have hDcd : upperSeamD (c 0)=(-9/10:ℝ) := by norm_num [upperSeamD,hc0]
  have hF0 : upperSeamF 0=1 := by norm_num [upperSeamF]
  have henergy : ContinuousAt (fun b => h*upperSeamA b (c b)/upperSeamA b d) 0 :=
    (continuousAt_const.mul hAc).div hAd (by rw [hAdd];exact (one_div_pos.mpr hd1).ne')
  have he0 : h*upperSeamA 0 (c 0)/upperSeamA 0 d=(9/10)*(1+d)*h := by
    rw [hAcd,hAdd]
    field_simp [hd1.ne']
    <;> ring
  have hpL : Tendsto (fun b => ((upperSeamD (c b),upperSeamF b),
      h*upperSeamA b (c b)/upperSeamA b d)) (𝓝[>] (0:ℝ))
        (𝓝 (((-9/10:ℝ),1),(9/10)*(1+d)*h)) := by
    simpa only [hDcd,hF0,he0] using
      ((hDc.prodMk hF).prodMk henergy).tendsto.mono_left nhdsWithin_le_nhds
  have hpR : Tendsto (fun b => ((upperSeamD d,upperSeamF b),h)) (𝓝[>] (0:ℝ))
      (𝓝 ((upperSeamD d,1),h)) := by
    simpa only [hF0] using ((continuousAt_const.prodMk hF).prodMk continuousAt_const).tendsto.mono_left nhdsWithin_le_nhds
  have hl := (hAc.tendsto.mono_left nhdsWithin_le_nhds).mul
    (tendsto_actual_period_energy_derivative hpL (upperSeam_boundary_admissible hd hdu hh))
  have hr := (hAd.tendsto.mono_left nhdsWithin_le_nhds).mul
    (tendsto_actual_period_energy_derivative hpR hh)
  rw [hAcd] at hl
  rw [hAdd] at hr
  have hle := le_of_tendsto_of_tendsto hl hr hcomparison
  simpa only [one_div,mul_comm,div_eq_mul_inv,one_mul] using hle

theorem upper_physical_F_one_positive {d h : ℝ} {c : ℝ→ℝ}
    (hd : 0≤d) (hdu : d≤1/9) (hc : ContinuousAt c 0) (hc0 : c 0=1/9)
    (hh : AdmissibleEnergy (upperSeamD d) 1 h)
    (hboundary : 0<deriv (periodQuadrature (-9/10) 1) ((9/10)*(1+d)*h))
    (hcomparison : ∀ᶠ b in 𝓝[>] (0:ℝ),
      upperSeamA b (c b)*deriv (periodQuadrature (upperSeamD (c b)) (upperSeamF b))
        (h*upperSeamA b (c b)/upperSeamA b d)≤
      upperSeamA b d*deriv (periodQuadrature (upperSeamD d) (upperSeamF b)) h) :
    0<deriv (periodQuadrature (upperSeamD d) 1) h := by
  have hle := upper_physical_F_one_comparison_limit hd hdu hc hc0 hh hcomparison
  have hp : 0<deriv (periodQuadrature (upperSeamD d) 1) h/(1+d) :=
    (mul_pos (by norm_num : (0:ℝ)<9/10) hboundary).trans_le hle
  simpa only [zero_mul] using (lt_div_iff₀ (by linarith : 0<1+d)).mp hp

end LeanVerification.RegionalSeamCompletion
