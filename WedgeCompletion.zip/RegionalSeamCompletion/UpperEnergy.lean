import LeanVerification.Loud.Well
import Mathlib.Tactic.Positivity

/-! Energy admissibility at the logarithmic seam, proved from the actual potential. -/
noncomputable section
open Set
namespace LeanVerification.RegionalSeamCompletion
open Loud
set_option maxHeartbeats 4000000

def upperSeamD (d : ℝ) : ℝ := -1/(1+d)
def upperSeamF (b : ℝ) : ℝ := 1/(1-b)
def upperSeamA (b d : ℝ) : ℝ := (1+b*d)/(1+d)

theorem upperSeam_central {d w : ℝ} (hd : 0≤d) (hw : 0<w) :
    inCentralInterval (upperSeamD d) w := by
  have hd1 : 0<1+d := by linarith
  refine ⟨hw,?_⟩
  have he : (upperSeamD d+1)*w-upperSeamD d=(d*w+1)/(1+d) := by
    unfold upperSeamD
    field_simp [hd1.ne']
    <;> ring
  rw [he]
  exact div_pos (by positivity) hd1

theorem upperSeam_potential_difference {d e w : ℝ} (hd : -1<d) (he : -1<e) :
    (1+e)*potential (upperSeamD e) 1 w-(1+d)*potential (upperSeamD d) 1 w=
      (e-d)*(w-1)^2/2 := by
  have hp (D:ℝ) : potential D 1 w=(D+1)*(w^2-1)/2-(2*D+1)*(w-1)+D*Real.log w := by
    norm_num [potential,powerIncrement,Real.rpow_two,Real.rpow_one]
    <;> ring
  rw [hp,hp]
  unfold upperSeamD
  have hd0 : 1+d≠0 := by linarith
  have he0 : 1+e≠0 := by linarith
  generalize hdd : 1+d=dd at *
  generalize hee : 1+e=ee at *
  field_simp [hd0,he0]
  rw [←hdd,←hee]
  ring

theorem upperSeam_admissible_energy_mono {d e h : ℝ}
    (hd : 0≤d) (hde : d≤e) (hh : AdmissibleEnergy (upperSeamD d) 1 h) :
    AdmissibleEnergy (upperSeamD e) 1 ((1+d)*h/(1+e)) := by
  have he : 0≤e := hd.trans hde
  have hd1 : 0<1+d := by linarith
  have he1 : 0<1+e := by linarith
  have hpot (w:ℝ) (hwh : h<potential (upperSeamD d) 1 w) :
      (1+d)*h/(1+e)<potential (upperSeamD e) 1 w := by
    apply (div_lt_iff₀ he1).mpr
    have hmul := mul_lt_mul_of_pos_left hwh hd1
    have hdiff := upperSeam_potential_difference (w:=w) (by linarith : -1<d) (by linarith : -1<e)
    have hn : 0≤(e-d)*(w-1)^2/2 := div_nonneg
      (mul_nonneg (sub_nonneg.mpr hde) (sq_nonneg _)) (by norm_num)
    nlinarith only [hmul,hdiff,hn]
  refine ⟨div_pos (mul_pos hd1 hh.1) he1,?_,?_⟩
  · obtain ⟨w,hw,hw1,hwh⟩ := hh.2.1
    exact ⟨w,upperSeam_central he hw.1,hw1,hpot w hwh⟩
  · obtain ⟨w,hw,hw1,hwh⟩ := hh.2.2
    exact ⟨w,upperSeam_central he hw.1,hw1,hpot w hwh⟩

theorem upperSeam_boundary_admissible {d h : ℝ} (hd : 0≤d) (hdu : d≤1/9)
    (hh : AdmissibleEnergy (upperSeamD d) 1 h) :
    AdmissibleEnergy (-9/10) 1 ((9/10)*(1+d)*h) := by
  have hm := upperSeam_admissible_energy_mono hd hdu hh
  norm_num [upperSeamD] at hm
  convert hm using 1 <;> ring

end LeanVerification.RegionalSeamCompletion
