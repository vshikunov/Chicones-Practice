import LeanVerification.UpperStripCompletion.JacobiForceAlgebra

/-! The force comparison function and its actual derivatives, including
the double zeros at regular turning points. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 1600000

def forceInvariantAt (W : ℝ → ℝ) (x : ℝ) : ℝ :=
  forceInvariant (deriv W x) (deriv (deriv W) x)
    (deriv (deriv (deriv W)) x) (deriv (deriv (deriv (deriv W))) x)
    (deriv (deriv (deriv (deriv (deriv W)))) x)

def jacobiC (W Y : ℝ → ℝ) (L x : ℝ) : ℝ :=
  jacobiCValue (L-W x) (deriv W x) (deriv (deriv (deriv W)) x)
    (deriv (deriv (deriv (deriv W))) x) (Y x) (deriv (deriv Y) x)

def jacobiC1 (W Y : ℝ → ℝ) (L x : ℝ) : ℝ :=
  jacobiCPrime (L-W x) (deriv W x) (deriv (deriv W) x)
    (deriv (deriv (deriv W)) x) (deriv (deriv (deriv (deriv W))) x)
    (deriv (deriv (deriv (deriv (deriv W)))) x)
    (Y x) (deriv Y x) (deriv (deriv Y) x) (deriv (deriv (deriv Y)) x)

def jacobiC2 (W Y : ℝ → ℝ) (L x : ℝ) : ℝ :=
  let v := L-W x
  let g := deriv W x
  let k := deriv (deriv W) x
  let f := deriv (deriv (deriv W)) x
  let t := deriv (deriv (deriv (deriv W))) x
  let u := deriv (deriv (deriv (deriv (deriv W)))) x
  let w := deriv (deriv (deriv (deriv (deriv (deriv W))))) x
  3*(5*f^2+12*k*t+9*g*u-2*v*w)*deriv (deriv Y) x+
    6*(5*k*f+7*g*t-2*v*u)*deriv (deriv (deriv Y)) x+
    3*forceAuxiliary v g f t*deriv (deriv (deriv (deriv Y))) x-
    10*(t^2+f*u)*Y x-20*f*t*deriv Y x-5*f^2*deriv (deriv Y) x

theorem analyticAt_jacobiC {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x) :
    AnalyticAt ℝ (jacobiC W Y L) x := by
  exact (((analyticAt_const.mul ((analyticAt_const.mul hW.deriv).mul hW.deriv.deriv.deriv
    |>.sub ((analyticAt_const.mul (analyticAt_const.sub hW)).mul
      hW.deriv.deriv.deriv.deriv))).mul hY.deriv.deriv).sub
        ((analyticAt_const.mul (hW.deriv.deriv.deriv.pow 2)).mul hY))

theorem hasDerivAt_jacobiC {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x) :
    HasDerivAt (jacobiC W Y L) (jacobiC1 W Y L x) x := by
  have dv := hW.differentiableAt.hasDerivAt.const_sub L
  have dg := hW.deriv.differentiableAt.hasDerivAt
  have df := hW.deriv.deriv.deriv.differentiableAt.hasDerivAt
  have dt := hW.deriv.deriv.deriv.deriv.differentiableAt.hasDerivAt
  have dA := ((dg.const_mul 5).mul df).sub ((dv.const_mul 2).mul dt)
  have hd := ((dA.const_mul 3).mul hY.deriv.deriv.differentiableAt.hasDerivAt).sub
    (((df.pow 2).const_mul 5).mul hY.differentiableAt.hasDerivAt)
  convert hd using 1 <;> simp only [jacobiC,jacobiC1,jacobiCValue,jacobiCPrime,forceAuxiliary] <;> ring

theorem hasDerivAt_jacobiC1 {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x) :
    HasDerivAt (jacobiC1 W Y L) (jacobiC2 W Y L x) x := by
  have dv := hW.differentiableAt.hasDerivAt.const_sub L
  have dg := hW.deriv.differentiableAt.hasDerivAt
  have dk := hW.deriv.deriv.differentiableAt.hasDerivAt
  have df := hW.deriv.deriv.deriv.differentiableAt.hasDerivAt
  have dt := hW.deriv.deriv.deriv.deriv.differentiableAt.hasDerivAt
  have du := hW.deriv.deriv.deriv.deriv.deriv.differentiableAt.hasDerivAt
  have dA := ((dg.const_mul 5).mul df).sub ((dv.const_mul 2).mul dt)
  have dB := (((dk.const_mul 5).mul df).add ((dg.const_mul 7).mul dt)).sub
    ((dv.const_mul 2).mul du)
  have hd := (((((dB.const_mul 3).mul hY.deriv.deriv.differentiableAt.hasDerivAt).add
    ((dA.const_mul 3).mul hY.deriv.deriv.deriv.differentiableAt.hasDerivAt)).sub
      (((df.const_mul 10).mul dt).mul hY.differentiableAt.hasDerivAt)).sub
        (((df.pow 2).const_mul 5).mul hY.deriv.differentiableAt.hasDerivAt))
  convert hd using 1 <;> simp only [jacobiC1,jacobiC2,jacobiCPrime,forceAuxiliary] <;> ring

theorem jacobiC_second_derivative {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x) :
    deriv (deriv (jacobiC W Y L)) x=jacobiC2 W Y L x := by
  have he : deriv (jacobiC W Y L) =ᶠ[𝓝 x] jacobiC1 W Y L := by
    filter_upwards [hW.eventually_analyticAt,hY.eventually_analyticAt] with z hzW hzY
    exact (hasDerivAt_jacobiC hzW hzY).deriv
  rw [he.deriv_eq,(hasDerivAt_jacobiC1 hW hY).deriv]

theorem jacobiC_turn_jets {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1)
    (hv : L-W x=0) (hg : deriv W x≠0) :
    jacobiC W Y L x=0 ∧ deriv (jacobiC W Y L) x=0 ∧
      deriv (deriv (jacobiC W Y L)) x=-8*forceInvariantAt W x/(105*deriv W x^2) := by
  obtain ⟨hy,hy₁,hy₂,hy₃,hy₄⟩ := jacobi_turn_jets hW hY he hv hg
  obtain ⟨hc,hc₁,hc₂⟩ := jacobi_C_turn_values
    (k := deriv (deriv W) x) (f := deriv (deriv (deriv W)) x)
    (t := deriv (deriv (deriv (deriv W))) x)
    (u := deriv (deriv (deriv (deriv (deriv W)))) x) hg
  constructor
  · simpa only [jacobiC,hv,hy,hy₂] using hc
  constructor
  · rw [(hasDerivAt_jacobiC hW hY).deriv]
    simpa only [jacobiC1,hv,hy,hy₁,hy₂,hy₃] using hc₁
  · rw [jacobiC_second_derivative hW hY]
    simp only [jacobiC2,hv,zero_mul,mul_zero,sub_zero,forceAuxiliary,
      hy,hy₁,hy₂,hy₃,hy₄,forceInvariantAt]
    convert hc₂ using 1 <;> ring

theorem jacobiC_derivative_at_zero {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1)
    (hv : L-W x≠0) (hg : deriv W x≠0)
    (hf : deriv (deriv (deriv W)) x≠0) (hC : jacobiC W Y L x=0) :
    deriv (jacobiC W Y L) x=
      2*(L-W x)*deriv (deriv Y) x*forceInvariantAt W x/
        (5*deriv W x*deriv (deriv (deriv W)) x) := by
  rw [(hasDerivAt_jacobiC hW hY).deriv]
  exact jacobi_C_derivative_at_zero hv hg hf (jacobi_second_at hW hY he)
    (jacobi_third_at hW hY he) hC

end LeanVerification.UpperStripCompletion
