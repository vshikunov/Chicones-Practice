import LeanVerification.UpperStripCompletion.UpperForcePolynomial

/-! Uniform force-invariant sign on the entire large-d chamber,
including the logarithmic b=0 edge and its isolated center zero. -/
noncomputable section
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 2200000

theorem upper_coefficients_large_d {b d : ℝ} (hb : 0≤b) (hb1 : b≤1/5)
    (hd : 1/9≤d) (hd1 : d≤1) :
    0<upperA0 b ∧ 0<upperA2 b d ∧ 0≤upperA3 b d ∧ 0≤upperA4 b d ∧
      0<upperKPolynomial b := by
  have h1 : 0<1+b := by linarith
  have h2 : 0<1-2*b := by linarith
  have h4 : 0<1-4*b := by linarith
  have h3 : 0<3-2*b := by linarith
  have hdm : 0≤1-d := by linarith
  have hdp : 0<d := by linarith
  have hbB : 0<upperBPolynomial b := lt_of_lt_of_le (by norm_num : (0:ℝ)<4)
    (upper_b_polynomial_lower hb hb1)
  have hb2 : b^2≤(1/5:ℝ)^2 := pow_le_pow_left₀ hb hb1 2
  have h31 : 0<31-12*b-3*b^2 := by nlinarith
  have h5 : 0<2-b := by linarith
  have h6 : 0<b+3 := by linarith
  have h7 : 0<2*b+1 := by linarith
  unfold upperA0 upperA2 upperA3 upperA4 upperKPolynomial
  exact ⟨by positivity,by positivity,by positivity,by positivity,by positivity⟩

theorem upper_discriminant_nonpos_large_d {b d : ℝ} (hb : 0≤b) (hb1 : b≤1/5)
    (hd : 1/9≤d) (hd1 : d≤1) :
    (upperA1 b d)^2-4*upperA0 b*upperA2 b d≤0 := by
  rw [upper_discriminant_certificate]
  apply mul_nonpos_of_nonneg_of_nonpos (by positivity)
  have hK := (upper_coefficients_large_d hb hb1 hd hd1).2.2.2.2
  have hJ := upper_j_polynomial_lower hb hb1
  have hbound : 64*upperHPolynomial b≤9*upperKPolynomial b := by
    have hh := upper_discriminant_comparison b
    have hp : 0≤64*b*upperJPolynomial b := by positivity
    linarith only [hh,hp]
  by_cases hH : upperHPolynomial b≤0
  · have ht : upperHPolynomial b*(1-d)^2≤0 := mul_nonpos_of_nonpos_of_nonneg hH (sq_nonneg _)
    have ht2 : 0≤upperKPolynomial b*d := mul_nonneg hK.le (by linarith)
    linarith only [ht,ht2]
  · have hHn : 0≤upperHPolynomial b := le_of_lt (lt_of_not_ge hH)
    have hs : (1-d)^2≤64/81 := by nlinarith [sq_nonneg (d-1/9)]
    have hmul := mul_nonneg hHn (sub_nonneg.mpr hs)
    have hmul2 := mul_nonneg hK.le (sub_nonneg.mpr hd)
    nlinarith only [hbound,hmul,hmul2]

theorem upper_discriminant_neg_large_d {b d : ℝ} (hb : 0<b) (hb1 : b≤1/5)
    (hd : 1/9≤d) (hd1 : d≤1) :
    (upperA1 b d)^2-4*upperA0 b*upperA2 b d<0 := by
  rw [upper_discriminant_certificate]
  have h2 : 0<1-2*b := by linarith
  apply mul_neg_of_pos_of_neg (by positivity)
  have hK := (upper_coefficients_large_d hb.le hb1 hd hd1).2.2.2.2
  have hJ := upper_j_polynomial_lower hb.le hb1
  have hbound : 64*upperHPolynomial b<9*upperKPolynomial b := by
    have hh := upper_discriminant_comparison b
    have hp : 0<64*b*upperJPolynomial b := by positivity
    linarith only [hh,hp]
  by_cases hH : upperHPolynomial b≤0
  · have ht : upperHPolynomial b*(1-d)^2≤0 := mul_nonpos_of_nonpos_of_nonneg hH (sq_nonneg _)
    have ht2 : 0<upperKPolynomial b*d := mul_pos hK (by linarith)
    linarith only [ht,ht2]
  · have hHn : 0≤upperHPolynomial b := le_of_lt (lt_of_not_ge hH)
    have hs : (1-d)^2≤64/81 := by nlinarith [sq_nonneg (d-1/9)]
    have hmul := mul_nonneg hHn (sub_nonneg.mpr hs)
    have hmul2 := mul_nonneg hK.le (sub_nonneg.mpr hd)
    nlinarith only [hbound,hmul,hmul2]

theorem upper_quartic_nonpos_large_d {b d x : ℝ} (hb : 0≤b) (hb1 : b≤1/5)
    (hd : 1/9≤d) (hd1 : d≤1) (hx : 0<x) : upperForceQuartic b d x≤0 := by
  obtain ⟨hA0,hA2,hA3,hA4,hK⟩ := upper_coefficients_large_d hb hb1 hd hd1
  have he := upper_quartic_square_certificate b d x
  have hD := upper_discriminant_nonpos_large_d hb hb1 hd hd1
  have h3 : 0≤4*upperA2 b d*upperA3 b d*x^3 := by positivity
  have h4 : 0≤4*upperA2 b d*upperA4 b d*x^4 := by positivity
  have hprod : 4*upperA2 b d*upperForceQuartic b d x≤0 := by nlinarith only [he,hD,h3,h4,sq_nonneg (2*upperA2 b d*x-upperA1 b d)]
  exact nonpos_of_mul_nonpos_right hprod (by positivity : 0<4*upperA2 b d)

theorem upper_quartic_neg_large_d {b d x : ℝ} (hb : 0<b) (hb1 : b≤1/5)
    (hd : 1/9≤d) (hd1 : d≤1) (hx : 0<x) : upperForceQuartic b d x<0 := by
  obtain ⟨hA0,hA2,hA3,hA4,hK⟩ := upper_coefficients_large_d hb.le hb1 hd hd1
  have he := upper_quartic_square_certificate b d x
  have hD := upper_discriminant_neg_large_d hb hb1 hd hd1
  have h3 : 0≤4*upperA2 b d*upperA3 b d*x^3 := by positivity
  have h4 : 0≤4*upperA2 b d*upperA4 b d*x^4 := by positivity
  have hprod : 4*upperA2 b d*upperForceQuartic b d x<0 := by nlinarith only [he,hD,h3,h4,sq_nonneg (2*upperA2 b d*x-upperA1 b d)]
  exact neg_of_mul_neg_right hprod (by positivity : 0≤4*upperA2 b d)

theorem upper_quartic_logarithmic_certificate (d x : ℝ) :
    upperForceQuartic 0 d x= -8*(x-1)^2-18*(d-1/9)*x*(1+4*x) := by
  unfold upperForceQuartic upperA0 upperA1 upperA2 upperA3 upperA4 upperTPolynomial upperBPolynomial
  ring

theorem upper_quartic_logarithmic_neg {d x : ℝ} (hd : 1/9≤d) (hx : 0<x) (hx1 : x≠1) :
    upperForceQuartic 0 d x<0 := by
  rw [upper_quartic_logarithmic_certificate]
  have hdp : 0≤d-1/9 := sub_nonneg.mpr hd
  have hp : 0≤18*(d-1/9)*x*(1+4*x) := by positivity
  have hs : 0<(x-1)^2 := sq_pos_of_ne_zero (sub_ne_zero.mpr hx1)
  linarith only [hp,hs]

end LeanVerification.UpperStripCompletion
