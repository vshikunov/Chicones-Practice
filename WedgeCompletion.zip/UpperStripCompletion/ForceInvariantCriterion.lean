import LeanVerification.UpperStripCompletion.JacobiMomentIdentities
import LeanVerification.AnalyticMultiplicity

/-! The Jacobi--Stein force-invariant criterion for actual complete
mechanical periods, including a possible zero of N at the force center.
Neither a Jacobi solution, an endpoint estimate, a moment identity nor a
period curvature implication appears among the hypotheses. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical GeneralMechanical.EnergyModes
set_option maxHeartbeats 1800000

theorem actual_jacobi_stein_identity {W a b : ℝ → ℝ} {L : ℝ}
    (h : RegularEnergyWell W a b L) (hstat : deriv (period W a b) L=0)
    (hk : ∀ x ∈ Icc (a L) (b L), 0<deriv (deriv W) x)
    (hf : ∀ x ∈ Icc (a L) (b L), deriv (deriv (deriv W)) x≠0) :
    deriv (deriv (period W a b)) L=12*Real.sqrt 2*
      ∫ x in a L..b L, jacobiWeight W L x*stationaryVariation W a b L x*
        jacobiB W (stationaryVariation W a b L) L (a L) (b L) x := by
  rw [(actual_jacobi_curvature_identity h hstat hk).2,
    (jacobi_comparison_integral_identity h (h.analytic_stationaryVariation hstat)
      (h.stationaryVariation_equation hstat) hf).2]
  ring

theorem force_invariant_stationary_curvature_positive {W a b : ℝ → ℝ} {L : ℝ}
    (h : RegularEnergyWell W a b L) (hstat : deriv (period W a b) L=0)
    (hk : ∀ x ∈ Icc (a L) (b L), 0<deriv (deriv W) x)
    (hf : ∀ x ∈ Icc (a L) (b L), deriv (deriv (deriv W)) x<0)
    (hN : ∀ x ∈ Icc (a L) (b L), forceInvariantAt W x≤0)
    (hNs : ∀ x ∈ Icc (a L) (b L), deriv W x≠0 → forceInvariantAt W x<0) :
    0<deriv (deriv (period W a b)) L := by
  rw [actual_jacobi_stein_identity h hstat hk (fun x hx => (hf x hx).ne)]
  apply mul_pos (by positivity)
  exact jacobi_comparison_moment_positive h.turns_ordered h.analytic_potential
    (h.analytic_stationaryVariation hstat) (h.stationaryVariation_equation hstat)
    (sub_eq_zero.mp h.root_left.self_of_nhds).symm (sub_eq_zero.mp h.root_right.self_of_nhds).symm
    h.force_left h.force_right h.positive_gap hk hf hN hNs

theorem force_invariant_critical_bound_one {W a b : ℝ → ℝ} {E₀ E₁ : ℝ}
    (hw : ∀ L ∈ Ioo E₀ E₁, RegularEnergyWell W a b L)
    (hk : ∀ L ∈ Ioo E₀ E₁, ∀ x ∈ Icc (a L) (b L), 0<deriv (deriv W) x)
    (hf : ∀ L ∈ Ioo E₀ E₁, ∀ x ∈ Icc (a L) (b L), deriv (deriv (deriv W)) x<0)
    (hN : ∀ L ∈ Ioo E₀ E₁, ∀ x ∈ Icc (a L) (b L), forceInvariantAt W x≤0)
    (hNs : ∀ L ∈ Ioo E₀ E₁, ∀ x ∈ Icc (a L) (b L),
      deriv W x≠0 → forceInvariantAt W x<0) :
    AnalyticMultiplicity.MultiplicityBound 1 (deriv (period W a b)) (Ioo E₀ E₁) := by
  apply AnalyticMultiplicity.multiplicityBound_one_of_deriv_pos_at_zeros
    (fun L hL => (hw L hL).analytic_period.deriv)
  intro L hL hstat
  exact force_invariant_stationary_curvature_positive (hw L hL) hstat
    (hk L hL) (hf L hL) (hN L hL) (hNs L hL)

end LeanVerification.UpperStripCompletion
