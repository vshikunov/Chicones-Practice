import LeanVerification.UpperStripCompletion.JacobiBComparison

/-! Strict finite-interval moment comparison with a proved zero first
moment.  This is the real-variable form of the Jacobi--Stein step. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 1600000

theorem weighted_moment_strictly_positive {ρ Y B : ℝ → ℝ} {a b q : ℝ}
    (hq : q ∈ Ioo a b) (hρ : ContinuousOn ρ (Icc a b))
    (hY : ContinuousOn Y (Icc a b)) (hB : ContinuousOn B (Icc a b))
    (hρn : ∀ x ∈ Icc a b, 0≤ρ x) (hρp : ∀ x ∈ Ioo a b, 0<ρ x)
    (hYq : Y q=0) (hYm : ∀ x ∈ Icc a b, x<q → Y x<0)
    (hYp : ∀ x ∈ Icc a b, q<x → 0<Y x) (hBm : StrictMonoOn B (Icc a b))
    (hzero : (∫ x in a..b, ρ x*Y x)=0) :
    0<∫ x in a..b, ρ x*Y x*B x := by
  have hab := hq.1.trans hq.2
  have hqc := Ioo_subset_Icc_self hq
  let F : ℝ → ℝ := fun x => ρ x*(Y x*(B x-B q))
  have hFc : ContinuousOn F (Icc a b) := hρ.mul (hY.mul (hB.sub continuousOn_const))
  have hnonneg : ∀ x ∈ Icc a b, 0≤F x := by
    intro x hx
    apply mul_nonneg (hρn x hx)
    rcases lt_trichotomy x q with hxq | rfl | hqx
    · exact (mul_pos_of_neg_of_neg (hYm x hx hxq) (sub_neg.mpr (hBm hx hqc hxq))).le
    · simp only [hYq,zero_mul,le_refl]
    · exact (mul_pos (hYp x hx hqx) (sub_pos.mpr (hBm hqc hx hqx))).le
  let c := (a+q)/2
  have hac : a<c := by dsimp [c]; linarith [hq.1]
  have hcq : c<q := by dsimp [c]; linarith [hq.1]
  have hci : c ∈ Ioo a b := ⟨hac,hcq.trans hq.2⟩
  have hcc := Ioo_subset_Icc_self hci
  have hFcpos : 0<F c := mul_pos (hρp c hci)
    (mul_pos_of_neg_of_neg (hYm c hcc hcq) (sub_neg.mpr (hBm hcc hqc hcq)))
  have hpos : 0<∫ x in a..b, F x := by
    have hh := intervalIntegral.integral_lt_integral_of_continuousOn_of_le_of_exists_lt
      hab (show ContinuousOn (fun _ : ℝ => (0:ℝ)) (Icc a b) from continuousOn_const)
      hFc (fun x hx => hnonneg x (Ioc_subset_Icc_self hx)) ⟨c,hcc,hFcpos⟩
    simpa only [intervalIntegral.integral_zero] using hh
  have hI : IntervalIntegrable (fun x => ρ x*Y x) volume a b :=
    (hρ.mul hY).intervalIntegrable_of_Icc hab.le
  have hIB : IntervalIntegrable (fun x => ρ x*Y x*B x) volume a b :=
    ((hρ.mul hY).mul hB).intervalIntegrable_of_Icc hab.le
  have he : (∫ x in a..b, F x)=(∫ x in a..b, ρ x*Y x*B x) := by
    calc
      (∫ x in a..b, F x)=∫ x in a..b, ρ x*Y x*B x-ρ x*Y x*B q := by
        apply intervalIntegral.integral_congr
        intro x hx
        dsimp only [F]
        ring
      _=(∫ x in a..b, ρ x*Y x*B x)-(∫ x in a..b, ρ x*Y x)*B q := by
        rw [intervalIntegral.integral_sub hIB (hI.mul_const _),intervalIntegral.integral_mul_const]
      _=_ := by rw [hzero,zero_mul,sub_zero]
  rwa [he] at hpos

def jacobiWeight (W : ℝ → ℝ) (L x : ℝ) : ℝ :=
  -deriv (deriv (deriv W)) x*Real.sqrt (L-W x)/2

theorem continuousAt_jacobiWeight {W : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) : ContinuousAt (jacobiWeight W L) x :=
  ((hW.deriv.deriv.deriv.continuousAt.neg).mul
    (Real.continuous_sqrt.continuousAt.comp (continuousAt_const.sub hW.continuousAt))).div_const 2

theorem jacobi_first_moment_zero {W Y : ℝ → ℝ} {a b L : ℝ}
    (hab : a<b) (hW : AnalyticOnNhd ℝ W (Icc a b))
    (hY : AnalyticOnNhd ℝ Y (Icc a b))
    (he : ∀ x ∈ Ioo a b, 2*(L-W x)*deriv Y x+deriv W x*Y x=1)
    (hWa : W a=L) (hWb : W b=L) (hv : ∀ x ∈ Ioo a b, 0<L-W x) :
    (∫ x in a..b, jacobiWeight W L x*Y x)=0 := by
  have hJc : ContinuousOn (jacobiConcavityFlux W Y L) (Icc a b) := by
    intro x hx
    exact ((((continuousAt_const.sub (hW x hx).continuousAt).mul
      (Real.continuous_sqrt.continuousAt.comp
        (continuousAt_const.sub (hW x hx).continuousAt))).mul
          (hY x hx).deriv.deriv.continuousAt)).continuousWithinAt
  have hρc : ContinuousOn (jacobiWeight W L) (Icc a b) :=
    fun x hx => (continuousAt_jacobiWeight (hW x hx)).continuousWithinAt
  have heg := jacobi_equation_closed_germ hab hW hY he
  have hd : ∀ x ∈ Ioo a b, HasDerivAt (jacobiConcavityFlux W Y L)
      (jacobiWeight W L x*Y x) x := by
    intro x hx
    convert jacobi_concavity_flux_derivative (hW x (Ioo_subset_Icc_self hx))
      (hY x (Ioo_subset_Icc_self hx)) (hv x hx) (heg x (Ioo_subset_Icc_self hx)) using 1
    unfold jacobiWeight
    ring
  have hh := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le hab.le hJc hd
    ((hρc.mul hY.continuousOn).intervalIntegrable_of_Icc hab.le)
  simpa [jacobiConcavityFlux,hWa,hWb] using hh

theorem jacobi_comparison_moment_positive {W Y : ℝ → ℝ} {a b L : ℝ}
    (hab : a<b) (hW : AnalyticOnNhd ℝ W (Icc a b))
    (hY : AnalyticOnNhd ℝ Y (Icc a b))
    (he : ∀ x ∈ Ioo a b, 2*(L-W x)*deriv Y x+deriv W x*Y x=1)
    (hWa : W a=L) (hWb : W b=L) (hga : deriv W a<0) (hgb : 0<deriv W b)
    (hv : ∀ x ∈ Ioo a b, 0<L-W x)
    (hk : ∀ x ∈ Icc a b, 0<deriv (deriv W) x)
    (hf : ∀ x ∈ Icc a b, deriv (deriv (deriv W)) x<0)
    (hN : ∀ x ∈ Icc a b, forceInvariantAt W x≤0)
    (hNs : ∀ x ∈ Icc a b, deriv W x≠0 → forceInvariantAt W x<0) :
    0<∫ x in a..b, jacobiWeight W L x*Y x*jacobiB W Y L a b x := by
  obtain ⟨q,hq,hYq,hYm,hYp⟩ := jacobi_unique_zero hab hW hY he hWa hWb hga hgb hv hk
  apply weighted_moment_strictly_positive hq
    (fun x hx => (continuousAt_jacobiWeight (hW x hx)).continuousWithinAt)
    hY.continuousOn
    (analyticOnNhd_jacobiB hab hW hY he hWa hWb hga.ne hgb.ne'
      (fun x hx => (hv x hx).ne') (fun x hx => (hf x hx).ne)).continuousOn
    (fun x hx => div_nonneg (mul_nonneg (neg_nonneg.mpr (hf x hx).le) (Real.sqrt_nonneg _)) (by norm_num))
    (fun x hx => div_pos (mul_pos (neg_pos.mpr (hf x (Ioo_subset_Icc_self hx)))
      (Real.sqrt_pos.2 (hv x hx))) (by norm_num)) hYq hYm hYp
    (jacobiB_strictMono hab hW hY he hWa hWb hga hgb hv hk hf hN hNs)
    (jacobi_first_moment_zero hab hW hY he hWa hWb hv)

end LeanVerification.UpperStripCompletion
