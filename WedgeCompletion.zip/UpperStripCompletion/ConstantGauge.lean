import LeanVerification.GeneralMechanical.EnergyGreenIntegral
import LeanVerification.UpperStripCompletion.JacobiJets

/-! The actual Green density with constant gauge, reduced to elementary
Jacobi jets.  The energy derivative of its curvature is identically zero. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical GeneralMechanical.EnergyModes AnalyticTwoPartials
set_option maxHeartbeats 1600000

theorem constant_gauge_H (W : ℝ → ℝ) (L x : ℝ) :
    CriticalEnergy.coefficientH W (fun _ => 1) L x=deriv (deriv W) x := by
  simp [CriticalEnergy.coefficientH,CriticalEnergy.jet]

theorem constant_gauge_curvature (W : ℝ → ℝ) (L x : ℝ) :
    curvature W (fun _ => 1) (L,x)=
      deriv (deriv (deriv (deriv W))) x/(3*deriv (deriv W) x)-
        5*deriv (deriv (deriv W)) x^2/(9*deriv (deriv W) x^2) := by
  simp [curvature,CriticalEnergy.coefficientQ,CriticalMode.curvature,
    CriticalEnergy.coefficientH,CriticalEnergy.coefficientH1,CriticalEnergy.coefficientH2,
    CriticalEnergy.jet]

theorem constant_gauge_curvature_energy (W : ℝ → ℝ) (L x : ℝ) :
    left (curvature W (fun _ => 1)) (L,x)=0 := by
  change deriv (fun l => curvature W (fun _ => 1) (l,x)) L=0
  have he : (fun l => curvature W (fun _ => 1) (l,x))=
      fun _ : ℝ => deriv (deriv (deriv (deriv W))) x/(3*deriv (deriv W) x)-
        5*deriv (deriv (deriv W)) x^2/(9*deriv (deriv W) x^2) :=
    funext fun l => constant_gauge_curvature W l x
  rw [he,deriv_const]

theorem constant_gauge_extendedWeight (W : ℝ → ℝ) (L x : ℝ) :
    extendedWeight W (fun _ => 1) L x=
      (3/2:ℝ)*Real.sqrt (L-W x)*deriv (deriv W) x^(-(1:ℝ)/3) := by
  simp [extendedWeight,CriticalMode.extendedWeightEnergy,CriticalEnergy.energyRatio,
    CriticalEnergy.coefficientH,CriticalEnergy.jet,Real.sqrt_eq_rpow]

def jacobiBasicMode (W Y : ℝ → ℝ) : ℝ → ℝ :=
  CriticalMode.mode (deriv Y) (deriv (deriv W))

def jacobiGreenValue (s k f t y₁ y₂ : ℝ) : ℝ :=
  (3/2:ℝ)*s/k*y₂^2-s*f/k^2*y₁*y₂+s*(f^2/k^3-t/(2*k^2))*y₁^2

theorem rpow_negative_third_cube {k : ℝ} (hk : 0<k) :
    (k^(-(1:ℝ)/3))^3=k⁻¹ := by
  rw [←Real.rpow_mul_natCast hk.le (-(1:ℝ)/3) 3]
  norm_num [Real.rpow_neg_one]

theorem constant_gauge_green_algebra {s k f t y₁ y₂ c : ℝ}
    (hk : k≠0) (hc : c^3=k⁻¹) :
    (3/2:ℝ)*s*c*(((y₂-y₁*f/(3*k))*c)^2-
      (t/(3*k)-5*f^2/(9*k^2))*(y₁*c)^2)=jacobiGreenValue s k f t y₁ y₂ := by
  unfold jacobiGreenValue
  ring_nf
  rw [hc]
  field_simp [hk]
  <;> ring

theorem constant_gauge_green_eq_jacobi {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (hk : 0<deriv (deriv W) x) :
    greenDensity W (fun _ => 1) L (jacobiBasicMode W Y) x=
      jacobiGreenValue (Real.sqrt (L-W x)) (deriv (deriv W) x)
        (deriv (deriv (deriv W)) x) (deriv (deriv (deriv (deriv W))) x)
        (deriv Y x) (deriv (deriv Y) x) := by
  have hd := CriticalMode.hasDerivAt_mode hY.deriv.differentiableAt.hasDerivAt
    hW.deriv.deriv.differentiableAt.hasDerivAt hk
  rw [greenDensity,constant_gauge_extendedWeight,constant_gauge_curvature,
    constant_gauge_curvature_energy]
  simp only [mul_zero,zero_mul,sub_zero]
  change _*((deriv (CriticalMode.mode (deriv Y) (deriv (deriv W))) x)^2-_*_)=_
  rw [hd.deriv]
  exact constant_gauge_green_algebra hk.ne' (rpow_negative_third_cube hk)

end LeanVerification.UpperStripCompletion
