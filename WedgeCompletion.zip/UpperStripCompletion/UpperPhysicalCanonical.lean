import LeanVerification.UpperStripCompletion.UpperPhysicalChart
import LeanVerification.UpperStripCompletion.CanonicalPhysicalTurns

/-! Joint identification of the actual physical period with the canonical
complete period, including both physical turning points and the time factor. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open Loud RegionalReal GeneralMechanical InteriorCompletion ContourCompletion AnalyticTwoPartials
set_option maxHeartbeats 3000000

theorem upper_physical_scaled_period (b : ℝ) (q : ℝ×ℝ) (a c : CanonicalCoefficients→ℝ)
    (hb : 0<b) (hb1 : b<1) (hd : 0<1+q.2)
    (hh : AdmissibleEnergy (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q))
    (hae : a (upperEnergyChart b q)=leftTurn (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q))
    (hce : c (upperEnergyChart b q)=rightTurn (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q)) :
    upperPhysicalChartPeriod b q=upperChartPeriod b a c q := by
  have hm : 0<1-b := by linarith
  have hp : 0<1+b := by linarith
  have hF : 1<1/(1-b) := (lt_div_iff₀ hm).mpr (by linarith)
  have hs : 0<upperPhysicalScale b q.2 := div_pos hm hd
  have hsqr : Real.sqrt (upperPhysicalScale b q.2)≠0 := (Real.sqrt_pos.mpr hs).ne'
  have hpar : AdmissibleEnergy (upperPhysicalParameter b q).1.1 (upperPhysicalParameter b q).1.2
      (upperPhysicalParameter b q).2 := hh
  unfold upperPhysicalChartPeriod
  rw [extendedPhysicalPeriod_eq_physical hpar]
  change Real.sqrt (upperPhysicalScale b q.2)*periodQuadrature (-1/(1+q.2)) (1/(1-b))
      (upperPhysicalEnergy b q)=_
  rw [periodQuadrature_eq_loudTurn_physical_cycle _ _ _ hF hh]
  change Real.sqrt (upperPhysicalScale b q.2)*(Real.sqrt 2*∫w in _.._,
      1/Real.sqrt (-loudTurnPolynomial _ _ _ w))=Real.sqrt 2*∫w in a (upperEnergyChart b q)..c (upperEnergyChart b q),
        1/Real.sqrt (canonicalGap (2*b/(1-b)) (upperEnergyChart b q,w))
  rw [hae,hce]
  calc
    _=Real.sqrt 2*(∫w in leftTurn (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q)..
        rightTurn (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q),
        Real.sqrt (upperPhysicalScale b q.2)*(1/Real.sqrt (-loudTurnPolynomial (-1/(1+q.2))
          (1/(1-b)) (upperPhysicalEnergy b q) w))) := by
      rw [intervalIntegral.integral_const_mul]
      ring
    _=_ := by
      congr 1
      apply intervalIntegral.integral_congr
      intro w hw
      dsimp only
      rw [upper_physical_gap_factor b q w hb.ne' hm.ne' hp.ne' hd.ne',Real.sqrt_mul hs.le]
      field_simp [hsqr]
      rw [div_mul_eq_div_div,div_self hsqr]

theorem upper_physical_canonical_period_germ (b : ℝ) (q : ℝ×ℝ) (a c : CanonicalCoefficients→ℝ)
    (hb : 0<b) (hb1 : b<1) (hd : 0<1+q.2)
    (hh : AdmissibleEnergy (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q))
    (hfam : RegularTwoTurnFamily (canonicalGap (2*b/(1-b))) a c (upperEnergyChart b q))
    (hae : a (upperEnergyChart b q)=leftTurn (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q))
    (hce : c (upperEnergyChart b q)=rightTurn (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q)) :
    upperPhysicalChartPeriod b =ᶠ[𝓝 q] upperChartPeriod b a c := by
  have hm : 0<1-b := by linarith
  have hp : 0<1+b := by linarith
  have hF : 1<1/(1-b) := (lt_div_iff₀ hm).mpr (by linarith)
  have hchart := (analyticAt_upperEnergyChart b q).continuousAt
  have hpar := (analyticAt_upperPhysicalParameter b q hd.ne').continuousAt
  have hac := hfam.analytic_left.continuousAt.comp hchart
  have hcc := hfam.analytic_right.continuousAt.comp hchart
  have hDc : ContinuousAt (fun r : ℝ×ℝ => -1/(1+r.2)) q := by fun_prop (disch := exact hd.ne')
  have hLa := leftTurn_spec _ _ _ hh
  have hRc := rightTurn_spec _ _ _ hh
  have hap : 0<a (upperEnergyChart b q) := by rw [hae]; exact hLa.1.1
  have hcp : 0<c (upperEnergyChart b q) := by rw [hce]; exact hRc.1.1
  have ha1 : a (upperEnergyChart b q)<1 := by rw [hae]; exact hLa.2.1
  have hc1 : 1<c (upperEnergyChart b q) := by rw [hce]; exact hRc.2.1
  have hSa : 0<saddleFactor (-1/(1+q.2)) (a (upperEnergyChart b q)) := by rw [hae]; exact hLa.1.2
  have hSc : 0<saddleFactor (-1/(1+q.2)) (c (upperEnergyChart b q)) := by rw [hce]; exact hRc.1.2
  have hSac : ContinuousAt (fun r : ℝ×ℝ => saddleFactor (-1/(1+r.2)) (a (upperEnergyChart b r))) q :=
    ((hDc.add continuousAt_const).mul hac).sub hDc
  have hScc : ContinuousAt (fun r : ℝ×ℝ => saddleFactor (-1/(1+r.2)) (c (upperEnergyChart b r))) q :=
    ((hDc.add continuousAt_const).mul hcc).sub hDc
  have hEh : ∀ᶠ r in 𝓝 q,AdmissibleEnergy (-1/(1+r.2)) (1/(1-b)) (upperPhysicalEnergy b r) :=
    hpar.eventually (isOpen_admissibleEnergy_joint.mem_nhds hh)
  filter_upwards [hEh,(continuousAt_const.add continuousAt_snd).eventually (Ioi_mem_nhds hd),
    hac.eventually (Ioi_mem_nhds hap),hcc.eventually (Ioi_mem_nhds hcp),
    hac.eventually (Iio_mem_nhds ha1),hcc.eventually (Ioi_mem_nhds hc1),
    hSac.eventually (Ioi_mem_nhds hSa),hScc.eventually (Ioi_mem_nhds hSc),
    hchart.eventually hfam.root_left,hchart.eventually hfam.root_right]
    with r hr hrd hra hrc hra1 hrc1 hrsA hrsC hrA hrC
  have hpot (w : ℝ) (hw : 0<w) (hz : canonicalGap (2*b/(1-b)) (upperEnergyChart b r,w)=0) :
      potential (-1/(1+r.2)) (1/(1-b)) w=upperPhysicalEnergy b r := by
    have hhg := upper_physical_gap_factor b r w hb.ne' hm.ne' hp.ne' hrd.ne'
    rw [hz,mul_zero] at hhg
    have hz' : loudTurnPolynomial (-1/(1+r.2)) (1/(1-b)) (upperPhysicalEnergy b r) w=0 := neg_eq_zero.mp hhg
    have hpi := loudTurnPolynomial_potential_identity (-1/(1+r.2)) (1/(1-b)) (upperPhysicalEnergy b r) w hF hw
    rw [hz',mul_zero] at hpi
    exact sub_eq_zero.mp hpi
  have hleft : a (upperEnergyChart b r)=leftTurn (-1/(1+r.2)) (1/(1-b)) (upperPhysicalEnergy b r) :=
    left_turn_unique _ _ _ ⟨⟨hra,hrsA⟩,hra1,hpot _ hra hrA⟩ (leftTurn_spec _ _ _ hr)
  have hright : c (upperEnergyChart b r)=rightTurn (-1/(1+r.2)) (1/(1-b)) (upperPhysicalEnergy b r) :=
    right_turn_unique _ _ _ ⟨⟨hrc,hrsC⟩,hrc1,hpot _ hrc hrC⟩ (rightTurn_spec _ _ _ hr)
  exact upper_physical_scaled_period b r a c hb hb1 hrd hr hleft hright

theorem exists_upper_physical_canonical_chart {b : ℝ} {q : ℝ×ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hX : 0<q.1) (hd : 0≤q.2) (hd1 : q.2≤1) :
    ∃a c : CanonicalCoefficients→ℝ,
      RegularTwoTurnFamily (canonicalGap (2*b/(1-b))) a c (upperEnergyChart b q) ∧
      0<a (upperEnergyChart b q) ∧
      upperPhysicalChartPeriod b =ᶠ[𝓝 q] upperChartPeriod b a c := by
  have hh := upper_physical_chart_admissible hb hb1 hX hd hd1
  have hLa := leftTurn_spec _ _ _ hh
  have hRc := rightTurn_spec _ _ _ hh
  have hm : 0<1-b := by linarith
  have hp : 0<1+b := by linarith
  have he : 0<1+q.2 := by linarith
  have hF : 1<1/(1-b) := (lt_div_iff₀ hm).mpr (by linarith)
  have hs : upperPhysicalScale b q.2≠0 := (div_pos hm he).ne'
  have hz := loudTurnPolynomial_left_right_roots _ _ _ hF hh
  have hzero (w : ℝ) (hw : loudTurnPolynomial (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q) w=0) :
      canonicalGap (2*b/(1-b)) (upperEnergyChart b q,w)=0 := by
    have hi := upper_physical_gap_factor b q w hb.ne' hm.ne' hp.ne' he.ne'
    rw [hw,neg_zero] at hi
    exact (mul_eq_zero.mp hi.symm).resolve_left hs
  have hH := (upper_physical_height_pos hb (by linarith) hd).1
  have hδ : 0<(upperEnergyChart b q).2.2 := by
    change 0<upperHeight b q.2*Real.exp (-q.1)
    unfold upperHeight
    have hbd : 0<1+b*q.2 := by positivity
    positivity
  obtain ⟨a,c,hae,hce,hfam⟩ := exists_canonical_action_chart (2*b/(1-b)) (upperEnergyChart b q)
    (leftTurn _ _ _) (rightTurn _ _ _) (by change 0≤q.2/2; positivity) (by positivity) hδ
    hLa.1.1 (hLa.2.1.trans hRc.2.1) (hzero _ hz.1) (hzero _ hz.2)
  exact ⟨a,c,hfam,by rw [hae]; exact hLa.1.1,
    upper_physical_canonical_period_germ b q a c hb (by linarith) he hh hfam hae hce⟩

end LeanVerification.UpperStripCompletion
