import LeanVerification.UpperStripCompletion.ConstantGauge

/-! The finite-interval correction converting the normalized Green
identity into the plain Jacobi curvature identity. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 2200000

def jacobiCorrectionValue (s k f y₁ y₂ : ℝ) : ℝ :=
  s*(y₁*y₂/(2*k)-f*y₁^2/(2*k^2))

def jacobiCorrectionDerivative (s g k f t y₁ y₂ y₃ : ℝ) : ℝ :=
  -g*y₁*y₂/(4*s*k)+g*f*y₁^2/(4*s*k^2)+s*y₂^2/(2*k)+s*y₁*y₃/(2*k)-
    3*s*f*y₁*y₂/(2*k^2)-s*t*y₁^2/(2*k^2)+s*f^2*y₁^2/k^3

theorem jacobi_correction_algebra {v s g k f t y y₁ y₂ y₃ : ℝ}
    (hv : v≠0) (hs : s≠0) (hk : k≠0) (hs2 : s^2=v)
    (h₂ : 2*v*y₂-g*y₁+k*y=0) (h₃ : 2*v*y₃-3*g*y₂+f*y=0) :
    jacobiCorrectionDerivative s g k f t y₁ y₂ y₃=
      jacobiGreenValue s k f t y₁ y₂+y*y₂/(2*s) := by
  have hy : y=(g*y₁-2*v*y₂)/k := by
    apply (eq_div_iff hk).2
    nlinarith only [h₂]
  have hy₃ : y₃=(3*g*y₂-f*y)/(2*v) := by
    apply (eq_div_iff (mul_ne_zero (by norm_num) hv)).2
    nlinarith only [h₃]
  rw [hy₃,hy]
  unfold jacobiCorrectionDerivative jacobiGreenValue
  field_simp [hv,hs,hk]
  ring_nf
  rw [hs2]
  have hs4 : s^4=v^2 := by
    calc s^4=(s^2)^2 := by ring
         _=v^2 := by rw [hs2]
  rw [hs4]
  ring

def jacobiGreenCorrection (W Y : ℝ → ℝ) (L x : ℝ) : ℝ :=
  jacobiCorrectionValue (Real.sqrt (L-W x)) (deriv (deriv W) x)
    (deriv (deriv (deriv W)) x) (deriv Y x) (deriv (deriv Y) x)

theorem hasDerivAt_jacobiGreenCorrection_raw {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (hv : 0<L-W x) (hk : deriv (deriv W) x≠0) :
    HasDerivAt (jacobiGreenCorrection W Y L)
      (jacobiCorrectionDerivative (Real.sqrt (L-W x)) (deriv W x)
        (deriv (deriv W) x) (deriv (deriv (deriv W)) x)
        (deriv (deriv (deriv (deriv W))) x) (deriv Y x)
        (deriv (deriv Y) x) (deriv (deriv (deriv Y)) x)) x := by
  have ds := (hW.differentiableAt.hasDerivAt.const_sub L).sqrt hv.ne'
  have dk := hW.deriv.deriv.differentiableAt.hasDerivAt
  have df := hW.deriv.deriv.deriv.differentiableAt.hasDerivAt
  have dy₁ := hY.deriv.differentiableAt.hasDerivAt
  have dy₂ := hY.deriv.deriv.differentiableAt.hasDerivAt
  have hd := ds.mul (((dy₁.mul dy₂).div (dk.const_mul 2) (mul_ne_zero (by norm_num) hk)).sub
    ((df.mul (dy₁.pow 2)).div ((dk.pow 2).const_mul 2)
      (mul_ne_zero (by norm_num) (pow_ne_zero 2 hk))))
  convert hd using 1
  unfold jacobiCorrectionDerivative
  field_simp [hk,(Real.sqrt_pos.2 hv).ne']
  <;> ring

theorem hasDerivAt_jacobiGreenCorrection {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1)
    (hv : 0<L-W x) (hk : 0<deriv (deriv W) x) :
    HasDerivAt (jacobiGreenCorrection W Y L)
      (GeneralMechanical.EnergyModes.greenDensity W (fun _ => 1) L (jacobiBasicMode W Y) x+
        Y x*deriv (deriv Y) x/(2*Real.sqrt (L-W x))) x := by
  have hd := hasDerivAt_jacobiGreenCorrection_raw hW hY hv hk.ne'
  rw [jacobi_correction_algebra hv.ne' (Real.sqrt_pos.2 hv).ne' hk.ne'
    (Real.sq_sqrt hv.le) (jacobi_second_at hW hY he) (jacobi_third_at hW hY he),
    ←constant_gauge_green_eq_jacobi hW hY hk] at hd
  exact hd

theorem jacobiGreenCorrection_at_turn {W Y : ℝ → ℝ} {L x : ℝ}
    (hv : L-W x=0) : jacobiGreenCorrection W Y L x=0 := by
  simp only [jacobiGreenCorrection,jacobiCorrectionValue,hv,Real.sqrt_zero,zero_mul]

theorem continuousAt_jacobiGreenCorrection {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (hk : deriv (deriv W) x≠0) : ContinuousAt (jacobiGreenCorrection W Y L) x := by
  have hs : ContinuousAt (fun z => Real.sqrt (L-W z)) x :=
    Real.continuous_sqrt.continuousAt.comp (continuousAt_const.sub hW.continuousAt)
  have hkc := hW.deriv.deriv.continuousAt
  exact hs.mul ((((hY.deriv.continuousAt.mul hY.deriv.deriv.continuousAt).div
    (continuousAt_const.mul hkc) (mul_ne_zero (by norm_num) hk))).sub
      ((hW.deriv.deriv.deriv.continuousAt.mul (hY.deriv.continuousAt.pow 2)).div
        (continuousAt_const.mul (hkc.pow 2)) (mul_ne_zero (by norm_num) (pow_ne_zero 2 hk))))

end LeanVerification.UpperStripCompletion
