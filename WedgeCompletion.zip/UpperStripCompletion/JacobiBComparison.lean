import LeanVerification.UpperStripCompletion.JacobiCPositive
import LeanVerification.GeneralMechanical.EndpointQuotient

/-! Removal of the turning singularities in B and its strict interior
comparison.  In particular no boundary continuity argument is used to
infer the missing sign inside the well. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical GeneralMechanical.EnergyModes
set_option maxHeartbeats 2000000

def jacobiBNumerator (W Y : ℝ → ℝ) (x : ℝ) : ℝ :=
  deriv (deriv Y) x/deriv (deriv (deriv W)) x-Y x^2/3

def jacobiBRaw (W Y : ℝ → ℝ) (L x : ℝ) : ℝ :=
  jacobiBNumerator W Y x/(L-W x)

def jacobiB (W Y : ℝ → ℝ) (L a b : ℝ) : ℝ → ℝ :=
  endpointQuotient (jacobiBNumerator W Y) (fun x => L-W x) a b

theorem analyticAt_jacobiBNumerator {W Y : ℝ → ℝ} {x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (hf : deriv (deriv (deriv W)) x≠0) :
    AnalyticAt ℝ (jacobiBNumerator W Y) x :=
  (hY.deriv.deriv.div hW.deriv.deriv.deriv hf).sub
    ((hY.pow 2).div analyticAt_const (by norm_num))

theorem jacobiBNumerator_zero_at_turn {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1)
    (hv : L-W x=0) (hg : deriv W x≠0) (hf : deriv (deriv (deriv W)) x≠0) :
    jacobiBNumerator W Y x=0 := by
  obtain ⟨hy,_,hy₂,_,_⟩ := jacobi_turn_jets hW hY he hv hg
  rw [jacobiBNumerator,hy,hy₂]
  field_simp [hg,hf]
  <;> ring

theorem hasDerivAt_jacobiBRaw {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1)
    (hv : L-W x≠0) (hf : deriv (deriv (deriv W)) x≠0) :
    HasDerivAt (jacobiBRaw W Y L)
      (jacobiC W Y L x/(6*deriv (deriv (deriv W)) x^2*(L-W x)^2)) x := by
  have hn : HasDerivAt (jacobiBNumerator W Y)
      ((deriv (deriv (deriv Y)) x*deriv (deriv (deriv W)) x-
          deriv (deriv Y) x*deriv (deriv (deriv (deriv W))) x)/
          deriv (deriv (deriv W)) x^2-(2/3:ℝ)*Y x*deriv Y x) x := by
    convert (hY.deriv.deriv.differentiableAt.hasDerivAt.div
      hW.deriv.deriv.deriv.differentiableAt.hasDerivAt hf).sub
        ((hY.differentiableAt.hasDerivAt.pow 2).div_const 3) using 1
    ring
  have hd := hn.div (hW.differentiableAt.hasDerivAt.const_sub L) hv
  convert hd using 1
  have hc := jacobi_B_derivative_certificate (t := deriv (deriv (deriv (deriv W))) x)
    hv hf he.self_of_nhds
    (jacobi_third_at hW hY he)
  convert hc.symm using 1 <;> simp only [jacobiC,jacobiBNumerator] <;> ring

theorem analyticOnNhd_jacobiB {W Y : ℝ → ℝ} {a b L : ℝ}
    (hab : a<b) (hW : AnalyticOnNhd ℝ W (Icc a b))
    (hY : AnalyticOnNhd ℝ Y (Icc a b))
    (he : ∀ x ∈ Ioo a b, 2*(L-W x)*deriv Y x+deriv W x*Y x=1)
    (hWa : W a=L) (hWb : W b=L) (hga : deriv W a≠0) (hgb : deriv W b≠0)
    (hv : ∀ x ∈ Ioo a b, L-W x≠0)
    (hf : ∀ x ∈ Icc a b, deriv (deriv (deriv W)) x≠0) :
    AnalyticOnNhd ℝ (jacobiB W Y L a b) (Icc a b) := by
  have ha : a ∈ Icc a b := ⟨le_rfl,hab.le⟩
  have hb : b ∈ Icc a b := ⟨hab.le,le_rfl⟩
  have heg := jacobi_equation_closed_germ hab hW hY he
  have hVa : L-W a=0 := by rw [hWa,sub_self]
  have hVb : L-W b=0 := by rw [hWb,sub_self]
  apply analyticOnNhd_endpointQuotient hab
    (fun x hx => analyticAt_jacobiBNumerator (hW x hx) (hY x hx) (hf x hx))
    (fun x hx => analyticAt_const.sub (hW x hx))
    (jacobiBNumerator_zero_at_turn (hW a ha) (hY a ha) (heg a ha) hVa hga (hf a ha))
    (jacobiBNumerator_zero_at_turn (hW b hb) (hY b hb) (heg b hb) hVb hgb (hf b hb))
    hVa hVb ?_ ?_ hv
  · change deriv (fun x => L-W x) a≠0
    rw [((hW a ha).differentiableAt.hasDerivAt.const_sub L).deriv]
    exact neg_ne_zero.mpr hga
  · change deriv (fun x => L-W x) b≠0
    rw [((hW b hb).differentiableAt.hasDerivAt.const_sub L).deriv]
    exact neg_ne_zero.mpr hgb

theorem jacobiB_interior_derivative {W Y : ℝ → ℝ} {a b L x : ℝ}
    (hx : x ∈ Ioo a b) (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1)
    (hv : L-W x≠0) (hf : deriv (deriv (deriv W)) x≠0) :
    deriv (jacobiB W Y L a b) x=
      jacobiC W Y L x/(6*deriv (deriv (deriv W)) x^2*(L-W x)^2) := by
  have heq : jacobiB W Y L a b =ᶠ[𝓝 x] jacobiBRaw W Y L := by
    filter_upwards [Ioo_mem_nhds hx.1 hx.2] with z hz
    exact endpointQuotient_eq_interior hz
  rw [heq.deriv_eq,(hasDerivAt_jacobiBRaw hW hY he hv hf).deriv]

theorem jacobiB_strictMono {W Y : ℝ → ℝ} {a b L : ℝ}
    (hab : a<b) (hW : AnalyticOnNhd ℝ W (Icc a b))
    (hY : AnalyticOnNhd ℝ Y (Icc a b))
    (he : ∀ x ∈ Ioo a b, 2*(L-W x)*deriv Y x+deriv W x*Y x=1)
    (hWa : W a=L) (hWb : W b=L) (hga : deriv W a<0) (hgb : 0<deriv W b)
    (hv : ∀ x ∈ Ioo a b, 0<L-W x)
    (hk : ∀ x ∈ Icc a b, 0<deriv (deriv W) x)
    (hf : ∀ x ∈ Icc a b, deriv (deriv (deriv W)) x<0)
    (hN : ∀ x ∈ Icc a b, forceInvariantAt W x≤0)
    (hNs : ∀ x ∈ Icc a b, deriv W x≠0 → forceInvariantAt W x<0) :
    StrictMonoOn (jacobiB W Y L a b) (Icc a b) := by
  have hBa := analyticOnNhd_jacobiB hab hW hY he hWa hWb hga.ne hgb.ne'
    (fun x hx => (hv x hx).ne') (fun x hx => (hf x hx).ne)
  have hBc := hBa.continuousOn
  have heg := jacobi_equation_closed_germ hab hW hY he
  have hCp := (jacobiC_nonnegative hab hW hY he hWa hWb hga hgb hv hk hf hN hNs).2
  have hd (x : ℝ) (hx : x ∈ Ioo a b) (hg : deriv W x≠0) :
      0<deriv (jacobiB W Y L a b) x := by
    have hxm := Ioo_subset_Icc_self hx
    rw [jacobiB_interior_derivative hx (hW x hxm) (hY x hxm) (heg x hxm)
      (hv x hx).ne' (hf x hxm).ne]
    exact div_pos (hCp x hx hg) (mul_pos
      (mul_pos (by norm_num) (sq_pos_of_ne_zero (hf x hxm).ne))
      (sq_pos_of_ne_zero (hv x hx).ne'))
  obtain ⟨c,hc,_,hgl,hgr⟩ := force_center_and_signs hab hW hga hgb hk
  have hleft : StrictMonoOn (jacobiB W Y L a b) (Icc a c) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc a c)
      (hBc.mono (fun x hx => ⟨hx.1,hx.2.trans hc.2.le⟩))
    intro x hx
    have hxi : x ∈ Ioo a c := by simpa only [interior_Icc] using hx
    have hxm : x ∈ Ioo a b := ⟨hxi.1,hxi.2.trans hc.2⟩
    exact hd x hxm (hgl x (Ioo_subset_Icc_self hxm) hxi.2).ne
  have hright : StrictMonoOn (jacobiB W Y L a b) (Icc c b) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc c b)
      (hBc.mono (fun x hx => ⟨hc.1.le.trans hx.1,hx.2⟩))
    intro x hx
    have hxi : x ∈ Ioo c b := by simpa only [interior_Icc] using hx
    have hxm : x ∈ Ioo a b := ⟨hc.1.trans hxi.1,hxi.2⟩
    exact hd x hxm (hgr x (Ioo_subset_Icc_self hxm) hxi.1).ne'
  intro x hx y hy hxy
  by_cases hyc : y≤c
  · exact hleft ⟨hx.1,hxy.le.trans hyc⟩ ⟨hy.1,hyc⟩ hxy
  by_cases hcx : c≤x
  · exact hright ⟨hcx,hx.2⟩ ⟨hcx.trans hxy.le,hy.2⟩ hxy
  exact (hleft ⟨hx.1,(lt_of_not_ge hcx).le⟩ ⟨hc.1.le,le_rfl⟩ (lt_of_not_ge hcx)).trans_le
    (hright.monotoneOn ⟨le_rfl,hc.2.le⟩ ⟨(lt_of_not_ge hyc).le,hy.2⟩ (lt_of_not_ge hyc).le)

end LeanVerification.UpperStripCompletion
