import LeanVerification.UpperStripCompletion.UpperForceLargeD
import LeanVerification.BoundaryAssembly.SchaafSigns
import LeanVerification.UpperStripCompletion.JacobiCAnalytic

/-! The fifth physical-potential jet and its exact force-invariant factor.
All factors use the original mechanical coordinate, including F=1. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open Loud RegionalReal BoundaryAssembly
set_option maxHeartbeats 3600000

def forceFourthBracket (D F w : ℝ) : ℝ :=
  (2*F+1)*(F^2-1)*(2*D+1)*w-4*(F+1)*(F^2-4)*D

def forceFourthPosition (D F X : ℝ) : ℝ :=
  forceFourthBracket D F (inversePosition F X)/
    ((affineAux F X)^3*(inversePosition F X)^2)

def physicalForceInvariantNumerator (D F w : ℝ) : ℝ :=
  15*forceSecondBracket D F w*forceSlopeNumerator D F w*forceThirdBracket D F w-
  15*((w-1)*saddleFactor D w)*forceSecondBracket D F w*forceFourthBracket D F w+
  21*((w-1)*saddleFactor D w)*(forceThirdBracket D F w)^2-
  25*(forceSecondBracket D F w)^3

theorem hasDerivAt_forceThirdPosition (D F X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (forceThirdPosition D F) (forceFourthPosition D F X) X := by
  have hw := (inversePosition_pos F X hX).ne'
  have hq : affineAux F X≠0 := hX.ne'
  have hdw := hasDerivAt_inversePosition_affine F X hX
  have hd := ((hdw.const_mul (-(F^2-1)*(2*D+1))).const_add (2*(F^2-4)*D)).div
    (((hasDerivAt_affineAux F X).pow 2).mul (hdw.pow 2))
    (mul_ne_zero (pow_ne_zero 2 hq) (pow_ne_zero 2 hw))
  convert hd using 1
  · ext Z
    dsimp only [forceThirdPosition,forceThirdBracket]
    congr 1
    ring
  · dsimp only [forceFourthPosition,forceFourthBracket,id_eq]
    field_simp
    ring

theorem actual_force_fourth_deriv (D F X : ℝ) (hX : mechanicalDomain F X) :
    deriv (deriv (deriv (deriv (forceInPosition D F)))) X=forceFourthPosition D F X := by
  have he : deriv (deriv (deriv (forceInPosition D F))) =ᶠ[𝓝 X] forceThirdPosition D F := by
    filter_upwards [mechanicalDomain_eventually hX] with Z hZ
    exact actual_force_third_deriv D F Z hZ
  exact he.deriv_eq.trans (hasDerivAt_forceThirdPosition D F X hX).deriv

theorem actual_potential_force_jets (D F X : ℝ) (hX : mechanicalDomain F X) :
    deriv (fun Z => potential D F (inversePosition F Z)) X=forceInPosition D F X ∧
    deriv (deriv (fun Z => potential D F (inversePosition F Z))) X=
      forceSpatialSlope D F (inversePosition F X) ∧
    deriv (deriv (deriv (fun Z => potential D F (inversePosition F Z)))) X=forceSecondPosition D F X ∧
    deriv (deriv (deriv (deriv (fun Z => potential D F (inversePosition F Z))))) X=forceThirdPosition D F X ∧
    deriv (deriv (deriv (deriv (deriv (fun Z => potential D F (inversePosition F Z)))))) X=forceFourthPosition D F X := by
  have he : deriv (fun Z => potential D F (inversePosition F Z)) =ᶠ[𝓝 X] forceInPosition D F := by
    filter_upwards [mechanicalDomain_eventually hX] with Z hZ
    exact (hasDerivAt_potentialInPosition D F Z hZ).deriv
  have he2 := he.iteratedDeriv_eq 2
  have he3 := he.iteratedDeriv_eq 3
  have he4 := he.iteratedDeriv_eq 4
  simp only [iteratedDeriv_succ,iteratedDeriv_zero] at he2 he3 he4
  exact ⟨he.self_of_nhds,physical_potential_second_jet D F X hX,
    he2.trans (actual_force_second_deriv D F X hX),
    he3.trans (actual_force_third_deriv D F X hX),
    he4.trans (actual_force_fourth_deriv D F X hX)⟩

theorem actual_forceInvariant_factor (D F X : ℝ) (hX : mechanicalDomain F X) :
    forceInvariantAt (fun Z => potential D F (inversePosition F Z)) X=
      physicalForceInvariantNumerator D F (inversePosition F X)/
        ((affineAux F X)^3*(inversePosition F X)^6) := by
  have hj := actual_potential_force_jets D F X hX
  dsimp only [forceInvariantAt]
  rw [hj.1,hj.2.1,hj.2.2.1,hj.2.2.2.1,hj.2.2.2.2,
    physical_force_eq_saddle_factor D F X hX]
  dsimp only [forceInvariant,forceSpatialSlope,forceSecondPosition,forceThirdPosition,
    forceFourthPosition,physicalForceInvariantNumerator]
  have hw := (inversePosition_pos F X hX).ne'
  have hq : affineAux F X≠0 := hX.ne'
  field_simp [hq,hw]
  ring

theorem physical_upper_parameters (D F : ℝ)
    (hD0 : -1≤D) (hD1 : D≤-(1/2)) (hF0 : 1≤F) (hF1 : F≤5/4) :
    0≤1-1/F ∧ 1-1/F≤1/5 ∧ 0≤ -(D+1)/D ∧ -(D+1)/D≤1 ∧
    1-(1-1/F)≠0 ∧ 1+(-(D+1)/D)≠0 ∧
    -1/(1+(-(D+1)/D))=D ∧ 1/(1-(1-1/F))=F := by
  have hF : 0<F := by linarith
  have hD : D<0 := by linarith
  have hFi : 1/F≤1 := (div_le_one hF).mpr hF0
  have hFi' : (4/5:ℝ)≤1/F := (le_div_iff₀ hF).mpr (by linarith)
  have hd0 : 0≤ -(D+1)/D := div_nonneg_of_nonpos (by linarith) hD.le
  have hd1 : -(D+1)/D≤1 := (div_le_iff_of_neg hD).mpr (by linarith)
  have heF : 1-(1-1/F)=1/F := by ring
  have heD : 1+(-(D+1)/D)= -1/D := by field_simp [hD.ne] <;> ring
  refine ⟨by linarith,by linarith,hd0,hd1,?_,by positivity,?_,?_⟩
  · rw [heF]; exact one_div_ne_zero hF.ne'
  · rw [heD]
    field_simp
  · rw [heF]
    field_simp

 theorem physical_upper_force_signs (D F X : ℝ)
    (hD0 : -1≤D) (hD1 : D≤-(1/2)) (hF0 : 1≤F) (hF1 : F≤5/4)
    (hX : mechanicalDomain F X) :
    0<deriv (deriv (fun Z => potential D F (inversePosition F Z))) X ∧
    deriv (deriv (deriv (fun Z => potential D F (inversePosition F Z)))) X<0 := by
  have hj := actual_potential_force_jets D F X hX
  rw [hj.2.1,hj.2.2.1]
  have hw := inversePosition_pos F X hX
  have hA : 0≤D+1 := by linarith
  have hB : 0≤ -(2*D+1) := by linarith
  have hF : 0<F := by linarith
  have hfm : 0≤F-1 := by linarith
  have hfp : 0<2-F := by linarith
  have hD : D<0 := by linarith
  have hp : 0<(2-F)*(-D) := mul_pos hfp (neg_pos.mpr hD)
  have h1 : 0≤F*(D+1)*(inversePosition F X)^2 := by positivity
  have h2 : 0≤(F-1)*(-(2*D+1))*inversePosition F X := by positivity
  have hk : 0<forceSlopeNumerator D F (inversePosition F X) := by
    dsimp only [forceSlopeNumerator]
    nlinarith only [hp,h1,h2]
  have hf : forceSecondBracket D F (inversePosition F X)<0 := by
    dsimp only [forceSecondBracket]
    nlinarith only [hp,h2]
  exact ⟨div_pos hk (sq_pos_of_pos hw),
    div_neg_of_neg_of_pos hf (mul_pos hX (sq_pos_of_pos hw))⟩

end LeanVerification.UpperStripCompletion
