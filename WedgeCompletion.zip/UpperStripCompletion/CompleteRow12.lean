import LeanVerification.UpperStripCompletion.UpperInteriorComparison
import LeanVerification.RegionalSeamCompletion.UpperPhysical
import LeanVerification.RegionalReal.PhysicalNonstationarity

/-! The complete unrestricted upper-strip row, including F=1 and both
closed D edges. All interior and physical-period hypotheses are discharged. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open Loud RegionalSeamCompletion
set_option maxHeartbeats 2200000

theorem physical_upper_period_deriv_pos_log_positive_center {d h : ℝ}
    (hd : 0≤d) (hd1 : d≤1) (hC : 0<upperCenterPolynomial 0 d)
    (hh : AdmissibleEnergy (-1/(1+d)) 1 h) :
    0<deriv (periodQuadrature (-1/(1+d)) 1) h := by
  have hd9 := (upper_center_positive_range (b:=0) (by norm_num) (by norm_num) hd hd1 hC).1
  apply upper_physical_F_one_positive (c:=upperCenterRoot) hd hd9.le
    continuousAt_upperCenterRoot_zero upperCenterRoot_zero hh
  · exact physical_upper_log_boundary_positive (upperSeam_boundary_admissible hd hd9.le hh)
  · have hroot : ∀ᶠ b in 𝓝 (0:ℝ),d<upperCenterRoot b :=
      continuousAt_upperCenterRoot_zero.eventually (Ioi_mem_nhds (by rwa [upperCenterRoot_zero]))
    have hCc : ContinuousAt (fun b => upperCenterPolynomial b 0) 0 := by
      unfold upperCenterPolynomial
      fun_prop
    have hC0 : ∀ᶠ b in 𝓝 (0:ℝ),0<upperCenterPolynomial b 0 :=
      hCc.eventually (Ioi_mem_nhds (by norm_num [upperCenterPolynomial]))
    have hparam : ContinuousAt (fun b : ℝ => (((-1/(1+d),1/(1-b)),h):PeriodParameterSpace)) 0 := by
      fun_prop (disch := norm_num)
    have hha : ∀ᶠ b in 𝓝 (0:ℝ),AdmissibleEnergy (-1/(1+d)) (1/(1-b)) h := by
      have hh0 : AdmissibleEnergy (-1/(1+d)) (1/(1-(0:ℝ))) h := by simpa using hh
      exact hparam.eventually (isOpen_admissibleEnergy_joint.mem_nhds hh0)
    have hsmall : ∀ᶠ b in 𝓝 (0:ℝ),b<1/5 := Iio_mem_nhds (by norm_num)
    filter_upwards [self_mem_nhdsWithin,
      hsmall.filter_mono nhdsWithin_le_nhds,
      hroot.filter_mono nhdsWithin_le_nhds,hC0.filter_mono nhdsWithin_le_nhds,
      hha.filter_mono nhdsWithin_le_nhds] with b hb hb1 hbr hbC hbh
    exact upper_physical_period_slope_comparison hb hb1.le hbC hd hbr.le hbh

theorem physical_upper_period_deriv_pos_full_positive_center (D F h : ℝ)
    (hD0 : -1≤D) (hD1 : D≤-(1/2)) (hF0 : 1≤F) (hF1 : F≤5/4)
    (hC : 0<upperCenterPolynomial (1-1/F) (-(D+1)/D))
    (hh : AdmissibleEnergy D F h) : 0<deriv (periodQuadrature D F) h := by
  obtain ⟨hb0,hb1,hd0,hd1,hbm,hdp,hDe,hFe⟩ := physical_upper_parameters D F hD0 hD1 hF0 hF1
  rcases eq_or_lt_of_le hF0 with hFeq|hFgt
  · have hFval : F=1 := hFeq.symm
    subst F
    have hC' : 0<upperCenterPolynomial 0 (-(D+1)/D) := by simpa using hC
    have hhh : AdmissibleEnergy (-1/(1+(-(D+1)/D))) 1 h := by rwa [hDe]
    have hp := physical_upper_period_deriv_pos_log_positive_center hd0 hd1 hC' hhh
    simpa only [hDe] using hp
  · have hFpos : 0<F := by linarith
    have hbp : 0<1-1/F := sub_pos.mpr ((div_lt_one hFpos).mpr hFgt)
    have hhh : AdmissibleEnergy (-1/(1+(-(D+1)/D))) (1/(1-(1-1/F))) h := by rwa [hDe,hFe]
    have hp := physical_upper_period_deriv_pos_positive_center hbp hb1 hd0 hd1 hC hhh
    simpa only [hDe,hFe] using hp

theorem criticalPeriodBound_one_upper_complete (D F : ℝ)
    (hD0 : -1≤D) (hD1 : D≤-(1/2)) (hF0 : 1≤F) (hF1 : F≤5/4) :
    CriticalPeriodBound 1 D F := by
  by_cases hC : upperCenterPolynomial (1-1/F) (-(D+1)/D)≤0
  · exact criticalPeriodBound_one_upper_nonpositive_center D F hD0 hD1 hF0 hF1 hC
  · have hz := RegionalReal.criticalPeriodBound_zero_of_deriv_ne_zero (D:=D) (F:=F)
      (fun h hh => (physical_upper_period_deriv_pos_full_positive_center D F h hD0 hD1 hF0 hF1
        (lt_of_not_ge hC) hh).ne')
    intro s hs
    exact (hz s hs).trans (by norm_num)

theorem full_regional_row12 (D F : ℝ) (hp : parameterRegion 12 D F) :
    CriticalPeriodBound (parameterRegionBound 12) D F := by
  change 1≤F ∧ F<5/4 ∧ -1≤D ∧ D≤-(1/2) at hp
  change CriticalPeriodBound 1 D F
  exact criticalPeriodBound_one_upper_complete D F hp.2.2.1 hp.2.2.2 hp.1 hp.2.1.le

end LeanVerification.UpperStripCompletion
