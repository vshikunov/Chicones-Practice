import LeanVerification.UpperStripCompletion.ForceInvariantCriterion
import LeanVerification.Loud.MechanicalQuadrature
import LeanVerification.ZeroOrientation
import LeanVerification.BoundaryAssembly.ZeroInput

/-! Transfer of the force-invariant criterion to the actual original-time
Loud period.  The selected turns are the physical Morse turns. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open Loud GeneralMechanical GeneralMechanical.EnergyModes
set_option maxHeartbeats 2400000

def loudMechanicalPotential (D F X : ℝ) : ℝ := potential D F (inversePosition F X)
def loudMechanicalLeft (D F h : ℝ) : ℝ := morsePosition D F (-Real.sqrt (2*h))
def loudMechanicalRight (D F h : ℝ) : ℝ := morsePosition D F (Real.sqrt (2*h))

theorem loud_mechanical_turn_values (D F h : ℝ) (hh : AdmissibleEnergy D F h) :
    loudMechanicalLeft D F h<loudMechanicalRight D F h ∧
    loudMechanicalPotential D F (loudMechanicalLeft D F h)=h ∧
    loudMechanicalPotential D F (loudMechanicalRight D F h)=h ∧
    deriv (loudMechanicalPotential D F) (loudMechanicalLeft D F h)<0 ∧
    0<deriv (loudMechanicalPotential D F) (loudMechanicalRight D F h) ∧
    ∀X∈Ioo (loudMechanicalLeft D F h) (loudMechanicalRight D F h),0<h-loudMechanicalPotential D F X := by
  have hr : 0<Real.sqrt (2*h) := Real.sqrt_pos.mpr (by linarith [hh.1])
  have he : (Real.sqrt (2*h))^2/2=h := by rw [Real.sq_sqrt (by linarith [hh.1])]; ring
  simpa only [loudMechanicalLeft,loudMechanicalRight,loudMechanicalPotential,he] using
    physical_regular_turn_data D F h (Real.sqrt (2*h)) hh le_rfl hr

theorem loud_regular_energy_well (D F h : ℝ) (hh : AdmissibleEnergy D F h) :
    RegularEnergyWell (loudMechanicalPotential D F) (loudMechanicalLeft D F) (loudMechanicalRight D F) h := by
  have hr : 0<Real.sqrt (2*h) := Real.sqrt_pos.mpr (by linarith [hh.1])
  have huL : -Real.sqrt (2*h)∈morseRange D F := morse_amplitude_in_range D F h hh
    ⟨le_rfl,by linarith⟩
  have huR : Real.sqrt (2*h)∈morseRange D F := morse_amplitude_in_range D F h hh
    ⟨by linarith,le_rfl⟩
  have hA : AnalyticAt ℝ (loudMechanicalLeft D F) h :=
    (analyticAt_morsePosition D F _ huL).comp_of_eq
      (f := fun k : ℝ => -Real.sqrt (2*k)) (analyticAt_energyAmplitude hh.1).neg rfl
  have hB : AnalyticAt ℝ (loudMechanicalRight D F) h :=
    (analyticAt_morsePosition D F _ huR).comp_of_eq
      (f := fun k : ℝ => Real.sqrt (2*k)) (analyticAt_energyAmplitude hh.1) rfl
  have hg : ∀ᶠ k in 𝓝 h,AdmissibleEnergy D F k := (isOpen_admissibleEnergy D F).mem_nhds hh
  have ha0 : ∀ᶠ k in 𝓝 h,k-loudMechanicalPotential D F (loudMechanicalLeft D F k)=0 := by
    filter_upwards [hg] with k hk
    rw [(loud_mechanical_turn_values D F k hk).2.1,sub_self]
  have hb0 : ∀ᶠ k in 𝓝 h,k-loudMechanicalPotential D F (loudMechanicalRight D F k)=0 := by
    filter_upwards [hg] with k hk
    rw [(loud_mechanical_turn_values D F k hk).2.2.1,sub_self]
  have ht := loud_mechanical_turn_values D F h hh
  refine ⟨hA,hB,ha0,hb0,ht.1,?_,ht.2.2.2.2.2,ht.2.2.2.1,ht.2.2.2.2.1⟩
  intro X hX
  exact analyticAt_potentialInPosition D F X (physical_turn_interval_coordinate_data D F h hh hX).1

theorem loud_mechanical_period_eq_physical (D F h : ℝ) (hh : AdmissibleEnergy D F h) :
    period (loudMechanicalPotential D F) (loudMechanicalLeft D F) (loudMechanicalRight D F) h=
      periodQuadrature D F h := by
  have ht := loud_mechanical_turn_values D F h hh
  have hquad := mechanical_period_quadrature D F h hh
  dsimp only at hquad
  rw [hquad.2]
  dsimp only [period,completeTurnPeriod,physicalTurnClock,gap,
    loudMechanicalPotential,loudMechanicalLeft,loudMechanicalRight]
  have hle : morsePosition D F (-Real.sqrt (2*h))≤morsePosition D F (Real.sqrt (2*h)) := ht.1.le
  rw [intervalIntegral.integral_of_le hle,integral_Ioc_eq_integral_Ioo,← integral_const_mul]
  congr 1
  apply setIntegral_congr_fun measurableSet_Ioo
  intro X hX
  dsimp only
  rw [Real.sqrt_mul (by norm_num : (0:ℝ)≤2),one_div,mul_inv_rev]
  ring

theorem loud_mechanical_period_germ (D F h : ℝ) (hh : AdmissibleEnergy D F h) :
    period (loudMechanicalPotential D F) (loudMechanicalLeft D F) (loudMechanicalRight D F)
      =ᶠ[𝓝 h] periodQuadrature D F := by
  filter_upwards [(isOpen_admissibleEnergy D F).mem_nhds hh] with k hk
  exact loud_mechanical_period_eq_physical D F k hk

theorem physical_force_invariant_stationary_curvature (D F h : ℝ)
    (hh : AdmissibleEnergy D F h) (hstat : deriv (periodQuadrature D F) h=0)
    (hk : ∀X,mechanicalDomain F X → 0<deriv (deriv (loudMechanicalPotential D F)) X)
    (hf : ∀X,mechanicalDomain F X → deriv (deriv (deriv (loudMechanicalPotential D F))) X<0)
    (hN : ∀X,mechanicalDomain F X → forceInvariantAt (loudMechanicalPotential D F) X≤0)
    (hNs : ∀X,mechanicalDomain F X → deriv (loudMechanicalPotential D F) X≠0 →
      forceInvariantAt (loudMechanicalPotential D F) X<0) :
    0<deriv (deriv (periodQuadrature D F)) h := by
  have hwell := loud_regular_energy_well D F h hh
  have he := loud_mechanical_period_germ D F h hh
  have hsta : deriv (period (loudMechanicalPotential D F) (loudMechanicalLeft D F) (loudMechanicalRight D F)) h=0 := by
    rw [he.deriv_eq,hstat]
  have hdom (X : ℝ) (hX : X∈Icc (loudMechanicalLeft D F h) (loudMechanicalRight D F h)) :
      mechanicalDomain F X := (physical_turn_interval_coordinate_data D F h hh hX).1
  have hc := force_invariant_stationary_curvature_positive hwell hsta
    (fun X hX => hk X (hdom X hX)) (fun X hX => hf X (hdom X hX))
    (fun X hX => hN X (hdom X hX)) (fun X hX => hNs X (hdom X hX))
  have he2 := he.iteratedDeriv_eq 2
  simp only [iteratedDeriv_succ,iteratedDeriv_zero] at he2
  rw [he2] at hc
  exact hc

theorem criticalPeriodBound_one_of_positive_stationary_curvature (D F : ℝ)
    (hcurv : ∀h,AdmissibleEnergy D F h → deriv (periodQuadrature D F) h=0 →
      0<deriv (deriv (periodQuadrature D F)) h) : CriticalPeriodBound 1 D F := by
  have hz : ZeroCounting.AtMostOneZeroOn (deriv (periodQuadrature D F)) {h | AdmissibleEnergy D F h} := by
    apply ZeroOrientation.atMostOneZeroOn_of_deriv_pos_at_zeros (ordConnected_admissibleEnergy D F).convex
    · exact fun h hh => (analyticAt_periodQuadrature_energy D F h hh).deriv.differentiableAt
    · exact fun h hh hs => hcurv h hh hs
  intro s hs
  apply Finset.card_le_one.mpr
  intro x hx y hy
  exact hz (hs x hx).1 (hs y hy).1 (hs x hx).2.1 (hs y hy).2.1

end LeanVerification.UpperStripCompletion
