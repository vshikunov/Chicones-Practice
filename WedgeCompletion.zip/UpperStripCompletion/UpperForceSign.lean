import LeanVerification.UpperStripCompletion.UpperForceZeroD
import LeanVerification.UpperStripCompletion.UpperForceParameter

/-! Complete force-invariant sign on the closed nonpositive-center chamber. -/
noncomputable section
open Set
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 1600000

theorem upper_quartic_sign_low_d {b d x : ℝ} (hb : 0≤b) (hb1 : b≤1/5)
    (hd : 0≤d) (hd1 : d≤1/9) (hC : upperCenterPolynomial b d≤0) (hx : 0<x) :
    upperForceQuartic b d x≤0 ∧ (x≠1 → upperForceQuartic b d x<0) := by
  have hm := (upper_quartic_parameter_strictAnti hb hb1 hx).antitoneOn
  by_cases hC0 : upperCenterPolynomial b 0≤0
  · have hn := hm (show (0:ℝ)∈Icc 0 (1/9) by norm_num) ⟨hd,hd1⟩ hd
    exact ⟨hn.trans (upper_quartic_nonpos_zero_parameter hb hb1 hC0 hx),
      fun hx1 => hn.trans_lt (upper_quartic_neg_zero_parameter hb hb1 hC0 hx hx1)⟩
  · have hccont : ContinuousOn (fun e => upperCenterPolynomial b e) (Icc 0 d) := by
      unfold upperCenterPolynomial
      fun_prop
    obtain ⟨c,hc,hc0⟩ := intermediate_value_Icc' hd hccont ⟨hC,(lt_of_not_ge hC0).le⟩
    have hc1 : c≤1/9 := hc.2.trans hd1
    have hn := hm ⟨hc.1,hc1⟩ ⟨hd,hd1⟩ hc.2
    exact ⟨hn.trans (upper_quartic_nonpos_center_zero hb hb1 hc.1 (by linarith) hc0 hx),
      fun hx1 => hn.trans_lt (upper_quartic_neg_center_zero hb hb1 hc.1 (by linarith) hc0 hx hx1)⟩

theorem upper_quartic_sign_nonpositive_center {b d x : ℝ} (hb : 0≤b) (hb1 : b≤1/5)
    (hd : 0≤d) (hd1 : d≤1) (hC : upperCenterPolynomial b d≤0) (hx : 0<x) :
    upperForceQuartic b d x≤0 ∧ (x≠1 → upperForceQuartic b d x<0) := by
  rcases le_or_gt d (1/9) with hlow|hhigh
  · exact upper_quartic_sign_low_d hb hb1 hd hlow hC hx
  · refine ⟨upper_quartic_nonpos_large_d hb hb1 hhigh.le hd1 hx,?_⟩
    intro hx1
    rcases eq_or_lt_of_le hb with he|hp
    · subst b
      exact upper_quartic_logarithmic_neg hhigh.le hx hx1
    · exact upper_quartic_neg_large_d hp hb1 hhigh.le hd1 hx

end LeanVerification.UpperStripCompletion
