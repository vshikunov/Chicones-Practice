import LeanVerification.UpperStripCompletion.JacobiGreenDerivative
import LeanVerification.UpperStripCompletion.StationaryJacobi

/-! The complete Jacobi curvature identity for the physical turning
period.  The singular integrand is proved absolutely integrable from the
actual turning clocks; both correction terms vanish at the turns. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology ContDiff
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical GeneralMechanical.EnergyModes AnalyticTwoPartials
set_option maxHeartbeats 2000000

theorem intervalIntegral_eq_of_eqOn_Ioo {f g : ℝ → ℝ} {a b : ℝ}
    (hab : a≤b) (he : ∀ x ∈ Ioo a b, f x=g x) :
    (∫ x in a..b, f x)=∫ x in a..b, g x := by
  apply intervalIntegral.integral_congr_ae
  have hn : ∀ᵐ x : ℝ, x≠b := by simp [ae_iff]
  filter_upwards [hn] with x hxb hx
  rw [uIoc_of_le hab] at hx
  exact he x ⟨hx.1,lt_of_le_of_ne hx.2 hxb⟩

theorem regular_energy_kernel_integrable {W a b : ℝ → ℝ} {L : ℝ}
    (h : RegularEnergyWell W a b L) :
    IntervalIntegrable (fun x => (Real.sqrt (L-W x))⁻¹) volume (a L) (b L) := by
  have hm : (a L+b L)/2 ∈ Ioo (a L) (b L) := by
    constructor <;> linarith [h.turns_ordered]
  have hh := (h.paired_clock_germ hm).self_of_nhds
  exact hh.2.2.1.trans hh.2.2.2.1.symm

theorem regular_energy_weighted_kernel_integrable {W a b Z : ℝ → ℝ} {L : ℝ}
    (h : RegularEnergyWell W a b L) (hZ : ContinuousOn Z (Icc (a L) (b L))) :
    IntervalIntegrable (fun x => Z x/Real.sqrt (L-W x)) volume (a L) (b L) := by
  have hi := (regular_energy_kernel_integrable h).mul_continuousOn
    (by rwa [uIcc_of_le h.turns_ordered.le])
  simpa only [div_eq_mul_inv,mul_comm] using hi

theorem analyticAt_jacobiBasicMode {W Y : ℝ → ℝ} {x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (hk : 0<deriv (deriv W) x) : AnalyticAt ℝ (jacobiBasicMode W Y) x := by
  have hp : AnalyticAt ℝ (fun z => deriv (deriv W) z^(-(1:ℝ)/3)) x :=
    (Real.contDiffAt_rpow_const_of_ne (p := -(1:ℝ)/3) (n := ω) hk.ne').analyticAt.comp
      hW.deriv.deriv
  exact hY.deriv.mul hp

theorem actual_constant_gauge_green_identity {W a b : ℝ → ℝ} {L : ℝ}
    (h : RegularEnergyWell W a b L) (hstat : deriv (period W a b) L=0)
    (hk : ∀ x ∈ Icc (a L) (b L), 0<deriv (deriv W) x) :
    (∫ x in a L..b L, greenDensity W (fun _ => 1) L
      (jacobiBasicMode W (stationaryVariation W a b L)) x)=
      deriv (deriv (period W a b)) L/(4*Real.sqrt 2) := by
  have hφ : AnalyticOnNhd ℝ (fun _ : ℝ => (1:ℝ)) (Icc (a L) (b L)) :=
    fun _ _ => analyticAt_const
  have hH : ∀ x ∈ Icc (a L) (b L), 0<CriticalEnergy.coefficientH W (fun _ => 1) L x := by
    intro x hx
    simpa only [constant_gauge_H] using hk x hx
  obtain ⟨U,_,_,_,hUL,_,_,_,hG⟩ :=
    h.improper_green_identity hstat hφ (fun _ _ => by norm_num) hH
  have hUe : EqOn U (jacobiBasicMode W (stationaryVariation W a b L)) (Ioo (a L) (b L)) := by
    intro x hx
    have he : stationaryVariation W a b L =ᶠ[𝓝 x] fun z => variation W a 1 (L,z) := by
      filter_upwards [Ioo_mem_nhds hx.1 hx.2] with z hz
      exact h.stationaryVariation_eq_left hstat hz
    calc
      U x=mode W (fun _ => 1) a 1 (L,x) := hUL hx
      _=deriv (fun z => variation W a 1 (L,z)) x*deriv (deriv W) x^(-(1:ℝ)/3) := by
        simp only [mode,deriv_const,one_mul,zero_mul,sub_zero,constant_gauge_H,right]
      _=jacobiBasicMode W (stationaryVariation W a b L) x := by
        rw [←he.deriv_eq]
        rfl
  have hGe : (∫ x in a L..b L, greenDensity W (fun _ => 1) L U x)=
      ∫ x in a L..b L, greenDensity W (fun _ => 1) L
        (jacobiBasicMode W (stationaryVariation W a b L)) x := by
    apply intervalIntegral_eq_of_eqOn_Ioo h.turns_ordered.le
    intro x hx
    have he : U =ᶠ[𝓝 x] jacobiBasicMode W (stationaryVariation W a b L) := by
      filter_upwards [Ioo_mem_nhds hx.1 hx.2] with z hz
      exact hUe hz
    simp only [greenDensity,he.self_of_nhds,he.deriv_eq]
  exact hGe.symm.trans hG

def jacobiSecondDensity (W Y : ℝ → ℝ) (L x : ℝ) : ℝ :=
  Y x*deriv (deriv Y) x/Real.sqrt (L-W x)

theorem actual_jacobi_curvature_identity {W a b : ℝ → ℝ} {L : ℝ}
    (h : RegularEnergyWell W a b L) (hstat : deriv (period W a b) L=0)
    (hk : ∀ x ∈ Icc (a L) (b L), 0<deriv (deriv W) x) :
    IntervalIntegrable (jacobiSecondDensity W (stationaryVariation W a b L) L)
      volume (a L) (b L) ∧
    deriv (deriv (period W a b)) L=-2*Real.sqrt 2*
      ∫ x in a L..b L, jacobiSecondDensity W (stationaryVariation W a b L) L x := by
  let Y := stationaryVariation W a b L
  have hY : AnalyticOnNhd ℝ Y (Icc (a L) (b L)) := h.analytic_stationaryVariation hstat
  have he := h.stationaryVariation_equation hstat
  have heg := jacobi_equation_closed_germ h.turns_ordered h.analytic_potential hY he
  have hAi : IntervalIntegrable (jacobiSecondDensity W Y L) volume (a L) (b L) :=
    regular_energy_weighted_kernel_integrable h (hY.continuousOn.mul
      (fun x hx => (hY x hx).deriv.deriv.continuousAt.continuousWithinAt))
  have hφ : AnalyticOnNhd ℝ (fun _ : ℝ => (1:ℝ)) (Icc (a L) (b L)) :=
    fun _ _ => analyticAt_const
  have hH : ∀ x ∈ Icc (a L) (b L), 0<CriticalEnergy.coefficientH W (fun _ => 1) L x := by
    intro x hx
    simpa only [constant_gauge_H] using hk x hx
  have hUa : AnalyticOnNhd ℝ (jacobiBasicMode W Y) (Icc (a L) (b L)) :=
    fun x hx => analyticAt_jacobiBasicMode (h.analytic_potential x hx) (hY x hx) (hk x hx)
  have hGi : IntervalIntegrable (greenDensity W (fun _ => 1) L (jacobiBasicMode W Y))
      volume (a L) (b L) :=
    (h.greenDensity_continuous hUa hφ (fun _ _ => by norm_num) hH).intervalIntegrable_of_Icc
      h.turns_ordered.le
  have hRc : ContinuousOn (jacobiGreenCorrection W Y L) (Icc (a L) (b L)) :=
    fun x hx => (continuousAt_jacobiGreenCorrection (h.analytic_potential x hx) (hY x hx)
      (hk x hx).ne').continuousWithinAt
  have hd : ∀ x ∈ Ioo (a L) (b L), HasDerivAt (jacobiGreenCorrection W Y L)
      (greenDensity W (fun _ => 1) L (jacobiBasicMode W Y) x+jacobiSecondDensity W Y L x/2) x := by
    intro x hx
    have hxm := Ioo_subset_Icc_self hx
    convert hasDerivAt_jacobiGreenCorrection (h.analytic_potential x hxm) (hY x hxm)
      (heg x hxm) (h.positive_gap x hx) (hk x hxm) using 1
    unfold jacobiSecondDensity
    ring
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le h.turns_ordered.le
    hRc hd (hGi.add (hAi.div_const 2))
  rw [intervalIntegral.integral_add hGi (hAi.div_const 2),intervalIntegral.integral_div,
    actual_constant_gauge_green_identity h hstat hk,
    jacobiGreenCorrection_at_turn h.root_left.self_of_nhds,
    jacobiGreenCorrection_at_turn h.root_right.self_of_nhds,sub_self] at hFTC
  refine ⟨hAi,?_⟩
  have hs : Real.sqrt (2:ℝ)≠0 := by positivity
  field_simp [hs] at hFTC
  nlinarith only [hFTC]

end LeanVerification.UpperStripCompletion
