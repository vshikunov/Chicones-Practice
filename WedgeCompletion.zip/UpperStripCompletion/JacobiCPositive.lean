import LeanVerification.UpperStripCompletion.JacobiCAnalytic
import LeanVerification.UpperStripCompletion.JacobiConcavity
import LeanVerification.UpperStripCompletion.DoubleZeroPositive

/-! Global positivity of the force comparison function.  A vanishing
force invariant at the force center is allowed, while all interior
estimates are derived from the actual Jacobi equation. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical GeneralMechanical.EnergyModes
set_option maxHeartbeats 2000000

theorem force_center_and_signs {W : ℝ → ℝ} {a b : ℝ}
    (hab : a<b) (hW : AnalyticOnNhd ℝ W (Icc a b))
    (hga : deriv W a<0) (hgb : 0<deriv W b)
    (hk : ∀ x ∈ Icc a b, 0<deriv (deriv W) x) :
    ∃ c ∈ Ioo a b, deriv W c=0 ∧
      (∀ x ∈ Icc a b, x<c → deriv W x<0) ∧
      (∀ x ∈ Icc a b, c<x → 0<deriv W x) := by
  have hgc : ContinuousOn (deriv W) (Icc a b) :=
    fun x hx => (hW x hx).deriv.continuousAt.continuousWithinAt
  have hm : StrictMonoOn (deriv W) (Icc a b) :=
    strictMonoOn_of_deriv_pos (convex_Icc a b) hgc (fun x hx => hk x (interior_subset hx))
  obtain ⟨c,hc,hc0⟩ := intermediate_value_Icc hab.le hgc ⟨hga.le,hgb.le⟩
  have hac : a<c := lt_of_le_of_ne hc.1 (by intro h; rw [←h] at hc0; exact hga.ne hc0)
  have hcb : c<b := lt_of_le_of_ne hc.2 (by intro h; rw [h] at hc0; exact hgb.ne' hc0)
  refine ⟨c,⟨hac,hcb⟩,hc0,?_,?_⟩
  · intro x hx hxc
    simpa only [hc0] using hm hx hc hxc
  · intro x hx hcx
    simpa only [hc0] using hm hc hx hcx

theorem jacobiC_nonnegative {W Y : ℝ → ℝ} {a b L : ℝ}
    (hab : a<b) (hW : AnalyticOnNhd ℝ W (Icc a b))
    (hY : AnalyticOnNhd ℝ Y (Icc a b))
    (he : ∀ x ∈ Ioo a b, 2*(L-W x)*deriv Y x+deriv W x*Y x=1)
    (hWa : W a=L) (hWb : W b=L) (hga : deriv W a<0) (hgb : 0<deriv W b)
    (hv : ∀ x ∈ Ioo a b, 0<L-W x)
    (hk : ∀ x ∈ Icc a b, 0<deriv (deriv W) x)
    (hf : ∀ x ∈ Icc a b, deriv (deriv (deriv W)) x<0)
    (hN : ∀ x ∈ Icc a b, forceInvariantAt W x≤0)
    (hNs : ∀ x ∈ Icc a b, deriv W x≠0 → forceInvariantAt W x<0) :
    (∀ x ∈ Icc a b, 0≤jacobiC W Y L x) ∧
    (∀ x ∈ Ioo a b, deriv W x≠0 → 0<jacobiC W Y L x) := by
  have ha : a ∈ Icc a b := ⟨le_rfl,hab.le⟩
  have hb : b ∈ Icc a b := ⟨hab.le,le_rfl⟩
  have heg := jacobi_equation_closed_germ hab hW hY he
  have hy₂ := jacobi_second_derivative_neg hab hW hY he hWa hWb hga hgb hv hk hf
  obtain ⟨c,hc,hgc,hgl,hgr⟩ := force_center_and_signs hab hW hga hgb hk
  have hcc := Ioo_subset_Icc_self hc
  have hCa := jacobiC_turn_jets (hW a ha) (hY a ha) (heg a ha)
    (by rw [hWa,sub_self]) hga.ne
  have hCb := jacobiC_turn_jets (hW b hb) (hY b hb) (heg b hb)
    (by rw [hWb,sub_self]) hgb.ne'
  have hCa2 : 0<deriv (deriv (jacobiC W Y L)) a := by
    rw [hCa.2.2]
    exact div_pos (mul_pos_of_neg_of_neg (by norm_num) (hNs a ha hga.ne))
      (mul_pos (by norm_num) (sq_pos_of_ne_zero hga.ne))
  have hCb2 : 0<deriv (deriv (jacobiC W Y L)) b := by
    rw [hCb.2.2]
    exact div_pos (mul_pos_of_neg_of_neg (by norm_num) (hNs b hb hgb.ne'))
      (mul_pos (by norm_num) (sq_pos_of_ne_zero hgb.ne'))
  have hCl : ∀ x ∈ Ioo a c, 0<jacobiC W Y L x := by
    apply positive_on_Ioo_of_left_double_zero_and_upward_zeros
      (fun x hx => analyticAt_jacobiC (hW x ⟨hx.1,hx.2.trans hc.2.le⟩)
        (hY x ⟨hx.1,hx.2.trans hc.2.le⟩)) hCa.1 hCa.2.1 hCa2
    intro x hx hxC
    have hxi : x ∈ Ioo a b := ⟨hx.1,hx.2.trans hc.2⟩
    have hxm := Ioo_subset_Icc_self hxi
    rw [(hasDerivAt_jacobiC (hW x hxm) (hY x hxm)).deriv]
    exact jacobi_C_prime_pos_left (hv x hxi) (hgl x hxm hx.2) (hf x hxm)
      (hy₂ x hxi) (hNs x hxm (hgl x hxm hx.2).ne)
      (jacobi_second_at (hW x hxm) (hY x hxm) (heg x hxm))
      (jacobi_third_at (hW x hxm) (hY x hxm) (heg x hxm)) hxC
  have hCr : ∀ x ∈ Ioo c b, 0<jacobiC W Y L x := by
    apply positive_on_Ioo_of_right_double_zero_and_downward_zeros
      (fun x hx => analyticAt_jacobiC (hW x ⟨hc.1.le.trans hx.1,hx.2⟩)
        (hY x ⟨hc.1.le.trans hx.1,hx.2⟩)) hCb.1 hCb.2.1 hCb2
    intro x hx hxC
    have hxi : x ∈ Ioo a b := ⟨hc.1.trans hx.1,hx.2⟩
    have hxm := Ioo_subset_Icc_self hxi
    rw [(hasDerivAt_jacobiC (hW x hxm) (hY x hxm)).deriv]
    exact jacobi_C_prime_neg_right (hv x hxi) (hgr x hxm hx.1) (hf x hxm)
      (hy₂ x hxi) (hNs x hxm (hgr x hxm hx.1).ne')
      (jacobi_second_at (hW x hxm) (hY x hxm) (heg x hxm))
      (jacobi_third_at (hW x hxm) (hY x hxm) (heg x hxm)) hxC
  have hcenter : 0≤jacobiC W Y L c := by
    have h2 : 2*(L-W c)*deriv (deriv Y) c+deriv (deriv W) c*Y c=0 := by
      simpa only [hgc,zero_mul,sub_zero] using
        jacobi_second_at (hW c hcc) (hY c hcc) (heg c hcc)
    have hyp : 0<Y c := by
      have hn := mul_neg_of_pos_of_neg (mul_pos (by norm_num : (0:ℝ)<2) (hv c hc)) (hy₂ c hc)
      exact pos_of_mul_pos_right (by linarith [h2] : 0<deriv (deriv W) c*Y c) (hk c hcc).le
    have hn : 5*deriv (deriv (deriv W)) c*
        (3*deriv (deriv W) c*deriv (deriv (deriv (deriv W))) c-
          5*deriv (deriv (deriv W)) c^2)≤0 := by
      have hh := hN c hcc
      unfold forceInvariantAt forceInvariant at hh
      rw [hgc] at hh
      nlinarith only [hh]
    have hfac := nonneg_of_mul_nonpos_right hn
      (mul_neg_of_pos_of_neg (by norm_num) (hf c hcc))
    unfold jacobiC
    rw [hgc,jacobi_C_at_force_center h2]
    exact mul_nonneg hfac hyp.le
  constructor
  · intro x hx
    rcases eq_or_lt_of_le hx.1 with hxa | hxa
    · simp only [←hxa,hCa.1,le_refl]
    rcases eq_or_lt_of_le hx.2 with hxb | hxb
    · simp only [hxb,hCb.1,le_refl]
    rcases lt_trichotomy x c with hxc | rfl | hcx
    · exact (hCl x ⟨hxa,hxc⟩).le
    · exact hcenter
    · exact (hCr x ⟨hcx,hxb⟩).le
  · intro x hx hxg
    rcases lt_trichotomy x c with hxc | rfl | hcx
    · exact hCl x ⟨hx.1,hxc⟩
    · exact False.elim (hxg hgc)
    · exact hCr x ⟨hcx,hx.2⟩

end LeanVerification.UpperStripCompletion
