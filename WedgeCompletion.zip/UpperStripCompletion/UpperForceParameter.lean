import LeanVerification.UpperStripCompletion.UpperForceCenter
import Mathlib.Analysis.Calculus.Deriv.MeanValue

/-! Parameter comparison below d=1/9, including the characteristic edge d=0. -/
noncomputable section
open Set
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 3000000

def upperA2D (b d : ℝ) : ℝ := ((72:ℝ)+((-300:ℝ)*b)+((-144:ℝ)*(b^4))+((174:ℝ)*(b^2))+((366:ℝ)*(b^3))+((-78:ℝ)*d*(b^3))+((-48:ℝ)*d*(b^4))+((-30:ℝ)*d*(b^2))+((36:ℝ)*b*d))

theorem upperA2D_pos {b d : ℝ} (hb : 0≤b) (hb1 : b≤1/5) (hd : 0≤d) (hd1 : d≤1/9) :
    0<upperA2D b d := by
  have hb0 : 0≤5*b := by positivity
  have hb2 : 0≤1-5*b := by linarith
  have hd0 : 0≤9*d := by positivity
  have hd2 : 0≤1-9*d := by linarith
  have he : upperA2D b d=20+((52:ℝ)*(5*b)^0*(1-5*b)^4*(9*d)^0*(1-9*d)^1 +
      (52:ℝ)*(5*b)^0*(1-5*b)^4*(9*d)^1*(1-9*d)^0 +
      (148:ℝ)*(5*b)^1*(1-5*b)^3*(9*d)^0*(1-9*d)^1 +
      ((744:ℝ)/5)*(5*b)^1*(1-5*b)^3*(9*d)^1*(1-9*d)^0 +
      ((3474:ℝ)/25)*(5*b)^2*(1-5*b)^2*(9*d)^0*(1-9*d)^1 +
      ((10592:ℝ)/75)*(5*b)^2*(1-5*b)^2*(9*d)^1*(1-9*d)^0 +
      ((5606:ℝ)/125)*(5*b)^3*(1-5*b)^1*(9*d)^0*(1-9*d)^1 +
      ((5864:ℝ)/125)*(5*b)^3*(1-5*b)^1*(9*d)^1*(1-9*d)^0 +
      ((1036:ℝ)/625)*(5*b)^4*(1-5*b)^0*(9*d)^0*(1-9*d)^1 +
      ((1404:ℝ)/625)*(5*b)^4*(1-5*b)^0*(9*d)^1*(1-9*d)^0) := by unfold upperA2D; ring
  have hp : 0≤(52:ℝ)*(5*b)^0*(1-5*b)^4*(9*d)^0*(1-9*d)^1 +
      (52:ℝ)*(5*b)^0*(1-5*b)^4*(9*d)^1*(1-9*d)^0 +
      (148:ℝ)*(5*b)^1*(1-5*b)^3*(9*d)^0*(1-9*d)^1 +
      ((744:ℝ)/5)*(5*b)^1*(1-5*b)^3*(9*d)^1*(1-9*d)^0 +
      ((3474:ℝ)/25)*(5*b)^2*(1-5*b)^2*(9*d)^0*(1-9*d)^1 +
      ((10592:ℝ)/75)*(5*b)^2*(1-5*b)^2*(9*d)^1*(1-9*d)^0 +
      ((5606:ℝ)/125)*(5*b)^3*(1-5*b)^1*(9*d)^0*(1-9*d)^1 +
      ((5864:ℝ)/125)*(5*b)^3*(1-5*b)^1*(9*d)^1*(1-9*d)^0 +
      ((1036:ℝ)/625)*(5*b)^4*(1-5*b)^0*(9*d)^0*(1-9*d)^1 +
      ((1404:ℝ)/625)*(5*b)^4*(1-5*b)^0*(9*d)^1*(1-9*d)^0 := by positivity
  rw [he]
  linarith only [hp]

def upperA3DReduced (b d : ℝ) : ℝ := ((31:ℝ)+((-77:ℝ)*b)+((-62:ℝ)*d)+((4:ℝ)*(b^3))+((14:ℝ)*(b^2))+((-28:ℝ)*d*(b^2))+((-8:ℝ)*d*(b^3))+((-7:ℝ)*(b^2)*(d^2))+((-3:ℝ)*b*(d^2))+((-2:ℝ)*(b^3)*(d^2))+((154:ℝ)*b*d))

theorem upperA3DReduced_pos {b d : ℝ} (hb : 0≤b) (hb1 : b≤1/5) (hd : 0≤d) (hd1 : d≤1/9) :
    0<upperA3DReduced b d := by
  have hb0 : 0≤5*b := by positivity
  have hb2 : 0≤1-5*b := by linarith
  have hd0 : 0≤9*d := by positivity
  have hd2 : 0≤1-9*d := by linarith
  have he : upperA3DReduced b d=12+((19:ℝ)*(5*b)^0*(1-5*b)^3*(9*d)^0*(1-9*d)^2 +
      ((280:ℝ)/9)*(5*b)^0*(1-5*b)^3*(9*d)^1*(1-9*d)^1 +
      ((109:ℝ)/9)*(5*b)^0*(1-5*b)^3*(9*d)^2*(1-9*d)^0 +
      ((208:ℝ)/5)*(5*b)^1*(1-5*b)^2*(9*d)^0*(1-9*d)^2 +
      ((2968:ℝ)/45)*(5*b)^1*(1-5*b)^2*(9*d)^1*(1-9*d)^1 +
      ((3287:ℝ)/135)*(5*b)^1*(1-5*b)^2*(9*d)^2*(1-9*d)^0 +
      ((669:ℝ)/25)*(5*b)^2*(1-5*b)^1*(9*d)^0*(1-9*d)^2 +
      ((2968:ℝ)/75)*(5*b)^2*(1-5*b)^1*(9*d)^1*(1-9*d)^1 +
      ((5182:ℝ)/405)*(5*b)^2*(1-5*b)^1*(9*d)^2*(1-9*d)^0 +
      ((524:ℝ)/125)*(5*b)^3*(1-5*b)^0*(9*d)^0*(1-9*d)^2 +
      ((5384:ℝ)/1125)*(5*b)^3*(1-5*b)^0*(9*d)^1*(1-9*d)^1 +
      ((236:ℝ)/405)*(5*b)^3*(1-5*b)^0*(9*d)^2*(1-9*d)^0) := by unfold upperA3DReduced; ring
  have hp : 0≤(19:ℝ)*(5*b)^0*(1-5*b)^3*(9*d)^0*(1-9*d)^2 +
      ((280:ℝ)/9)*(5*b)^0*(1-5*b)^3*(9*d)^1*(1-9*d)^1 +
      ((109:ℝ)/9)*(5*b)^0*(1-5*b)^3*(9*d)^2*(1-9*d)^0 +
      ((208:ℝ)/5)*(5*b)^1*(1-5*b)^2*(9*d)^0*(1-9*d)^2 +
      ((2968:ℝ)/45)*(5*b)^1*(1-5*b)^2*(9*d)^1*(1-9*d)^1 +
      ((3287:ℝ)/135)*(5*b)^1*(1-5*b)^2*(9*d)^2*(1-9*d)^0 +
      ((669:ℝ)/25)*(5*b)^2*(1-5*b)^1*(9*d)^0*(1-9*d)^2 +
      ((2968:ℝ)/75)*(5*b)^2*(1-5*b)^1*(9*d)^1*(1-9*d)^1 +
      ((5182:ℝ)/405)*(5*b)^2*(1-5*b)^1*(9*d)^2*(1-9*d)^0 +
      ((524:ℝ)/125)*(5*b)^3*(1-5*b)^0*(9*d)^0*(1-9*d)^2 +
      ((5384:ℝ)/1125)*(5*b)^3*(1-5*b)^0*(9*d)^1*(1-9*d)^1 +
      ((236:ℝ)/405)*(5*b)^3*(1-5*b)^0*(9*d)^2*(1-9*d)^0 := by positivity
  rw [he]
  linarith only [hp]

theorem upper_quartic_parameter_deriv (b d x : ℝ) :
    HasDerivAt (fun e => upperForceQuartic b e x)
      (-3*(1-2*b)*upperTPolynomial b*x-upperA2D b d*x^2-
        3*b*upperA3DReduced b d*x^3-
        3*b^2*(2-b)*(b+3)*(1-d)*(1-3*d)*x^4) d := by
  have h1 := (((hasDerivAt_id d).const_sub 1).const_mul (3*(1-2*b)*upperTPolynomial b)).mul_const x
  have h2 := ((((hasDerivAt_id d).const_sub 1).pow 2).const_mul (3*b*upperBPolynomial b)).add
    ((hasDerivAt_id d).const_mul (24*(1+b)*(3-2*b)*(1-2*b)^2))
  have h3 := (((hasDerivAt_id d).const_sub 1).const_mul b).mul
    (((((hasDerivAt_id d).const_sub 1).pow 2).const_mul (b*(2*b+1)*(b+3))).add
      ((hasDerivAt_id d).const_mul (3*(1-2*b)*(31-12*b-3*b^2))))
  have h4 := ((hasDerivAt_id d).mul (((hasDerivAt_id d).const_sub 1).pow 2)).const_mul
    (3*b^2*(2-b)*(b+3))
  convert ((((hasDerivAt_const d (-upperA0 b)).add h1).sub (h2.mul_const (x^2))).sub
    (h3.mul_const (x^3))).sub (h4.mul_const (x^4)) using 1
  all_goals
    dsimp only [upperForceQuartic,upperA1,upperA2,upperA3,upperA4,id_eq]
    first | (funext e; ring) | (unfold upperA2D upperA3DReduced upperBPolynomial; ring)

theorem upper_quartic_parameter_strictAnti {b x : ℝ} (hb : 0≤b) (hb1 : b≤1/5) (hx : 0<x) :
    StrictAntiOn (fun d => upperForceQuartic b d x) (Icc 0 (1/9)) := by
  apply strictAntiOn_of_deriv_neg (convex_Icc 0 (1/9))
    (fun d hd => (upper_quartic_parameter_deriv b d x).continuousAt.continuousWithinAt)
  intro d hd
  have hdc : d∈Icc 0 (1/9) := interior_subset hd
  rw [(upper_quartic_parameter_deriv b d x).deriv]
  have h2 := upperA2D_pos hb hb1 hdc.1 hdc.2
  have h3 := upperA3DReduced_pos hb hb1 hdc.1 hdc.2
  have hT : 0<upperTPolynomial b := lt_of_lt_of_le (by norm_num : (0:ℝ)<4/5)
    (upper_t_polynomial_lower hb hb1)
  have hk : 0<1-2*b := by linarith
  have hdm : 0≤1-d := by linarith [hdc.2]
  have hd3 : 0≤1-3*d := by linarith [hdc.2]
  have hbm : 0<2-b := by linarith
  have hbp : 0<b+3 := by linarith
  have hfirst : 0<3*(1-2*b)*upperTPolynomial b*x := by positivity
  have hsecond : 0≤upperA2D b d*x^2 := by positivity
  have hthird : 0≤3*b*upperA3DReduced b d*x^3 := by positivity
  have hfourth : 0≤3*b^2*(2-b)*(b+3)*(1-d)*(1-3*d)*x^4 := by positivity
  linarith only [hfirst,hsecond,hthird,hfourth]

end LeanVerification.UpperStripCompletion
