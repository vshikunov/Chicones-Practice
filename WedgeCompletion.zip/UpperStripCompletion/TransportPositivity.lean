import LeanVerification.UpperStripCompletion.TransportMaximum
import Mathlib.Analysis.Calculus.Deriv.MeanValue

/-! Full finite-energy interior positivity from the transport equation.
The coefficient may vanish at d=0; the proof checks that edge explicitly. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open AnalyticTwoPartials
set_option maxHeartbeats 3000000

theorem parameter_antitone_from_right_negative {U : ℝ×ℝ→ℝ} {X D : ℝ}
    (hU : ∀d∈Icc 0 D,AnalyticAt ℝ U (X,d))
    (hder : ∀d∈Icc 0 D,right U (X,d)<0) :
    AntitoneOn (fun d => U (X,d)) (Icc 0 D) := by
  apply StrictAntiOn.antitoneOn
  apply strictAntiOn_of_deriv_neg (convex_Icc 0 D)
    (fun d hd => (hU d hd).curry_right.continuousAt.continuousWithinAt)
  intro d hd
  exact hder d (interior_subset hd)

theorem transport_initial_positive_strip {U : ℝ×ℝ→ℝ} {T D : ℝ}
    (hT : 0<T) (hD : 0≤D)
    (hU : AnalyticOnNhd ℝ U (transportRectangle T D))
    (hinit : ∀d∈Icc 0 D,right U (0,d)<0)
    (hboundary : ∀X∈Ioc 0 T,0<U (X,D)) :
    ∃ε∈Ioo 0 T,∀q∈Ioc 0 ε ×ˢ Icc 0 D,0<U q := by
  have he : ∀ᶠ X in 𝓝 (0:ℝ),∀d∈Icc 0 D,right U (X,d)<0 := by
    apply isCompact_Icc.eventually_forall_of_forall_eventually
    intro d hd
    exact (analyticAt_right (hU (0,d) ⟨⟨le_rfl,hT.le⟩,hd⟩)).continuousAt.eventually
      (Iio_mem_nhds (hinit d hd))
  obtain ⟨l,r,⟨hl0,h0r⟩,hlr⟩ := he.exists_Ioo_subset
  let ε := min T r/2
  have hε0 : 0<ε := by dsimp [ε]; have := lt_min hT h0r; linarith
  have hεT : ε<T := by dsimp [ε]; have := min_le_left T r; linarith
  have hεr : ε<r := by dsimp [ε]; have := min_le_right T r; linarith
  refine ⟨ε,⟨hε0,hεT⟩,?_⟩
  intro q hq
  have hqT : q.1∈Ioc 0 T := ⟨hq.1.1,hq.1.2.trans hεT.le⟩
  have hder (d : ℝ) (hd : d∈Icc 0 D) : right U (q.1,d)<0 :=
    hlr ⟨hl0.trans hq.1.1,hq.1.2.trans_lt hεr⟩ d hd
  have hm := parameter_antitone_from_right_negative
    (fun d hd => hU (q.1,d) ⟨⟨hqT.1.le,hqT.2⟩,hd⟩) hder
  exact (hboundary q.1 hqT).trans_le (hm hq.2 ⟨hD,le_rfl⟩ hq.2.2)

/-- Interior positivity on every finite energy rectangle.  The hypotheses
are the actual transport PDE, its initial trace, and the positive far
parameter boundary; no interior positivity is assumed. -/
theorem transport_interior_positive {U : ℝ×ℝ→ℝ} {v c γ : ℝ→ℝ} {T D : ℝ}
    (hT : 0<T) (hD : 0≤D)
    (hU : AnalyticOnNhd ℝ U (transportRectangle T D))
    (hU0 : ∀d∈Icc 0 D,0≤U (0,d))
    (hinit : ∀d∈Icc 0 D,right U (0,d)<0)
    (hboundary : ∀X∈Ioc 0 T,0<U (X,D))
    (hv0 : v 0=0) (hv : ∀d∈Icc 0 D,0≤v d)
    (hc : ∀d∈Icc 0 D,0≤c d) (hcc : ContinuousOn c (Icc 0 D))
    (hγ : ∀d∈Icc 0 D,0≤γ d)
    (hpde : ∀q∈transportRectangle T D,0<q.1 →
      left (right U) q+v q.2*right (right U) q+c q.2*right U q= -γ q.2*U q) :
    ∀q∈Ioc 0 T ×ˢ Icc 0 D,0<U q := by
  obtain ⟨ε,hε,hsmall⟩ := transport_initial_positive_strip hT hD hU hinit hboundary
  intro q hq
  by_contra hn
  have hqn : U q≤0 := le_of_not_gt hn
  have hqe : ε≤q.1 := by
    by_contra he
    exact (hsmall q ⟨⟨hq.1.1,(lt_of_not_ge he).le⟩,hq.2⟩).not_le hqn
  let R : Set (ℝ×ℝ) := Icc ε T ×ˢ Icc 0 D
  let K : Set (ℝ×ℝ) := R ∩ U ⁻¹' Iic 0
  have hRsub : R ⊆ transportRectangle T D := fun z hz =>
    ⟨⟨hε.1.le.trans hz.1.1,hz.1.2⟩,hz.2⟩
  have hRc : ContinuousOn U R := hU.continuousOn.mono hRsub
  have hKc : IsCompact K := (isCompact_Icc.prod isCompact_Icc).of_isClosed_subset
    (hRc.preimage_isClosed_of_isClosed (isClosed_Icc.prod isClosed_Icc) isClosed_Iic) inter_subset_left
  have hKn : K.Nonempty := ⟨q,⟨⟨⟨hqe,hq.1.2⟩,hq.2⟩,hqn⟩⟩
  obtain ⟨z,hz,hzmin⟩ := hKc.exists_isMinOn hKn continuous_fst.continuousOn
  have hzR : z∈R := hz.1
  have hz0 : 0<z.1 := hε.1.trans_le hzR.1.1
  have hzT : z.1≤T := hzR.1.2
  have hzD : z.2∈Icc 0 D := hzR.2
  have hzU : U z≤0 := hz.2
  have hbefore : ∀X∈Ioo 0 z.1,∀d∈Icc 0 D,0<U (X,d) := by
    intro X hX d hd
    by_cases hXe : X≤ε
    · exact hsmall (X,d) ⟨⟨hX.1,hXe⟩,hd⟩
    by_contra hnX
    have hXU : U (X,d)≤0 := le_of_not_gt hnX
    have hm : z.1≤X := hzmin ⟨⟨⟨(lt_of_not_ge hXe).le,hX.2.le.trans hzT⟩,hd⟩,hXU⟩
    exact hX.2.not_le hm
  have hpre : ∀w∈transportRectangle z.1 D,0≤U w := by
    intro w hw
    by_cases hw0 : w.1=0
    · have hh := hU0 w.2 hw.2
      simpa only [← hw0,Prod.mk.eta] using hh
    have hwpos : 0<w.1 := lt_of_le_of_ne hw.1.1 (Ne.symm hw0)
    by_cases hwz : w.1<z.1
    · exact (hbefore w.1 ⟨hwpos,hwz⟩ w.2 hw.2).le
    have hweq : w.1=z.1 := le_antisymm hw.1.2 (le_of_not_gt hwz)
    have hcont := (hU w ⟨⟨hw.1.1,hw.1.2.trans hzT⟩,hw.2⟩).curry_left.continuousAt
    have ht := hcont.tendsto.mono_left (nhdsWithin_le_nhds (s:=Iio w.1))
    apply ge_of_tendsto ht
    filter_upwards [self_mem_nhdsWithin,
      (eventually_gt_nhds hwpos).filter_mono nhdsWithin_le_nhds] with X hX hX0
    exact (hbefore X ⟨hX0,by simpa only [hweq] using hX⟩ w.2 hw.2).le
  have hsub : transportRectangle z.1 D ⊆ transportRectangle T D :=
    fun w hw => ⟨⟨hw.1.1,hw.1.2.trans hzT⟩,hw.2⟩
  have hVneg := transport_negative_of_nonpositive_forcing hz0.le hD
    (fun w hw => analyticAt_right (hU w (hsub hw))) hinit hv0 hv hc hcc (by
      intro w hw hwp
      rw [hpde w (hsub hw) hwp]
      exact mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr (hγ w.2 hw.2)) (hpre w hw))
  have hm := parameter_antitone_from_right_negative
    (fun d hd => hU (z.1,d) ⟨⟨hz0.le,hzT⟩,hd⟩)
    (fun d hd => hVneg (z.1,d) ⟨⟨hz0.le,le_rfl⟩,hd⟩)
  have hpos : 0<U z := (hboundary z.1 ⟨hz0,hzT⟩).trans_le (hm hzD ⟨hD,le_rfl⟩ hzD.2)
  exact hpos.not_le hzU

end LeanVerification.UpperStripCompletion
