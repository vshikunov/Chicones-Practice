import LeanVerification.UpperStripCompletion.UpperForceLargeD
import Mathlib.Analysis.Calculus.Deriv.MeanValue

/-! Monotonic normalized force coefficients on the complete b interval. -/
noncomputable section
open Set
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 3000000

def upperP2Polynomial (b : ℝ) : ℝ := ((18:ℝ)+((-4035:ℝ)*(b^5))+((-828:ℝ)*(b^2))+((-309:ℝ)*(b^4))+((-21:ℝ)*b)+((419:ℝ)*(b^6))+((2430:ℝ)*(b^7))+((2726:ℝ)*(b^3)))

theorem upperP2Polynomial_pos {b : ℝ} (hb : 0≤b) (hb1 : b≤1/5) :
    0<upperP2Polynomial b := by
  have h0 : 0≤5*b := by positivity
  have h1 : 0≤1-5*b := by linarith
  have he : upperP2Polynomial b=((1:ℝ)/2)+(((35:ℝ)/2)*(5*b)^0*(1-5*b)^7 +
      ((1183:ℝ)/10)*(5*b)^1*(1-5*b)^6 +
      ((15459:ℝ)/50)*(5*b)^2*(1-5*b)^5 +
      ((101427:ℝ)/250)*(5*b)^3*(1-5*b)^4 +
      ((355047:ℝ)/1250)*(5*b)^4*(1-5*b)^3 +
      ((126717:ℝ)/1250)*(5*b)^5*(1-5*b)^2 +
      ((465413:ℝ)/31250)*(5*b)^6*(1-5*b)^1 +
      ((1627:ℝ)/6250)*(5*b)^7*(1-5*b)^0) := by
    unfold upperP2Polynomial
    ring
  have hp : 0≤((35:ℝ)/2)*(5*b)^0*(1-5*b)^7 +
      ((1183:ℝ)/10)*(5*b)^1*(1-5*b)^6 +
      ((15459:ℝ)/50)*(5*b)^2*(1-5*b)^5 +
      ((101427:ℝ)/250)*(5*b)^3*(1-5*b)^4 +
      ((355047:ℝ)/1250)*(5*b)^4*(1-5*b)^3 +
      ((126717:ℝ)/1250)*(5*b)^5*(1-5*b)^2 +
      ((465413:ℝ)/31250)*(5*b)^6*(1-5*b)^1 +
      ((1627:ℝ)/6250)*(5*b)^7*(1-5*b)^0 := by positivity
  rw [he]
  linarith only [hp]

def upperP3Polynomial (b : ℝ) : ℝ := ((12:ℝ)+((-3636:ℝ)*(b^5))+((-433:ℝ)*(b^2))+((-27:ℝ)*b)+((409:ℝ)*(b^4))+((1240:ℝ)*(b^7))+((1412:ℝ)*(b^6))+((1423:ℝ)*(b^3)))

theorem upperP3Polynomial_pos {b : ℝ} (hb : 0≤b) (hb1 : b≤1/5) :
    0<upperP3Polynomial b := by
  have h0 : 0≤5*b := by positivity
  have h1 : 0≤1-5*b := by linarith
  have he : upperP3Polynomial b=((1:ℝ)/5)+(((59:ℝ)/5)*(5*b)^0*(1-5*b)^7 +
      ((386:ℝ)/5)*(5*b)^1*(1-5*b)^6 +
      ((4952:ℝ)/25)*(5*b)^2*(1-5*b)^5 +
      ((32098:ℝ)/125)*(5*b)^3*(1-5*b)^4 +
      ((111244:ℝ)/625)*(5*b)^4*(1-5*b)^3 +
      ((195949:ℝ)/3125)*(5*b)^5*(1-5*b)^2 +
      ((138477:ℝ)/15625)*(5*b)^6*(1-5*b)^1 +
      ((191:ℝ)/3125)*(5*b)^7*(1-5*b)^0) := by
    unfold upperP3Polynomial
    ring
  have hp : 0≤((59:ℝ)/5)*(5*b)^0*(1-5*b)^7 +
      ((386:ℝ)/5)*(5*b)^1*(1-5*b)^6 +
      ((4952:ℝ)/25)*(5*b)^2*(1-5*b)^5 +
      ((32098:ℝ)/125)*(5*b)^3*(1-5*b)^4 +
      ((111244:ℝ)/625)*(5*b)^4*(1-5*b)^3 +
      ((195949:ℝ)/3125)*(5*b)^5*(1-5*b)^2 +
      ((138477:ℝ)/15625)*(5*b)^6*(1-5*b)^1 +
      ((191:ℝ)/3125)*(5*b)^7*(1-5*b)^0 := by positivity
  rw [he]
  linarith only [hp]

def upperNormalizedB2 (b : ℝ) : ℝ := (((8:ℝ)/3)*b*((1:ℝ)+b)*((1:ℝ)+((-4:ℝ)*b))*((6:ℝ)+((-13:ℝ)*(b^2))+((-8:ℝ)*(b^3))+((-5:ℝ)*b)))/(upperTPolynomial b)^2

theorem upperNormalizedB2_deriv {b : ℝ} (ht : upperTPolynomial b≠0) :
    HasDerivAt upperNormalizedB2 (16*upperP2Polynomial b/(3*(upperTPolynomial b)^3)) b := by
  have ht' : HasDerivAt upperTPolynomial ((-39:ℝ)+((-15:ℝ)*(b^2))+((140:ℝ)*b)) b := by
    convert ((((hasDerivAt_const b (6:ℝ)).add ((hasDerivAt_const b (-39:ℝ)).mul (hasDerivAt_id b))).add ((hasDerivAt_const b (-5:ℝ)).mul ((hasDerivAt_id b).pow 3))).add ((hasDerivAt_const b (70:ℝ)).mul ((hasDerivAt_id b).pow 2))) using 1
    all_goals
      dsimp only [upperTPolynomial,id_eq]
      first | (funext x; dsimp only [upperTPolynomial,id_eq]; ring) | ring
  have hn := (((((hasDerivAt_const b ((8:ℝ)/3)).mul (hasDerivAt_id b)).mul ((hasDerivAt_const b (1:ℝ)).add (hasDerivAt_id b))).mul ((hasDerivAt_const b (1:ℝ)).add ((hasDerivAt_const b (-4:ℝ)).mul (hasDerivAt_id b)))).mul ((((hasDerivAt_const b (6:ℝ)).add ((hasDerivAt_const b (-13:ℝ)).mul ((hasDerivAt_id b).pow 2))).add ((hasDerivAt_const b (-8:ℝ)).mul ((hasDerivAt_id b).pow 3))).add ((hasDerivAt_const b (-5:ℝ)).mul (hasDerivAt_id b))))
  convert hn.div (ht'.pow 2) (pow_ne_zero 2 ht) using 1
  all_goals
    try funext x
    dsimp only [upperNormalizedB2,id_eq]
    field_simp [ht]
    unfold upperP2Polynomial upperTPolynomial
    ring

def upperNormalizedB3 (b : ℝ) : ℝ := (((64:ℝ)/27)*(b^2)*(((1:ℝ)+b)^2)*(((1:ℝ)+((-4:ℝ)*b))^2)*((1:ℝ)+((-2:ℝ)*b))*((1:ℝ)+((2:ℝ)*b))*((3:ℝ)+b))/(upperTPolynomial b)^3

theorem upperNormalizedB3_deriv {b : ℝ} (ht : upperTPolynomial b≠0) :
    HasDerivAt upperNormalizedB3 (64*b*(1+b)*(1-4*b)*upperP3Polynomial b/(9*(upperTPolynomial b)^4)) b := by
  have ht' : HasDerivAt upperTPolynomial ((-39:ℝ)+((-15:ℝ)*(b^2))+((140:ℝ)*b)) b := by
    convert ((((hasDerivAt_const b (6:ℝ)).add ((hasDerivAt_const b (-39:ℝ)).mul (hasDerivAt_id b))).add ((hasDerivAt_const b (-5:ℝ)).mul ((hasDerivAt_id b).pow 3))).add ((hasDerivAt_const b (70:ℝ)).mul ((hasDerivAt_id b).pow 2))) using 1
    all_goals
      dsimp only [upperTPolynomial,id_eq]
      first | (funext x; dsimp only [upperTPolynomial,id_eq]; ring) | ring
  have hn := (((((((hasDerivAt_const b ((64:ℝ)/27)).mul ((hasDerivAt_id b).pow 2)).mul (((hasDerivAt_const b (1:ℝ)).add (hasDerivAt_id b)).pow 2)).mul (((hasDerivAt_const b (1:ℝ)).add ((hasDerivAt_const b (-4:ℝ)).mul (hasDerivAt_id b))).pow 2)).mul ((hasDerivAt_const b (1:ℝ)).add ((hasDerivAt_const b (-2:ℝ)).mul (hasDerivAt_id b)))).mul ((hasDerivAt_const b (1:ℝ)).add ((hasDerivAt_const b (2:ℝ)).mul (hasDerivAt_id b)))).mul ((hasDerivAt_const b (3:ℝ)).add (hasDerivAt_id b)))
  convert hn.div (ht'.pow 3) (pow_ne_zero 3 ht) using 1
  all_goals
    try funext x
    dsimp only [upperNormalizedB3,id_eq]
    field_simp [ht]
    unfold upperP3Polynomial upperTPolynomial
    ring

theorem upperNormalizedB2_strictMono : StrictMonoOn upperNormalizedB2 (Icc 0 (1/5)) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc 0 (1/5))
  · intro b hb
    exact (upperNormalizedB2_deriv (ne_of_gt (lt_of_lt_of_le (by norm_num : (0:ℝ)<4/5)
      (upper_t_polynomial_lower hb.1 hb.2)))).continuousAt.continuousWithinAt
  · intro b hb
    have hbc : b∈Icc 0 (1/5) := interior_subset hb
    have ht : 0<upperTPolynomial b := lt_of_lt_of_le (by norm_num : (0:ℝ)<4/5)
      (upper_t_polynomial_lower hbc.1 hbc.2)
    rw [(upperNormalizedB2_deriv ht.ne').deriv]
    have hp := upperP2Polynomial_pos hbc.1 hbc.2
    positivity

theorem upperNormalizedB3_monotone : MonotoneOn upperNormalizedB3 (Icc 0 (1/5)) := by
  apply monotoneOn_of_deriv_nonneg (convex_Icc 0 (1/5))
  · intro b hb
    exact (upperNormalizedB3_deriv (ne_of_gt (lt_of_lt_of_le (by norm_num : (0:ℝ)<4/5)
      (upper_t_polynomial_lower hb.1 hb.2)))).continuousAt.continuousWithinAt
  · intro b hb
    have hbc : b∈Icc 0 (1/5) := interior_subset hb
    exact (upperNormalizedB3_deriv (ne_of_gt (lt_of_lt_of_le (by norm_num : (0:ℝ)<4/5)
      (upper_t_polynomial_lower hbc.1 hbc.2)))).differentiableAt.differentiableWithinAt
  · intro b hb
    have hbc : b∈Icc 0 (1/5) := interior_subset hb
    have ht : 0<upperTPolynomial b := lt_of_lt_of_le (by norm_num : (0:ℝ)<4/5)
      (upper_t_polynomial_lower hbc.1 hbc.2)
    rw [(upperNormalizedB3_deriv ht.ne').deriv]
    have hp := upperP3Polynomial_pos hbc.1 hbc.2
    have h4 : 0≤1-4*b := by linarith [hbc.2]
    have hb0 := hbc.1
    positivity

end LeanVerification.UpperStripCompletion
