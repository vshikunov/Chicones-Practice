import LeanVerification.UpperStripCompletion.UpperForceNormalized
import LeanVerification.UpperStripCompletion.UpperForceCenter

/-! The d=0 force chamber, proved by normalized coefficient comparison. -/
noncomputable section
open Set
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 3000000

theorem normalized_cubic_algebra (a0 a1 a2 a3 x : ℝ) (h0 : a0≠0) (h1 : a1≠0) :
    (-a0+a1*x-a2*x^2-a3*x^3)/a0=
      -1+(a1*x/a0)-(a2*a0/a1^2)*(a1*x/a0)^2-
        (a3*a0^2/a1^3)*(a1*x/a0)^3 := by
  field_simp
  ring

theorem upper_normalized_coefficient_identities {b : ℝ} (hb : 0≤b) (hb1 : b≤1/5) :
    upperA2 b 0*upperA0 b/(upperA1 b 0)^2=upperNormalizedB2 b ∧
    upperA3 b 0*(upperA0 b)^2/(upperA1 b 0)^3=upperNormalizedB3 b := by
  have ht : upperTPolynomial b≠0 := (lt_of_lt_of_le (by norm_num : (0:ℝ)<4/5)
    (upper_t_polynomial_lower hb hb1)).ne'
  have hk : 1-2*b≠0 := by linarith
  constructor
  · unfold upperA0 upperA1 upperA2 upperNormalizedB2
    simp only [sub_zero,mul_zero,add_zero,one_pow,mul_one]
    field_simp [ht,hk]
    unfold upperBPolynomial
    ring
  · unfold upperA0 upperA1 upperA3 upperNormalizedB3
    simp only [sub_zero,mul_zero,zero_mul,add_zero,one_pow,mul_one]
    field_simp [ht,hk]
    ring

theorem upper_quartic_zero_parameter_normalized {b x : ℝ} (hb : 0≤b) (hb1 : b≤1/5) :
    upperForceQuartic b 0 x/upperA0 b=
      -1+(upperA1 b 0*x/upperA0 b)-upperNormalizedB2 b*(upperA1 b 0*x/upperA0 b)^2-
        upperNormalizedB3 b*(upperA1 b 0*x/upperA0 b)^3 := by
  have h0 := (upper_coefficients_general hb hb1 (by norm_num : (0:ℝ)≤0) (by norm_num)).1
  have h1 := upper_A1_pos hb hb1 (by norm_num : (0:ℝ)<1)
  have he := normalized_cubic_algebra (upperA0 b) (upperA1 b 0) (upperA2 b 0) (upperA3 b 0) x h0.ne' h1.ne'
  rw [(upper_normalized_coefficient_identities hb hb1).1,
    (upper_normalized_coefficient_identities hb hb1).2] at he
  simpa only [upperForceQuartic,upperA4,mul_zero,zero_mul,sub_zero] using he

theorem upper_quartic_neg_zero_parameter_of_center_neg {b x : ℝ}
    (hb : 0≤b) (hb1 : b≤1/5) (hC : upperCenterPolynomial b 0<0) (hx : 0<x) :
    upperForceQuartic b 0 x<0 := by
  have hccont : ContinuousOn (fun r => upperCenterPolynomial r 0) (Icc 0 b) := by
    unfold upperCenterPolynomial
    fun_prop
  obtain ⟨c,hc,hc0⟩ := intermediate_value_Icc' hb hccont
    ⟨hC.le,by norm_num [upperCenterPolynomial]⟩
  have hc1 : c≤1/5 := hc.2.trans hb1
  have hcb : c<b := by
    by_contra hn
    have he : c=b := le_antisymm hc.2 (le_of_not_gt hn)
    rw [he] at hc0
    exact hC.ne hc0
  have hA0b := (upper_coefficients_general hb hb1 (by norm_num : (0:ℝ)≤0) (by norm_num)).1
  have hA0c := (upper_coefficients_general hc.1 hc1 (by norm_num : (0:ℝ)≤0) (by norm_num)).1
  have hA1b := upper_A1_pos hb hb1 (by norm_num : (0:ℝ)<1)
  have hA1c := upper_A1_pos hc.1 hc1 (by norm_num : (0:ℝ)<1)
  let z := upperA1 b 0*x/upperA0 b
  let y := z*upperA0 c/upperA1 c 0
  have hz : 0<z := div_pos (mul_pos hA1b hx) hA0b
  have hy : 0<y := div_pos (mul_pos hz hA0c) hA1c
  have hyz : upperA1 c 0*y/upperA0 c=z := by
    dsimp only [y]
    field_simp
  have hcn := div_nonpos_of_nonpos_of_nonneg
    (upper_quartic_nonpos_center_zero hc.1 hc1 (by norm_num) (by norm_num) hc0 hy) hA0c.le
  rw [upper_quartic_zero_parameter_normalized hc.1 hc1,hyz] at hcn
  have hB2 := upperNormalizedB2_strictMono ⟨hc.1,hc1⟩ ⟨hb,hb1⟩ hcb
  have hB3 := upperNormalizedB3_monotone ⟨hc.1,hc1⟩ ⟨hb,hb1⟩ hcb.le
  have h2 := mul_lt_mul_of_pos_right hB2 (sq_pos_of_pos hz)
  have h3 := mul_le_mul_of_nonneg_right hB3 (pow_nonneg hz.le 3)
  have hbn : upperForceQuartic b 0 x/upperA0 b<0 := by
    rw [upper_quartic_zero_parameter_normalized hb hb1]
    change -1+z-upperNormalizedB2 b*z^2-upperNormalizedB3 b*z^3<0
    linarith only [hcn,h2,h3]
  simpa only [zero_mul] using (div_lt_iff₀ hA0b).mp hbn

theorem upper_quartic_nonpos_zero_parameter {b x : ℝ}
    (hb : 0≤b) (hb1 : b≤1/5) (hC : upperCenterPolynomial b 0≤0) (hx : 0<x) :
    upperForceQuartic b 0 x≤0 := by
  rcases lt_or_eq_of_le hC with hn|he
  · exact (upper_quartic_neg_zero_parameter_of_center_neg hb hb1 hn hx).le
  · exact upper_quartic_nonpos_center_zero hb hb1 (by norm_num) (by norm_num) he hx

theorem upper_quartic_neg_zero_parameter {b x : ℝ}
    (hb : 0≤b) (hb1 : b≤1/5) (hC : upperCenterPolynomial b 0≤0) (hx : 0<x) (hx1 : x≠1) :
    upperForceQuartic b 0 x<0 := by
  rcases lt_or_eq_of_le hC with hn|he
  · exact upper_quartic_neg_zero_parameter_of_center_neg hb hb1 hn hx
  · exact upper_quartic_neg_center_zero hb hb1 (by norm_num) (by norm_num) he hx hx1

end LeanVerification.UpperStripCompletion
