import LeanVerification.UpperStripCompletion.JacobiJets
import LeanVerification.GeneralMechanical.PositiveMode

/-! Monotonicity and strict concavity of the actual stationary Jacobi
variation.  Both signs follow from the first variation equation and the
two regular turns; they are not imposed as regional hypotheses. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical GeneralMechanical.EnergyModes
set_option maxHeartbeats 1600000

theorem jacobi_equation_closed_germ {W Y : ℝ → ℝ} {a b L : ℝ}
    (hab : a<b) (hW : AnalyticOnNhd ℝ W (Icc a b))
    (hY : AnalyticOnNhd ℝ Y (Icc a b))
    (he : ∀ x ∈ Ioo a b, 2*(L-W x)*deriv Y x+deriv W x*Y x=1) :
    ∀ x ∈ Icc a b, ∀ᶠ z in 𝓝 x,
      2*(L-W z)*deriv Y z+deriv W z*Y z=1 := by
  obtain ⟨s,hs,hsub,_,_,hse⟩ := regular_variation_extension hab hW hY he
  intro x hx
  filter_upwards [hs.mem_nhds (hsub hx)] with z hz
  exact hse z hz

theorem jacobi_derivative_pos {W Y : ℝ → ℝ} {a b L : ℝ}
    (hab : a<b) (hW : AnalyticOnNhd ℝ W (Icc a b))
    (hY : AnalyticOnNhd ℝ Y (Icc a b))
    (he : ∀ x ∈ Ioo a b, 2*(L-W x)*deriv Y x+deriv W x*Y x=1)
    (hWa : W a=L) (hWb : W b=L) (hga : deriv W a<0) (hgb : 0<deriv W b)
    (hv : ∀ x ∈ Ioo a b, 0<L-W x)
    (hk : ∀ x ∈ Icc a b, 0<deriv (deriv W) x) :
    ∀ x ∈ Icc a b, 0<deriv Y x := by
  have hφ : AnalyticOnNhd ℝ (fun _ : ℝ => (1 : ℝ)) (Icc a b) :=
    fun _ _ => analyticAt_const
  have hH : ∀ x ∈ Icc a b,
      0<CriticalEnergy.coefficientH W (fun _ => 1) L x := by
    intro x hx
    simpa [CriticalEnergy.coefficientH,CriticalEnergy.jet] using hk x hx
  have hp := (positive_normalized_mode hab hW hY he hWa hWb hga hgb hv hφ
    (fun _ _ => by norm_num) hH).2.1
  intro x hx
  have hh := hp x hx
  simp only [CriticalMode.mode,CriticalMode.bracket,deriv_const,one_mul,zero_mul,
    sub_zero] at hh
  exact pos_of_mul_pos_left hh (Real.rpow_nonneg (hH x hx).le _)

def jacobiConcavityFlux (W Y : ℝ → ℝ) (L x : ℝ) : ℝ :=
  (L-W x)*Real.sqrt (L-W x)*deriv (deriv Y) x

theorem jacobi_concavity_flux_derivative {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x) (hv : 0<L-W x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1) :
    HasDerivAt (jacobiConcavityFlux W Y L)
      (-Real.sqrt (L-W x)*deriv (deriv (deriv W)) x*Y x/2) x := by
  have hgap := hW.differentiableAt.hasDerivAt.const_sub L
  have hd := ((hgap.mul (hgap.sqrt hv.ne')).mul
    hY.deriv.deriv.differentiableAt.hasDerivAt)
  have h3 := jacobi_third_at hW hY he
  convert hd using 1
  have hs : Real.sqrt (L-W x)≠0 := (Real.sqrt_pos.2 hv).ne'
  field_simp [hs]
  ring_nf
  rw [Real.sq_sqrt hv.le]
  nlinarith only [congrArg (fun z : ℝ => z*(L-W x)) h3]

theorem jacobi_unique_zero {W Y : ℝ → ℝ} {a b L : ℝ}
    (hab : a<b) (hW : AnalyticOnNhd ℝ W (Icc a b))
    (hY : AnalyticOnNhd ℝ Y (Icc a b))
    (he : ∀ x ∈ Ioo a b, 2*(L-W x)*deriv Y x+deriv W x*Y x=1)
    (hWa : W a=L) (hWb : W b=L) (hga : deriv W a<0) (hgb : 0<deriv W b)
    (hv : ∀ x ∈ Ioo a b, 0<L-W x)
    (hk : ∀ x ∈ Icc a b, 0<deriv (deriv W) x) :
    ∃ q ∈ Ioo a b, Y q=0 ∧
      (∀ x ∈ Icc a b, x<q → Y x<0) ∧
      (∀ x ∈ Icc a b, q<x → 0<Y x) := by
  have ha : a ∈ Icc a b := ⟨le_rfl,hab.le⟩
  have hb : b ∈ Icc a b := ⟨hab.le,le_rfl⟩
  have heg := jacobi_equation_closed_germ hab hW hY he
  have hYa : Y a<0 := by
    rw [CriticalMode.variation_value_at_turn
      (by rw [hWa,sub_self]) hga.ne (heg a ha).self_of_nhds]
    exact one_div_neg.mpr hga
  have hYb : 0<Y b := by
    rw [CriticalMode.variation_value_at_turn
      (by rw [hWb,sub_self]) hgb.ne' (heg b hb).self_of_nhds]
    exact one_div_pos.mpr hgb
  have hmono : StrictMonoOn Y (Icc a b) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc a b) hY.continuousOn
    intro x hx
    exact jacobi_derivative_pos hab hW hY he hWa hWb hga hgb hv hk x (interior_subset hx)
  obtain ⟨q,hq,hq0⟩ := intermediate_value_Icc hab.le hY.continuousOn ⟨hYa.le,hYb.le⟩
  have hqa : a<q := lt_of_le_of_ne hq.1 (by intro h; rw [←h] at hq0; exact hYa.ne hq0)
  have hqb : q<b := lt_of_le_of_ne hq.2 (by intro h; rw [h] at hq0; exact hYb.ne' hq0)
  refine ⟨q,⟨hqa,hqb⟩,hq0,?_,?_⟩
  · intro x hx hxq
    simpa only [hq0] using hmono hx hq hxq
  · intro x hx hqx
    simpa only [hq0] using hmono hq hx hqx

theorem jacobi_second_derivative_neg {W Y : ℝ → ℝ} {a b L : ℝ}
    (hab : a<b) (hW : AnalyticOnNhd ℝ W (Icc a b))
    (hY : AnalyticOnNhd ℝ Y (Icc a b))
    (he : ∀ x ∈ Ioo a b, 2*(L-W x)*deriv Y x+deriv W x*Y x=1)
    (hWa : W a=L) (hWb : W b=L) (hga : deriv W a<0) (hgb : 0<deriv W b)
    (hv : ∀ x ∈ Ioo a b, 0<L-W x)
    (hk : ∀ x ∈ Icc a b, 0<deriv (deriv W) x)
    (hf : ∀ x ∈ Icc a b, deriv (deriv (deriv W)) x<0) :
    ∀ x ∈ Ioo a b, deriv (deriv Y) x<0 := by
  obtain ⟨q,hq,_,hl,hr⟩ := jacobi_unique_zero hab hW hY he hWa hWb hga hgb hv hk
  have heg := jacobi_equation_closed_germ hab hW hY he
  have hc : ContinuousOn (jacobiConcavityFlux W Y L) (Icc a b) := by
    intro x hx
    exact ((((continuousAt_const.sub (hW x hx).continuousAt).mul
      (Real.continuous_sqrt.continuousAt.comp
        (continuousAt_const.sub (hW x hx).continuousAt))).mul
          (hY x hx).deriv.deriv.continuousAt)).continuousWithinAt
  have hd (x : ℝ) (hx : x ∈ Ioo a b) :=
    (jacobi_concavity_flux_derivative (hW x (Ioo_subset_Icc_self hx))
      (hY x (Ioo_subset_Icc_self hx)) (hv x hx) (heg x (Ioo_subset_Icc_self hx))).deriv
  have hneg := PairedCompletion.negative_flux_of_single_switch (q := q) hc
    (by simp [jacobiConcavityFlux,hWa]) (by simp [jacobiConcavityFlux,hWb])
    (fun x hx hxq => by
      rw [hd x hx]
      exact div_neg_of_neg_of_pos
        (mul_neg_of_pos_of_neg (mul_pos_of_neg_of_neg
          (neg_neg_of_pos (Real.sqrt_pos.2 (hv x hx))) (hf x (Ioo_subset_Icc_self hx)))
          (hl x (Ioo_subset_Icc_self hx) hxq)) (by norm_num))
    (fun x hx hqx => by
      rw [hd x hx]
      exact div_pos (mul_pos (mul_pos_of_neg_of_neg
          (neg_neg_of_pos (Real.sqrt_pos.2 (hv x hx))) (hf x (Ioo_subset_Icc_self hx)))
          (hr x (Ioo_subset_Icc_self hx) hqx)) (by norm_num))
  intro x hx
  exact neg_of_mul_neg_right (hneg x hx) (mul_pos (hv x hx) (Real.sqrt_pos.2 (hv x hx))).le

end LeanVerification.UpperStripCompletion
