import LeanVerification.InteriorCompletion.ActionFirstVariation
import LeanVerification.GeneralMechanical.RegularIntervalPersistence
import Mathlib.Analysis.Calculus.FDeriv.Symmetric

/-! Actual complete action for the four-coefficient canonical family.
The derivatives below are derivatives of the convergent moving-turn
integral, identified with analytic fixed-angle quadratures. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology ContDiff
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical DirectionalPartials InteriorCompletion
set_option maxHeartbeats 3000000

abbrev CanonicalCoefficients := (ℝ×ℝ)×(ℝ×ℝ)
def canonicalA : CanonicalCoefficients := ((1,0),(0,0))
def canonicalB : CanonicalCoefficients := ((0,1),(0,0))
def canonicalC : CanonicalCoefficients := ((0,0),(1,0))
def canonicalDelta : CanonicalCoefficients := ((0,0),(0,1))

def canonicalGap (p : ℝ) (q : CanonicalCoefficients×ℝ) : ℝ :=
  q.1.1.1-q.1.1.2*q.2-q.1.2.1*q.2^2-q.1.2.2*q.2^(-p)

def directional {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (f : E→ℝ) (η : E) (q : E) : ℝ := fderiv ℝ f q η

theorem analyticAt_directional {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {f : E→ℝ} {q : E} (hf : AnalyticAt ℝ f q) (η : E) :
    AnalyticAt ℝ (directional f η) q :=
  ((ContinuousLinearMap.apply ℝ ℝ η).analyticAt _).comp hf.fderiv

theorem hasFDerivAt_directional {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {f : E→ℝ} {q : E} (hf : AnalyticAt ℝ f q) (η : E) :
    HasFDerivAt (directional f η)
      ((ContinuousLinearMap.apply ℝ ℝ η).comp (fderiv ℝ (fderiv ℝ f) q)) q :=
  (ContinuousLinearMap.apply ℝ ℝ η).hasFDerivAt.comp q hf.fderiv.differentiableAt.hasFDerivAt

theorem directional_commute {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {f : E→ℝ} {q : E} (hf : AnalyticAt ℝ f q) (η ξ : E) :
    directional (directional f η) ξ q=directional (directional f ξ) η q := by
  dsimp only [directional]
  rw [(hasFDerivAt_directional hf η).fderiv,(hasFDerivAt_directional hf ξ).fderiv]
  exact hf.contDiffAt.isSymmSndFDerivAt_of_omega ξ η

theorem analyticAt_canonicalGap (p : ℝ) (q : CanonicalCoefficients×ℝ) (hx : 0<q.2) :
    AnalyticAt ℝ (canonicalGap p) q := by
  have hA : AnalyticAt ℝ (fun r : CanonicalCoefficients×ℝ => r.1.1.1) q := analyticAt_fst.comp (analyticAt_fst.comp analyticAt_fst)
  have hB : AnalyticAt ℝ (fun r : CanonicalCoefficients×ℝ => r.1.1.2) q := analyticAt_snd.comp (analyticAt_fst.comp analyticAt_fst)
  have hC : AnalyticAt ℝ (fun r : CanonicalCoefficients×ℝ => r.1.2.1) q := analyticAt_fst.comp (analyticAt_snd.comp analyticAt_fst)
  have hδ : AnalyticAt ℝ (fun r : CanonicalCoefficients×ℝ => r.1.2.2) q := analyticAt_snd.comp (analyticAt_snd.comp analyticAt_fst)
  exact ((hA.sub (hB.mul analyticAt_snd)).sub (hC.mul (analyticAt_snd.pow 2))).sub
    (hδ.mul ((Loud.analyticAt_rpow_const (-p) q.2 hx).comp_of_eq analyticAt_snd rfl))

theorem canonicalGap_parameter (p : ℝ) (q η : CanonicalCoefficients) (x : ℝ) (hx : 0<x) :
    parameter (canonicalGap p) η (q,x)=η.1.1-η.1.2*x-η.2.1*x^2-η.2.2*x^(-p) := by
  rw [parameter_eq_slice_fderiv (analyticAt_canonicalGap p (q,x) hx).differentiableAt η]
  have hA : HasFDerivAt (fun r : ℝ×ℝ => r.1) (ContinuousLinearMap.fst ℝ ℝ ℝ) q.1 := hasFDerivAt_fst
  have hB : HasFDerivAt (fun r : ℝ×ℝ => r.2) (ContinuousLinearMap.snd ℝ ℝ ℝ) q.1 := hasFDerivAt_snd
  have hC : HasFDerivAt (fun r : ℝ×ℝ => r.1) (ContinuousLinearMap.fst ℝ ℝ ℝ) q.2 := hasFDerivAt_fst
  have hδ : HasFDerivAt (fun r : ℝ×ℝ => r.2) (ContinuousLinearMap.snd ℝ ℝ ℝ) q.2 := hasFDerivAt_snd
  have hf : HasFDerivAt (fun r : CanonicalCoefficients => r.1)
      (ContinuousLinearMap.fst ℝ (ℝ×ℝ) (ℝ×ℝ)) q := hasFDerivAt_fst
  have hs : HasFDerivAt (fun r : CanonicalCoefficients => r.2)
      (ContinuousLinearMap.snd ℝ (ℝ×ℝ) (ℝ×ℝ)) q := hasFDerivAt_snd
  have hd := (((hA.comp q hf).sub ((hB.comp q hf).mul_const x)).sub
    ((hC.comp q hs).mul_const (x^2))).sub ((hδ.comp q hs).mul_const (x^(-p)))
  dsimp only [Function.comp_apply] at hd
  change fderiv ℝ (fun r : CanonicalCoefficients =>
    r.1.1-r.1.2*x-r.2.1*x^2-r.2.2*x^(-p)) q η=_
  rw [hd.fderiv]
  simp only [ContinuousLinearMap.sub_apply,ContinuousLinearMap.smul_apply,
    ContinuousLinearMap.comp_apply,smul_eq_mul]
  change η.1.1-x*η.1.2-x^2*η.2.1-x^(-p)*η.2.2=_
  ring

theorem regularTwoTurnFamily_eventually {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [CompleteSpace E] [FiniteDimensional ℝ E]
    {V : E×ℝ→ℝ} {a b : E→ℝ} {q : E} (h : RegularTwoTurnFamily V a b q) :
    ∀ᶠ r in 𝓝 q,RegularTwoTurnFamily V a b r := by
  have hp := regular_interval_persistence h.analytic_left h.analytic_right h.root_left h.root_right
    h.turns_ordered h.analytic_gap h.positive_gap h.slope_left h.slope_right
  filter_upwards [hp,h.analytic_left.eventually_analyticAt,h.analytic_right.eventually_analyticAt,
    eventually_eventually_nhds.mpr h.root_left,eventually_eventually_nhds.mpr h.root_right]
    with r hr hra hrb hrza hrzb
  exact ⟨hra,hrb,hrza,hrzb,hr.1,hr.2.2.2.1,hr.2.2.2.2.1,hr.2.2.2.2.2.1,hr.2.2.2.2.2.2⟩

def canonicalPeriod (p : ℝ) (a b : CanonicalCoefficients→ℝ) (q : CanonicalCoefficients) : ℝ :=
  Real.sqrt 2*∫x in a q..b q,1/Real.sqrt (canonicalGap p (q,x))

def canonicalKernelA (p : ℝ) (a b : CanonicalCoefficients→ℝ) (q : CanonicalCoefficients×ℝ) : ℝ :=
  (b q.1-a q.1)/Real.sqrt (angularTurnFactor (canonicalGap p) a b q)

def canonicalKernelB (p : ℝ) (a b : CanonicalCoefficients→ℝ) (q : CanonicalCoefficients×ℝ) : ℝ :=
  -(b q.1-a q.1)*angularTurnNode a b q/Real.sqrt (angularTurnFactor (canonicalGap p) a b q)

theorem canonicalKernels_analytic {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (θ : ℝ) :
    AnalyticAt ℝ (canonicalKernelA p a b) (q,θ) ∧
      AnalyticAt ℝ (canonicalKernelB p a b) (q,θ) := by
  have hl : AnalyticAt ℝ (fun r : CanonicalCoefficients×ℝ => b r.1-a r.1) (q,θ) :=
    (h.analytic_right.comp_of_eq analyticAt_fst rfl).sub
    (h.analytic_left.comp_of_eq analyticAt_fst rfl)
  have hH := analyticAt_sqrt_comp (h.angularFactor_analytic θ) (h.factor_pos _ (unitSinNode_mem θ))
  have hH0 := (Real.sqrt_pos.mpr (h.factor_pos _ (unitSinNode_mem θ))).ne'
  exact ⟨hl.div hH hH0,(hl.neg.mul (h.angularNode_analytic θ)).div hH hH0⟩

theorem canonical_action_partials_angular {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    directional (completeTurnAction (canonicalGap p) a b) canonicalA q=
      Real.sqrt 2*∫θ in -(Real.pi/2)..Real.pi/2,canonicalKernelA p a b (q,θ) ∧
    directional (completeTurnAction (canonicalGap p) a b) canonicalB q=
      Real.sqrt 2*∫θ in -(Real.pi/2)..Real.pi/2,canonicalKernelB p a b (q,θ) := by
  have hA := h.action_first_variation canonicalA
  have hB := h.action_first_variation canonicalB
  have heA : (∫x in a q..b q,parameter (canonicalGap p) canonicalA (q,x)/
      Real.sqrt (canonicalGap p (q,x)))=
      ∫x in a q..b q,1/Real.sqrt (canonicalGap p (q,x)) := by
    apply intervalIntegral.integral_congr
    intro x hx
    rw [uIcc_of_le h.turns_ordered.le] at hx
    dsimp only
    rw [canonicalGap_parameter p q canonicalA x (lt_of_lt_of_le ha hx.1)]
    simp [canonicalA]
  have heB : (∫x in a q..b q,parameter (canonicalGap p) canonicalB (q,x)/
      Real.sqrt (canonicalGap p (q,x)))=
      ∫x in a q..b q,(-x)/Real.sqrt (canonicalGap p (q,x)) := by
    apply intervalIntegral.integral_congr
    intro x hx
    rw [uIcc_of_le h.turns_ordered.le] at hx
    dsimp only
    rw [canonicalGap_parameter p q canonicalB x (lt_of_lt_of_le ha hx.1)]
    simp [canonicalB]
  rw [heA,(h.weighted_quadrature (fun _ => 1) continuousOn_const).2] at hA
  rw [heB,(h.weighted_quadrature (fun x => -x) continuousOn_id.neg).2] at hB
  constructor
  · rw [directional,hA]
    dsimp only [canonicalKernelA]
    simp only [← intervalIntegral.integral_const_mul]
    congr 2
    funext θ
    ring
  · rw [directional,hB]
    dsimp only [canonicalKernelB]
    rw [← intervalIntegral.integral_const_mul]
    congr 2
    funext θ
    ring

theorem canonical_action_energy_derivative {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    directional (completeTurnAction (canonicalGap p) a b) canonicalA q=canonicalPeriod p a b q := by
  rw [directional,h.action_first_variation]
  dsimp only [canonicalPeriod]
  congr 1
  apply intervalIntegral.integral_congr
  intro x hx
  rw [uIcc_of_le h.turns_ordered.le] at hx
  dsimp only
  rw [canonicalGap_parameter p q canonicalA x (lt_of_lt_of_le ha hx.1)]
  simp [canonicalA]

end LeanVerification.UpperStripCompletion
