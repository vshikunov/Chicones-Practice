import LeanVerification.UpperStripCompletion.UpperPhysicalCanonical
import LeanVerification.UpperStripCompletion.UpperTransportEquation
import LeanVerification.UpperStripCompletion.UpperParameterRoot

/-! The actual physical transported slope, its center trace, and its
interior transport equation. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open Loud GeneralMechanical Sharpness AnalyticTwoPartials
set_option maxHeartbeats 3000000

def upperPhysicalU (b : ℝ) : ℝ×ℝ→ℝ :=
  parameterGauge upperTransportGauge (left (upperPhysicalChartPeriod b))

def upperInitialTrace (b d : ℝ) : ℝ :=
  Real.pi*Real.sqrt ((1-b)/2)/(12*b*(1+b))*
    ((1+b*d)*upperCenterPolynomial b d/(1+d)^3)

theorem partial_left_eventuallyEq {f g : ℝ×ℝ→ℝ} {q : ℝ×ℝ} (h : f=ᶠ[𝓝 q] g) :
    left f=ᶠ[𝓝 q] left g := by
  filter_upwards [eventually_eventually_nhds.mpr h] with r hr
  exact partial_left_congr hr

theorem partial_right_eventuallyEq {f g : ℝ×ℝ→ℝ} {q : ℝ×ℝ} (h : f=ᶠ[𝓝 q] g) :
    right f=ᶠ[𝓝 q] right g := by
  filter_upwards [eventually_eventually_nhds.mpr h] with r hr
  exact partial_right_congr hr

theorem analyticAt_upperPhysicalU {b : ℝ} {q : ℝ×ℝ}
    (hb : b<1) (hd : 0<1+q.2)
    (hq : q.1=0 ∨ AdmissibleEnergy (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q)) :
    AnalyticAt ℝ (upperPhysicalU b) q :=
  ((analyticAt_upperTransportGauge hd).comp_of_eq analyticAt_snd rfl).mul
    (analyticAt_left (analyticAt_upperPhysicalChartPeriod hb hd hq))

theorem upper_physical_period_chart_left {b : ℝ} {q : ℝ×ℝ}
    (hb : b<1) (hd : 0<1+q.2)
    (hq : q.1=0 ∨ AdmissibleEnergy (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q)) :
    left (upperPhysicalChartPeriod b) q=
      Real.sqrt (upperPhysicalScale b q.2)*extendedPhysicalSlope (upperPhysicalParameter b q)*
        (upperPhysicalHeight b q.2*Real.exp (-q.1)) := by
  have ha : AnalyticAt ℝ extendedPhysicalPeriod (upperPhysicalParameter b q) := by
    apply analyticAt_extendedPhysicalPeriod
    rcases hq with h0|hp
    · left
      have he : upperPhysicalParameter b q=((-1/(1+q.2),1/(1-b)),0) := by
        simp only [upperPhysicalParameter,upperPhysicalEnergy,h0,neg_zero,Real.exp_zero,sub_self,mul_zero]
      rw [he]
      exact jointCenterDomain_contains_center _ _
    · exact Or.inr hp
  have hs : HasDerivAt (fun h => extendedPhysicalPeriod ((-1/(1+q.2),1/(1-b)),h))
      (extendedPhysicalSlope (upperPhysicalParameter b q)) (upperPhysicalEnergy b q) := by
    rw [extendedPhysicalSlope,verticalDerivative_eq_deriv ha]
    exact ha.curry_right.differentiableAt.hasDerivAt
  have he : HasDerivAt (fun X => upperPhysicalEnergy b (X,q.2))
      (upperPhysicalHeight b q.2*Real.exp (-q.1)) q.1 := by
    convert (((hasDerivAt_id q.1).neg.exp).const_sub 1).const_mul (upperPhysicalHeight b q.2) using 1
    simp only [id_eq]
    ring
  have hh := (hs.comp q.1 he).const_mul (Real.sqrt (upperPhysicalScale b q.2))
  convert hh.deriv using 1
  ring

theorem upper_gauge_scale_product {b d : ℝ} (hd : 0<1+d) :
    upperTransportGauge d*Real.sqrt (upperPhysicalScale b d)=Real.sqrt ((1-b)/2) := by
  unfold upperTransportGauge upperPhysicalScale
  rw [← Real.sqrt_mul (show 0≤(1+d)/2 by positivity)]
  congr 1
  field_simp [hd.ne']
  ring

theorem upper_physical_U_formula {b : ℝ} {q : ℝ×ℝ}
    (hb : b<1) (hd : 0<1+q.2)
    (hq : q.1=0 ∨ AdmissibleEnergy (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q)) :
    upperPhysicalU b q=Real.sqrt ((1-b)/2)*upperPhysicalHeight b q.2*Real.exp (-q.1)*
      extendedPhysicalSlope (upperPhysicalParameter b q) := by
  change upperTransportGauge q.2*left (upperPhysicalChartPeriod b) q=_
  rw [upper_physical_period_chart_left hb hd hq]
  calc
    _=(upperTransportGauge q.2*Real.sqrt (upperPhysicalScale b q.2))*
      upperPhysicalHeight b q.2*Real.exp (-q.1)*extendedPhysicalSlope (upperPhysicalParameter b q) := by ring
    _=_ := by rw [upper_gauge_scale_product hd]

theorem upper_physical_U_center {b d : ℝ} (hb : 0<b) (hb1 : b<1) (hd : 0<1+d) :
    upperPhysicalU b (0,d)=upperInitialTrace b d := by
  have hm : 0<1-b := by linarith
  have hp : 0<1+b := by linarith
  rw [upper_physical_U_formula hb1 hd (Or.inl rfl),upper_physical_parameter_center,
    extendedPhysicalSlope_center_value,actual_tau1_polynomial,
    upper_tau1_normalization b d hm.ne' hd.ne']
  simp only [neg_zero,Real.exp_zero,mul_one]
  unfold upperInitialTrace upperPhysicalHeight upperPhysicalScale upperHeight
  field_simp [hb.ne',hm.ne',hp.ne',hd.ne']
  ring

theorem upper_initialTrace_deriv {b d : ℝ} (hd : 1+d≠0) :
    HasDerivAt (upperInitialTrace b)
      (Real.pi*Real.sqrt ((1-b)/2)/(12*b*(1+b))*
        (-6*(1-b)*upperGammaNumerator b d/(1+d)^4)) d := by
  have hn := (((hasDerivAt_id d).const_mul b).const_add 1).mul (upper_center_parameter_deriv b d)
  have he := ((hasDerivAt_id d).const_add 1).pow 3
  have hf := (hn.div he (pow_ne_zero 3 hd)).const_mul
    (Real.pi*Real.sqrt ((1-b)/2)/(12*b*(1+b)))
  convert hf using 1
  all_goals
    dsimp only [upperInitialTrace,id_eq]
    first | (funext x; dsimp only [upperInitialTrace]; ring) |
      (congr 1; field_simp [hd]; unfold upperCenterPolynomial upperGammaNumerator; ring)

theorem upper_physical_U_center_parameter_deriv {b d : ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hd : 0≤d) (hd1 : d≤1/9) :
    right (upperPhysicalU b) (0,d)<0 := by
  have hm : 0<1-b := by linarith
  have hp : 0<1+b := by linarith
  have he : 0<1+d := by linarith
  have hg : (fun e => upperPhysicalU b (0,e))=ᶠ[𝓝 d] upperInitialTrace b := by
    filter_upwards [(continuousAt_const.add continuousAt_id).eventually (Ioi_mem_nhds he)] with e he'
    exact upper_physical_U_center hb (by linarith) he'
  change deriv (fun e => upperPhysicalU b (0,e)) d<0
  rw [hg.deriv_eq,(upper_initialTrace_deriv he.ne').deriv]
  have hC : 0<Real.pi*Real.sqrt ((1-b)/2)/(12*b*(1+b)) := by positivity
  have hγ := upper_gamma_numerator_pos hb.le hb1 hd hd1
  apply mul_neg_of_pos_of_neg hC
  apply div_neg_of_neg_of_pos _ (by positivity)
  have hpos : 0<6*(1-b)*upperGammaNumerator b d := by positivity
  linarith only [hpos]

theorem upper_physical_transport {b : ℝ} {q : ℝ×ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hX : 0<q.1) (hd : 0≤q.2) (hd1 : q.2≤1) :
    left (right (upperPhysicalU b)) q+
      upperTransportV b q.2*right (right (upperPhysicalU b)) q+
      upperTransportC1 b q.2*right (upperPhysicalU b) q=
      -upperTransportGamma b q.2*upperPhysicalU b q := by
  obtain ⟨a,c,hfam,ha,hR⟩ := exists_upper_physical_canonical_chart hb hb1 hX hd hd1
  have hL := partial_left_eventuallyEq hR
  have hU : upperPhysicalU b=ᶠ[𝓝 q] upperActualU b a c := by
    filter_upwards [hL] with r hr
    change upperTransportGauge r.2*left (upperPhysicalChartPeriod b) r=
      upperTransportGauge r.2*left (upperChartPeriod b a c) r
    rw [hr]
  rw [partial_left_congr (partial_right_eventuallyEq hU),
    partial_right_congr (partial_right_eventuallyEq hU),partial_right_congr hU,hU.self_of_nhds]
  exact upper_actual_transport b a c q hb.ne' (by linarith) (by linarith)
    (by linarith) (by positivity) hfam ha

end LeanVerification.UpperStripCompletion
