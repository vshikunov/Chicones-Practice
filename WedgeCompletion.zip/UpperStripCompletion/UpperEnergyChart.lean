import LeanVerification.UpperStripCompletion.UpperCanonicalPDE

/-! The physical characteristic energy chart for the actual canonical
period.  This is an analytic substitution into the complete period. -/
noncomputable section
open Set Filter
open scoped Topology ContDiff
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical DirectionalPartials InteriorCompletion AnalyticTwoPartials
set_option maxHeartbeats 3600000

def upperHeight (b d : ℝ) : ℝ := (1-b)*(1+b*d)/(2*b*(1+b))
def upperChartDelta (b : ℝ) (q : ℝ×ℝ) : ℝ := upperHeight b q.2*Real.exp (-q.1)
def upperEnergyChart (b : ℝ) (q : ℝ×ℝ) : CanonicalCoefficients :=
  upperCanonicalPoint b q.2 (upperChartDelta b q)
def upperDChartDirection (b X : ℝ) : CanonicalCoefficients :=
  ((0,-1/(1+b)),(1/2,(1-b)/(2*(1+b))*Real.exp (-X)))
def upperDChartXDirection (b X : ℝ) : CanonicalCoefficients :=
  ((0,0),(0,-(1-b)/(2*(1+b))*Real.exp (-X)))
def upperChartPeriod (b : ℝ) (a c : CanonicalCoefficients→ℝ) (q : ℝ×ℝ) : ℝ :=
  canonicalPeriod (2*b/(1-b)) a c (upperEnergyChart b q)

theorem analyticAt_upperEnergyChart (b : ℝ) (q : ℝ×ℝ) :
    AnalyticAt ℝ (upperEnergyChart b) q := by
  exact (analyticAt_const.prod ((analyticAt_const.sub analyticAt_snd).mul analyticAt_const)).prod
    ((analyticAt_snd.mul analyticAt_const).prod
      (((analyticAt_const.mul (analyticAt_const.add (analyticAt_const.mul analyticAt_snd))).mul
        analyticAt_const).mul analyticAt_fst.neg.rexp'))

theorem hasDerivAt_upperChart_left (b : ℝ) (q : ℝ×ℝ) :
    HasDerivAt (fun X => upperEnergyChart b (X,q.2))
      (upperXDirection (upperChartDelta b q)) q.1 := by
  have hd := ((hasDerivAt_id q.1).neg.exp).const_mul (upperHeight b q.2)
  convert ((hasDerivAt_const q.1 (1/(2*b))).prodMk
    (hasDerivAt_const q.1 ((1-q.2)/(1+b)))).prodMk
      ((hasDerivAt_const q.1 (q.2/2)).prodMk hd) using 1
  simp only [upperXDirection,upperChartDelta,id_eq]
  congr 2
  ring

theorem hasDerivAt_upperChart_right (b : ℝ) (q : ℝ×ℝ) (hb : b≠0) (hp : 1+b≠0) :
    HasDerivAt (fun d => upperEnergyChart b (q.1,d)) (upperDChartDirection b q.1) q.2 := by
  have hδ := (((((hasDerivAt_id q.2).const_mul b).const_add 1).const_mul (1-b)).div_const
    (2*b*(1+b))).mul_const (Real.exp (-q.1))
  have hh := ((hasDerivAt_const q.2 (1/(2*b))).prodMk
    (((hasDerivAt_id q.2).const_sub 1).div_const (1+b))).prodMk
      (((hasDerivAt_id q.2).div_const 2).prodMk hδ)
  convert hh using 1
  simp only [upperDChartDirection,id_eq]
  congr 2
  field_simp [hb,hp]
  ring

theorem upperDChartDirection_eq (b : ℝ) (q : ℝ×ℝ)
    (hb : b≠0) (hp : 1+b≠0) (hbd : 1+b*q.2≠0) :
    upperDChartDirection b q.1=upperDDirection b q.2 (upperChartDelta b q) := by
  dsimp only [upperDChartDirection,upperDDirection,upperChartDelta,upperHeight]
  congr 2
  field_simp [hb,hp,hbd]
  ring

theorem hasDerivAt_upperDChartDirection (b X : ℝ) :
    HasDerivAt (upperDChartDirection b) (upperDChartXDirection b X) X := by
  have hd := ((hasDerivAt_id X).neg.exp).const_mul ((1-b)/(2*(1+b)))
  convert ((hasDerivAt_const X (0:ℝ)).prodMk (hasDerivAt_const X (-1/(1+b)))).prodMk
    ((hasDerivAt_const X (1/2:ℝ)).prodMk hd) using 1
  simp only [upperDChartXDirection,id_eq]
  congr 2
  ring

theorem upperDChartXDirection_eq (b : ℝ) (q : ℝ×ℝ)
    (hb : b≠0) (hp : 1+b≠0) (hbd : 1+b*q.2≠0) :
    upperDChartXDirection b q.1=upperTransportZeta b q.2 • upperXDirection (upperChartDelta b q) := by
  ext <;> simp only [upperDChartXDirection,upperTransportZeta,upperXDirection,upperChartDelta,
    upperHeight,Prod.smul_fst,Prod.smul_snd,smul_eq_mul] <;> field_simp [hb,hp,hbd] <;> ring

theorem hasDerivAt_directional_comp {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {f : E→ℝ} {c v : ℝ→E} {t : ℝ} {c' v' : E}
    (hf : AnalyticAt ℝ f (c t)) (hc : HasDerivAt c c' t) (hv : HasDerivAt v v' t) :
    HasDerivAt (fun r => directional f (v r) (c r))
      (hessian f (c t) c' (v t)+directional f v' (c t)) t := by
  have hh := ((hf.fderiv.differentiableAt.hasFDerivAt.comp_hasDerivAt t hc).clm_apply hv)
  convert hh using 1

theorem chart_period_first_partials {b : ℝ} {a c : CanonicalCoefficients→ℝ} {q : ℝ×ℝ}
    (hb : b≠0) (hp : 1+b≠0)
    (hT : AnalyticAt ℝ (canonicalPeriod (2*b/(1-b)) a c) (upperEnergyChart b q)) :
    left (upperChartPeriod b a c) q=directional (canonicalPeriod (2*b/(1-b)) a c)
      (upperXDirection (upperChartDelta b q)) (upperEnergyChart b q) ∧
    right (upperChartPeriod b a c) q=directional (canonicalPeriod (2*b/(1-b)) a c)
      (upperDChartDirection b q.1) (upperEnergyChart b q) := by
  exact ⟨(hT.differentiableAt.hasFDerivAt.comp_hasDerivAt q.1 (hasDerivAt_upperChart_left b q)).deriv,
    (hT.differentiableAt.hasFDerivAt.comp_hasDerivAt q.2 (hasDerivAt_upperChart_right b q hb hp)).deriv⟩

theorem chart_period_right_germ {b : ℝ} {a c : CanonicalCoefficients→ℝ} {q : ℝ×ℝ}
    (hb : b≠0) (hp : 1+b≠0)
    (hT : AnalyticAt ℝ (canonicalPeriod (2*b/(1-b)) a c) (upperEnergyChart b q)) :
    right (upperChartPeriod b a c) =ᶠ[𝓝 q] fun r =>
      directional (canonicalPeriod (2*b/(1-b)) a c) (upperDChartDirection b r.1) (upperEnergyChart b r) := by
  filter_upwards [(analyticAt_upperEnergyChart b q).continuousAt.eventually hT.eventually_analyticAt] with r hr
  exact (chart_period_first_partials hb hp hr).2

theorem chart_period_second_partials {b : ℝ} {a c : CanonicalCoefficients→ℝ} {q : ℝ×ℝ}
    (hb : b≠0) (hp : 1+b≠0) (hbd : 1+b*q.2≠0)
    (hT : AnalyticAt ℝ (canonicalPeriod (2*b/(1-b)) a c) (upperEnergyChart b q)) :
    let P := canonicalPeriod (2*b/(1-b)) a c
    let e := upperDDirection b q.2 (upperChartDelta b q)
    let x := upperXDirection (upperChartDelta b q)
    left (right (upperChartPeriod b a c)) q=
      hessian P (upperEnergyChart b q) e x+upperTransportZeta b q.2*directional P x (upperEnergyChart b q) ∧
    right (right (upperChartPeriod b a c)) q=hessian P (upperEnergyChart b q) e e := by
  have hg := chart_period_right_germ hb hp hT
  have hxg : (fun X => right (upperChartPeriod b a c) (X,q.2)) =ᶠ[𝓝 q.1]
      (fun X => directional (canonicalPeriod (2*b/(1-b)) a c) (upperDChartDirection b X)
        (upperEnergyChart b (X,q.2))) := (continuousAt_id.prodMk continuousAt_const).eventually hg
  have hdg : (fun d => right (upperChartPeriod b a c) (q.1,d)) =ᶠ[𝓝 q.2]
      (fun d => directional (canonicalPeriod (2*b/(1-b)) a c) (upperDChartDirection b q.1)
        (upperEnergyChart b (q.1,d))) := (continuousAt_const.prodMk continuousAt_id).eventually hg
  constructor
  · have hh := hasDerivAt_directional_comp (c:=fun X => upperEnergyChart b (X,q.2))
      (v:=upperDChartDirection b) (t:=q.1) hT (hasDerivAt_upperChart_left b q)
      (hasDerivAt_upperDChartDirection b q.1)
    change deriv (fun X => right (upperChartPeriod b a c) (X,q.2)) q.1=_
    rw [hxg.deriv_eq,hh.deriv,upperDChartDirection_eq b q hb hp hbd,
      upperDChartXDirection_eq b q hb hp hbd]
    rw [hessian_symmetric hT]
    simp only [directional,map_smul,smul_eq_mul]
  · have hh := hasDerivAt_directional_comp (c:=fun d => upperEnergyChart b (q.1,d))
      (v:=fun _ => upperDChartDirection b q.1) (t:=q.2) hT (hasDerivAt_upperChart_right b q hb hp)
      (hasDerivAt_const q.2 (upperDChartDirection b q.1))
    change deriv (fun d => right (upperChartPeriod b a c) (q.1,d)) q.2=_
    rw [hdg.deriv_eq,hh.deriv,upperDChartDirection_eq b q hb hp hbd]
    simp only [directional,map_zero,add_zero]

theorem upper_actual_period_PDE (b : ℝ) (a c : CanonicalCoefficients→ℝ) (q : ℝ×ℝ)
    (hb : b≠0) (hm : 1-b≠0) (hp : 1+b≠0) (hd : 1+q.2≠0) (hbd : 1+b*q.2≠0)
    (h : RegularTwoTurnFamily (canonicalGap (2*b/(1-b))) a c (upperEnergyChart b q))
    (ha : 0<a (upperEnergyChart b q)) :
    left (right (upperChartPeriod b a c)) q+
      upperTransportV b q.2*right (right (upperChartPeriod b a c)) q+
      upperTransportA b q.2*right (upperChartPeriod b a c) q+
      1/(2*(1+q.2))*left (upperChartPeriod b a c) q+
      upperTransportC b q.2*upperChartPeriod b a c q=0 := by
  have hT := analyticAt_canonicalPeriod h ha
  have h1 := chart_period_first_partials hb hp hT
  have h2 := chart_period_second_partials hb hp hbd hT
  have he := upper_canonical_period_jet_equation b q.2 (upperChartDelta b q) a c hb hm hp hd hbd h ha
  rw [h2.1,h2.2,h1.1,h1.2,upperDChartDirection_eq b q hb hp hbd]
  change _=0 at he
  dsimp only [upperChartPeriod,upperEnergyChart]
  linarith only [he]

end LeanVerification.UpperStripCompletion
