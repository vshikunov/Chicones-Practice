import LeanVerification.UpperStripCompletion.CanonicalEuler

/-! Differentiated Euler identities for the actual canonical period. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology ContDiff
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical DirectionalPartials InteriorCompletion
set_option maxHeartbeats 2800000

def canonicalDilationLinear (p : ℝ) : CanonicalCoefficients→L[ℝ] CanonicalCoefficients :=
  ((0 : CanonicalCoefficients→L[ℝ] ℝ).prod
    ((ContinuousLinearMap.snd ℝ ℝ ℝ).comp (ContinuousLinearMap.fst ℝ (ℝ×ℝ) (ℝ×ℝ)))).prod
  (((2:ℝ) • (ContinuousLinearMap.fst ℝ ℝ ℝ).comp (ContinuousLinearMap.snd ℝ (ℝ×ℝ) (ℝ×ℝ))).prod
    ((-p) • (ContinuousLinearMap.snd ℝ ℝ ℝ).comp (ContinuousLinearMap.snd ℝ (ℝ×ℝ) (ℝ×ℝ))))

theorem canonicalDilationLinear_apply (p : ℝ) (q : CanonicalCoefficients) :
    canonicalDilationLinear p q=canonicalDilation p q := by
  rfl

theorem hasFDerivAt_canonicalDilation (p : ℝ) (q : CanonicalCoefficients) :
    HasFDerivAt (canonicalDilation p) (canonicalDilationLinear p) q := by
  convert (canonicalDilationLinear p).hasFDerivAt using 1

def hessian {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (f : E→ℝ) (q η ξ : E) : ℝ := fderiv ℝ (fderiv ℝ f) q η ξ

theorem hessian_eq_directional {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {f : E→ℝ} {q : E} (hf : AnalyticAt ℝ f q) (η ξ : E) :
    hessian f q η ξ=directional (directional f ξ) η q := by
  rw [directional,(hasFDerivAt_directional hf ξ).fderiv]
  rfl

theorem hessian_symmetric {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {f : E→ℝ} {q : E} (hf : AnalyticAt ℝ f q) (η ξ : E) :
    hessian f q η ξ=hessian f q ξ η :=
  hf.contDiffAt.isSymmSndFDerivAt_of_omega η ξ

theorem canonical_period_euler_germs {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    ((fun r => directional (canonicalPeriod p a b) r r) =ᶠ[𝓝 q]
      fun r => -canonicalPeriod p a b r/2) ∧
    ((fun r => directional (canonicalPeriod p a b) (canonicalDilation p r) r) =ᶠ[𝓝 q]
      fun r => -canonicalPeriod p a b r) := by
  have hg := (regularTwoTurnFamily_eventually h).and
    (h.analytic_left.continuousAt.eventually (Ioi_mem_nhds ha))
  exact ⟨hg.mono (fun r hr => (canonical_period_euler_identities hr.1 hr.2).1),
    hg.mono (fun r hr => (canonical_period_euler_identities hr.1 hr.2).2)⟩

theorem canonical_period_euler_hessian {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) (η : CanonicalCoefficients) :
    hessian (canonicalPeriod p a b) q η q= -(3/2)*directional (canonicalPeriod p a b) η q ∧
    hessian (canonicalPeriod p a b) q η (canonicalDilation p q)=
      -directional (canonicalPeriod p a b) (η+canonicalDilation p η) q := by
  have hT := analyticAt_canonicalPeriod h ha
  have hg := canonical_period_euler_germs h ha
  have hrad := hT.fderiv.differentiableAt.hasFDerivAt.clm_apply (hasFDerivAt_id q)
  have hdil := hT.fderiv.differentiableAt.hasFDerivAt.clm_apply (hasFDerivAt_canonicalDilation p q)
  simp only [id_eq] at hrad
  have hrhs : HasFDerivAt (fun r => -canonicalPeriod p a b r/2)
      (-(1/2:ℝ) • fderiv ℝ (canonicalPeriod p a b) q) q := by
    convert hT.differentiableAt.hasFDerivAt.const_mul (-(1/2:ℝ)) using 1
    ext r
    ring
  have hrrhs := hT.differentiableAt.hasFDerivAt.neg
  constructor
  · have he := congrArg (fun d : CanonicalCoefficients→L[ℝ] ℝ => d η) hg.1.fderiv_eq
    change fderiv ℝ (fun r => fderiv ℝ (canonicalPeriod p a b) r r) q η=_ at he
    rw [hrad.fderiv,hrhs.fderiv] at he
    simp only [ContinuousLinearMap.add_apply,ContinuousLinearMap.comp_apply,
      ContinuousLinearMap.id_apply,ContinuousLinearMap.smul_apply,
      ContinuousLinearMap.neg_apply,smul_eq_mul] at he
    change directional (canonicalPeriod p a b) η q+hessian (canonicalPeriod p a b) q η q=
      -(1/2:ℝ)*directional (canonicalPeriod p a b) η q at he
    linarith only [he]
  · have he := congrArg (fun d : CanonicalCoefficients→L[ℝ] ℝ => d η) hg.2.fderiv_eq
    change fderiv ℝ (fun r => fderiv ℝ (canonicalPeriod p a b) r (canonicalDilation p r)) q η=_ at he
    rw [hdil.fderiv,hrrhs.fderiv] at he
    simp only [ContinuousLinearMap.add_apply,ContinuousLinearMap.comp_apply,
      ContinuousLinearMap.neg_apply,canonicalDilationLinear_apply] at he
    change directional (canonicalPeriod p a b) (canonicalDilation p η) q+
      hessian (canonicalPeriod p a b) q η (canonicalDilation p q)=
      -directional (canonicalPeriod p a b) η q at he
    simp only [directional,map_add]
    change hessian (canonicalPeriod p a b) q η (canonicalDilation p q)=
      -(directional (canonicalPeriod p a b) η q+directional (canonicalPeriod p a b) (canonicalDilation p η) q)
    linarith only [he]

end LeanVerification.UpperStripCompletion
