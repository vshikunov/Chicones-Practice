import LeanVerification.UpperStripCompletion.UpperForceSign
import LeanVerification.UpperStripCompletion.UpperTransportAlgebra

/-! The separating center curve and the transport coefficient signs. -/
noncomputable section
open Set
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 2000000

def upperGammaNumerator (b d : ℝ) : ℝ :=
  2-5*b+2*b^2-(3-4*b+3*b^2)*d-b*d^2

theorem upper_gamma_numerator_pos {b d : ℝ}
    (hb : 0≤b) (hb1 : b≤1/5) (hd : 0≤d) (hd1 : d≤1/9) : 0<upperGammaNumerator b d := by
  have hb2 : b^2≤1/25 := by nlinarith [mul_nonneg hb (sub_nonneg.mpr hb1)]
  have hd2 : d^2≤1/81 := by nlinarith [mul_nonneg hd (sub_nonneg.mpr hd1)]
  have hcoef : 3-4*b+3*b^2≤3 := by nlinarith [mul_nonneg hb (show 0≤4-3*b by linarith)]
  have hfirst := mul_le_mul_of_nonneg_right hcoef hd
  have hlast := mul_le_mul_of_nonneg_left hd2 hb
  unfold upperGammaNumerator
  nlinarith [sq_nonneg b]

theorem upper_transport_coefficient_signs {b d : ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hd : 0≤d) (hd1 : d≤1/9) :
    0≤upperTransportV b d ∧ 0≤upperTransportC1 b d ∧ 0<upperTransportGamma b d := by
  have hm : 0<1-b := by linarith
  have hp : 0<1+b := by linarith
  have he : 0<1+d := by linarith
  have hbd : 0<1+b*d := by positivity
  have hdp : 0≤b+d := by positivity
  have hg := upper_gamma_numerator_pos hb.le hb1 hd hd1
  have hc : 0≤b^2*d^2+5*b^2*d+3*b*d^3+7*b*d^2-b*d+3*b+d^2+5*d := by
    have h3 : 0≤b*(3-d) := mul_nonneg hb.le (by linarith)
    have hn : 0≤b^2*d^2+5*b^2*d+3*b*d^3+7*b*d^2+d^2+5*d := by positivity
    nlinarith only [h3,hn]
  refine ⟨?_,?_,?_⟩
  · unfold upperTransportV
    positivity
  · unfold upperTransportC1
    exact div_nonneg (mul_nonneg hm.le hc) (by positivity)
  · unfold upperTransportGamma
    exact div_pos (mul_pos hm hg) (by positivity)

theorem upper_transport_v_zero (b : ℝ) : upperTransportV b 0=0 := by simp [upperTransportV]

theorem upper_transport_c_continuous {b D : ℝ} (hb : 0<b) (hD : 0≤D) :
    ContinuousOn (upperTransportC1 b) (Icc 0 D) := by
  intro d hd
  have hp : 0<1+b := by linarith
  have he : 0<1+d := by linarith [hd.1]
  apply ContinuousAt.continuousWithinAt
  unfold upperTransportC1
  fun_prop (disch := positivity)

theorem upper_center_parameter_deriv (b d : ℝ) :
    HasDerivAt (upperCenterPolynomial b) (2*b*(b+3)*d+3*b^2+14*b-9) d := by
  convert ((((hasDerivAt_id d).pow 2).const_mul (b*(b+3))).add
    ((hasDerivAt_id d).const_mul (3*b^2+14*b-9))).add_const (12*b^2-9*b+1) using 1
  all_goals
    dsimp only [upperCenterPolynomial,id_eq]
    first | (funext x; unfold upperCenterPolynomial; ring) | ring

theorem upper_center_strictAnti {b : ℝ} (hb : 0≤b) (hb1 : b≤1/5) :
    StrictAntiOn (upperCenterPolynomial b) (Icc 0 1) := by
  apply strictAntiOn_of_deriv_neg (convex_Icc 0 1)
    (fun d hd => (upper_center_parameter_deriv b d).continuousAt.continuousWithinAt)
  intro d hd
  have hdc : d∈Icc 0 1 := interior_subset hd
  rw [(upper_center_parameter_deriv b d).deriv]
  have hb2 : b^2≤1/25 := by nlinarith [mul_nonneg hb (sub_nonneg.mpr hb1)]
  have hm := mul_le_mul_of_nonneg_left hdc.2 (show 0≤2*b*(b+3) by positivity)
  nlinarith only [hb1,hb2,hm]

theorem upper_center_at_ninth (b : ℝ) :
    upperCenterPolynomial b (1/9)=200*b*(5*b-3)/81 := by unfold upperCenterPolynomial; ring

theorem upper_center_positive_range {b d : ℝ} (hb : 0≤b) (hb1 : b≤1/5)
    (hd : 0≤d) (hd1 : d≤1) (hC : 0<upperCenterPolynomial b d) :
    d<1/9 ∧ 0<upperCenterPolynomial b 0 := by
  have hm := (upper_center_strictAnti hb hb1).antitoneOn
  have hc0 := hC.trans_le (hm ⟨by norm_num,by norm_num⟩ ⟨hd,hd1⟩ hd)
  refine ⟨?_,hc0⟩
  by_contra hn
  have hd9 : 1/9≤d := le_of_not_gt hn
  have hh := hm (show (1/9:ℝ)∈Icc 0 1 by norm_num) ⟨hd,hd1⟩ hd9
  rw [upper_center_at_ninth] at hh
  have hp : 200*b*(5*b-3)/81≤0 := div_nonpos_of_nonpos_of_nonneg
    (mul_nonpos_of_nonneg_of_nonpos (by positivity) (by linarith)) (by norm_num)
  exact hC.not_le (hh.trans hp)

def upperRootDiscriminant (b : ℝ) : ℝ :=
  (9-14*b-3*b^2)^2-4*b*(b+3)*upperCenterPolynomial b 0

def upperCenterRoot (b : ℝ) : ℝ :=
  2*upperCenterPolynomial b 0/(9-14*b-3*b^2+Real.sqrt (upperRootDiscriminant b))

theorem upperCenterRoot_zero : upperCenterRoot 0=1/9 := by
  have hs : Real.sqrt (81:ℝ)=9 := by convert Real.sqrt_sq (show (0:ℝ)≤9 by norm_num) using 1 <;> norm_num
  norm_num [upperCenterRoot,upperRootDiscriminant,upperCenterPolynomial,hs]

theorem continuousAt_upperCenterRoot_zero : ContinuousAt upperCenterRoot 0 := by
  unfold upperCenterRoot
  apply ContinuousAt.div
  · unfold upperCenterPolynomial
    fun_prop
  · unfold upperRootDiscriminant upperCenterPolynomial
    fun_prop
  · have hs : Real.sqrt (81:ℝ)=9 := by convert Real.sqrt_sq (show (0:ℝ)≤9 by norm_num) using 1 <;> norm_num
    norm_num [upperRootDiscriminant,upperCenterPolynomial,hs]

theorem upperCenterRoot_eq_of_zero {b c : ℝ} (hb : 0≤b) (hb1 : b≤1/5)
    (hc : 0≤c) (hc1 : c≤1/9) (hz : upperCenterPolynomial b c=0) : upperCenterRoot b=c := by
  have hb2 : b^2≤1/25 := by nlinarith [mul_nonneg hb (sub_nonneg.mpr hb1)]
  have hm := mul_le_mul_of_nonneg_left hc1 (show 0≤2*b*(b+3) by positivity)
  have hs : 0<9-14*b-3*b^2-2*b*(b+3)*c := by nlinarith only [hb1,hb2,hm]
  have he : upperRootDiscriminant b=(9-14*b-3*b^2-2*b*(b+3)*c)^2 := by
    unfold upperRootDiscriminant
    have hid : (9-14*b-3*b^2)^2-4*b*(b+3)*upperCenterPolynomial b 0-
        (9-14*b-3*b^2-2*b*(b+3)*c)^2= -4*b*(b+3)*upperCenterPolynomial b c := by
      unfold upperCenterPolynomial
      ring
    rw [hz,mul_zero] at hid
    linarith only [hid]
  unfold upperCenterRoot
  rw [he,Real.sqrt_sq hs.le]
  have hd : 9-14*b-3*b^2+(9-14*b-3*b^2-2*b*(b+3)*c)≠0 := by
    have ha : 0≤2*b*(b+3)*c := by positivity
    nlinarith only [hs,ha]
  apply (div_eq_iff hd).mpr
  unfold upperCenterPolynomial at hz ⊢
  nlinarith only [hz]

theorem upperCenterRoot_spec {b : ℝ} (hb : 0<b) (hb1 : b≤1/5)
    (hC0 : 0<upperCenterPolynomial b 0) :
    0<upperCenterRoot b ∧ upperCenterRoot b<1/9 ∧ upperCenterPolynomial b (upperCenterRoot b)=0 := by
  have hC9 : upperCenterPolynomial b (1/9)<0 := by
    rw [upper_center_at_ninth]
    exact div_neg_of_neg_of_pos (mul_neg_of_pos_of_neg (by positivity) (by linarith)) (by norm_num)
  have hccont : ContinuousOn (upperCenterPolynomial b) (Icc 0 (1/9)) := by
    unfold upperCenterPolynomial
    fun_prop
  obtain ⟨c,hc,hc0⟩ := intermediate_value_Icc' (by norm_num : (0:ℝ)≤1/9) hccont ⟨hC9.le,hC0.le⟩
  have he := upperCenterRoot_eq_of_zero hb.le hb1 hc.1 hc.2 hc0
  rw [he]
  refine ⟨?_,?_,hc0⟩
  · by_contra hn
    have hz : c=0 := le_antisymm (le_of_not_gt hn) hc.1
    rw [hz] at hc0
    exact hC0.ne' hc0
  · by_contra hn
    have hz : c=1/9 := le_antisymm hc.2 (le_of_not_gt hn)
    rw [hz] at hc0
    exact hC9.ne hc0

theorem upper_positive_parameter_lt_root {b d : ℝ} (hb : 0<b) (hb1 : b≤1/5)
    (hd : 0≤d) (hd1 : d≤1) (hC : 0<upperCenterPolynomial b d) : d<upperCenterRoot b := by
  have hr := upperCenterRoot_spec hb hb1 (upper_center_positive_range hb.le hb1 hd hd1 hC).2
  by_contra hn
  have hh := (upper_center_strictAnti hb.le hb1).antitoneOn
    ⟨hr.1.le,by linarith [hr.2.1]⟩ ⟨hd,hd1⟩ (le_of_not_gt hn)
  rw [hr.2.2] at hh
  exact hC.not_le hh

end LeanVerification.UpperStripCompletion
