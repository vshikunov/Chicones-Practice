import LeanVerification.UpperStripCompletion.CanonicalAction

/-! Cancellation of the actual second-variation kernel.  The primitive
is regular at both angular endpoints and vanishes there. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology ContDiff
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical DirectionalPartials InteriorCompletion
set_option maxHeartbeats 3600000

theorem canonical_turn_velocity_identity {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    fderiv ℝ a q canonicalC=a q*fderiv ℝ a q canonicalB ∧
      fderiv ℝ b q canonicalC=b q*fderiv ℝ b q canonicalB := by
  have hab := lt_trans ha h.turns_ordered
  constructor
  · rw [implicit_turn_parameter_derivative
      (h.analytic_gap _ ⟨le_rfl,h.turns_ordered.le⟩).differentiableAt
      h.analytic_left.differentiableAt h.root_left h.slope_left.ne' canonicalC,
      implicit_turn_parameter_derivative
      (h.analytic_gap _ ⟨le_rfl,h.turns_ordered.le⟩).differentiableAt
      h.analytic_left.differentiableAt h.root_left h.slope_left.ne' canonicalB,
      canonicalGap_parameter p q canonicalC (a q) ha,
      canonicalGap_parameter p q canonicalB (a q) ha]
    simp only [canonicalC,canonicalB,Prod.fst,Prod.snd,zero_mul,one_mul,sub_zero,zero_sub]
    ring
  · rw [implicit_turn_parameter_derivative
      (h.analytic_gap _ ⟨h.turns_ordered.le,le_rfl⟩).differentiableAt
      h.analytic_right.differentiableAt h.root_right h.slope_right.ne canonicalC,
      implicit_turn_parameter_derivative
      (h.analytic_gap _ ⟨h.turns_ordered.le,le_rfl⟩).differentiableAt
      h.analytic_right.differentiableAt h.root_right h.slope_right.ne canonicalB,
      canonicalGap_parameter p q canonicalC (b q) hab,
      canonicalGap_parameter p q canonicalB (b q) hab]
    simp only [canonicalC,canonicalB,Prod.fst,Prod.snd,zero_mul,one_mul,sub_zero,zero_sub]
    ring

theorem canonical_angular_velocity_identities {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) (θ : ℝ) :
    angularTurnVelocity a b canonicalC q θ-angularTurnNode a b (q,θ)*
      angularTurnVelocity a b canonicalB q θ=
      (fderiv ℝ b q canonicalB-fderiv ℝ a q canonicalB)*(b q-a q)*(Real.cos θ/2)^2 ∧
    (fderiv ℝ b q canonicalC-fderiv ℝ a q canonicalC)-
      (fderiv ℝ b q canonicalB-fderiv ℝ a q canonicalB)*angularTurnNode a b (q,θ)-
      (b q-a q)*angularTurnVelocity a b canonicalB q θ=
      -(fderiv ℝ b q canonicalB-fderiv ℝ a q canonicalB)*(b q-a q)*Real.sin θ := by
  obtain ⟨hca,hcb⟩ := canonical_turn_velocity_identity h ha
  constructor
  · rw [← unitSinNode_product θ]
    dsimp only [angularTurnVelocity,angularTurnNode,affineTurnNode]
    rw [hca,hcb]
    ring
  · dsimp only [angularTurnVelocity,angularTurnNode,affineTurnNode]
    rw [hca,hcb]
    dsimp only [unitSinNode]
    ring

theorem angularFactor_parameter_relation {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [CompleteSpace E] [FiniteDimensional ℝ E]
    {V : E×ℝ→ℝ} {a b : E→ℝ} {q : E} (h : RegularTwoTurnFamily V a b q) (η : E) (θ : ℝ) :
    (Real.cos θ/2)^2*parameter (angularTurnFactor V a b) η (q,θ)=
      parameter V η (q,angularTurnNode a b (q,θ))+
      spatial V (q,angularTurnNode a b (q,θ))*angularTurnVelocity a b η q θ := by
  have he : (fun r => angularTurnGap V a b (r,θ)) =ᶠ[𝓝 q]
      (fun r => (Real.cos θ/2)^2*angularTurnFactor V a b (r,θ)) :=
    h.angular_factorization_germ.mono fun r hr => hr θ
  have hd := ((h.angularFactor_analytic θ).curry_left.differentiableAt.hasFDerivAt).const_mul
    ((Real.cos θ/2)^2)
  have hdv := congrArg (fun d : E→L[ℝ] ℝ => d η) he.fderiv_eq
  rw [hd.fderiv] at hdv
  simp only [ContinuousLinearMap.smul_apply,smul_eq_mul] at hdv
  rw [← parameter_eq_slice_fderiv (h.angularGap_analytic θ).differentiableAt η,
    ← parameter_eq_slice_fderiv (h.angularFactor_analytic θ).differentiableAt η,
    h.angularGap_parameter η θ] at hdv
  exact hdv.symm

theorem canonical_factor_parameter_cancellation {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q)
    (θ : ℝ) (hθ : θ∈Ioo (-(Real.pi/2)) (Real.pi/2)) :
    angularTurnNode a b (q,θ)*parameter (angularTurnFactor (canonicalGap p) a b) canonicalB (q,θ)-
      parameter (angularTurnFactor (canonicalGap p) a b) canonicalC (q,θ)=
      -spatial (canonicalGap p) (q,angularTurnNode a b (q,θ))*
        (fderiv ℝ b q canonicalB-fderiv ℝ a q canonicalB)*(b q-a q) := by
  have hx : 0<angularTurnNode a b (q,θ) :=
    lt_of_lt_of_le ha (affineTurnNode_mem h.turns_ordered.le (unitSinNode_mem θ)).1
  have hB := angularFactor_parameter_relation h canonicalB θ
  have hC := angularFactor_parameter_relation h canonicalC θ
  rw [canonicalGap_parameter p q canonicalB _ hx] at hB
  rw [canonicalGap_parameter p q canonicalC _ hx] at hC
  simp only [canonicalB,canonicalC,Prod.fst,Prod.snd,zero_mul,one_mul,sub_zero,zero_sub] at hB hC
  have hvel := (canonical_angular_velocity_identities h ha θ).1
  have hc : (Real.cos θ/2)^2≠0 := (sq_pos_of_pos (div_pos (Real.cos_pos_of_mem_Ioo hθ) (by norm_num))).ne'
  apply mul_left_cancel₀ hc
  dsimp only [canonicalB,canonicalC] at *
  linear_combination angularTurnNode a b (q,θ)*hB-hC-
    spatial (canonicalGap p) (q,angularTurnNode a b (q,θ))*hvel

theorem angularFactor_spatial_relation {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [CompleteSpace E] [FiniteDimensional ℝ E]
    {V : E×ℝ→ℝ} {a b : E→ℝ} {q : E} (h : RegularTwoTurnFamily V a b q)
    (θ : ℝ) (hθ : θ∈Ioo (-(Real.pi/2)) (Real.pi/2)) :
    spatial V (q,angularTurnNode a b (q,θ))*(b q-a q)=
      Real.cos θ/2*spatial (angularTurnFactor V a b) (q,θ)-
        Real.sin θ*angularTurnFactor V a b (q,θ) := by
  have he : (fun s => angularTurnGap V a b (q,s)) =
      (fun s => (Real.cos s/2)^2*angularTurnFactor V a b (q,s)) :=
    funext (h.angular_factorization_germ.self_of_nhds)
  have hd := (((Real.hasDerivAt_cos θ).div_const 2).pow 2).mul
    (h.angularFactor_analytic θ).curry_right.differentiableAt.hasDerivAt
  have hd' := h.angularGap_spatial θ
  rw [he] at hd'
  have heq := hd'.unique hd
  have hc : Real.cos θ/2≠0 := (div_pos (Real.cos_pos_of_mem_Ioo hθ) (by norm_num)).ne'
  apply mul_right_cancel₀ hc
  dsimp only [spatial] at *
  norm_num only [Nat.reduceSub,Nat.cast_ofNat,pow_one] at heq
  linear_combination heq

theorem canonical_kernel_parameter_formulas {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (η : CanonicalCoefficients) (θ : ℝ) :
    parameter (canonicalKernelA p a b) η (q,θ)=
      (fderiv ℝ b q η-fderiv ℝ a q η)/Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))-
        (b q-a q)*parameter (angularTurnFactor (canonicalGap p) a b) η (q,θ)/
          (2*Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))^3) ∧
    parameter (canonicalKernelB p a b) η (q,θ)=
      -(fderiv ℝ b q η-fderiv ℝ a q η)*angularTurnNode a b (q,θ)/
        Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))-
      (b q-a q)*angularTurnVelocity a b η q θ/Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))+
      (b q-a q)*angularTurnNode a b (q,θ)*parameter (angularTurnFactor (canonicalGap p) a b) η (q,θ)/
        (2*Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))^3) := by
  have hH := (h.angularFactor_analytic θ).curry_left.differentiableAt.hasFDerivAt
  have hHp : 0<angularTurnFactor (canonicalGap p) a b (q,θ) := h.factor_pos _ (unitSinNode_mem θ)
  have hs0 : Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))≠0 := (Real.sqrt_pos.mpr hHp).ne'
  have hs5 : Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))^5=
      Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))^3*
        angularTurnFactor (canonicalGap p) a b (q,θ) := by
    calc
      _=Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))^3*
          Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))^2 := by ring
      _=_ := by rw [Real.sq_sqrt hHp.le]
  have hl := h.analytic_right.differentiableAt.hasFDerivAt.sub h.analytic_left.differentiableAt.hasFDerivAt
  have hx := (h.angularNode_analytic θ).curry_left.differentiableAt.hasFDerivAt
  have hi := (hasDerivAt_inv hs0).comp_hasFDerivAt q (hH.sqrt hHp.ne')
  have hA := hl.mul hi
  have hB := (hl.neg.mul hx).mul hi
  dsimp only [Function.comp_apply] at hA hB
  constructor
  · rw [parameter_eq_slice_fderiv (canonicalKernels_analytic h θ).1.differentiableAt η]
    change fderiv ℝ (fun r => (b r-a r)/Real.sqrt (angularTurnFactor (canonicalGap p) a b (r,θ))) q η=_
    simp only [div_eq_mul_inv]
    rw [hA.fderiv]
    simp only [ContinuousLinearMap.smul_apply,ContinuousLinearMap.add_apply,
      ContinuousLinearMap.sub_apply,smul_eq_mul]
    rw [← parameter_eq_slice_fderiv (h.angularFactor_analytic θ).differentiableAt η]
    field_simp [hs0]
    ring_nf
    rw [hs5]
    ring
  · rw [parameter_eq_slice_fderiv (canonicalKernels_analytic h θ).2.differentiableAt η]
    change fderiv ℝ (fun r => -(b r-a r)*angularTurnNode a b (r,θ)/
      Real.sqrt (angularTurnFactor (canonicalGap p) a b (r,θ))) q η=_
    simp only [div_eq_mul_inv]
    rw [hB.fderiv]
    simp only [ContinuousLinearMap.smul_apply,ContinuousLinearMap.add_apply,
      ContinuousLinearMap.neg_apply,ContinuousLinearMap.sub_apply,smul_eq_mul]
    rw [← parameter_eq_slice_fderiv (h.angularFactor_analytic θ).differentiableAt η,
      h.angularNode_slice_fderiv η θ]
    field_simp [hs0]
    ring_nf
    rw [hs5]
    ring


theorem canonical_hessian_algebra {s H l d dc X v hB hC g ht c si : ℝ}
    (hs : s≠0) (hsq : s^2=H) (hv : dc-d*X-l*v= -d*l*si)
    (hp : X*hB-hC= -g*d*l) (hx : g*l=c/2*ht-si*H) :
    (d*l*(-si)*(2*s)-d*l*c*(2*(ht/(2*s))))/(2*s)^2=
      -d*X/s-l*v/s+l*X*hB/(2*s^3)+dc/s-l*hC/(2*s^3) := by
  have hdc : dc=d*X+l*v-d*l*si := by linarith only [hv]
  have hhC : hC=X*hB+g*d*l := by linarith only [hp]
  have hh : c*ht=2*(g*l+si*s^2) := by rw [hsq]; linarith only [hx]
  calc
    _= -d*l*si/(2*s)-(d*l)*(c*ht)/(4*s^3) := by field_simp [hs]; ring
    _= -d*l*si/s-d*l*(g*l)/(2*s^3) := by rw [hh]; field_simp [hs]; ring
    _=_ := by rw [hdc,hhC]; field_simp [hs]; ring

def canonicalHessianPrimitive (p : ℝ) (a b : CanonicalCoefficients→ℝ)
    (q : CanonicalCoefficients) (θ : ℝ) : ℝ :=
  (fderiv ℝ b q canonicalB-fderiv ℝ a q canonicalB)*(b q-a q)*Real.cos θ/
    (2*Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ)))

theorem canonicalHessianPrimitive_derivative {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q)
    (θ : ℝ) (hθ : θ∈Ioo (-(Real.pi/2)) (Real.pi/2)) :
    HasDerivAt (canonicalHessianPrimitive p a b q)
      (parameter (canonicalKernelB p a b) canonicalB (q,θ)+
       parameter (canonicalKernelA p a b) canonicalC (q,θ)) θ := by
  have hHp : 0<angularTurnFactor (canonicalGap p) a b (q,θ) := h.factor_pos _ (unitSinNode_mem θ)
  have hs0 : Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))≠0 := (Real.sqrt_pos.mpr hHp).ne'
  have hsq := Real.sq_sqrt hHp.le
  have hd := ((Real.hasDerivAt_cos θ).const_mul
      ((fderiv ℝ b q canonicalB-fderiv ℝ a q canonicalB)*(b q-a q))).div
    (((h.angularFactor_analytic θ).curry_right.differentiableAt.hasDerivAt.sqrt hHp.ne').const_mul 2)
      (mul_ne_zero (by norm_num) hs0)
  apply hd.congr_deriv
  rw [(canonical_kernel_parameter_formulas h canonicalB θ).2,
    (canonical_kernel_parameter_formulas h canonicalC θ).1]
  have hp := canonical_factor_parameter_cancellation h ha θ hθ
  have hv := (canonical_angular_velocity_identities h ha θ).2
  have hx := angularFactor_spatial_relation h θ hθ
  convert canonical_hessian_algebra hs0 hsq hv hp hx using 1 <;> ring

end LeanVerification.UpperStripCompletion
