import LeanVerification.Loud.UpperAngularRegularity
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

/-! The full physical energy interval in the upper strip. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open Loud
set_option maxHeartbeats 1800000

theorem upper_potential_infinity (D F : ℝ) (hD : -1≤D) (hF : 1<F) :
    Tendsto (potential D F) atTop atTop := by
  have hi : Tendsto (fun w:ℝ => w⁻¹) atTop (𝓝 0) := tendsto_inv_atTop_zero
  rcases eq_or_lt_of_le hD with hDe|hDp
  · have hDval : D= -1 := hDe.symm
    subst D
    have hA : 0<1/(2*F-1) := div_pos (by norm_num) (by linarith)
    have hq : Tendsto (fun w:ℝ => 1/(2*F-1)-1/(2*F-2)*w⁻¹) atTop (𝓝 (1/(2*F-1))) := by
      simpa using (tendsto_const_nhds (x:=1/(2*F-1))).sub (hi.const_mul (1/(2*F-2)))
    have hp := (tendsto_rpow_atTop (show 0<2*F-1 by linarith)).atTop_mul_pos hA hq
    have ht := tendsto_atTop_add_const_left atTop (zeroEndpointHeight (-1) F) hp
    apply ht.congr'
    filter_upwards [eventually_gt_atTop (0:ℝ)] with w hw
    have he : w^(2*F-2)=w^(2*F-1)*w⁻¹ := by
      rw [show 2*F-2=(2*F-1)-1 by ring,Real.rpow_sub_one hw.ne',div_eq_mul_inv]
    rw [potential_expansion_above_one (-1) F w hF,he]
    ring
  · have hA : 0<(D+1)/(2*F) := div_pos (by linarith) (by linarith)
    have hq : Tendsto (fun w:ℝ => (D+1)/(2*F)-(2*D+1)/(2*F-1)*w⁻¹+
        D/(2*F-2)*(w⁻¹)^2) atTop (𝓝 ((D+1)/(2*F))) := by
      simpa using ((tendsto_const_nhds (x:=(D+1)/(2*F))).sub
        (hi.const_mul ((2*D+1)/(2*F-1)))).add ((hi.pow 2).const_mul (D/(2*F-2)))
    have hp := (tendsto_rpow_atTop (show 0<2*F by linarith)).atTop_mul_pos hA hq
    have ht := tendsto_atTop_add_const_left atTop (zeroEndpointHeight D F) hp
    apply ht.congr'
    filter_upwards [eventually_gt_atTop (0:ℝ)] with w hw
    have h1 : w^(2*F-1)=w^(2*F)*w⁻¹ := by rw [Real.rpow_sub_one hw.ne',div_eq_mul_inv]
    have h2 : w^(2*F-2)=w^(2*F)*(w⁻¹)^2 := by
      rw [Real.rpow_sub hw,Real.rpow_two,div_eq_mul_inv,inv_pow]
    rw [potential_expansion_above_one D F w hF,h1,h2]
    ring

theorem upper_admissibleEnergy_iff (D F h : ℝ) (hD0 : -1≤D) (hD1 : D≤0) (hF : 1<F) :
    AdmissibleEnergy D F h ↔ 0<h ∧ h<zeroEndpointHeight D F := by
  apply admissibleEnergy_iff_below_left_endpoint_of_right_infinite
  · simpa only [centralLeftEndpoint,if_neg (not_lt_of_ge hD1)] using
      tendsto_potential_zero_above_one D F hF
  · simpa only [centralRightEndpointFilter,if_neg (not_lt_of_ge hD0)] using
      upper_potential_infinity D F hD0 hF

end LeanVerification.UpperStripCompletion
