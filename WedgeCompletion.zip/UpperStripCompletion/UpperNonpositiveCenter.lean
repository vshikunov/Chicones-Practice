import LeanVerification.UpperStripCompletion.PhysicalForcePolynomial
import LeanVerification.UpperStripCompletion.UpperForceSign
import LeanVerification.UpperStripCompletion.PhysicalForceCriterion

/-! Actual original-time stationary curvature on the full nonpositive
center chamber of row 12, including F=1 and D=-1,-1/2. -/
noncomputable section
namespace LeanVerification.UpperStripCompletion
open Loud RegionalReal
set_option maxHeartbeats 2000000

theorem physical_upper_forceInvariant_nonpositive (D F X : ℝ)
    (hD0 : -1≤D) (hD1 : D≤-(1/2)) (hF0 : 1≤F) (hF1 : F≤5/4)
    (hC : upperCenterPolynomial (1-1/F) (-(D+1)/D)≤0) (hX : mechanicalDomain F X) :
    forceInvariantAt (loudMechanicalPotential D F) X≤0 ∧
    (deriv (loudMechanicalPotential D F) X≠0 → forceInvariantAt (loudMechanicalPotential D F) X<0) := by
  obtain ⟨hb0,hb1,hd0,hd1,hbm,hdp,hDe,hFe⟩ := physical_upper_parameters D F hD0 hD1 hF0 hF1
  have hw := inversePosition_pos F X hX
  have hn := physical_force_polynomial_normalized (1-1/F) (-(D+1)/D) (inversePosition F X) hbm hdp
  rw [hDe,hFe] at hn
  have hq := upper_quartic_sign_nonpositive_center hb0 hb1 hd0 hd1 hC hw
  have hm : 0<1-(1-1/F) := by linarith
  have he : 0<1+(-(D+1)/D) := by linarith
  have hcoef : 0<2/((1+(-(D+1)/D))^3*(1-(1-1/F))^4) := by positivity
  have hden : 0<(affineAux F X)^3*(inversePosition F X)^6 := mul_pos (pow_pos hX 3) (pow_pos hw 6)
  have hfac : forceInvariantAt (loudMechanicalPotential D F) X=
      (2/((1+(-(D+1)/D))^3*(1-(1-1/F))^4)*
        upperForceQuartic (1-1/F) (-(D+1)/D) (inversePosition F X))/
          ((affineAux F X)^3*(inversePosition F X)^6) := by
    change forceInvariantAt (fun Z => potential D F (inversePosition F Z)) X=_
    rw [actual_forceInvariant_factor D F X hX,hn]
  refine ⟨?_,?_⟩
  · rw [hfac]
    exact div_nonpos_of_nonpos_of_nonneg (mul_nonpos_of_nonneg_of_nonpos hcoef.le hq.1) hden.le
  · intro hg
    have hw1 : inversePosition F X≠1 := by
      intro heq
      apply hg
      change deriv (fun Z => potential D F (inversePosition F Z)) X=0
      rw [(actual_potential_force_jets D F X hX).1,physical_force_eq_saddle_factor D F X hX,heq]
      ring
    rw [hfac]
    exact div_neg_of_neg_of_pos (mul_neg_of_pos_of_neg hcoef (hq.2 hw1)) hden

theorem physical_upper_stationary_curvature_nonpositive_center (D F h : ℝ)
    (hD0 : -1≤D) (hD1 : D≤-(1/2)) (hF0 : 1≤F) (hF1 : F≤5/4)
    (hC : upperCenterPolynomial (1-1/F) (-(D+1)/D)≤0)
    (hh : AdmissibleEnergy D F h) (hs : deriv (periodQuadrature D F) h=0) :
    0<deriv (deriv (periodQuadrature D F)) h := by
  apply physical_force_invariant_stationary_curvature D F h hh hs
  · exact fun X hX => (physical_upper_force_signs D F X hD0 hD1 hF0 hF1 hX).1
  · exact fun X hX => (physical_upper_force_signs D F X hD0 hD1 hF0 hF1 hX).2
  · exact fun X hX => (physical_upper_forceInvariant_nonpositive D F X hD0 hD1 hF0 hF1 hC hX).1
  · exact fun X hX => (physical_upper_forceInvariant_nonpositive D F X hD0 hD1 hF0 hF1 hC hX).2

theorem criticalPeriodBound_one_upper_nonpositive_center (D F : ℝ)
    (hD0 : -1≤D) (hD1 : D≤-(1/2)) (hF0 : 1≤F) (hF1 : F≤5/4)
    (hC : upperCenterPolynomial (1-1/F) (-(D+1)/D)≤0) : CriticalPeriodBound 1 D F :=
  criticalPeriodBound_one_of_positive_stationary_curvature D F
    (fun h hh hs => physical_upper_stationary_curvature_nonpositive_center D F h hD0 hD1 hF0 hF1 hC hh hs)

end LeanVerification.UpperStripCompletion
