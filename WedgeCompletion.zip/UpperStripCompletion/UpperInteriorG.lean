import LeanVerification.UpperStripCompletion.UpperInteriorComparison

/-! The manuscript's canonical raised derivative G, defined from the
actual physical period. Its interior sign and zero bound are discharged. -/
noncomputable section
open Set
namespace LeanVerification.UpperStripCompletion
open Loud AnalyticTwoPartials
set_option maxHeartbeats 2200000

def upperPhysicalG (b : ℝ) (q : ℝ×ℝ) : ℝ :=
  Real.sqrt (q.2/2)*left (upperPhysicalChartPeriod b) q

theorem upper_physical_G_eq_scaled_U {b : ℝ} {q : ℝ×ℝ} (hd : 0≤q.2) :
    upperPhysicalG b q=Real.sqrt (q.2/(1+q.2))*upperPhysicalU b q := by
  have he : 0<1+q.2 := by linarith
  unfold upperPhysicalG upperPhysicalU parameterGauge upperTransportGauge
  rw [← mul_assoc,← Real.sqrt_mul (div_nonneg hd he.le)]
  congr 1
  congr 1
  field_simp [he.ne'] <;> ring

theorem upper_physical_G_positive_interior {b : ℝ} {q : ℝ×ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hX : 0<q.1) (hd : 0<q.2) (hd1 : q.2≤1)
    (hC : 0<upperCenterPolynomial b q.2) : 0<upperPhysicalG b q := by
  have hC0 := (upper_center_positive_range hb.le hb1 hd.le hd1 hC).2
  have hroot := upper_positive_parameter_lt_root hb hb1 hd.le hd1 hC
  have hU := (upper_physical_interior_comparison hb hb1 hC0 hX).1 q
    ⟨⟨hX,le_rfl⟩,⟨hd.le,hroot.le⟩⟩
  rw [upper_physical_G_eq_scaled_U (b:=b) (q:=q) hd.le]
  have he : 0<1+q.2 := by linarith
  exact mul_pos (Real.sqrt_pos.mpr (div_pos hd he)) hU

theorem upper_physical_G_zero_iff {b : ℝ} {q : ℝ×ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hX : 0<q.1) (hd : 0<q.2) (hd1 : q.2≤1) :
    upperPhysicalG b q=0 ↔
      deriv (periodQuadrature (-1/(1+q.2)) (1/(1-b))) (upperPhysicalEnergy b q)=0 := by
  have hh := upper_physical_chart_admissible (q:=q) hb hb1 hX hd.le hd1
  have hm : 0<1-b := by linarith
  have he : 0<1+q.2 := by linarith
  have hH := upper_physical_height_pos hb (by linarith) hd.le
  unfold upperPhysicalG
  rw [upper_physical_period_chart_left (b:=b) (q:=q) (by linarith) he (Or.inr hh),
    extendedPhysicalSlope_eq_physical (q:=upperPhysicalParameter b q) hh]
  change Real.sqrt (q.2/2)*(Real.sqrt (upperPhysicalScale b q.2)*
    deriv (periodQuadrature (-1/(1+q.2)) (1/(1-b))) (upperPhysicalEnergy b q)*
      (upperPhysicalHeight b q.2*Real.exp (-q.1)))=0 ↔ _
  have h0 : Real.sqrt (q.2/2)≠0 := (Real.sqrt_pos.mpr (by positivity)).ne'
  have h1 : Real.sqrt (upperPhysicalScale b q.2)≠0 := (Real.sqrt_pos.mpr hH.1).ne'
  have h2 : upperPhysicalHeight b q.2*Real.exp (-q.1)≠0 := (mul_pos hH.2 (Real.exp_pos _)).ne'
  simp only [mul_eq_zero,h0,h1,h2,false_or,or_false]

theorem upper_physical_G_atMostOneZero_nonpositive_center {b d : ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hd : 0<d) (hd1 : d≤1)
    (hC : upperCenterPolynomial b d≤0) :
    ZeroCounting.AtMostOneZeroOn (fun X => upperPhysicalG b (X,d)) (Ioi 0) := by
  obtain ⟨hD0,hD1,hF0,hF1,hbe,hde⟩ := normalized_upper_physical_parameters hb.le hb1 hd.le hd1
  have hCphys : upperCenterPolynomial (1-1/(1/(1-b))) (-((-1/(1+d))+1)/(-1/(1+d)))≤0 := by
    rwa [hbe,hde]
  have huniq : ZeroCounting.AtMostOneZeroOn (deriv (periodQuadrature (-1/(1+d)) (1/(1-b))))
      {h | AdmissibleEnergy (-1/(1+d)) (1/(1-b)) h} := by
    apply ZeroOrientation.atMostOneZeroOn_of_deriv_pos_at_zeros
      (ordConnected_admissibleEnergy _ _).convex
    · exact fun h hh => (analyticAt_periodQuadrature_energy _ _ h hh).deriv.differentiableAt
    · exact fun h hh hs => physical_upper_stationary_curvature_nonpositive_center _ _ h
        hD0 hD1 hF0 hF1 hCphys hh hs
  intro X Y hX hY hzX hzY
  have hEq := huniq (x:=upperPhysicalEnergy b (X,d)) (y:=upperPhysicalEnergy b (Y,d))
    (upper_physical_chart_admissible (q:=(X,d)) hb hb1 hX hd.le hd1)
    (upper_physical_chart_admissible (q:=(Y,d)) hb hb1 hY hd.le hd1)
    ((upper_physical_G_zero_iff (q:=(X,d)) hb hb1 hX hd hd1).mp hzX)
    ((upper_physical_G_zero_iff (q:=(Y,d)) hb hb1 hY hd hd1).mp hzY)
  have hH := (upper_physical_height_pos hb (by linarith) hd.le).2
  change upperPhysicalHeight b d*(1-Real.exp (-X))=upperPhysicalHeight b d*(1-Real.exp (-Y)) at hEq
  have he := mul_left_cancel₀ hH.ne' hEq
  have he' : Real.exp (-X)=Real.exp (-Y) := by linarith
  have hn := Real.exp_injective he'
  linarith

theorem upper_physical_G_atMostOneZero_full {b d : ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hd : 0<d) (hd1 : d≤1) :
    ZeroCounting.AtMostOneZeroOn (fun X => upperPhysicalG b (X,d)) (Ioi 0) := by
  by_cases hC : upperCenterPolynomial b d≤0
  · exact upper_physical_G_atMostOneZero_nonpositive_center hb hb1 hd hd1 hC
  · intro X Y hX hY hzX hzY
    exact False.elim ((upper_physical_G_positive_interior (q:=(X,d)) hb hb1 hX hd hd1 (lt_of_not_ge hC)).ne' hzX)

end LeanVerification.UpperStripCompletion
