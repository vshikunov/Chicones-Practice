import LeanVerification.UpperStripCompletion.JacobiForceAlgebra

/-! Exact certificates for the upper-strip force quartic. -/
noncomputable section
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 2400000

def upperCenterPolynomial (b d : ℝ) : ℝ :=
  b*(b+3)*d^2+(3*b^2+14*b-9)*d+12*b^2-9*b+1

def upperTPolynomial (b : ℝ) : ℝ := 6-39*b+70*b^2-5*b^3
def upperBPolynomial (b : ℝ) : ℝ := 6-5*b-13*b^2-8*b^3
def upperHPolynomial (b : ℝ) : ℝ :=
  3*(upperTPolynomial b)^2-32*b*(1+b)*(1-4*b)*upperBPolynomial b
def upperKPolynomial (b : ℝ) : ℝ :=
  256*(1+b)^2*(1-4*b)*(3-2*b)*(1-2*b)^2
def upperJPolynomial (b : ℝ) : ℝ :=
  2101*b^5+3668*b^4-16686*b^3+17224*b^2-6847*b+876

def upperA0 (b : ℝ) : ℝ := 8*(1+b)*(1-2*b)^2*(1-4*b)
def upperA1 (b d : ℝ) : ℝ := 3*(1-2*b)*(1-d)*upperTPolynomial b
def upperA2 (b d : ℝ) : ℝ :=
  3*b*upperBPolynomial b*(1-d)^2+24*(1+b)*(3-2*b)*(1-2*b)^2*d
def upperA3 (b d : ℝ) : ℝ :=
  b*(1-d)*(b*(2*b+1)*(b+3)*(1-d)^2+3*d*(1-2*b)*(31-12*b-3*b^2))
def upperA4 (b d : ℝ) : ℝ := 3*b^2*d*(2-b)*(b+3)*(1-d)^2

def upperForceQuartic (b d x : ℝ) : ℝ :=
  -upperA0 b+upperA1 b d*x-upperA2 b d*x^2-upperA3 b d*x^3-upperA4 b d*x^4

theorem upper_t_polynomial_lower {b : ℝ} (hb : 0≤b) (hb1 : b≤1/5) :
    (4/5:ℝ)≤upperTPolynomial b := by
  have h0 : 0≤5*b := by positivity
  have h1 : 0≤1-5*b := by linarith
  have he : upperTPolynomial b=(4/5:ℝ)+
      ((26:ℝ)/5)*(5*b)^0*(1-5*b)^3+
      ((39:ℝ)/5)*(5*b)^1*(1-5*b)^2+
      ((14:ℝ)/5)*(5*b)^2*(1-5*b)^1+
      ((4:ℝ)/25)*(5*b)^3*(1-5*b)^0 := by unfold upperTPolynomial; ring
  rw [he]
  have hp : 0≤((26:ℝ)/5)*(5*b)^0*(1-5*b)^3+
      ((39:ℝ)/5)*(5*b)^1*(1-5*b)^2+
      ((14:ℝ)/5)*(5*b)^2*(1-5*b)^1+
      ((4:ℝ)/25)*(5*b)^3*(1-5*b)^0 := by positivity
  linarith only [hp]

theorem upper_b_polynomial_lower {b : ℝ} (hb : 0≤b) (hb1 : b≤1/5) :
    (4:ℝ)≤upperBPolynomial b := by
  have h0 : 0≤5*b := by positivity
  have h1 : 0≤1-5*b := by linarith
  have he : upperBPolynomial b=(4:ℝ)+
      ((2:ℝ))*(5*b)^0*(1-5*b)^3+
      ((5:ℝ))*(5*b)^1*(1-5*b)^2+
      ((87:ℝ)/25)*(5*b)^2*(1-5*b)^1+
      ((52:ℝ)/125)*(5*b)^3*(1-5*b)^0 := by unfold upperBPolynomial; ring
  rw [he]
  have hp : 0≤((2:ℝ))*(5*b)^0*(1-5*b)^3+
      ((5:ℝ))*(5*b)^1*(1-5*b)^2+
      ((87:ℝ)/25)*(5*b)^2*(1-5*b)^1+
      ((52:ℝ)/125)*(5*b)^3*(1-5*b)^0 := by positivity
  linarith only [hp]

theorem upper_j_polynomial_lower {b : ℝ} (hb : 0≤b) (hb1 : b≤1/5) :
    (60:ℝ)≤upperJPolynomial b := by
  have h0 : 0≤5*b := by positivity
  have h1 : 0≤1-5*b := by linarith
  have he : upperJPolynomial b=(60:ℝ)+
      ((816:ℝ))*(5*b)^0*(1-5*b)^5+
      ((13553:ℝ)/5)*(5*b)^1*(1-5*b)^4+
      ((84284:ℝ)/25)*(5*b)^2*(1-5*b)^3+
      ((234624:ℝ)/125)*(5*b)^3*(1-5*b)^2+
      ((255108:ℝ)/625)*(5*b)^4*(1-5*b)^1+
      ((26916:ℝ)/3125)*(5*b)^5*(1-5*b)^0 := by unfold upperJPolynomial; ring
  rw [he]
  have hp : 0≤((816:ℝ))*(5*b)^0*(1-5*b)^5+
      ((13553:ℝ)/5)*(5*b)^1*(1-5*b)^4+
      ((84284:ℝ)/25)*(5*b)^2*(1-5*b)^3+
      ((234624:ℝ)/125)*(5*b)^3*(1-5*b)^2+
      ((255108:ℝ)/625)*(5*b)^4*(1-5*b)^1+
      ((26916:ℝ)/3125)*(5*b)^5*(1-5*b)^0 := by positivity
  linarith only [hp]

theorem upper_discriminant_certificate (b d : ℝ) :
    (upperA1 b d)^2-4*upperA0 b*upperA2 b d=
      3*(1-2*b)^2*(upperHPolynomial b*(1-d)^2-upperKPolynomial b*d) := by
  unfold upperA0 upperA1 upperA2 upperHPolynomial upperKPolynomial
  ring

theorem upper_discriminant_comparison (b : ℝ) :
    9*upperKPolynomial b-64*upperHPolynomial b=64*b*upperJPolynomial b := by
  unfold upperKPolynomial upperHPolynomial upperJPolynomial upperTPolynomial upperBPolynomial
  ring

theorem upper_quartic_center (b d : ℝ) :
    upperForceQuartic b d 1=5*(1-b)*(2-3*b-b*d)*upperCenterPolynomial b d := by
  unfold upperForceQuartic upperA0 upperA1 upperA2 upperA3 upperA4 upperCenterPolynomial
    upperTPolynomial upperBPolynomial
  ring

theorem upper_quartic_center_derivative (b d : ℝ) :
    upperA1 b d-2*upperA2 b d-3*upperA3 b d-4*upperA4 b d=
      3*(6*b^2*d+2*b^2-7*b*d-9*b+6)*upperCenterPolynomial b d := by
  unfold upperA1 upperA2 upperA3 upperA4 upperCenterPolynomial upperTPolynomial upperBPolynomial
  ring

theorem upper_quartic_square_certificate (b d x : ℝ) :
    4*upperA2 b d*upperForceQuartic b d x=
      -(2*upperA2 b d*x-upperA1 b d)^2+
      ((upperA1 b d)^2-4*upperA0 b*upperA2 b d)-
      4*upperA2 b d*upperA3 b d*x^3-4*upperA2 b d*upperA4 b d*x^4 := by
  unfold upperForceQuartic
  ring

end LeanVerification.UpperStripCompletion
