import LeanVerification.AnalyticTwoPartials
import Mathlib.Analysis.Calculus.Deriv.Slope
import Mathlib.Topology.Order.Compact

/-! A compact-rectangle comparison for the upper-strip transport.
The proof uses actual derivatives and never extends a boundary sign
into the interior by continuity alone. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open AnalyticTwoPartials
set_option maxHeartbeats 2000000

theorem deriv_nonneg_at_left_interval_max {f : ℝ→ℝ} {a x : ℝ}
    (hax : a<x) (hf : DifferentiableAt ℝ f x)
    (hm : ∀y∈Icc a x,f y≤f x) : 0≤deriv f x := by
  have ht := (hasDerivAt_iff_tendsto_slope.mp hf.hasDerivAt).mono_left (nhdsLT_le_nhdsNE x)
  apply ge_of_tendsto ht
  filter_upwards [self_mem_nhdsWithin,
    (eventually_gt_nhds hax).filter_mono nhdsWithin_le_nhds] with y hy hya
  rw [slope_def_field]
  exact div_nonneg_of_nonpos (sub_nonpos.mpr (hm y ⟨hya.le,hy.le⟩)) (sub_nonpos.mpr hy.le)

def transportRectangle (T D : ℝ) : Set (ℝ×ℝ) := Icc 0 T ×ˢ Icc 0 D

theorem transport_strict_maximum {V : ℝ×ℝ→ℝ} {v c : ℝ→ℝ} {T D : ℝ}
    (hT : 0≤T) (hD : 0≤D)
    (hV : ContinuousOn V (transportRectangle T D))
    (hd : ∀q∈transportRectangle T D,DifferentiableAt ℝ V q)
    (hinit : ∀d∈Icc 0 D,V (0,d)<0)
    (hv0 : v 0=0) (hv : ∀d∈Icc 0 D,0≤v d) (hc : ∀d∈Icc 0 D,0≤c d)
    (hpde : ∀q∈transportRectangle T D,0<q.1 →
      left V q+v q.2*right V q+c q.2*V q<0) :
    ∀q∈transportRectangle T D,V q<0 := by
  intro q hq
  by_contra hn
  have hnq : 0≤V q := le_of_not_gt hn
  have hcomp : IsCompact (transportRectangle T D) := isCompact_Icc.prod isCompact_Icc
  obtain ⟨z,hz,hm⟩ := hcomp.exists_isMaxOn ⟨q,hq⟩ hV
  have hzv : 0≤V z := hnq.trans (hm hq)
  have hzx : 0<z.1 := by
    have h0 : 0≤z.1 := hz.1.1
    have hne : z.1≠0 := by
      intro he
      have hneg := hinit z.2 hz.2
      have hez : (0,z.2)=z := by rw [← he]
      rw [hez] at hneg
      exact hneg.not_le hzv
    exact lt_of_le_of_ne h0 (Ne.symm hne)
  have hx : 0≤left V z := by
    apply deriv_nonneg_at_left_interval_max hzx
      ((hd z hz).comp z.1 (differentiableAt_id.prodMk (differentiableAt_const z.2)))
    intro t ht
    exact hm ⟨⟨ht.1,ht.2.trans hz.1.2⟩,hz.2⟩
  have hy : 0≤v z.2*right V z := by
    by_cases hz0 : z.2=0
    · rw [hz0,hv0,zero_mul]
    have hzp : 0<z.2 := lt_of_le_of_ne hz.2.1 (Ne.symm hz0)
    apply mul_nonneg (hv z.2 hz.2)
    apply deriv_nonneg_at_left_interval_max hzp
      ((hd z hz).comp z.2 ((differentiableAt_const z.1).prodMk differentiableAt_id))
    intro d hd'
    exact hm ⟨hz.1,⟨hd'.1,hd'.2.trans hz.2.2⟩⟩
  have hcV := mul_nonneg (hc z.2 hz.2) hzv
  linarith only [hpde z hz hzx,hx,hy,hcV]

theorem transport_negative_of_nonpositive_forcing {V : ℝ×ℝ→ℝ} {v c : ℝ→ℝ} {T D : ℝ}
    (hT : 0≤T) (hD : 0≤D)
    (hV : AnalyticOnNhd ℝ V (transportRectangle T D))
    (hinit : ∀d∈Icc 0 D,V (0,d)<0)
    (hv0 : v 0=0) (hv : ∀d∈Icc 0 D,0≤v d) (hc : ∀d∈Icc 0 D,0≤c d)
    (hcc : ContinuousOn c (Icc 0 D))
    (hpde : ∀q∈transportRectangle T D,0<q.1 →
      left V q+v q.2*right V q+c q.2*V q≤0) :
    ∀q∈transportRectangle T D,V q<0 := by
  have hiC : ContinuousOn (fun d => V (0,d)) (Icc 0 D) := fun d hd =>
    (hV (0,d) ⟨⟨le_rfl,hT⟩,hd⟩).curry_right.continuousAt.continuousWithinAt
  obtain ⟨r,hr,hrmax⟩ := isCompact_Icc.exists_isMaxOn ⟨0,le_rfl,hD⟩ hiC
  obtain ⟨s,hs,hsmax⟩ := isCompact_Icc.exists_isMaxOn ⟨0,le_rfl,hD⟩ hcc
  let ε := -V (0,r)/2
  let K := c s+1
  have hε : 0<ε := by dsimp [ε]; linarith only [hinit r hr]
  have hK (d : ℝ) (hd : d∈Icc 0 D) : c d<K := by
    have hh : c d≤c s := hsmax hd
    dsimp [K]
    linarith only [hh]
  let W : ℝ×ℝ→ℝ := fun q => V q+ε*Real.exp (-K*q.1)
  have hWa (q : ℝ×ℝ) (hq : q∈transportRectangle T D) : AnalyticAt ℝ W q :=
    (hV q hq).add (analyticAt_const.mul (analyticAt_const.mul analyticAt_fst).rexp')
  have hWi (d : ℝ) (hd : d∈Icc 0 D) : W (0,d)<0 := by
    have hh : V (0,d)≤V (0,r) := hrmax hd
    dsimp only [W,ε]
    simp only [mul_zero,Real.exp_zero,mul_one]
    linarith only [hh,hinit r hr]
  have hWx (q : ℝ×ℝ) (hq : q∈transportRectangle T D) :
      left W q=left V q-K*ε*Real.exp (-K*q.1) := by
    have hdv := (hV q hq).curry_left.differentiableAt.hasDerivAt
    have hde := (((hasDerivAt_id q.1).const_mul (-K)).exp).const_mul ε
    have hh := (hdv.add hde).deriv
    simp only [id_eq] at hh
    change left W q=deriv (fun t => V (t,q.2)) q.1-K*ε*Real.exp (-K*q.1)
    change deriv (fun t => V (t,q.2)+ε*Real.exp (-K*t)) q.1=_
    rw [hh]
    ring
  have hWd (q : ℝ×ℝ) (hq : q∈transportRectangle T D) : right W q=right V q := by
    exact ((hV q hq).curry_right.differentiableAt.hasDerivAt.add_const
      (ε*Real.exp (-K*q.1))).deriv
  have hpW : ∀q∈transportRectangle T D,0<q.1 →
      left W q+v q.2*right W q+c q.2*W q<0 := by
    intro q hq hqp
    rw [hWx q hq,hWd q hq]
    dsimp only [W]
    have hneg : (c q.2-K)*(ε*Real.exp (-K*q.1))<0 :=
      mul_neg_of_neg_of_pos (sub_neg.mpr (hK q.2 hq.2)) (mul_pos hε (Real.exp_pos _))
    nlinarith only [hpde q hq hqp,hneg]
  have hWneg := transport_strict_maximum hT hD
    (fun q hq => (hWa q hq).continuousAt.continuousWithinAt)
    (fun q hq => (hWa q hq).differentiableAt) hWi hv0 hv hc hpW
  intro q hq
  have hh := hWneg q hq
  have hp : 0<ε*Real.exp (-K*q.1) := mul_pos hε (Real.exp_pos _)
  change V q+ε*Real.exp (-K*q.1)<0 at hh
  linarith only [hh,hp]

end LeanVerification.UpperStripCompletion
