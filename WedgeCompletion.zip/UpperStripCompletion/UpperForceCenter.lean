import LeanVerification.UpperStripCompletion.UpperForceLargeD

/-! Exact centered comparison for the quartic on the zero center curve. -/
noncomputable section
open Set
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 2400000

theorem upper_coefficients_general {b d : ℝ} (hb : 0≤b) (hb1 : b≤1/5)
    (hd : 0≤d) (hd1 : d≤1) :
    0<upperA0 b ∧ 0≤upperA1 b d ∧ 0≤upperA2 b d ∧ 0≤upperA3 b d ∧ 0≤upperA4 b d := by
  have h1 : 0<1+b := by linarith
  have h2 : 0<1-2*b := by linarith
  have h4 : 0<1-4*b := by linarith
  have h3 : 0<3-2*b := by linarith
  have hdm : 0≤1-d := by linarith
  have hbB : 0<upperBPolynomial b := lt_of_lt_of_le (by norm_num : (0:ℝ)<4)
    (upper_b_polynomial_lower hb hb1)
  have hbT : 0<upperTPolynomial b := lt_of_lt_of_le (by norm_num : (0:ℝ)<4/5)
    (upper_t_polynomial_lower hb hb1)
  have hb2 : b^2≤(1/5:ℝ)^2 := pow_le_pow_left₀ hb hb1 2
  have h31 : 0<31-12*b-3*b^2 := by nlinarith
  have h5 : 0<2-b := by linarith
  have h6 : 0<b+3 := by linarith
  have h7 : 0<2*b+1 := by linarith
  unfold upperA0 upperA1 upperA2 upperA3 upperA4
  exact ⟨by positivity,by positivity,by positivity,by positivity,by positivity⟩

theorem upper_A1_pos {b d : ℝ} (hb : 0≤b) (hb1 : b≤1/5) (hd1 : d<1) :
    0<upperA1 b d := by
  have h2 : 0<1-2*b := by linarith
  have hdm : 0<1-d := by linarith
  have hT : 0<upperTPolynomial b := lt_of_lt_of_le (by norm_num : (0:ℝ)<4/5)
    (upper_t_polynomial_lower hb hb1)
  unfold upperA1
  positivity

theorem upper_A2_pos_of_center_zero {b d : ℝ} (hb : 0≤b) (hb1 : b≤1/5)
    (hd : 0≤d) (hd1 : d≤1) (hC : upperCenterPolynomial b d=0) : 0<upperA2 b d := by
  have h1 : 0<1+b := by linarith
  have h2 : 0<1-2*b := by linarith
  have h3 : 0<3-2*b := by linarith
  have hB : 0<upperBPolynomial b := lt_of_lt_of_le (by norm_num : (0:ℝ)<4)
    (upper_b_polynomial_lower hb hb1)
  by_cases hd0 : d=0
  · subst d
    have hb0 : 0<b := by
      by_contra hn
      have hbe : b=0 := le_antisymm (le_of_not_gt hn) hb
      simp [hbe,upperCenterPolynomial] at hC
    unfold upperA2
    positivity
  · have hdp : 0<d := lt_of_le_of_ne hd (Ne.symm hd0)
    unfold upperA2
    positivity

theorem upper_quartic_centered_identity (b d x : ℝ) :
    upperForceQuartic b d x=upperForceQuartic b d 1+
      (upperA1 b d-2*upperA2 b d-3*upperA3 b d-4*upperA4 b d)*(x-1)-
      (x-1)^2*(upperA2 b d+upperA3 b d*(x+2)+upperA4 b d*(x^2+2*x+3)) := by
  unfold upperForceQuartic
  ring

theorem upper_quartic_nonpos_center_zero {b d x : ℝ} (hb : 0≤b) (hb1 : b≤1/5)
    (hd : 0≤d) (hd1 : d≤1) (hC : upperCenterPolynomial b d=0) (hx : 0<x) :
    upperForceQuartic b d x≤0 := by
  obtain ⟨h0,h1,h2,h3,h4⟩ := upper_coefficients_general hb hb1 hd hd1
  rw [upper_quartic_centered_identity,upper_quartic_center,upper_quartic_center_derivative,hC]
  have hp : 0≤(x-1)^2*(upperA2 b d+upperA3 b d*(x+2)+upperA4 b d*(x^2+2*x+3)) := by positivity
  nlinarith only [hp]

theorem upper_quartic_neg_center_zero {b d x : ℝ} (hb : 0≤b) (hb1 : b≤1/5)
    (hd : 0≤d) (hd1 : d≤1) (hC : upperCenterPolynomial b d=0)
    (hx : 0<x) (hx1 : x≠1) : upperForceQuartic b d x<0 := by
  obtain ⟨h0,h1,h2,h3,h4⟩ := upper_coefficients_general hb hb1 hd hd1
  have h2p := upper_A2_pos_of_center_zero hb hb1 hd hd1 hC
  have hs : 0<(x-1)^2 := sq_pos_of_ne_zero (sub_ne_zero.mpr hx1)
  rw [upper_quartic_centered_identity,upper_quartic_center,upper_quartic_center_derivative,hC]
  have hp : 0<(x-1)^2*(upperA2 b d+upperA3 b d*(x+2)+upperA4 b d*(x^2+2*x+3)) := by positivity
  nlinarith only [hp]

end LeanVerification.UpperStripCompletion
