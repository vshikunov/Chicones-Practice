import LeanVerification.UpperStripCompletion.CanonicalEuler
import LeanVerification.InteriorCompletion.InversePowerAction

/-! The full four-coefficient canonical family exists at every pair of
physical positive turns; no analytic turn family is assumed. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical DirectionalPartials InteriorCompletion
set_option maxHeartbeats 2000000

theorem canonical_inversePower_slice (p : ℝ) (q : CanonicalCoefficients) :
    (fun x => canonicalGap p (q,x))=fun x => inversePowerGap q.2.1 q.1.2 p ((q.1.1,q.2.2),x) := by
  funext x
  dsimp only [canonicalGap,inversePowerGap,inversePowerPotential]
  ring

theorem canonical_inversePower_spatial (p : ℝ) (q : CanonicalCoefficients) (x : ℝ) :
    spatial (canonicalGap p) (q,x)=spatial (inversePowerGap q.2.1 q.1.2 p) ((q.1.1,q.2.2),x) := by
  dsimp only [spatial]
  rw [canonical_inversePower_slice]

theorem exists_canonical_action_chart (p : ℝ) (q : CanonicalCoefficients) (a₀ b₀ : ℝ)
    (hC : 0≤q.2.1) (hp : 0<p) (hδ : 0<q.2.2) (ha₀ : 0<a₀) (hab : a₀<b₀)
    (hza : canonicalGap p (q,a₀)=0) (hzb : canonicalGap p (q,b₀)=0) :
    ∃a b : CanonicalCoefficients→ℝ,a q=a₀ ∧ b q=b₀ ∧ RegularTwoTurnFamily (canonicalGap p) a b q := by
  have he := canonical_inversePower_slice p q
  have hza' : inversePowerGap q.2.1 q.1.2 p ((q.1.1,q.2.2),a₀)=0 := by
    rw [← congrFun he a₀]
    exact hza
  have hzb' : inversePowerGap q.2.1 q.1.2 p ((q.1.1,q.2.2),b₀)=0 := by
    rw [← congrFun he b₀]
    exact hzb
  have ht := inversePower_between_equal_turns q.2.1 q.1.2 p q.1.1 q.2.2 a₀ b₀ hC hp hδ ha₀ hab hza' hzb'
  have hda : 0<spatial (canonicalGap p) (q,a₀) := by rw [canonical_inversePower_spatial]; exact ht.1
  have hdb : spatial (canonicalGap p) (q,b₀)<0 := by rw [canonical_inversePower_spatial]; exact ht.2.1
  obtain ⟨a,ha,hae,haz⟩ := exists_analytic_simple_turn (analyticAt_canonicalGap p (q,a₀) ha₀) hza hda.ne'
  obtain ⟨b,hb,hbe,hbz⟩ := exists_analytic_simple_turn
    (analyticAt_canonicalGap p (q,b₀) (ha₀.trans hab)) hzb hdb.ne
  refine ⟨a,b,hae,hbe,⟨ha,hb,haz,hbz,?_,?_,?_,?_,?_⟩⟩
  · simpa only [hae,hbe] using hab
  · intro x hx
    rw [hae,hbe] at hx
    exact analyticAt_canonicalGap p (q,x) (ha₀.trans_le hx.1)
  · intro x hx
    rw [hae,hbe] at hx
    rw [congrFun he x]
    exact ht.2.2 x hx
  · simpa only [hae] using hda
  · simpa only [hbe] using hdb

end LeanVerification.UpperStripCompletion
