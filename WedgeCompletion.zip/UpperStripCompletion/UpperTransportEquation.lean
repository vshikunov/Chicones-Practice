import LeanVerification.UpperStripCompletion.UpperEnergyChart

/-! The transport PDE for the actual scaled complete-period derivative.
All coefficient derivatives come from the actual analytic period. -/
noncomputable section
open Set Filter
open scoped Topology ContDiff
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical DirectionalPartials InteriorCompletion AnalyticTwoPartials
set_option maxHeartbeats 3600000

theorem partial_left_congr {f g : ℝ×ℝ→ℝ} {q : ℝ×ℝ} (he : f =ᶠ[𝓝 q] g) :
    left f q=left g q := by
  have hh : (fun X => f (X,q.2)) =ᶠ[𝓝 q.1] (fun X => g (X,q.2)) :=
    (continuousAt_id.prodMk continuousAt_const).eventually he
  exact hh.deriv_eq

theorem partial_right_congr {f g : ℝ×ℝ→ℝ} {q : ℝ×ℝ} (he : f =ᶠ[𝓝 q] g) :
    right f q=right g q := by
  have hh : (fun d => f (q.1,d)) =ᶠ[𝓝 q.2] (fun d => g (q.1,d)) :=
    (continuousAt_const.prodMk continuousAt_id).eventually he
  exact hh.deriv_eq

theorem upper_actual_period_PDE_germ (b : ℝ) (a c : CanonicalCoefficients→ℝ) (q : ℝ×ℝ)
    (hb : b≠0) (hm : 1-b≠0) (hp : 1+b≠0) (hd : 1+q.2≠0) (hbd : 1+b*q.2≠0)
    (h : RegularTwoTurnFamily (canonicalGap (2*b/(1-b))) a c (upperEnergyChart b q))
    (ha : 0<a (upperEnergyChart b q)) :
    ∀ᶠ r in 𝓝 q,left (right (upperChartPeriod b a c)) r+
      upperTransportV b r.2*right (right (upperChartPeriod b a c)) r+
      upperTransportA b r.2*right (upperChartPeriod b a c) r+
      1/(2*(1+r.2))*left (upperChartPeriod b a c) r+
      upperTransportC b r.2*upperChartPeriod b a c r=0 := by
  have hch := (analyticAt_upperEnergyChart b q).continuousAt
  have hdg : ∀ᶠ r : ℝ×ℝ in 𝓝 q,1+r.2≠0 :=
    (continuousAt_const.add continuousAt_snd).eventually_ne hd
  have hbg : ∀ᶠ r : ℝ×ℝ in 𝓝 q,1+b*r.2≠0 :=
    (continuousAt_const.add (continuousAt_const.mul continuousAt_snd)).eventually_ne hbd
  filter_upwards [hch.eventually (regularTwoTurnFamily_eventually h),
    (h.analytic_left.continuousAt.comp hch).eventually (Ioi_mem_nhds ha),hdg,hbg]
    with r hr hra hrd hrb
  exact upper_actual_period_PDE b a c r hb hm hp hrd hrb hr hra

theorem analytic_left_PDE {R : ℝ×ℝ→ℝ} {q : ℝ×ℝ} (hR : AnalyticAt ℝ R q)
    (v a j c : ℝ→ℝ)
    (he : ∀ᶠ r in 𝓝 q,left (right R) r+v r.2*right (right R) r+
      a r.2*right R r+j r.2*left R r+c r.2*R r=0) :
    left (right (left R)) q+v q.2*right (right (left R)) q+
      a q.2*right (left R) q+j q.2*left (left R) q+c q.2*left R q=0 := by
  have hRg := analyticAt_right hR
  have hRR := analyticAt_right hRg
  have hLR := analyticAt_left hRg
  have hLL := analyticAt_left hR
  have hex : (fun X => left (right R) (X,q.2)+v q.2*right (right R) (X,q.2)+
      a q.2*right R (X,q.2)+j q.2*left R (X,q.2)+c q.2*R (X,q.2)) =ᶠ[𝓝 q.1] (fun _ => (0:ℝ)) :=
    (continuousAt_id.prodMk continuousAt_const).eventually he
  have hd := ((((hLR.curry_left.differentiableAt.hasDerivAt).add
    (hRR.curry_left.differentiableAt.hasDerivAt.const_mul (v q.2))).add
    (hRg.curry_left.differentiableAt.hasDerivAt.const_mul (a q.2))).add
    (hLL.curry_left.differentiableAt.hasDerivAt.const_mul (j q.2))).add
    (hR.curry_left.differentiableAt.hasDerivAt.const_mul (c q.2))
  have hz := (hd.congr_of_eventuallyEq hex.symm).unique (hasDerivAt_const q.1 (0:ℝ))
  change left (left (right R)) q+v q.2*left (right (right R)) q+
    a q.2*left (right R) q+j q.2*left (left R) q+c q.2*left R q=0 at hz
  have hm : left (left (right R)) q=left (right (left R)) q := by
    have hg : ∀ᶠ r in 𝓝 q,left (right R) r=right (left R) r :=
      hR.eventually_analyticAt.mono (fun r hr => AnalyticTwoPartials.mixed_partials_commute hr)
    exact partial_left_congr hg
  rw [hm,left_right_right hR,AnalyticTwoPartials.mixed_partials_commute hR] at hz
  exact hz

def parameterGauge (g : ℝ→ℝ) (S : ℝ×ℝ→ℝ) (q : ℝ×ℝ) : ℝ := g q.2*S q

theorem parameterGauge_right_germ {g : ℝ→ℝ} {S : ℝ×ℝ→ℝ} {q : ℝ×ℝ}
    (hg : AnalyticAt ℝ g q.2) (hS : AnalyticAt ℝ S q) :
    right (parameterGauge g S) =ᶠ[𝓝 q] fun r => deriv g r.2*S r+g r.2*right S r := by
  filter_upwards [hS.eventually_analyticAt,continuousAt_snd.eventually hg.eventually_analyticAt]
    with r hr hrG
  exact (hrG.differentiableAt.hasDerivAt.mul hr.curry_right.differentiableAt.hasDerivAt).deriv

theorem parameterGauge_jets {g : ℝ→ℝ} {S : ℝ×ℝ→ℝ} {q : ℝ×ℝ}
    (hg : AnalyticAt ℝ g q.2) (hS : AnalyticAt ℝ S q) :
    right (parameterGauge g S) q=deriv g q.2*S q+g q.2*right S q ∧
    left (right (parameterGauge g S)) q=deriv g q.2*left S q+g q.2*left (right S) q ∧
    right (right (parameterGauge g S)) q=deriv (deriv g) q.2*S q+
      2*deriv g q.2*right S q+g q.2*right (right S) q := by
  have hgerm := parameterGauge_right_germ hg hS
  refine ⟨hgerm.self_of_nhds,?_,?_⟩
  · have hh := (hS.curry_left.differentiableAt.hasDerivAt.const_mul (deriv g q.2)).add
      ((analyticAt_right hS).curry_left.differentiableAt.hasDerivAt.const_mul (g q.2))
    exact (partial_left_congr hgerm).trans hh.deriv
  · have hh := (hg.deriv.differentiableAt.hasDerivAt.mul hS.curry_right.differentiableAt.hasDerivAt).add
      (hg.differentiableAt.hasDerivAt.mul (analyticAt_right hS).curry_right.differentiableAt.hasDerivAt)
    rw [partial_right_congr hgerm]
    change deriv (fun d => deriv g d*S (q.1,d)+g d*right S (q.1,d)) q.2=_
    rw [hh.deriv]
    dsimp only [right]
    ring

def upperTransportGauge (d : ℝ) : ℝ := Real.sqrt ((1+d)/2)

theorem analyticAt_upperTransportGauge {d : ℝ} (hd : 0<1+d) :
    AnalyticAt ℝ upperTransportGauge d :=
  analyticAt_sqrt_comp ((analyticAt_const.add analyticAt_id).div analyticAt_const (by norm_num)) (by positivity)

theorem gauge_square_algebra {s H : ℝ} (hs : s≠0) (hH : H≠0) (hsq : s^2=H/2) :
    (1/2)/(2*s)=s/(2*H) := by
  field_simp [hs,hH]
  nlinarith only [hsq]

theorem upperTransportGauge_jets {d : ℝ} (hd : 0<1+d) :
    deriv upperTransportGauge d=upperTransportGauge d/(2*(1+d)) ∧
    deriv (deriv upperTransportGauge) d= -upperTransportGauge d/(4*(1+d)^2) := by
  have hdp : 0<(1+d)/2 := by positivity
  have hs : upperTransportGauge d≠0 := (Real.sqrt_pos.mpr hdp).ne'
  have hsq : (upperTransportGauge d)^2=(1+d)/2 := Real.sq_sqrt hdp.le
  have hfirst (r : ℝ) (hr : 0<1+r) : deriv upperTransportGauge r=upperTransportGauge r/(2*(1+r)) := by
    have hd' := (((hasDerivAt_id r).const_add 1).div_const 2).sqrt (by positivity : (1+r)/2≠0)
    have heq : (1/2)/(2*Real.sqrt ((1+r)/2))=Real.sqrt ((1+r)/2)/(2*(1+r)) := by
      have hsr : Real.sqrt ((1+r)/2)≠0 := (Real.sqrt_pos.mpr (by positivity)).ne'
      have hsq' := Real.sq_sqrt (by positivity : 0≤(1+r)/2)
      exact gauge_square_algebra hsr hr.ne' hsq'
    exact hd'.deriv.trans heq
  refine ⟨hfirst d hd,?_⟩
  have he : deriv upperTransportGauge =ᶠ[𝓝 d] fun r => upperTransportGauge r/(2*(1+r)) := by
    filter_upwards [(continuousAt_const.add continuousAt_id).eventually (Ioi_mem_nhds hd)] with r hr
    exact hfirst r hr
  have hgd := (analyticAt_upperTransportGauge hd).differentiableAt.hasDerivAt
  rw [hfirst d hd] at hgd
  have hh := hgd.div (((hasDerivAt_id d).const_add 1).const_mul 2) (by positivity : 2*(1+d)≠0)
  simp only [id_eq] at hh
  rw [he.deriv_eq,hh.deriv]
  field_simp [hd.ne']
  ring

def upperActualU (b : ℝ) (a c : CanonicalCoefficients→ℝ) : ℝ×ℝ→ℝ :=
  parameterGauge upperTransportGauge (left (upperChartPeriod b a c))

theorem upper_actual_transport (b : ℝ) (a c : CanonicalCoefficients→ℝ) (q : ℝ×ℝ)
    (hb : b≠0) (hm : 1-b≠0) (hp : 1+b≠0) (hd : 0<1+q.2) (hbd : 1+b*q.2≠0)
    (h : RegularTwoTurnFamily (canonicalGap (2*b/(1-b))) a c (upperEnergyChart b q))
    (ha : 0<a (upperEnergyChart b q)) :
    left (right (upperActualU b a c)) q+
      upperTransportV b q.2*right (right (upperActualU b a c)) q+
      upperTransportC1 b q.2*right (upperActualU b a c) q=
      -upperTransportGamma b q.2*upperActualU b a c q := by
  have hR : AnalyticAt ℝ (upperChartPeriod b a c) q :=
    (analyticAt_canonicalPeriod h ha).comp (analyticAt_upperEnergyChart b q)
  have hP := analytic_left_PDE hR (upperTransportV b) (upperTransportA b)
    (fun d => 1/(2*(1+d))) (upperTransportC b)
    (upper_actual_period_PDE_germ b a c q hb hm hp hd.ne' hbd h ha)
  have hgj := upperTransportGauge_jets hd
  have hj := parameterGauge_jets (analyticAt_upperTransportGauge hd) (analyticAt_left hR)
  have hc := upper_transport_gauge_coefficients b q.2 hb hp hd.ne'
  dsimp only [upperActualU]
  rw [hj.1,hj.2.1,hj.2.2,hgj.1,hgj.2]
  dsimp only [parameterGauge]
  have hc1 : upperTransportC1 b q.2=upperTransportA b q.2-upperTransportV b q.2/(1+q.2) := hc.1.symm
  have hcγ : upperTransportGamma b q.2=3*upperTransportV b q.2/(4*(1+q.2)^2)-
      upperTransportA b q.2/(2*(1+q.2))+upperTransportC b q.2 := hc.2.symm
  rw [hc1,hcγ]
  linear_combination (norm := (field_simp [hd.ne']; ring)) upperTransportGauge q.2*hP

end LeanVerification.UpperStripCompletion
