import LeanVerification.UpperStripCompletion.UpperPhysicalTransport
import LeanVerification.UpperStripCompletion.TransportComparison

/-! The full interior bound and its retained comparison with the actual
C=0 physical boundary. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open Loud GeneralMechanical Sharpness AnalyticTwoPartials
set_option maxHeartbeats 2600000

theorem upper_physical_interior_comparison {b T : ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hC0 : 0<upperCenterPolynomial b 0) (hT : 0<T) :
    (∀q∈Ioc 0 T ×ˢ Icc 0 (upperCenterRoot b),0<upperPhysicalU b q) ∧
    (∀q∈transportRectangle T (upperCenterRoot b),right (upperPhysicalU b) q<0) ∧
    (∀X∈Icc 0 T,∀d∈Icc 0 (upperCenterRoot b),upperPhysicalU b (X,upperCenterRoot b)≤upperPhysicalU b (X,d)) := by
  have hr := upperCenterRoot_spec hb hb1 hC0
  have hm : 0<1-b := by linarith
  have hp : 0<1+b := by linarith
  have hcr : upperCenterRoot b≤1 := by linarith [hr.2.1]
  apply transport_interior_comparison hT hr.1.le
  · intro q hq
    apply analyticAt_upperPhysicalU (by linarith) (by linarith [hq.2.1])
    rcases eq_or_lt_of_le hq.1.1 with he|he
    · exact Or.inl he.symm
    · exact Or.inr (upper_physical_chart_admissible hb hb1 he hq.2.1 (hq.2.2.trans hcr))
  · intro d hd
    rw [upper_physical_U_center hb (by linarith) (by linarith [hd.1])]
    have hCd : 0≤upperCenterPolynomial b d := by
      have hh := (upper_center_strictAnti hb.le hb1).antitoneOn
        ⟨hd.1,hd.2.trans hcr⟩ ⟨hr.1.le,hcr⟩ hd.2
      rwa [hr.2.2] at hh
    have hd0 : 0≤d := hd.1
    have hbd : 0<1+b*d := by positivity
    have he : 0<1+d := by linarith [hd.1]
    unfold upperInitialTrace
    positivity
  · intro d hd
    exact upper_physical_U_center_parameter_deriv hb hb1 hd.1 (hd.2.trans hr.2.1.le)
  · intro X hX
    have hAd := upper_physical_chart_admissible (q:=(X,upperCenterRoot b)) hb hb1 hX.1 hr.1.le hcr
    rw [upper_physical_U_formula (by linarith) (by linarith [hr.1]) (Or.inr hAd),
      extendedPhysicalSlope_eq_physical hAd]
    have hSlope := physical_upper_period_deriv_pos_center_zero hb.le hb1 hr.1.le hr.2.1.le hr.2.2 hAd
    have hH := (upper_physical_height_pos hb (by linarith) hr.1.le).2
    change 0<Real.sqrt ((1-b)/2)*upperPhysicalHeight b (upperCenterRoot b)*Real.exp (-X)*
      deriv (periodQuadrature (-1/(1+upperCenterRoot b)) (1/(1-b))) (upperPhysicalEnergy b (X,upperCenterRoot b))
    positivity
  · exact upper_transport_v_zero b
  · intro d hd
    exact (upper_transport_coefficient_signs hb hb1 hd.1 (hd.2.trans hr.2.1.le)).1
  · intro d hd
    exact (upper_transport_coefficient_signs hb hb1 hd.1 (hd.2.trans hr.2.1.le)).2.1
  · exact upper_transport_c_continuous hb hr.1.le
  · intro d hd
    exact (upper_transport_coefficient_signs hb hb1 hd.1 (hd.2.trans hr.2.1.le)).2.2.le
  · intro q hq hqp
    exact upper_physical_transport hb hb1 hqp hq.2.1 (hq.2.2.trans hcr)

def upperPhysicalA (b d : ℝ) : ℝ := (1+b*d)/(1+d)
def upperPhysicalHeightScale (b : ℝ) : ℝ := (1-b)^2/(2*b*(1+b))

theorem upper_physical_height_factor (b d : ℝ) :
    upperPhysicalHeight b d=upperPhysicalHeightScale b*upperPhysicalA b d := by
  unfold upperPhysicalHeight upperPhysicalScale upperHeight upperPhysicalHeightScale upperPhysicalA
  ring

theorem upper_physical_A_pos {b d : ℝ} (hb : 0≤b) (hd : 0≤d) : 0<upperPhysicalA b d := by
  unfold upperPhysicalA
  have he : 0<1+d := by linarith
  positivity

theorem exists_upper_physical_energy_coordinate {b d h : ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hd : 0≤d) (hd1 : d≤1)
    (hh : AdmissibleEnergy (-1/(1+d)) (1/(1-b)) h) :
    ∃X,0<X ∧ upperPhysicalEnergy b (X,d)=h := by
  have hm : 0<1-b := by linarith
  have hp : 0<1+b := by linarith
  have he : 0<1+d := by linarith
  have hF : 1<1/(1-b) := (lt_div_iff₀ hm).mpr (by linarith)
  obtain ⟨hD0,hD1,_,_,_,_⟩ := normalized_upper_physical_parameters hb.le hb1 hd hd1
  have hbound := (upper_admissibleEnergy_iff _ _ _ hD0 (by linarith) hF).mp hh
  rw [(upper_physical_coefficient_normalization b d hb.ne' hm.ne' hp.ne' he.ne').2.2.2.1] at hbound
  have hH := (upper_physical_height_pos hb (by linarith) hd).2
  have hy0 : 0<1-h/upperPhysicalHeight b d := sub_pos.mpr ((div_lt_one hH).mpr hbound.2)
  have hy1 : 1-h/upperPhysicalHeight b d<1 := by have := div_pos hh.1 hH; linarith
  refine ⟨-Real.log (1-h/upperPhysicalHeight b d),neg_pos.mpr (Real.log_neg hy0 hy1),?_⟩
  unfold upperPhysicalEnergy
  rw [neg_neg,Real.exp_log hy0]
  field_simp [hH.ne']

theorem upper_physical_energy_parameter_comparison {b X d c h : ℝ}
    (hb : 0<b) (hb1 : b<1) (hd : 0≤d) (hc : 0≤c)
    (he : upperPhysicalEnergy b (X,d)=h) :
    upperPhysicalEnergy b (X,c)=h*upperPhysicalA b c/upperPhysicalA b d := by
  have hdA := upper_physical_A_pos hb.le hd
  apply (eq_div_iff hdA.ne').mpr
  rw [← he]
  unfold upperPhysicalEnergy
  rw [upper_physical_height_factor,upper_physical_height_factor]
  ring

theorem upper_physical_period_slope_comparison {b d h : ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hC0 : 0<upperCenterPolynomial b 0)
    (hd : 0≤d) (hdr : d≤upperCenterRoot b)
    (hh : AdmissibleEnergy (-1/(1+d)) (1/(1-b)) h) :
    upperPhysicalA b (upperCenterRoot b)*deriv (periodQuadrature (-1/(1+upperCenterRoot b)) (1/(1-b)))
      (h*upperPhysicalA b (upperCenterRoot b)/upperPhysicalA b d)≤
    upperPhysicalA b d*deriv (periodQuadrature (-1/(1+d)) (1/(1-b))) h := by
  have hr := upperCenterRoot_spec hb hb1 hC0
  have hd1 : d≤1 := hdr.trans (by linarith [hr.2.1])
  obtain ⟨X,hX,hEX⟩ := exists_upper_physical_energy_coordinate hb hb1 hd hd1 hh
  have hcmp := (upper_physical_interior_comparison hb hb1 hC0 hX).2.2 X ⟨hX.le,le_rfl⟩ d ⟨hd,hdr⟩
  have hAc := upper_physical_chart_admissible (q:=(X,upperCenterRoot b)) hb hb1 hX hr.1.le (by linarith [hr.2.1])
  have hAd := upper_physical_chart_admissible (q:=(X,d)) hb hb1 hX hd hd1
  rw [upper_physical_U_formula (by linarith) (by linarith [hr.1]) (Or.inr hAc),
    upper_physical_U_formula (by linarith) (by linarith) (Or.inr hAd),
    extendedPhysicalSlope_eq_physical hAc,extendedPhysicalSlope_eq_physical hAd] at hcmp
  change Real.sqrt ((1-b)/2)*upperPhysicalHeight b (upperCenterRoot b)*Real.exp (-X)*
      deriv (periodQuadrature (-1/(1+upperCenterRoot b)) (1/(1-b))) (upperPhysicalEnergy b (X,upperCenterRoot b))≤
    Real.sqrt ((1-b)/2)*upperPhysicalHeight b d*Real.exp (-X)*
      deriv (periodQuadrature (-1/(1+d)) (1/(1-b))) (upperPhysicalEnergy b (X,d)) at hcmp
  rw [upper_physical_energy_parameter_comparison hb (by linarith) hd hr.1.le hEX,hEX,
    upper_physical_height_factor,upper_physical_height_factor] at hcmp
  have hscale : 0<Real.sqrt ((1-b)/2)*upperPhysicalHeightScale b*Real.exp (-X) := by
    have hm : 0<1-b := by linarith
    unfold upperPhysicalHeightScale
    positivity
  apply (mul_le_mul_left hscale).mp
  convert hcmp using 1 <;> ring

theorem physical_upper_period_deriv_pos_positive_center {b d h : ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hd : 0≤d) (hd1 : d≤1)
    (hC : 0<upperCenterPolynomial b d)
    (hh : AdmissibleEnergy (-1/(1+d)) (1/(1-b)) h) :
    0<deriv (periodQuadrature (-1/(1+d)) (1/(1-b))) h := by
  have hC0 := (upper_center_positive_range hb.le hb1 hd hd1 hC).2
  have hr := upperCenterRoot_spec hb hb1 hC0
  have hdr := upper_positive_parameter_lt_root hb hb1 hd hd1 hC
  obtain ⟨X,hX,hEX⟩ := exists_upper_physical_energy_coordinate hb hb1 hd hd1 hh
  have hU := (upper_physical_interior_comparison hb hb1 hC0 hX).1 (X,d)
    ⟨⟨hX,le_rfl⟩,⟨hd,hdr.le⟩⟩
  have hAd := upper_physical_chart_admissible (q:=(X,d)) hb hb1 hX hd hd1
  rw [upper_physical_U_formula (by linarith) (by linarith) (Or.inr hAd),extendedPhysicalSlope_eq_physical hAd] at hU
  change 0<Real.sqrt ((1-b)/2)*upperPhysicalHeight b d*Real.exp (-X)*
    deriv (periodQuadrature (-1/(1+d)) (1/(1-b))) (upperPhysicalEnergy b (X,d)) at hU
  rw [hEX] at hU
  apply pos_of_mul_pos_right hU
  have hm : 0<1-b := by linarith
  have hH := (upper_physical_height_pos hb (by linarith) hd).2
  positivity

end LeanVerification.UpperStripCompletion
