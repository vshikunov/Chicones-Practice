import LeanVerification.UpperStripCompletion.JacobiJets

/-! Exact force-invariant identities for the actual Jacobi variation.
The zero-derivative identity treats ordinary and exceptional zeros together:
there is no division by the auxiliary A or by the variation Y. -/
noncomputable section
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 1800000

def forceInvariant (g k f t u : ℝ) : ℝ :=
  15*f*k*t-15*g*f*u+21*g*t^2-25*f^3

def forceAuxiliary (v g f t : ℝ) : ℝ := 5*g*f-2*v*t

def jacobiCValue (v g f t y y₂ : ℝ) : ℝ :=
  3*forceAuxiliary v g f t*y₂-5*f^2*y

def jacobiCPrime (v g k f t u y y₁ y₂ y₃ : ℝ) : ℝ :=
  3*(5*k*f+7*g*t-2*v*u)*y₂+3*forceAuxiliary v g f t*y₃-
    10*f*t*y-5*f^2*y₁

theorem jacobi_C_zero_derivative_certificate
    (v g k f t u y y₁ y₂ y₃ : ℝ) :
    2*v*(5*g*f*jacobiCPrime v g k f t u y y₁ y₂ y₃-
      2*v*y₂*forceInvariant g k f t u)=
      15*g*f*forceAuxiliary v g f t*(2*v*y₃-3*g*y₂+f*y)+
      50*v*f^3*(2*v*y₂-g*y₁+k*y)+
      (15*f*g^2+10*f*k*v+14*g*t*v)*jacobiCValue v g f t y y₂ := by
  unfold jacobiCPrime jacobiCValue forceAuxiliary forceInvariant
  ring

theorem jacobi_C_derivative_at_zero
    {v g k f t u y y₁ y₂ y₃ : ℝ} (hv : v≠0) (hg : g≠0) (hf : f≠0)
    (h₂ : 2*v*y₂-g*y₁+k*y=0) (h₃ : 2*v*y₃-3*g*y₂+f*y=0)
    (hC : jacobiCValue v g f t y y₂=0) :
    jacobiCPrime v g k f t u y y₁ y₂ y₃=
      2*v*y₂*forceInvariant g k f t u/(5*g*f) := by
  have he := jacobi_C_zero_derivative_certificate v g k f t u y y₁ y₂ y₃
  rw [h₂,h₃,hC,mul_zero,mul_zero,mul_zero,add_zero,add_zero] at he
  have hh : 5*g*f*jacobiCPrime v g k f t u y y₁ y₂ y₃-
      2*v*y₂*forceInvariant g k f t u=0 :=
    (mul_eq_zero.mp he).resolve_left (mul_ne_zero (by norm_num) hv)
  apply (eq_div_iff (mul_ne_zero (mul_ne_zero (by norm_num) hg) hf)).2
  nlinarith only [hh]

theorem jacobi_C_prime_pos_left
    {v g k f t u y y₁ y₂ y₃ : ℝ} (hv : 0<v) (hg : g<0) (hf : f<0)
    (hy₂ : y₂<0) (hN : forceInvariant g k f t u<0)
    (h₂ : 2*v*y₂-g*y₁+k*y=0) (h₃ : 2*v*y₃-3*g*y₂+f*y=0)
    (hC : jacobiCValue v g f t y y₂=0) :
    0<jacobiCPrime v g k f t u y y₁ y₂ y₃ := by
  rw [jacobi_C_derivative_at_zero hv.ne' hg.ne hf.ne h₂ h₃ hC]
  exact div_pos (mul_pos_of_neg_of_neg (mul_neg_of_pos_of_neg (by positivity) hy₂) hN)
    (mul_pos_of_neg_of_neg (mul_neg_of_pos_of_neg (by norm_num) hg) hf)

theorem jacobi_C_prime_neg_right
    {v g k f t u y y₁ y₂ y₃ : ℝ} (hv : 0<v) (hg : 0<g) (hf : f<0)
    (hy₂ : y₂<0) (hN : forceInvariant g k f t u<0)
    (h₂ : 2*v*y₂-g*y₁+k*y=0) (h₃ : 2*v*y₃-3*g*y₂+f*y=0)
    (hC : jacobiCValue v g f t y y₂=0) :
    jacobiCPrime v g k f t u y y₁ y₂ y₃<0 := by
  rw [jacobi_C_derivative_at_zero hv.ne' hg.ne' hf.ne h₂ h₃ hC]
  exact div_neg_of_pos_of_neg
    (mul_pos_of_neg_of_neg (mul_neg_of_pos_of_neg (by positivity) hy₂) hN)
    (mul_neg_of_pos_of_neg (by positivity) hf)

theorem jacobi_C_at_force_center
    {v k f t y y₂ : ℝ} (h₂ : 2*v*y₂+k*y=0) :
    jacobiCValue v 0 f t y y₂=(3*k*t-5*f^2)*y := by
  unfold jacobiCValue forceAuxiliary
  linear_combination -3*t*h₂

theorem jacobi_C_turn_values {g k f t u : ℝ} (hg : g≠0) :
    jacobiCValue 0 g f t (1/g) (f/(3*g^2))=0 ∧
    jacobiCPrime 0 g k f t u (1/g) (k/g^2) (f/(3*g^2)) (t/(5*g^2))=0 ∧
    (3*(5*f^2+12*k*t+9*g*u)*(f/(3*g^2))+
      6*(5*k*f+7*g*t)*(t/(5*g^2))+
      15*g*f*((g*u+(2/5:ℝ)*k*t-(2/3:ℝ)*f^2)/(7*g^3))-
      10*(t^2+f*u)*(1/g)-20*f*t*(k/g^2)-5*f^2*(f/(3*g^2)))=
        -8*forceInvariant g k f t u/(105*g^2) := by
  unfold jacobiCValue jacobiCPrime forceAuxiliary forceInvariant
  constructor
  · field_simp [hg]
    <;> ring
  constructor
  · field_simp [hg]
    <;> ring
  · field_simp [hg]
    <;> ring

theorem jacobi_B_derivative_certificate {v g f t y y₁ y₂ y₃ : ℝ}
    (hv : v≠0) (hf : f≠0)
    (h₁ : 2*v*y₁+g*y=1) (h₃ : 2*v*y₃-3*g*y₂+f*y=0) :
    (((y₃*f-y₂*t)/f^2-(2/3:ℝ)*y*y₁)*v+
      g*(y₂/f-y^2/3))/v^2=
      jacobiCValue v g f t y y₂/(6*f^2*v^2) := by
  have hy₁ : y₁=(1-g*y)/(2*v) := by
    apply (eq_div_iff (mul_ne_zero (by norm_num) hv)).2
    nlinarith only [h₁]
  have hy₃ : y₃=(3*g*y₂-f*y)/(2*v) := by
    apply (eq_div_iff (mul_ne_zero (by norm_num) hv)).2
    nlinarith only [h₃]
  rw [hy₁,hy₃]
  unfold jacobiCValue forceAuxiliary
  field_simp [hv,hf]
  <;> ring

end LeanVerification.UpperStripCompletion
