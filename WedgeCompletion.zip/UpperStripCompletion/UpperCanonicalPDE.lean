import LeanVerification.UpperStripCompletion.UpperTransportAlgebra

/-! Reduction of the actual complete-period equation to the physical
energy and mixture directions. -/
noncomputable section
open Set Filter
open scoped Topology ContDiff
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical DirectionalPartials InteriorCompletion
set_option maxHeartbeats 4800000

theorem upper_canonical_period_jet_equation (b d δ : ℝ)
    (a c : CanonicalCoefficients→ℝ)
    (hb : b≠0) (hm : 1-b≠0) (hp : 1+b≠0) (hd : 1+d≠0) (hbd : 1+b*d≠0)
    (h : RegularTwoTurnFamily (canonicalGap (2*b/(1-b))) a c (upperCanonicalPoint b d δ))
    (ha : 0<a (upperCanonicalPoint b d δ)) :
    let q := upperCanonicalPoint b d δ
    let T := canonicalPeriod (2*b/(1-b)) a c
    hessian T q (upperDDirection b d δ) (upperXDirection δ)+
      upperTransportV b d*hessian T q (upperDDirection b d δ) (upperDDirection b d δ)+
      upperTransportA b d*directional T (upperDDirection b d δ) q+
      (1/(2*(1+d))+upperTransportZeta b d)*directional T (upperXDirection δ) q+
      upperTransportC b d*T q=0 := by
  let q := upperCanonicalPoint b d δ
  let T := canonicalPeriod (2*b/(1-b)) a c
  let z := canonicalDilation (2*b/(1-b)) q
  let e := upperDDirection b d δ
  let x := upperXDirection δ
  let L := fderiv ℝ T q
  let H := fderiv ℝ (fderiv ℝ T) q
  have hT : AnalyticAt ℝ T q := analyticAt_canonicalPeriod h ha
  have hsym (u v : CanonicalCoefficients) : H u v=H v u := hT.contDiffAt.isSymmSndFDerivAt_of_omega u v
  have hLq : L q= -T q/2 := (canonical_period_euler_identities h ha).1
  have hLz : L z= -T q := (canonical_period_euler_identities h ha).2
  have hQ (u : CanonicalCoefficients) : H u q= -(3/2)*L u := (canonical_period_euler_hessian h ha u).1
  have hZ (u : CanonicalCoefficients) : H u z= -L (u+canonicalDilation (2*b/(1-b)) u) :=
    (canonical_period_euler_hessian h ha u).2
  have hqz : H q z=(3/2)*T q := by rw [hsym,hQ,hLz]; ring
  have hqe : H q e= -(3/2)*L e := by rw [hsym,hQ]
  have hqx : H q x= -(3/2)*L x := by rw [hsym,hQ]
  obtain ⟨hDe,hDx,hDz⟩ := upper_dilation_direction_basis b d δ hm hp hd hbd
  have hez : H e z=T q/(1+d)-(1+2/(1+d))*L e := by
    rw [hZ]
    change -L (e+canonicalDilation (2*b/(1-b)) (upperDDirection b d δ))=_
    rw [hDe]
    change -L (e+((1/(1+d)) • z+(2/(1+d)) • e))=_
    simp only [map_add,map_smul,smul_eq_mul,hLz]
    ring
  have hze : H z e=T q/(1+d)-(1+2/(1+d))*L e := (hsym z e).trans hez
  have hxz : H x z= -(1-2*b/(1-b))*L x := by
    rw [hZ]
    change -L (x+canonicalDilation (2*b/(1-b)) (upperXDirection δ))=_
    rw [hDx]
    simp only [map_add,map_smul,smul_eq_mul]
    ring
  have hzx : H z x= -(1-2*b/(1-b))*L x := (hsym z x).trans hxz
  have hzz : H z z=(1+(3*d+1)/(1+d))*T q-2*d*(1-d)/(1+d)*L e+
      (1+d)/(1-b)*upperTransportK b d*L x := by
    rw [hZ]
    change -L (z+canonicalDilation (2*b/(1-b))
      (canonicalDilation (2*b/(1-b)) (upperCanonicalPoint b d δ)))=_
    rw [hDz]
    simp only [map_add,map_smul,smul_eq_mul]
    change -(L z+(((3*d+1)/(1+d))*L z+(2*d*(1-d)/(1+d))*L e+
      (-(1+d)/(1-b)*upperTransportK b d)*L x))=_
    rw [hLz]
    ring
  obtain ⟨hA,hB,hC⟩ := upper_canonical_direction_basis b d δ hb hm hp hd hbd
  have hpf := canonical_period_hessian_identity h ha
  rw [← hessian_eq_directional hT canonicalB canonicalB,
    ← hessian_eq_directional hT canonicalA canonicalC] at hpf
  change H canonicalB canonicalB+H canonicalA canonicalC=0 at hpf
  have hcert := upper_transport_jet_certificate b d (T q) (L e) (L x)
    (H e e) (H e x) (H x x) hb hm hp hd hbd
  have hsum : H canonicalB canonicalB+H canonicalA canonicalC=
      (4*b*(1+b)/(1-b))*(H e x+upperTransportV b d*H e e+upperTransportA b d*L e+
        (1/(2*(1+d))+upperTransportZeta b d)*L x+upperTransportC b d*T q) := by
    calc
      _=_ := ?_
      _=_ := hcert
    rw [hA,hB,hC]
    change H (((1+b)/(1+d)) • z+(-2*d*(1+b)/(1+d)) • e+(-upperTransportK b d) • x)
        (((1+b)/(1+d)) • z+(-2*d*(1+b)/(1+d)) • e+(-upperTransportK b d) • x)+
      H ((2*b) • q+(-2*b/(1+d)) • z+(2*b*d*(1-d)/(1+d)) • e+upperTransportK b d • x)
        ((2/(1+d)) • z+(2*(1-d)/(1+d)) • e+(-upperTransportK b d) • x)=_
    simp only [map_add,map_smul,ContinuousLinearMap.add_apply,ContinuousLinearMap.smul_apply,smul_eq_mul]
    rw [hqz,hqe,hqx,hzz,hez,hze,hxz,hzx,hsym x e]
    ring
  rw [hsum] at hpf
  have hscale : 4*b*(1+b)/(1-b)≠0 := div_ne_zero (mul_ne_zero (mul_ne_zero (by norm_num) hb) hp) hm
  exact (mul_eq_zero.mp hpf).resolve_left hscale

end LeanVerification.UpperStripCompletion
