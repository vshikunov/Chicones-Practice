import LeanVerification.CriticalEnergy

/-! A double zero with positive second derivative supplies the strict
interior starting sign used by the force comparison argument. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 1000000

theorem positive_right_of_double_zero {f : ℝ → ℝ} {a b : ℝ}
    (hab : a<b) (hf : AnalyticAt ℝ f a) (h0 : f a=0)
    (h1 : deriv f a=0) (h2 : 0<deriv (deriv f) a) :
    ∃ c ∈ Ioo a b, ∀ x ∈ Ioc a c, 0<f x := by
  have he : ∀ᶠ x in 𝓝 a, AnalyticAt ℝ f x ∧ 0<deriv (deriv f) x := by
    filter_upwards [hf.eventually_analyticAt,
      hf.deriv.deriv.continuousAt.eventually (Ioi_mem_nhds h2)] with x hx hx2
    exact ⟨hx,hx2⟩
  obtain ⟨l,r,⟨hla,har⟩,hlr⟩ := he.exists_Ioo_subset
  let c := (a+min b r)/2
  have hac : a<c := by dsimp [c]; have := lt_min hab har; linarith
  have hcb : c<b := by dsimp [c]; have := min_le_left b r; linarith
  have hcr : c<r := by dsimp [c]; have := min_le_right b r; linarith
  have hd (x : ℝ) (hx : x ∈ Icc a c) : AnalyticAt ℝ f x ∧ 0<deriv (deriv f) x :=
    hlr ⟨hla.trans_le hx.1,hx.2.trans_lt hcr⟩
  have hm1 : StrictMonoOn (deriv f) (Icc a c) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc a c)
      (fun x hx => (hd x hx).1.deriv.continuousAt.continuousWithinAt)
    exact fun x hx => (hd x (interior_subset hx)).2
  have hm : StrictMonoOn f (Icc a c) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc a c)
      (fun x hx => (hd x hx).1.continuousAt.continuousWithinAt)
    intro x hx
    have hxi : x ∈ Ioo a c := by simpa only [interior_Icc] using hx
    simpa only [h1] using hm1 ⟨le_rfl,hac.le⟩ (Ioo_subset_Icc_self hxi) hxi.1
  refine ⟨c,⟨hac,hcb⟩,?_⟩
  intro x hx
  simpa only [h0] using hm ⟨le_rfl,hac.le⟩ ⟨hx.1.le,hx.2⟩ hx.1

theorem positive_left_of_double_zero {f : ℝ → ℝ} {a b : ℝ}
    (hab : a<b) (hf : AnalyticAt ℝ f b) (h0 : f b=0)
    (h1 : deriv f b=0) (h2 : 0<deriv (deriv f) b) :
    ∃ c ∈ Ioo a b, ∀ x ∈ Ico c b, 0<f x := by
  have he : ∀ᶠ x in 𝓝 b, AnalyticAt ℝ f x ∧ 0<deriv (deriv f) x := by
    filter_upwards [hf.eventually_analyticAt,
      hf.deriv.deriv.continuousAt.eventually (Ioi_mem_nhds h2)] with x hx hx2
    exact ⟨hx,hx2⟩
  obtain ⟨l,r,⟨hlb,hbr⟩,hlr⟩ := he.exists_Ioo_subset
  let c := (max a l+b)/2
  have hac : a<c := by dsimp [c]; have := le_max_left a l; linarith
  have hcb : c<b := by dsimp [c]; have := max_lt hab hlb; linarith
  have hlc : l<c := by dsimp [c]; have := le_max_right a l; linarith
  have hd (x : ℝ) (hx : x ∈ Icc c b) : AnalyticAt ℝ f x ∧ 0<deriv (deriv f) x :=
    hlr ⟨hlc.trans_le hx.1,hx.2.trans_lt hbr⟩
  have hm1 : StrictMonoOn (deriv f) (Icc c b) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc c b)
      (fun x hx => (hd x hx).1.deriv.continuousAt.continuousWithinAt)
    exact fun x hx => (hd x (interior_subset hx)).2
  have hm : StrictAntiOn f (Icc c b) := by
    apply strictAntiOn_of_deriv_neg (convex_Icc c b)
      (fun x hx => (hd x hx).1.continuousAt.continuousWithinAt)
    intro x hx
    have hxi : x ∈ Ioo c b := by simpa only [interior_Icc] using hx
    simpa only [h1] using hm1 (Ioo_subset_Icc_self hxi) ⟨hcb.le,le_rfl⟩ hxi.2
  refine ⟨c,⟨hac,hcb⟩,?_⟩
  intro x hx
  simpa only [h0] using hm ⟨hx.1,hx.2.le⟩ ⟨hcb.le,le_rfl⟩ hx.2

theorem positive_on_Ioo_of_left_double_zero_and_upward_zeros
    {f : ℝ → ℝ} {a b : ℝ} (hf : AnalyticOnNhd ℝ f (Icc a b))
    (h0 : f a=0) (h1 : deriv f a=0) (h2 : 0<deriv (deriv f) a)
    (hzero : ∀ x ∈ Ioo a b, f x=0 → 0<deriv f x) :
    ∀ x ∈ Ioo a b, 0<f x := by
  intro x hx
  obtain ⟨c,hc,hcp⟩ := positive_right_of_double_zero hx.1
    (hf a ⟨le_rfl,hx.1.le.trans hx.2.le⟩) h0 h1 h2
  have hp : 0<f c := hcp c ⟨hc.1,le_rfl⟩
  exact CriticalMode.pos_on_Icc_of_deriv_pos_at_zeros
    (fun z hz => (hf z ⟨hc.1.le.trans hz.1,hz.2.trans hx.2.le⟩).differentiableAt)
    (fun z hz => hzero z ⟨hc.1.trans_le hz.1,hz.2.trans_lt hx.2⟩)
    hp x ⟨hc.2.le,le_rfl⟩

theorem positive_on_Ioo_of_right_double_zero_and_downward_zeros
    {f : ℝ → ℝ} {a b : ℝ} (hf : AnalyticOnNhd ℝ f (Icc a b))
    (h0 : f b=0) (h1 : deriv f b=0) (h2 : 0<deriv (deriv f) b)
    (hzero : ∀ x ∈ Ioo a b, f x=0 → deriv f x<0) :
    ∀ x ∈ Ioo a b, 0<f x := by
  intro x hx
  obtain ⟨c,hc,hcp⟩ := positive_left_of_double_zero hx.2
    (hf b ⟨hx.1.le.trans hx.2.le,le_rfl⟩) h0 h1 h2
  have hp : 0<f c := hcp c ⟨le_rfl,hc.2⟩
  exact CriticalMode.pos_on_Icc_of_deriv_neg_at_zeros
    (fun z hz => (hf z ⟨hx.1.le.trans hz.1,hz.2.trans hc.2.le⟩).differentiableAt)
    (fun z hz => hzero z ⟨hx.1.trans_le hz.1,hz.2.trans_lt hc.2⟩)
    hp x ⟨le_rfl,hc.1.le⟩

end LeanVerification.UpperStripCompletion
