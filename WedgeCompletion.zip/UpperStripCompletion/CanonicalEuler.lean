import LeanVerification.UpperStripCompletion.CanonicalHessian
import LeanVerification.UpperStripCompletion.ActualJacobiCurvature

/-! Homogeneity and coordinate-dilation identities for the actual
canonical complete period, proved from its regular quadrature. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology ContDiff
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical DirectionalPartials InteriorCompletion
set_option maxHeartbeats 3600000

def canonicalDilation (p : ℝ) (q : CanonicalCoefficients) : CanonicalCoefficients :=
  ((0,q.1.2),(2*q.2.1,-p*q.2.2))

theorem canonicalGap_radial_parameter (p : ℝ) (q : CanonicalCoefficients) (x : ℝ) (hx : 0<x) :
    parameter (canonicalGap p) q (q,x)=canonicalGap p (q,x) := by
  rw [canonicalGap_parameter p q q x hx]
  rfl

theorem canonicalGap_spatial (p : ℝ) (q : CanonicalCoefficients) (x : ℝ) (hx : 0<x) :
    spatial (canonicalGap p) (q,x)= -q.1.2-2*q.2.1*x+p*q.2.2*x^(-p)/x := by
  have hd := (((hasDerivAt_const x q.1.1).sub ((hasDerivAt_id x).const_mul q.1.2)).sub
    (((hasDerivAt_id x).pow 2).const_mul q.2.1)).sub
    (((hasDerivAt_id x).rpow_const (p:=-p) (Or.inl hx.ne')).const_mul q.2.2)
  simp only [id_eq] at hd
  change deriv (fun y => q.1.1-q.1.2*y-q.2.1*y^2-q.2.2*y^(-p)) x=_
  rw [hd.deriv]
  simp only [id_eq,Real.rpow_sub_one hx.ne']
  norm_num
  ring

theorem canonicalGap_dilation_parameter (p : ℝ) (q : CanonicalCoefficients) (x : ℝ) (hx : 0<x) :
    parameter (canonicalGap p) (canonicalDilation p q) (q,x)=
      x*spatial (canonicalGap p) (q,x) := by
  rw [canonicalGap_parameter p q (canonicalDilation p q) x hx,canonicalGap_spatial p q x hx]
  dsimp only [canonicalDilation]
  field_simp [hx.ne']
  ring

theorem canonical_radial_turn_velocities {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    fderiv ℝ a q q=0 ∧ fderiv ℝ b q q=0 := by
  constructor
  · rw [implicit_turn_parameter_derivative
      (h.analytic_gap _ ⟨le_rfl,h.turns_ordered.le⟩).differentiableAt
      h.analytic_left.differentiableAt h.root_left h.slope_left.ne' q,
      canonicalGap_radial_parameter p q (a q) ha,h.root_left.self_of_nhds,zero_div]
  · rw [implicit_turn_parameter_derivative
      (h.analytic_gap _ ⟨h.turns_ordered.le,le_rfl⟩).differentiableAt
      h.analytic_right.differentiableAt h.root_right h.slope_right.ne q,
      canonicalGap_radial_parameter p q (b q) (ha.trans h.turns_ordered),h.root_right.self_of_nhds,zero_div]

theorem canonical_dilation_turn_velocities {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    fderiv ℝ a q (canonicalDilation p q)= -a q ∧
      fderiv ℝ b q (canonicalDilation p q)= -b q := by
  constructor
  · rw [implicit_turn_parameter_derivative
      (h.analytic_gap _ ⟨le_rfl,h.turns_ordered.le⟩).differentiableAt
      h.analytic_left.differentiableAt h.root_left h.slope_left.ne' (canonicalDilation p q),
      canonicalGap_dilation_parameter p q (a q) ha]
    field_simp [h.slope_left.ne']
  · rw [implicit_turn_parameter_derivative
      (h.analytic_gap _ ⟨h.turns_ordered.le,le_rfl⟩).differentiableAt
      h.analytic_right.differentiableAt h.root_right h.slope_right.ne (canonicalDilation p q),
      canonicalGap_dilation_parameter p q (b q) (ha.trans h.turns_ordered)]
    field_simp [h.slope_right.ne]

theorem canonical_factor_radial_parameter {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q)
    (θ : ℝ) (hθ : θ∈Ioo (-(Real.pi/2)) (Real.pi/2)) :
    parameter (angularTurnFactor (canonicalGap p) a b) q (q,θ)=
      angularTurnFactor (canonicalGap p) a b (q,θ) := by
  have hx : 0<angularTurnNode a b (q,θ) :=
    lt_of_lt_of_le ha (affineTurnNode_mem h.turns_ordered.le (unitSinNode_mem θ)).1
  have hv : angularTurnVelocity a b q q θ=0 := by
    obtain ⟨hva,hvb⟩ := canonical_radial_turn_velocities h ha
    simp only [angularTurnVelocity,hva,hvb,sub_self,zero_mul,add_zero]
  have hh := angularFactor_parameter_relation h q θ
  rw [canonicalGap_radial_parameter p q _ hx,hv,mul_zero,add_zero] at hh
  change (Real.cos θ/2)^2*parameter (angularTurnFactor (canonicalGap p) a b) q (q,θ)=
    angularTurnGap (canonicalGap p) a b (q,θ) at hh
  rw [h.angular_factorization_germ.self_of_nhds θ] at hh
  exact mul_left_cancel₀ (sq_pos_of_pos (div_pos (Real.cos_pos_of_mem_Ioo hθ) (by norm_num))).ne' hh

theorem canonical_factor_dilation_parameter {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q)
    (θ : ℝ) (hθ : θ∈Ioo (-(Real.pi/2)) (Real.pi/2)) :
    parameter (angularTurnFactor (canonicalGap p) a b) (canonicalDilation p q) (q,θ)=0 := by
  have hx : 0<angularTurnNode a b (q,θ) :=
    lt_of_lt_of_le ha (affineTurnNode_mem h.turns_ordered.le (unitSinNode_mem θ)).1
  have hv : angularTurnVelocity a b (canonicalDilation p q) q θ= -angularTurnNode a b (q,θ) := by
    obtain ⟨hva,hvb⟩ := canonical_dilation_turn_velocities h ha
    dsimp only [angularTurnVelocity,angularTurnNode,affineTurnNode]
    rw [hva,hvb]
    ring
  have hh := angularFactor_parameter_relation h (canonicalDilation p q) θ
  rw [canonicalGap_dilation_parameter p q _ hx,hv] at hh
  have hz : (Real.cos θ/2)^2*parameter (angularTurnFactor (canonicalGap p) a b)
      (canonicalDilation p q) (q,θ)=0 := by nlinarith only [hh]
  exact (mul_eq_zero.mp hz).resolve_left
    (sq_pos_of_pos (div_pos (Real.cos_pos_of_mem_Ioo hθ) (by norm_num))).ne'

theorem canonical_period_parameter_integral {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) (η : CanonicalCoefficients) :
    directional (canonicalPeriod p a b) η q=
      Real.sqrt 2*∫θ in -(Real.pi/2)..Real.pi/2,parameter (canonicalKernelA p a b) η (q,θ) := by
  have he := (canonical_period_action_germ h ha).symm.trans (canonical_action_partials_angular_germ h ha).1
  have hKA := fun θ (_ : θ∈Icc (-(Real.pi/2)) (Real.pi/2)) => (canonicalKernels_analytic h θ).1
  rw [directional,he.fderiv_eq,((analyticAt_fixedAngularIntegral hKA).differentiableAt.hasFDerivAt.const_mul
    (Real.sqrt 2)).fderiv]
  simp only [ContinuousLinearMap.smul_apply,smul_eq_mul]
  rw [fixedAngularIntegral_parameter η hKA]

theorem canonical_period_euler_identities {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    directional (canonicalPeriod p a b) q q= -canonicalPeriod p a b q/2 ∧
      directional (canonicalPeriod p a b) (canonicalDilation p q) q= -canonicalPeriod p a b q := by
  have he := (canonical_period_action_germ h ha).symm.trans (canonical_action_partials_angular_germ h ha).1
  have hvR := canonical_radial_turn_velocities h ha
  have hvD := canonical_dilation_turn_velocities h ha
  have hab : -(Real.pi/2)≤Real.pi/2 := by linarith [Real.pi_pos]
  constructor
  · rw [canonical_period_parameter_integral h ha q,he.self_of_nhds]
    have hi : (∫θ in -(Real.pi/2)..Real.pi/2,parameter (canonicalKernelA p a b) q (q,θ))=
        ∫θ in -(Real.pi/2)..Real.pi/2,-canonicalKernelA p a b (q,θ)/2 := by
      apply intervalIntegral_eq_of_eqOn_Ioo hab
      intro θ hθ
      rw [(canonical_kernel_parameter_formulas h q θ).1,hvR.1,hvR.2,
        canonical_factor_radial_parameter h ha θ hθ]
      dsimp only [canonicalKernelA]
      have hHp : 0<angularTurnFactor (canonicalGap p) a b (q,θ) := h.factor_pos _ (unitSinNode_mem θ)
      have hs : Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))≠0 := (Real.sqrt_pos.mpr hHp).ne'
      rw [show (0:ℝ)-0=0 by ring,zero_div,zero_sub]
      have hsq := Real.sq_sqrt hHp.le
      field_simp [hs]
      ring_nf
      have hs3 : Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))^3=
          Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))*angularTurnFactor (canonicalGap p) a b (q,θ) := by
        calc _=Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))*Real.sqrt (angularTurnFactor (canonicalGap p) a b (q,θ))^2 := by ring
             _=_ := by rw [hsq]
      rw [hs3]
      ring
    rw [hi,intervalIntegral.integral_div,intervalIntegral.integral_neg]
    ring
  · rw [canonical_period_parameter_integral h ha (canonicalDilation p q),he.self_of_nhds]
    have hi : (∫θ in -(Real.pi/2)..Real.pi/2,parameter (canonicalKernelA p a b) (canonicalDilation p q) (q,θ))=
        ∫θ in -(Real.pi/2)..Real.pi/2,-canonicalKernelA p a b (q,θ) := by
      apply intervalIntegral_eq_of_eqOn_Ioo hab
      intro θ hθ
      rw [(canonical_kernel_parameter_formulas h (canonicalDilation p q) θ).1,hvD.1,hvD.2,
        canonical_factor_dilation_parameter h ha θ hθ]
      dsimp only [canonicalKernelA]
      ring
    rw [hi,intervalIntegral.integral_neg]
    ring

end LeanVerification.UpperStripCompletion
