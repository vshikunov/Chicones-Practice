import LeanVerification.UpperStripCompletion.PhysicalForceFactor

/-! Exact polynomial normalization of the original-time force invariant. -/
noncomputable section
namespace LeanVerification.UpperStripCompletion
open Loud RegionalReal BoundaryAssembly
set_option maxHeartbeats 3000000

def upperJetG (d w : ℝ) : ℝ := (w-1)*(d*w+1)
def upperJetK (b d w : ℝ) : ℝ := d*w^2+b*(1-d)*w+1-2*b
def upperJetF (b d w : ℝ) : ℝ := b*(1-d)*w+2*(1-2*b)
def upperJetT (b d w : ℝ) : ℝ := b*(2-b)*(1-d)*w+2*(1-2*b)*(3-2*b)
def upperJetU (b d w : ℝ) : ℝ := b*(2-b)*(3-b)*(1-d)*w+4*(1-2*b)*(3-2*b)*(2-b)

theorem physical_upper_bracket_normalization (b d w : ℝ)
    (hb : 1-b≠0) (hd : 1+d≠0) :
    (w-1)*saddleFactor (-1/(1+d)) w=upperJetG d w/(1+d) ∧
    forceSlopeNumerator (-1/(1+d)) (1/(1-b)) w=upperJetK b d w/((1-b)*(1+d)) ∧
    forceSecondBracket (-1/(1+d)) (1/(1-b)) w= -upperJetF b d w/((1-b)*(1+d)) ∧
    forceThirdBracket (-1/(1+d)) (1/(1-b)) w=upperJetT b d w/((1-b)^2*(1+d)) ∧
    forceFourthBracket (-1/(1+d)) (1/(1-b)) w= -upperJetU b d w/((1-b)^3*(1+d)) := by
  refine ⟨?_,?_,?_,?_,?_⟩
  · unfold saddleFactor upperJetG
    field_simp [hb,hd] <;> ring
  · unfold forceSlopeNumerator upperJetK
    field_simp [hb,hd] <;> ring
  · unfold forceSecondBracket upperJetF
    field_simp [hb,hd] <;> ring
  · unfold forceThirdBracket upperJetT
    field_simp [hb,hd] <;> ring
  · unfold forceFourthBracket upperJetU
    field_simp [hb,hd] <;> ring

theorem force_normalization_fraction (m e G K f t u : ℝ) (hm : m≠0) (he : e≠0) :
    15*(-f/(m*e))*(K/(m*e))*(t/(m^2*e))-
      15*(G/e)*(-f/(m*e))*(-u/(m^3*e))+21*(G/e)*(t/(m^2*e))^2-
      25*(-f/(m*e))^3 =
      (-15*f*K*t-15*G*f*u+21*G*t^2+25*m*f^3)/(m^4*e^3) := by
  field_simp
  ring

theorem upper_jet_invariant_polynomial (b d w : ℝ) :
    -15*upperJetF b d w*upperJetK b d w*upperJetT b d w-
      15*upperJetG d w*upperJetF b d w*upperJetU b d w+
      21*upperJetG d w*(upperJetT b d w)^2+25*(1-b)*(upperJetF b d w)^3=
      2*upperForceQuartic b d w := by
  unfold upperJetG upperJetK upperJetF upperJetT upperJetU upperForceQuartic
    upperA0 upperA1 upperA2 upperA3 upperA4 upperTPolynomial upperBPolynomial
  ring

theorem physical_force_polynomial_normalized (b d w : ℝ)
    (hb : 1-b≠0) (hd : 1+d≠0) :
    physicalForceInvariantNumerator (-1/(1+d)) (1/(1-b)) w=
      2/((1+d)^3*(1-b)^4)*upperForceQuartic b d w := by
  have hj := physical_upper_bracket_normalization b d w hb hd
  unfold physicalForceInvariantNumerator
  rw [hj.1,hj.2.1,hj.2.2.1,hj.2.2.2.1,hj.2.2.2.2,
    force_normalization_fraction _ _ _ _ _ _ _ hb hd,upper_jet_invariant_polynomial]
  ring

end LeanVerification.UpperStripCompletion
