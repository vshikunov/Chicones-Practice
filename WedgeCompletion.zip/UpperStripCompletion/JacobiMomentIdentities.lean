import LeanVerification.UpperStripCompletion.ActualJacobiCurvature
import LeanVerification.UpperStripCompletion.WeightedMomentComparison

/-! All finite-interval Jacobi--Stein moment identities, with absolute
integrability and both turning boundary terms discharged. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical GeneralMechanical.EnergyModes
set_option maxHeartbeats 2200000

def jacobiThirdDensity (W Y : ℝ → ℝ) (L x : ℝ) : ℝ :=
  deriv (deriv (deriv W)) x*Y x^3/Real.sqrt (L-W x)

def jacobiThirdBoundary (W Y : ℝ → ℝ) (L x : ℝ) : ℝ :=
  Real.sqrt (L-W x)*Y x^2*deriv (deriv Y) x

theorem jacobi_third_boundary_algebra {v s g f y y₁ y₂ y₃ : ℝ}
    (hv : v≠0) (hs : s≠0) (hs2 : s^2=v)
    (h₁ : 2*v*y₁+g*y=1) (h₃ : 2*v*y₃-3*g*y₂+f*y=0) :
    -g/(2*s)*y^2*y₂+s*(2*y*y₁*y₂+y^2*y₃)=y*y₂/s-(f*y^3/s)/2 := by
  have hy₁ : y₁=(1-g*y)/(2*v) := by
    apply (eq_div_iff (mul_ne_zero (by norm_num) hv)).2
    nlinarith only [h₁]
  have hy₃ : y₃=(3*g*y₂-f*y)/(2*v) := by
    apply (eq_div_iff (mul_ne_zero (by norm_num) hv)).2
    nlinarith only [h₃]
  rw [hy₁,hy₃]
  field_simp [hv,hs]
  ring_nf
  have hs4 : s^4=v^2 := by
    calc s^4=(s^2)^2 := by ring
         _=v^2 := by rw [hs2]
  simp only [hs2,hs4]
  ring

theorem hasDerivAt_jacobiThirdBoundary {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1)
    (hv : 0<L-W x) :
    HasDerivAt (jacobiThirdBoundary W Y L)
      (jacobiSecondDensity W Y L x-jacobiThirdDensity W Y L x/2) x := by
  have ds := (hW.differentiableAt.hasDerivAt.const_sub L).sqrt hv.ne'
  have hd := ((ds.mul (hY.differentiableAt.hasDerivAt.pow 2)).mul
    hY.deriv.deriv.differentiableAt.hasDerivAt)
  have hh := jacobi_third_boundary_algebra hv.ne' (Real.sqrt_pos.2 hv).ne'
    (Real.sq_sqrt hv.le) he.self_of_nhds (jacobi_third_at hW hY he)
  convert hd using 1
  convert hh.symm using 1 <;> ring

theorem jacobi_moment_integral_balance {W a b Y : ℝ → ℝ} {L : ℝ}
    (h : RegularEnergyWell W a b L) (hY : AnalyticOnNhd ℝ Y (Icc (a L) (b L)))
    (he : ∀ x ∈ Ioo (a L) (b L), 2*(L-W x)*deriv Y x+deriv W x*Y x=1) :
    IntervalIntegrable (jacobiSecondDensity W Y L) volume (a L) (b L) ∧
    IntervalIntegrable (jacobiThirdDensity W Y L) volume (a L) (b L) ∧
    (∫ x in a L..b L, jacobiThirdDensity W Y L x)=
      2*∫ x in a L..b L, jacobiSecondDensity W Y L x := by
  have hAi : IntervalIntegrable (jacobiSecondDensity W Y L) volume (a L) (b L) :=
    regular_energy_weighted_kernel_integrable h (hY.continuousOn.mul
      (fun x hx => (hY x hx).deriv.deriv.continuousAt.continuousWithinAt))
  have hfc : ContinuousOn (deriv (deriv (deriv W))) (Icc (a L) (b L)) :=
    fun x hx => (h.analytic_potential x hx).deriv.deriv.deriv.continuousAt.continuousWithinAt
  have hCi : IntervalIntegrable (jacobiThirdDensity W Y L) volume (a L) (b L) :=
    regular_energy_weighted_kernel_integrable h (hfc.mul (hY.continuousOn.pow 3))
  have hRc : ContinuousOn (jacobiThirdBoundary W Y L) (Icc (a L) (b L)) := by
    intro x hx
    exact (((Real.continuous_sqrt.continuousAt.comp
      (continuousAt_const.sub (h.analytic_potential x hx).continuousAt)).mul
        ((hY x hx).continuousAt.pow 2)).mul
          (hY x hx).deriv.deriv.continuousAt).continuousWithinAt
  have heg := jacobi_equation_closed_germ h.turns_ordered h.analytic_potential hY he
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le h.turns_ordered.le hRc
    (fun x hx => hasDerivAt_jacobiThirdBoundary (h.analytic_potential x (Ioo_subset_Icc_self hx))
      (hY x (Ioo_subset_Icc_self hx)) (heg x (Ioo_subset_Icc_self hx)) (h.positive_gap x hx))
    (hAi.sub (hCi.div_const 2))
  rw [intervalIntegral.integral_sub hAi (hCi.div_const 2),intervalIntegral.integral_div] at hFTC
  have hRa : jacobiThirdBoundary W Y L (a L)=0 := by
    simp only [jacobiThirdBoundary,h.root_left.self_of_nhds,Real.sqrt_zero,zero_mul]
  have hRb : jacobiThirdBoundary W Y L (b L)=0 := by
    simp only [jacobiThirdBoundary,h.root_right.self_of_nhds,Real.sqrt_zero,zero_mul]
  rw [hRa,hRb,sub_self] at hFTC
  exact ⟨hAi,hCi,by linarith only [hFTC]⟩

theorem jacobi_comparison_density_algebra {v s f y y₂ : ℝ}
    (hv : v≠0) (hs : s≠0) (hf : f≠0) (hs2 : s^2=v) :
    (-f*s/2)*y*((y₂/f-y^2/3)/v)=-(y*y₂/s)/2+(f*y^3/s)/6 := by
  field_simp [hv,hs,hf]
  ring_nf
  have hs3 : s^3=s*v := by
    calc s^3=s*s^2 := by ring
         _=s*v := by rw [hs2]
  rw [hs3]
  ring

theorem jacobi_comparison_integral_identity {W a b Y : ℝ → ℝ} {L : ℝ}
    (h : RegularEnergyWell W a b L) (hY : AnalyticOnNhd ℝ Y (Icc (a L) (b L)))
    (he : ∀ x ∈ Ioo (a L) (b L), 2*(L-W x)*deriv Y x+deriv W x*Y x=1)
    (hf : ∀ x ∈ Icc (a L) (b L), deriv (deriv (deriv W)) x≠0) :
    IntervalIntegrable (fun x => jacobiWeight W L x*Y x*jacobiB W Y L (a L) (b L) x)
      volume (a L) (b L) ∧
    (∫ x in a L..b L, jacobiWeight W L x*Y x*jacobiB W Y L (a L) (b L) x)=
      -(∫ x in a L..b L, jacobiSecondDensity W Y L x)/6 := by
  obtain ⟨hAi,hCi,hCA⟩ := jacobi_moment_integral_balance h hY he
  have hBa := analyticOnNhd_jacobiB h.turns_ordered h.analytic_potential hY he
    (sub_eq_zero.mp h.root_left.self_of_nhds).symm (sub_eq_zero.mp h.root_right.self_of_nhds).symm
    h.force_left.ne h.force_right.ne' (fun x hx => (h.positive_gap x hx).ne') hf
  have hρc : ContinuousOn (jacobiWeight W L) (Icc (a L) (b L)) :=
    fun x hx => (continuousAt_jacobiWeight (h.analytic_potential x hx)).continuousWithinAt
  have hBi : IntervalIntegrable
      (fun x => jacobiWeight W L x*Y x*jacobiB W Y L (a L) (b L) x) volume (a L) (b L) :=
    ((hρc.mul hY.continuousOn).mul hBa.continuousOn).intervalIntegrable_of_Icc h.turns_ordered.le
  refine ⟨hBi,?_⟩
  calc
    (∫ x in a L..b L, jacobiWeight W L x*Y x*jacobiB W Y L (a L) (b L) x)=
        ∫ x in a L..b L, -jacobiSecondDensity W Y L x/2+jacobiThirdDensity W Y L x/6 := by
      apply intervalIntegral_eq_of_eqOn_Ioo h.turns_ordered.le
      intro x hx
      dsimp only [jacobiB]
      rw [endpointQuotient_eq_interior hx]
      exact jacobi_comparison_density_algebra (h.positive_gap x hx).ne'
        (Real.sqrt_pos.2 (h.positive_gap x hx)).ne' (hf x (Ioo_subset_Icc_self hx))
        (Real.sq_sqrt (h.positive_gap x hx).le)
    _=-(∫ x in a L..b L, jacobiSecondDensity W Y L x)/2+
        (∫ x in a L..b L, jacobiThirdDensity W Y L x)/6 := by
      have hAh : IntervalIntegrable (fun x => -jacobiSecondDensity W Y L x/2)
          volume (a L) (b L) := hAi.neg.div_const 2
      rw [intervalIntegral.integral_add hAh (hCi.div_const 6),
        intervalIntegral.integral_div,intervalIntegral.integral_neg,
        intervalIntegral.integral_div]
    _=_ := by rw [hCA]; ring

end LeanVerification.UpperStripCompletion
