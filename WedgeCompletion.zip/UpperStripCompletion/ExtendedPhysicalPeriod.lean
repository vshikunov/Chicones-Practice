import LeanVerification.Sharpness.PeriodTaylorRemainder
import LeanVerification.Loud.CompactAnalyticIntegral

/-! One actual physical period function analytic both through the center
and throughout every positive admissible annulus. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open Loud GeneralMechanical Sharpness
set_option maxHeartbeats 1800000

def extendedPhysicalPeriod (q : PeriodParameterSpace) : ℝ := by
  classical
  exact if q∈jointCenterDomain then jointCenterPeriod q else periodQuadrature q.1.1 q.1.2 q.2

theorem extendedPhysicalPeriod_center_germ {q : PeriodParameterSpace} (hq : q∈jointCenterDomain) :
    extendedPhysicalPeriod =ᶠ[𝓝 q] jointCenterPeriod := by
  filter_upwards [isOpen_jointCenterDomain.mem_nhds hq] with r hr
  simp only [extendedPhysicalPeriod,if_pos hr]

theorem extendedPhysicalPeriod_eq_physical {q : PeriodParameterSpace}
    (hq : AdmissibleEnergy q.1.1 q.1.2 q.2) :
    extendedPhysicalPeriod q=periodQuadrature q.1.1 q.1.2 q.2 := by
  by_cases hc : q∈jointCenterDomain
  · rw [extendedPhysicalPeriod,if_pos hc]
    exact (jointCenterPeriod_eq_periodQuadrature hc hq.1).2
  · exact if_neg hc

theorem extendedPhysicalPeriod_physical_germ {q : PeriodParameterSpace}
    (hq : AdmissibleEnergy q.1.1 q.1.2 q.2) :
    extendedPhysicalPeriod =ᶠ[𝓝 q] (fun r => periodQuadrature r.1.1 r.1.2 r.2) := by
  filter_upwards [isOpen_admissibleEnergy_joint.mem_nhds hq] with r hr
  exact extendedPhysicalPeriod_eq_physical hr

theorem analyticAt_extendedPhysicalPeriod {q : PeriodParameterSpace}
    (hq : q∈jointCenterDomain ∨ AdmissibleEnergy q.1.1 q.1.2 q.2) :
    AnalyticAt ℝ extendedPhysicalPeriod q := by
  rcases hq with hc|hp
  · exact (analyticOnNhd_jointCenterPeriod q hc).congr (extendedPhysicalPeriod_center_germ hc).symm
  · exact (analyticAt_periodQuadrature_joint q.1.1 q.1.2 q.2 hp).congr
      (extendedPhysicalPeriod_physical_germ hp).symm

def extendedPhysicalSlope : PeriodParameterSpace→ℝ := verticalDerivative extendedPhysicalPeriod

theorem extendedPhysicalSlope_eq_physical {q : PeriodParameterSpace}
    (hq : AdmissibleEnergy q.1.1 q.1.2 q.2) :
    extendedPhysicalSlope q=deriv (periodQuadrature q.1.1 q.1.2) q.2 := by
  rw [extendedPhysicalSlope,verticalDerivative_eq_deriv (analyticAt_extendedPhysicalPeriod (Or.inr hq))]
  have he : (fun h => extendedPhysicalPeriod (q.1,h)) =ᶠ[𝓝 q.2] periodQuadrature q.1.1 q.1.2 :=
    (continuousAt_const.prodMk continuousAt_id).eventually (extendedPhysicalPeriod_physical_germ hq)
  exact he.deriv_eq

theorem extendedPhysicalPeriod_center_value (D F : ℝ) :
    extendedPhysicalPeriod ((D,F),0)=2*Real.pi := by
  rw [(extendedPhysicalPeriod_center_germ (jointCenterDomain_contains_center D F)).self_of_nhds,
    jointCenterPeriod_zero]

theorem extendedPhysicalSlope_center_value (D F : ℝ) :
    extendedPhysicalSlope ((D,F),0)=2*Real.pi*periodCoefficient D F 1 := by
  have hc := jointCenterDomain_contains_center D F
  rw [extendedPhysicalSlope,verticalDerivative_eq_deriv (analyticAt_extendedPhysicalPeriod (Or.inl hc))]
  have he : (fun h => extendedPhysicalPeriod ((D,F),h)) =ᶠ[𝓝 0] centerPeriod D F :=
    (continuousAt_const.prodMk continuousAt_id).eventually (extendedPhysicalPeriod_center_germ hc)
  rw [he.deriv_eq]
  unfold periodCoefficient
  norm_num [iteratedDeriv_succ,iteratedDeriv_zero,Nat.factorial]
  field_simp [Real.pi_ne_zero]

/-- The slope is the derivative of the chosen signed-energy fiber on a
neighborhood of each center. -/
theorem extendedPhysicalSlope_center_fiber_germ (D F : ℝ) :
    (fun h => extendedPhysicalSlope ((D,F),h)) =ᶠ[𝓝 (0:ℝ)] deriv (centerPeriod D F) := by
  have hg : ∀ᶠ h in 𝓝 (0:ℝ),((D,F),h)∈jointCenterDomain :=
    (continuousAt_const.prodMk continuousAt_id).eventually
      (isOpen_jointCenterDomain.mem_nhds (jointCenterDomain_contains_center D F))
  filter_upwards [hg] with h hh
  rw [extendedPhysicalSlope,verticalDerivative_eq_deriv (analyticAt_extendedPhysicalPeriod (Or.inl hh))]
  have he : (fun k => extendedPhysicalPeriod ((D,F),k)) =ᶠ[𝓝 h] centerPeriod D F :=
    (continuousAt_const.prodMk continuousAt_id).eventually (extendedPhysicalPeriod_center_germ hh)
  exact he.deriv_eq

theorem extendedPhysicalSlope_center_derivative (D F : ℝ) :
    deriv (fun h => extendedPhysicalSlope ((D,F),h)) 0=4*Real.pi*periodCoefficient D F 2 := by
  rw [(extendedPhysicalSlope_center_fiber_germ D F).deriv_eq]
  unfold periodCoefficient
  norm_num [iteratedDeriv_succ,iteratedDeriv_zero,Nat.factorial]
  field_simp [Real.pi_ne_zero]
  ring

end LeanVerification.UpperStripCompletion
