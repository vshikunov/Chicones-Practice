import LeanVerification.UpperStripCompletion.CanonicalEulerJets

/-! Rational change from the canonical coefficient directions to the
physical upper-strip energy and mixture directions. -/
noncomputable section
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 4000000

def upperCanonicalPoint (b d δ : ℝ) : CanonicalCoefficients :=
  ((1/(2*b),(1-d)/(1+b)),(d/2,δ))
def upperXDirection (δ : ℝ) : CanonicalCoefficients := ((0,0),(0,-δ))
def upperDDirection (b d δ : ℝ) : CanonicalCoefficients :=
  ((0,-1/(1+b)),(1/2,δ*b/(1+b*d)))
def upperTransportV (b d : ℝ) : ℝ :=
  (1-b)*d*(b+d)*(1+b*d)/(b*(1+b)*(1+d)^2)
def upperTransportA (b d : ℝ) : ℝ :=
  (1-b)*(3*b^2*d^2+5*b^2*d+5*b*d^3+7*b*d^2+b*d+3*b+3*d^2+5*d)/
    (2*b*(1+b)*(1+d)^3)
def upperTransportC (b d : ℝ) : ℝ :=
  (1-b)*(b^2+b*d^2+2*b*d-b+1)/(2*b*(1+b)*(1+d)^3)
def upperTransportK (b d : ℝ) : ℝ := 2*b*(1+b)/((1-b)*(1+b*d))
def upperTransportZeta (b d : ℝ) : ℝ := b/(1+b*d)
def upperTransportGamma (b d : ℝ) : ℝ :=
  (1-b)*(2-5*b+2*b^2-(3-4*b+3*b^2)*d-b*d^2)/(4*b*(1+b)*(1+d)^4)
def upperTransportC1 (b d : ℝ) : ℝ :=
  (1-b)*(b^2*d^2+5*b^2*d+3*b*d^3+7*b*d^2-b*d+3*b+d^2+5*d)/
    (2*b*(1+b)*(1+d)^3)

theorem upper_canonical_direction_basis (b d δ : ℝ)
    (hb : b≠0) (hm : 1-b≠0) (hp : 1+b≠0) (hd : 1+d≠0) (hbd : 1+b*d≠0) :
    canonicalA=(2*b) • upperCanonicalPoint b d δ+
      (-2*b/(1+d)) • canonicalDilation (2*b/(1-b)) (upperCanonicalPoint b d δ)+
      (2*b*d*(1-d)/(1+d)) • upperDDirection b d δ+
      upperTransportK b d • upperXDirection δ ∧
    canonicalB=((1+b)/(1+d)) • canonicalDilation (2*b/(1-b)) (upperCanonicalPoint b d δ)+
      (-2*d*(1+b)/(1+d)) • upperDDirection b d δ+
      (-upperTransportK b d) • upperXDirection δ ∧
    canonicalC=(2/(1+d)) • canonicalDilation (2*b/(1-b)) (upperCanonicalPoint b d δ)+
      (2*(1-d)/(1+d)) • upperDDirection b d δ+
      (-upperTransportK b d) • upperXDirection δ := by
  constructor
  · ext <;> simp only [canonicalA,upperCanonicalPoint,canonicalDilation,upperDDirection,
      upperXDirection,upperTransportK,Prod.fst_add,Prod.snd_add,Prod.smul_fst,Prod.smul_snd,
      smul_eq_mul] <;> field_simp [hb,hm,hp,hd,hbd] <;> ring
  constructor
  · ext <;> simp only [canonicalB,upperCanonicalPoint,canonicalDilation,upperDDirection,
      upperXDirection,upperTransportK,Prod.fst_add,Prod.snd_add,Prod.smul_fst,Prod.smul_snd,
      smul_eq_mul] <;> field_simp [hb,hm,hp,hd,hbd] <;> ring
  · ext <;> simp only [canonicalC,upperCanonicalPoint,canonicalDilation,upperDDirection,
      upperXDirection,upperTransportK,Prod.fst_add,Prod.snd_add,Prod.smul_fst,Prod.smul_snd,
      smul_eq_mul] <;> field_simp [hb,hm,hp,hd,hbd] <;> ring

theorem upper_dilation_direction_basis (b d δ : ℝ)
    (hm : 1-b≠0) (hp : 1+b≠0) (hd : 1+d≠0) (hbd : 1+b*d≠0) :
    canonicalDilation (2*b/(1-b)) (upperDDirection b d δ)=
      (1/(1+d)) • canonicalDilation (2*b/(1-b)) (upperCanonicalPoint b d δ)+
      (2/(1+d)) • upperDDirection b d δ ∧
    canonicalDilation (2*b/(1-b)) (upperXDirection δ)=
      (-2*b/(1-b)) • upperXDirection δ ∧
    canonicalDilation (2*b/(1-b))
        (canonicalDilation (2*b/(1-b)) (upperCanonicalPoint b d δ))=
      ((3*d+1)/(1+d)) • canonicalDilation (2*b/(1-b)) (upperCanonicalPoint b d δ)+
      (2*d*(1-d)/(1+d)) • upperDDirection b d δ+
      (-(1+d)/(1-b)*upperTransportK b d) • upperXDirection δ := by
  constructor
  · ext <;> simp only [upperCanonicalPoint,canonicalDilation,upperDDirection,
      upperXDirection,Prod.fst_add,Prod.snd_add,Prod.smul_fst,Prod.smul_snd,
      smul_eq_mul] <;> field_simp [hm,hp,hd,hbd] <;> ring
  constructor
  · ext <;> simp only [upperCanonicalPoint,canonicalDilation,upperDDirection,
      upperXDirection,Prod.fst_add,Prod.snd_add,Prod.smul_fst,Prod.smul_snd,
      smul_eq_mul] <;> field_simp [hm,hp,hd,hbd] <;> ring
  · ext <;> simp only [upperCanonicalPoint,canonicalDilation,upperDDirection,
      upperXDirection,upperTransportK,Prod.fst_add,Prod.snd_add,Prod.smul_fst,Prod.smul_snd,
      smul_eq_mul] <;> field_simp [hm,hp,hd,hbd] <;> ring

theorem upper_transport_quadratic_reduce (b d k Hzz Hzd HzX Hdd HdX HXX Hqz Hqd HqX : ℝ)
    (hd : 1+d≠0) :
    ((1+b)/(1+d))^2*Hzz+2*((1+b)/(1+d))*(-2*d*(1+b)/(1+d))*Hzd+
      2*((1+b)/(1+d))*(-k)*HzX+(-2*d*(1+b)/(1+d))^2*Hdd+
      2*(-2*d*(1+b)/(1+d))*(-k)*HdX+(-k)^2*HXX+
    (2*b)*(2/(1+d)*Hqz+2*(1-d)/(1+d)*Hqd+(-k)*HqX)+
    (-2*b/(1+d))*(2/(1+d)*Hzz+2*(1-d)/(1+d)*Hzd+(-k)*HzX)+
    (2*b*d*(1-d)/(1+d))*(2/(1+d)*Hzd+2*(1-d)/(1+d)*Hdd+(-k)*HdX)+
    k*(2/(1+d)*HzX+2*(1-d)/(1+d)*HdX+(-k)*HXX)=
    (1-b)^2/(1+d)^2*Hzz-4*(b+d)*(1+b*d)/(1+d)^2*Hzd+
      4*d*(b+d)*(1+b*d)/(1+d)^2*Hdd+2*k*(1+b*d)*HdX+
      4*b/(1+d)*Hqz+4*b*(1-d)/(1+d)*Hqd-2*b*k*HqX := by
  field_simp [hd]
  ring

theorem upper_transport_jet_certificate (b d T Td TX Hdd HdX HXX : ℝ)
    (hb : b≠0) (hm : 1-b≠0) (hp : 1+b≠0) (hd : 1+d≠0) (hbd : 1+b*d≠0) :
    let k := upperTransportK b d
    let Hzz := (1+(3*d+1)/(1+d))*T-2*d*(1-d)/(1+d)*Td+(1+d)/(1-b)*k*TX
    let Hzd := T/(1+d)-(1+2/(1+d))*Td
    let HzX := -(1-2*b/(1-b))*TX
    ((1+b)/(1+d))^2*Hzz+2*((1+b)/(1+d))*(-2*d*(1+b)/(1+d))*Hzd+
      2*((1+b)/(1+d))*(-k)*HzX+(-2*d*(1+b)/(1+d))^2*Hdd+
      2*(-2*d*(1+b)/(1+d))*(-k)*HdX+(-k)^2*HXX+
    (2*b)*(2/(1+d)*(3/2*T)+2*(1-d)/(1+d)*(-(3/2)*Td)+(-k)*(-(3/2)*TX))+
    (-2*b/(1+d))*(2/(1+d)*Hzz+2*(1-d)/(1+d)*Hzd+(-k)*HzX)+
    (2*b*d*(1-d)/(1+d))*(2/(1+d)*Hzd+2*(1-d)/(1+d)*Hdd+(-k)*HdX)+
    k*(2/(1+d)*HzX+2*(1-d)/(1+d)*HdX+(-k)*HXX)=
    (4*b*(1+b)/(1-b))*(HdX+upperTransportV b d*Hdd+upperTransportA b d*Td+
      (1/(2*(1+d))+upperTransportZeta b d)*TX+upperTransportC b d*T) := by
  dsimp only
  rw [upper_transport_quadratic_reduce b d (upperTransportK b d) _ _ _ _ _ _ _ _ _ hd]
  let S := 4*b*(1+b)/(1-b)
  have hT : (1-b)^2/(1+d)^2*(1+(3*d+1)/(1+d))-
      4*(b+d)*(1+b*d)/(1+d)^2/(1+d)+6*b/(1+d)=S*upperTransportC b d := by
    unfold S upperTransportC
    field_simp [hb,hm,hp,hd]
    ring
  have hD : -(1-b)^2/(1+d)^2*(2*d*(1-d)/(1+d))+
      4*(b+d)*(1+b*d)/(1+d)^2*(1+2/(1+d))-6*b*(1-d)/(1+d)=S*upperTransportA b d := by
    unfold S upperTransportA
    field_simp [hb,hm,hp,hd]
    ring
  have hX : (1-b)^2/(1+d)^2*((1+d)/(1-b)*upperTransportK b d)+
      3*b*upperTransportK b d=S*(1/(2*(1+d))+upperTransportZeta b d) := by
    unfold S upperTransportK upperTransportZeta
    field_simp [hb,hm,hp,hd,hbd]
    ring
  have hDD : 4*d*(b+d)*(1+b*d)/(1+d)^2=S*upperTransportV b d := by
    unfold S upperTransportV
    field_simp [hb,hm,hp,hd]
    ring
  have hDX : 2*upperTransportK b d*(1+b*d)=S := by
    unfold S upperTransportK
    field_simp [hm,hbd]
    ring
  linear_combination T*hT+Td*hD+TX*hX+Hdd*hDD+HdX*hDX

theorem upper_transport_gauge_coefficients (b d : ℝ)
    (hb : b≠0) (hp : 1+b≠0) (hd : 1+d≠0) :
    upperTransportA b d-upperTransportV b d/(1+d)=upperTransportC1 b d ∧
    3*upperTransportV b d/(4*(1+d)^2)-upperTransportA b d/(2*(1+d))+
      upperTransportC b d=upperTransportGamma b d := by
  constructor <;> dsimp only [upperTransportA,upperTransportV,upperTransportC,upperTransportGamma,upperTransportC1] <;>
    field_simp [hb,hp,hd] <;> ring

end LeanVerification.UpperStripCompletion
