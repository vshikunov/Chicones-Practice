import LeanVerification.CriticalEnergy
import LeanVerification.PairedCompletion.FluxOrder

/-! Differential consequences of the actual regular energy variation.
The equations below are differentiated from the first Jacobi equation;
none of the higher equations or turning jets is an additional assumption
in the eventual physical application. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
set_option maxHeartbeats 1600000

theorem jacobi_second_at {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1) :
    2*(L-W x)*deriv (deriv Y) x-deriv W x*deriv Y x+
      deriv (deriv W) x*Y x=0 := by
  have hd := (((hW.differentiableAt.hasDerivAt.const_sub L).const_mul 2).mul
    hY.deriv.differentiableAt.hasDerivAt).add
      (hW.deriv.differentiableAt.hasDerivAt.mul hY.differentiableAt.hasDerivAt)
  have hz := (hd.congr_of_eventuallyEq (he.mono fun _ h => h.symm)).unique (hasDerivAt_const x (1 : ℝ))
  nlinarith only [hz]

theorem jacobi_second_germ {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1) :
    ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv (deriv Y) z-deriv W z*deriv Y z+
      deriv (deriv W) z*Y z=0 := by
  filter_upwards [hW.eventually_analyticAt,hY.eventually_analyticAt,
    eventually_eventually_nhds.mpr he] with z hzW hzY hze
  exact jacobi_second_at hzW hzY hze

theorem jacobi_third_at {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1) :
    2*(L-W x)*deriv (deriv (deriv Y)) x-
      3*deriv W x*deriv (deriv Y) x+deriv (deriv (deriv W)) x*Y x=0 := by
  have h2 := jacobi_second_germ hW hY he
  have hd := ((((hW.differentiableAt.hasDerivAt.const_sub L).const_mul 2).mul
    hY.deriv.deriv.differentiableAt.hasDerivAt).sub
      (hW.deriv.differentiableAt.hasDerivAt.mul hY.deriv.differentiableAt.hasDerivAt)).add
        (hW.deriv.deriv.differentiableAt.hasDerivAt.mul hY.differentiableAt.hasDerivAt)
  have hz := (hd.congr_of_eventuallyEq (h2.mono fun _ h => h.symm)).unique (hasDerivAt_const x (0 : ℝ))
  nlinarith only [hz]

theorem jacobi_third_germ {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1) :
    ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv (deriv (deriv Y)) z-
      3*deriv W z*deriv (deriv Y) z+deriv (deriv (deriv W)) z*Y z=0 := by
  filter_upwards [hW.eventually_analyticAt,hY.eventually_analyticAt,
    eventually_eventually_nhds.mpr he] with z hzW hzY hze
  exact jacobi_third_at hzW hzY hze

theorem jacobi_fourth_at {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1) :
    2*(L-W x)*deriv (deriv (deriv (deriv Y))) x-
      5*deriv W x*deriv (deriv (deriv Y)) x-
      3*deriv (deriv W) x*deriv (deriv Y) x+
      deriv (deriv (deriv (deriv W))) x*Y x+
      deriv (deriv (deriv W)) x*deriv Y x=0 := by
  have h3 := jacobi_third_germ hW hY he
  have hd := ((((hW.differentiableAt.hasDerivAt.const_sub L).const_mul 2).mul
    hY.deriv.deriv.deriv.differentiableAt.hasDerivAt).sub
      ((hW.deriv.differentiableAt.hasDerivAt.const_mul 3).mul
        hY.deriv.deriv.differentiableAt.hasDerivAt)).add
          (hW.deriv.deriv.deriv.differentiableAt.hasDerivAt.mul hY.differentiableAt.hasDerivAt)
  have hz := (hd.congr_of_eventuallyEq (h3.mono fun _ h => h.symm)).unique (hasDerivAt_const x (0 : ℝ))
  nlinarith only [hz]

theorem jacobi_fourth_germ {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1) :
    ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv (deriv (deriv (deriv Y))) z-
      5*deriv W z*deriv (deriv (deriv Y)) z-
      3*deriv (deriv W) z*deriv (deriv Y) z+
      deriv (deriv (deriv (deriv W))) z*Y z+
      deriv (deriv (deriv W)) z*deriv Y z=0 := by
  filter_upwards [hW.eventually_analyticAt,hY.eventually_analyticAt,
    eventually_eventually_nhds.mpr he] with z hzW hzY hze
  exact jacobi_fourth_at hzW hzY hze

theorem jacobi_fifth_at {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1) :
    2*(L-W x)*deriv (deriv (deriv (deriv (deriv Y)))) x-
      7*deriv W x*deriv (deriv (deriv (deriv Y))) x-
      8*deriv (deriv W) x*deriv (deriv (deriv Y)) x-
      2*deriv (deriv (deriv W)) x*deriv (deriv Y) x+
      deriv (deriv (deriv (deriv (deriv W)))) x*Y x+
      2*deriv (deriv (deriv (deriv W))) x*deriv Y x=0 := by
  have h4 := jacobi_fourth_germ hW hY he
  have hd := ((((((hW.differentiableAt.hasDerivAt.const_sub L).const_mul 2).mul
    hY.deriv.deriv.deriv.deriv.differentiableAt.hasDerivAt).sub
      ((hW.deriv.differentiableAt.hasDerivAt.const_mul 5).mul
        hY.deriv.deriv.deriv.differentiableAt.hasDerivAt)).sub
          ((hW.deriv.deriv.differentiableAt.hasDerivAt.const_mul 3).mul
            hY.deriv.deriv.differentiableAt.hasDerivAt)).add
              (hW.deriv.deriv.deriv.deriv.differentiableAt.hasDerivAt.mul
                hY.differentiableAt.hasDerivAt)).add
                  (hW.deriv.deriv.deriv.differentiableAt.hasDerivAt.mul
                    hY.deriv.differentiableAt.hasDerivAt)
  have hz := (hd.congr_of_eventuallyEq (h4.mono fun _ h => h.symm)).unique (hasDerivAt_const x (0 : ℝ))
  nlinarith only [hz]

theorem jacobi_turn_jets {W Y : ℝ → ℝ} {L x : ℝ}
    (hW : AnalyticAt ℝ W x) (hY : AnalyticAt ℝ Y x)
    (he : ∀ᶠ z in 𝓝 x, 2*(L-W z)*deriv Y z+deriv W z*Y z=1)
    (hv : L-W x=0) (hg : deriv W x≠0) :
    Y x=1/deriv W x ∧
    deriv Y x=deriv (deriv W) x/deriv W x^2 ∧
    deriv (deriv Y) x=deriv (deriv (deriv W)) x/(3*deriv W x^2) ∧
    deriv (deriv (deriv Y)) x=deriv (deriv (deriv (deriv W))) x/(5*deriv W x^2) ∧
    deriv (deriv (deriv (deriv Y))) x=
      (deriv W x*deriv (deriv (deriv (deriv (deriv W)))) x+
        (2/5:ℝ)*deriv (deriv W) x*deriv (deriv (deriv (deriv W))) x-
        (2/3:ℝ)*deriv (deriv (deriv W)) x^2)/(7*deriv W x^3) := by
  have h1 := he.self_of_nhds
  have h2 := jacobi_second_at hW hY he
  have h3 := jacobi_third_at hW hY he
  have h4 := jacobi_fourth_at hW hY he
  have h5 := jacobi_fifth_at hW hY he
  have hY0 := CriticalMode.variation_value_at_turn hv hg h1
  have hY1 := CriticalMode.variation_derivative_at_turn hv hg h1 h2
  have hY2 : deriv (deriv Y) x=deriv (deriv (deriv W)) x/(3*deriv W x^2) := by
    rw [hv,hY0] at h3
    field_simp [hg] at h3 ⊢
    nlinarith only [h3]
  have hY3 : deriv (deriv (deriv Y)) x=deriv (deriv (deriv (deriv W))) x/(5*deriv W x^2) := by
    rw [hv,hY0,hY1,hY2] at h4
    ring_nf at h4
    field_simp [hg] at h4 ⊢
    nlinarith only [h4]
  refine ⟨hY0,hY1,hY2,hY3,?_⟩
  rw [hv,hY0,hY1,hY2,hY3] at h5
  ring_nf at h5
  field_simp [hg] at h5 ⊢
  have hh : deriv W x^3 *
      (-105*deriv W x^3*deriv (deriv (deriv (deriv Y))) x+
        15*deriv W x*deriv (deriv (deriv (deriv (deriv W)))) x+
        6*deriv (deriv W) x*deriv (deriv (deriv (deriv W))) x-
        10*deriv (deriv (deriv W)) x^2)=0 := by
    nlinarith only [h5]
  have hz := (mul_eq_zero.mp hh).resolve_left (pow_ne_zero 3 hg)
  nlinarith only [hz]

end LeanVerification.UpperStripCompletion
