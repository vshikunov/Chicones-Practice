import LeanVerification.UpperStripCompletion.CanonicalHessianKernel

/-! The complete-action Hessian equation and its actual period consequence.
Both moving turns are accounted for by an analytic endpoint-zero primitive. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology ContDiff
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical DirectionalPartials InteriorCompletion
set_option maxHeartbeats 3600000

theorem canonical_action_partials_angular_germ {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    (directional (completeTurnAction (canonicalGap p) a b) canonicalA =ᶠ[𝓝 q]
      fun r => Real.sqrt 2*∫θ in -(Real.pi/2)..Real.pi/2,canonicalKernelA p a b (r,θ)) ∧
    (directional (completeTurnAction (canonicalGap p) a b) canonicalB =ᶠ[𝓝 q]
      fun r => Real.sqrt 2*∫θ in -(Real.pi/2)..Real.pi/2,canonicalKernelB p a b (r,θ)) := by
  have hg := (regularTwoTurnFamily_eventually h).and
    (h.analytic_left.continuousAt.eventually (Ioi_mem_nhds ha))
  exact ⟨hg.mono (fun r hr => (canonical_action_partials_angular hr.1 hr.2).1),
    hg.mono (fun r hr => (canonical_action_partials_angular hr.1 hr.2).2)⟩

theorem canonical_action_second_partials {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    directional (directional (completeTurnAction (canonicalGap p) a b) canonicalB) canonicalB q=
      Real.sqrt 2*∫θ in -(Real.pi/2)..Real.pi/2,parameter (canonicalKernelB p a b) canonicalB (q,θ) ∧
    directional (directional (completeTurnAction (canonicalGap p) a b) canonicalA) canonicalC q=
      Real.sqrt 2*∫θ in -(Real.pi/2)..Real.pi/2,parameter (canonicalKernelA p a b) canonicalC (q,θ) := by
  have hg := canonical_action_partials_angular_germ h ha
  have hKA := fun θ (_ : θ∈Icc (-(Real.pi/2)) (Real.pi/2)) => (canonicalKernels_analytic h θ).1
  have hKB := fun θ (_ : θ∈Icc (-(Real.pi/2)) (Real.pi/2)) => (canonicalKernels_analytic h θ).2
  constructor
  · dsimp only [directional]
    rw [hg.2.fderiv_eq,((analyticAt_fixedAngularIntegral hKB).differentiableAt.hasFDerivAt.const_mul
      (Real.sqrt 2)).fderiv]
    simp only [ContinuousLinearMap.smul_apply,smul_eq_mul]
    rw [fixedAngularIntegral_parameter canonicalB hKB]
  · dsimp only [directional]
    rw [hg.1.fderiv_eq,((analyticAt_fixedAngularIntegral hKA).differentiableAt.hasFDerivAt.const_mul
      (Real.sqrt 2)).fderiv]
    simp only [ContinuousLinearMap.smul_apply,smul_eq_mul]
    rw [fixedAngularIntegral_parameter canonicalC hKA]

theorem canonical_hessian_kernel_integral_zero {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    (∫θ in -(Real.pi/2)..Real.pi/2,
      parameter (canonicalKernelB p a b) canonicalB (q,θ)+
      parameter (canonicalKernelA p a b) canonicalC (q,θ))=0 := by
  have hab : -(Real.pi/2)≤Real.pi/2 := by linarith [Real.pi_pos]
  have hPc : ContinuousOn (canonicalHessianPrimitive p a b q) (Icc (-(Real.pi/2)) (Real.pi/2)) := by
    intro θ hθ
    have hs := (analyticAt_sqrt_comp (h.angularFactor_analytic θ)
      (h.factor_pos _ (unitSinNode_mem θ))).curry_right.continuousAt
    exact ((continuousAt_const.mul (Real.continuous_cos.continuousAt)).div
      (continuousAt_const.mul hs) (mul_ne_zero (by norm_num)
        (Real.sqrt_pos.mpr (h.factor_pos _ (unitSinNode_mem θ))).ne')).continuousWithinAt
  have hKi : IntervalIntegrable (fun θ =>
      parameter (canonicalKernelB p a b) canonicalB (q,θ)+
      parameter (canonicalKernelA p a b) canonicalC (q,θ)) volume (-(Real.pi/2)) (Real.pi/2) := by
    apply ContinuousOn.intervalIntegrable_of_Icc hab
    intro θ hθ
    exact ((analyticAt_parameter (canonicalKernels_analytic h θ).2 canonicalB).curry_right.continuousAt.add
      (analyticAt_parameter (canonicalKernels_analytic h θ).1 canonicalC).curry_right.continuousAt).continuousWithinAt
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le hab hPc
    (fun θ hθ => canonicalHessianPrimitive_derivative h ha θ hθ) hKi
  simpa only [canonicalHessianPrimitive,Real.cos_neg,Real.cos_pi_div_two,
    mul_zero,zero_div,sub_self] using hFTC

theorem canonical_action_hessian_identity {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    directional (directional (completeTurnAction (canonicalGap p) a b) canonicalB) canonicalB q+
      directional (directional (completeTurnAction (canonicalGap p) a b) canonicalA) canonicalC q=0 := by
  have hab : -(Real.pi/2)≤Real.pi/2 := by linarith [Real.pi_pos]
  have hiB : IntervalIntegrable (fun θ => parameter (canonicalKernelB p a b) canonicalB (q,θ))
      volume (-(Real.pi/2)) (Real.pi/2) :=
    ContinuousOn.intervalIntegrable_of_Icc hab (fun θ _ =>
      (analyticAt_parameter (canonicalKernels_analytic h θ).2 canonicalB).curry_right.continuousAt.continuousWithinAt)
  have hiA : IntervalIntegrable (fun θ => parameter (canonicalKernelA p a b) canonicalC (q,θ))
      volume (-(Real.pi/2)) (Real.pi/2) :=
    ContinuousOn.intervalIntegrable_of_Icc hab (fun θ _ =>
      (analyticAt_parameter (canonicalKernels_analytic h θ).1 canonicalC).curry_right.continuousAt.continuousWithinAt)
  rw [(canonical_action_second_partials h ha).1,(canonical_action_second_partials h ha).2,
    ← mul_add,← intervalIntegral.integral_add hiB hiA,canonical_hessian_kernel_integral_zero h ha,mul_zero]

theorem canonical_period_action_germ {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    directional (completeTurnAction (canonicalGap p) a b) canonicalA =ᶠ[𝓝 q] canonicalPeriod p a b := by
  filter_upwards [regularTwoTurnFamily_eventually h,
    h.analytic_left.continuousAt.eventually (Ioi_mem_nhds ha)] with r hr hra
  exact canonical_action_energy_derivative hr hra

theorem analyticAt_canonicalPeriod {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    AnalyticAt ℝ (canonicalPeriod p a b) q :=
  (analyticAt_directional h.action_analytic canonicalA).congr (canonical_period_action_germ h ha)

theorem directional_congr {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {f g : E→ℝ} {q : E} (h : f =ᶠ[𝓝 q] g) (η : E) :
    directional f η q=directional g η q := congrArg (fun d : E→L[ℝ] ℝ => d η) h.fderiv_eq

theorem directional_congr_germ {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {f g : E→ℝ} {q : E} (h : f =ᶠ[𝓝 q] g) (η : E) :
    directional f η =ᶠ[𝓝 q] directional g η := by
  filter_upwards [eventually_eventually_nhds.mpr h] with r hr
  exact directional_congr hr η

theorem directional_triple_commute {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {f : E→ℝ} {q : E} (hf : AnalyticAt ℝ f q) (η ξ ζ : E) :
    directional (directional (directional f η) ξ) ζ q=
      directional (directional (directional f ζ) η) ξ q := by
  rw [directional_commute (analyticAt_directional hf η) ξ ζ]
  apply directional_congr _ ξ
  filter_upwards [hf.eventually_analyticAt] with r hr
  exact directional_commute hr η ζ

/-- Picard--Fuchs identity for the actual complete period on its moving
regular turning interval.  No formal contour equation is an input. -/
theorem canonical_period_hessian_identity {p : ℝ} {a b : CanonicalCoefficients→ℝ} {q : CanonicalCoefficients}
    (h : RegularTwoTurnFamily (canonicalGap p) a b q) (ha : 0<a q) :
    directional (directional (canonicalPeriod p a b) canonicalB) canonicalB q+
      directional (directional (canonicalPeriod p a b) canonicalC) canonicalA q=0 := by
  let I := completeTurnAction (canonicalGap p) a b
  have he : (fun r => directional (directional I canonicalB) canonicalB r+
      directional (directional I canonicalA) canonicalC r) =ᶠ[𝓝 q] fun _ => (0:ℝ) := by
    filter_upwards [regularTwoTurnFamily_eventually h,
      h.analytic_left.continuousAt.eventually (Ioi_mem_nhds ha)] with r hr hra
    exact canonical_action_hessian_identity hr hra
  have hd := directional_congr he canonicalA
  have hBB := analyticAt_directional (analyticAt_directional h.action_analytic canonicalB) canonicalB
  have hAC := analyticAt_directional (analyticAt_directional h.action_analytic canonicalA) canonicalC
  simp only [directional,fderiv_const,ContinuousLinearMap.zero_apply] at hd
  change fderiv ℝ (fun r => directional (directional I canonicalB) canonicalB r+
    directional (directional I canonicalA) canonicalC r) q canonicalA=0 at hd
  rw [(hBB.differentiableAt.hasFDerivAt.add hAC.differentiableAt.hasFDerivAt).fderiv] at hd
  simp only [ContinuousLinearMap.add_apply] at hd
  change directional (directional (directional I canonicalB) canonicalB) canonicalA q+
    directional (directional (directional I canonicalA) canonicalC) canonicalA q=0 at hd
  rw [directional_triple_commute h.action_analytic canonicalB canonicalB canonicalA] at hd
  have hg := canonical_period_action_germ h ha
  rw [directional_congr (directional_congr_germ hg canonicalB) canonicalB,
    directional_congr (directional_congr_germ hg canonicalC) canonicalA] at hd
  exact hd

end LeanVerification.UpperStripCompletion
