import LeanVerification.UpperStripCompletion.UpperEnergyChart
import LeanVerification.UpperStripCompletion.UpperBoundaryPositive
import LeanVerification.UpperStripCompletion.UpperEnergyRange
import LeanVerification.ContourCompletion.PhysicalCycle

/-! The characteristic energy chart preserves the actual physical time;
its square-root scale is explicitly retained. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open Loud GeneralMechanical InteriorCompletion ContourCompletion AnalyticTwoPartials
set_option maxHeartbeats 2600000

def upperPhysicalScale (b d : ℝ) : ℝ := (1-b)/(1+d)
def upperPhysicalHeight (b d : ℝ) : ℝ := upperPhysicalScale b d*upperHeight b d
def upperPhysicalEnergy (b : ℝ) (q : ℝ×ℝ) : ℝ := upperPhysicalHeight b q.2*(1-Real.exp (-q.1))
def upperPhysicalParameter (b : ℝ) (q : ℝ×ℝ) : PeriodParameterSpace :=
  ((-1/(1+q.2),1/(1-b)),upperPhysicalEnergy b q)
def upperPhysicalChartPeriod (b : ℝ) (q : ℝ×ℝ) : ℝ :=
  Real.sqrt (upperPhysicalScale b q.2)*extendedPhysicalPeriod (upperPhysicalParameter b q)

theorem upper_physical_coefficient_normalization (b d : ℝ)
    (hb : b≠0) (hm : 1-b≠0) (hp : 1+b≠0) (hd : 1+d≠0) :
    loudTurnA (-1/(1+d)) (1/(1-b))= -upperPhysicalScale b d*(d/2) ∧
    loudTurnB (-1/(1+d)) (1/(1-b))=upperPhysicalScale b d*((1-d)/(1+b)) ∧
    loudTurnC (-1/(1+d)) (1/(1-b))=upperPhysicalScale b d*(1/(2*b)) ∧
    zeroEndpointHeight (-1/(1+d)) (1/(1-b))=upperPhysicalHeight b d ∧
    2*(1/(1-b))-2=2*b/(1-b) := by
  have h2F : 2*(1/(1-b))-2=2*b/(1-b) := by field_simp [hm]; ring
  have h2F1 : 2*(1/(1-b))-1=(1+b)/(1-b) := by field_simp [hm]; ring
  have hA : loudTurnA (-1/(1+d)) (1/(1-b))= -upperPhysicalScale b d*(d/2) := by
    unfold loudTurnA upperPhysicalScale
    field_simp [hb,hm,hp,hd]
    ring
  have hB : loudTurnB (-1/(1+d)) (1/(1-b))=upperPhysicalScale b d*((1-d)/(1+b)) := by
    unfold loudTurnB upperPhysicalScale
    rw [h2F1]
    field_simp [hb,hm,hp,hd]
    ring
  have hC : loudTurnC (-1/(1+d)) (1/(1-b))=upperPhysicalScale b d*(1/(2*b)) := by
    unfold loudTurnC upperPhysicalScale
    rw [h2F]
    field_simp [hb,hm,hp,hd]
  refine ⟨hA,hB,hC,?_,h2F⟩
  rw [loudTurn_height_identity,hA,hB,hC]
  unfold upperPhysicalHeight upperHeight
  field_simp [hb,hp]
  ring

theorem upper_physical_gap_factor (b : ℝ) (q : ℝ×ℝ) (w : ℝ)
    (hb : b≠0) (hm : 1-b≠0) (hp : 1+b≠0) (hd : 1+q.2≠0) :
    -loudTurnPolynomial (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q) w=
      upperPhysicalScale b q.2*canonicalGap (2*b/(1-b)) (upperEnergyChart b q,w) := by
  have hc := upper_physical_coefficient_normalization b q.2 hb hm hp hd
  unfold loudTurnPolynomial
  rw [hc.1,hc.2.1,hc.2.2.1,hc.2.2.2.1,hc.2.2.2.2]
  unfold upperPhysicalEnergy upperPhysicalHeight canonicalGap upperEnergyChart upperCanonicalPoint upperChartDelta
  ring

theorem upper_physical_height_pos {b d : ℝ} (hb : 0<b) (hb1 : b<1) (hd : 0≤d) :
    0<upperPhysicalScale b d ∧ 0<upperPhysicalHeight b d := by
  have hm : 0<1-b := by linarith
  have he : 0<1+d := by linarith
  have hs : 0<upperPhysicalScale b d := div_pos hm he
  refine ⟨hs,?_⟩
  unfold upperPhysicalHeight upperHeight
  have hbd : 0<1+b*d := by positivity
  exact mul_pos hs (div_pos (mul_pos hm hbd) (by positivity))

theorem upper_physical_chart_admissible {b : ℝ} {q : ℝ×ℝ}
    (hb : 0<b) (hb1 : b≤1/5) (hX : 0<q.1) (hd : 0≤q.2) (hd1 : q.2≤1) :
    AdmissibleEnergy (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q) := by
  obtain ⟨hD0,hD1,hF0,hF1,_,_⟩ := normalized_upper_physical_parameters hb.le hb1 hd hd1
  have hm : 0<1-b := by linarith
  have hp : 0<1+b := by linarith
  have he : 0<1+q.2 := by linarith
  have hF : 1<1/(1-b) := (lt_div_iff₀ hm).mpr (by linarith)
  rw [upper_admissibleEnergy_iff _ _ _ hD0 (by linarith) hF,
    (upper_physical_coefficient_normalization b q.2 hb.ne' hm.ne' hp.ne' he.ne').2.2.2.1]
  have hH := (upper_physical_height_pos hb (by linarith) hd).2
  have hxp : 0<Real.exp (-q.1) := Real.exp_pos _
  have hxe : Real.exp (-q.1)<1 := Real.exp_lt_one_iff.mpr (by linarith)
  unfold upperPhysicalEnergy
  constructor
  · exact mul_pos hH (sub_pos.mpr hxe)
  · nlinarith only [mul_pos hH hxp]

theorem analyticAt_upperPhysicalParameter (b : ℝ) (q : ℝ×ℝ) (hd : 1+q.2≠0) :
    AnalyticAt ℝ (upperPhysicalParameter b) q := by
  have hs : AnalyticAt ℝ (fun r : ℝ×ℝ => upperPhysicalScale b r.2) q :=
    analyticAt_const.div (analyticAt_const.add analyticAt_snd) hd
  have hh : AnalyticAt ℝ (fun r : ℝ×ℝ => upperHeight b r.2) q := by
    unfold upperHeight
    exact (analyticAt_const.mul (analyticAt_const.add (analyticAt_const.mul analyticAt_snd))).mul analyticAt_const
  exact ((analyticAt_const.div (analyticAt_const.add analyticAt_snd) hd).prod analyticAt_const).prod
    ((hs.mul hh).mul (analyticAt_const.sub analyticAt_fst.neg.rexp'))

theorem upper_physical_parameter_center (b d : ℝ) :
    upperPhysicalParameter b (0,d)=((-1/(1+d),1/(1-b)),0) := by
  simp only [upperPhysicalParameter,upperPhysicalEnergy,neg_zero,Real.exp_zero,sub_self,mul_zero]

theorem analyticAt_upperPhysicalChartPeriod {b : ℝ} {q : ℝ×ℝ}
    (hb : b<1) (hd : 0<1+q.2)
    (hq : q.1=0 ∨ AdmissibleEnergy (-1/(1+q.2)) (1/(1-b)) (upperPhysicalEnergy b q)) :
    AnalyticAt ℝ (upperPhysicalChartPeriod b) q := by
  have hs : AnalyticAt ℝ (fun r : ℝ×ℝ => upperPhysicalScale b r.2) q :=
    analyticAt_const.div (analyticAt_const.add analyticAt_snd) hd.ne'
  have hsp : 0<upperPhysicalScale b q.2 := div_pos (by linarith) hd
  have ha : AnalyticAt ℝ extendedPhysicalPeriod (upperPhysicalParameter b q) := by
    apply analyticAt_extendedPhysicalPeriod
    rcases hq with h0|hp
    · left
      have he : upperPhysicalParameter b q=((-1/(1+q.2),1/(1-b)),0) := by
        simp only [upperPhysicalParameter,upperPhysicalEnergy,h0,neg_zero,Real.exp_zero,sub_self,mul_zero]
      rw [he]
      exact jointCenterDomain_contains_center _ _
    · exact Or.inr hp
  exact (analyticAt_sqrt_comp hs hsp).mul (ha.comp (analyticAt_upperPhysicalParameter b q hd.ne'))

end LeanVerification.UpperStripCompletion
