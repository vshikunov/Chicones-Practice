import LeanVerification.UpperStripCompletion.TransportPositivity

/-! The quantitative interior-to-boundary comparison retained at parameter
seams: the transported derivative decreases strictly in d. -/
noncomputable section
open Set
namespace LeanVerification.UpperStripCompletion
open AnalyticTwoPartials
set_option maxHeartbeats 1400000

theorem transport_interior_comparison {U : ℝ×ℝ→ℝ} {v c γ : ℝ→ℝ} {T D : ℝ}
    (hT : 0<T) (hD : 0≤D)
    (hU : AnalyticOnNhd ℝ U (transportRectangle T D))
    (hU0 : ∀d∈Icc 0 D,0≤U (0,d))
    (hinit : ∀d∈Icc 0 D,right U (0,d)<0)
    (hboundary : ∀X∈Ioc 0 T,0<U (X,D))
    (hv0 : v 0=0) (hv : ∀d∈Icc 0 D,0≤v d)
    (hc : ∀d∈Icc 0 D,0≤c d) (hcc : ContinuousOn c (Icc 0 D))
    (hγ : ∀d∈Icc 0 D,0≤γ d)
    (hpde : ∀q∈transportRectangle T D,0<q.1 →
      left (right U) q+v q.2*right (right U) q+c q.2*right U q= -γ q.2*U q) :
    (∀q∈Ioc 0 T ×ˢ Icc 0 D,0<U q) ∧
    (∀q∈transportRectangle T D,right U q<0) ∧
    (∀X∈Icc 0 T,∀d∈Icc 0 D,U (X,D)≤U (X,d)) := by
  have hp := transport_interior_positive hT hD hU hU0 hinit hboundary hv0 hv hc hcc hγ hpde
  have hneg := transport_negative_of_nonpositive_forcing hT.le hD
    (fun q hq => analyticAt_right (hU q hq)) hinit hv0 hv hc hcc (by
      intro q hq hqp
      rw [hpde q hq hqp]
      exact mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr (hγ q.2 hq.2))
        (hp q ⟨⟨hqp,hq.1.2⟩,hq.2⟩).le)
  refine ⟨hp,hneg,?_⟩
  intro X hX d hd
  have hm := parameter_antitone_from_right_negative
    (fun r hr => hU (X,r) ⟨hX,hr⟩) (fun r hr => hneg (X,r) ⟨hX,hr⟩)
  exact hm hd ⟨hD,le_rfl⟩ hd.2

end LeanVerification.UpperStripCompletion
