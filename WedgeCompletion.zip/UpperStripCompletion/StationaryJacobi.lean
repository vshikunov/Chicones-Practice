import LeanVerification.UpperStripCompletion.JacobiConcavity
import LeanVerification.GeneralMechanical.StationaryMode

/-! Concavity of the actual glued stationary energy variation. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open GeneralMechanical GeneralMechanical.EnergyModes

theorem RegularEnergyWell.stationary_jacobi_concave {W a b : ℝ → ℝ} {L : ℝ}
    (h : RegularEnergyWell W a b L) (hstat : deriv (period W a b) L=0)
    (hk : ∀ x ∈ Icc (a L) (b L), 0<deriv (deriv W) x)
    (hf : ∀ x ∈ Icc (a L) (b L), deriv (deriv (deriv W)) x<0) :
    (∀ x ∈ Icc (a L) (b L), 0<deriv (stationaryVariation W a b L) x) ∧
    (∀ x ∈ Ioo (a L) (b L), deriv (deriv (stationaryVariation W a b L)) x<0) := by
  have hWa := (sub_eq_zero.mp h.root_left.self_of_nhds).symm
  have hWb := (sub_eq_zero.mp h.root_right.self_of_nhds).symm
  exact ⟨jacobi_derivative_pos h.turns_ordered h.analytic_potential
      (h.analytic_stationaryVariation hstat) (h.stationaryVariation_equation hstat)
      hWa hWb h.force_left h.force_right h.positive_gap hk,
    jacobi_second_derivative_neg h.turns_ordered h.analytic_potential
      (h.analytic_stationaryVariation hstat) (h.stationaryVariation_equation hstat)
      hWa hWb h.force_left h.force_right h.positive_gap hk hf⟩

end LeanVerification.UpperStripCompletion
