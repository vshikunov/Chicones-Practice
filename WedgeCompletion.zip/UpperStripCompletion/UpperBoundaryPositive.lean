import LeanVerification.UpperStripCompletion.UpperNonpositiveCenter
import LeanVerification.UpperStripCompletion.UpperCenterCoefficients
import LeanVerification.UpperStripCompletion.ExtendedPhysicalPeriod

/-! Strict positivity of the actual physical period derivative on the
separating center curve, including its F=1 endpoint. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperStripCompletion
open Loud GeneralMechanical Sharpness
set_option maxHeartbeats 2400000

theorem physical_period_deriv_pos_of_zero_center_and_positive_curvature (D F h : ℝ)
    (ht1 : periodCoefficient D F 1=0) (ht2 : 0<periodCoefficient D F 2)
    (hcurv : ∀k,AdmissibleEnergy D F k → deriv (periodQuadrature D F) k=0 →
      0<deriv (deriv (periodQuadrature D F)) k)
    (hh : AdmissibleEnergy D F h) : 0<deriv (periodQuadrature D F) h := by
  let f : ℝ→ℝ := fun k => extendedPhysicalSlope ((D,F),k)
  have hf0 : f 0=0 := by
    dsimp only [f]
    rw [extendedPhysicalSlope_center_value,ht1,mul_zero]
  have hf0d : 0<deriv f 0 := by
    rw [show deriv f 0=4*Real.pi*periodCoefficient D F 2 from extendedPhysicalSlope_center_derivative D F]
    positivity
  have hfa (k : ℝ) (hk : k∈Icc 0 h) : AnalyticAt ℝ f k := by
    have hdom : ((D,F),k)∈jointCenterDomain ∨ AdmissibleEnergy D F k := by
      by_cases hk0 : k=0
      · exact Or.inl (hk0 ▸ jointCenterDomain_contains_center D F)
      · exact Or.inr (admissibleEnergy_downward D F h k hh
          (lt_of_le_of_ne hk.1 (Ne.symm hk0)) hk.2)
    exact (analyticAt_verticalDerivative (analyticAt_extendedPhysicalPeriod hdom)).curry_right
  have hfg (k : ℝ) (hk : AdmissibleEnergy D F k) : f =ᶠ[𝓝 k] deriv (periodQuadrature D F) := by
    filter_upwards [(isOpen_admissibleEnergy D F).mem_nhds hk] with l hl
    exact extendedPhysicalSlope_eq_physical hl
  have hzero (k : ℝ) (hk : k∈Icc 0 h) (hfk : f k=0) : 0<deriv f k := by
    by_cases hk0 : k=0
    · simpa only [hk0] using hf0d
    have hkpos : 0<k := lt_of_le_of_ne hk.1 (Ne.symm hk0)
    have hka := admissibleEnergy_downward D F h k hh hkpos hk.2
    have he := hfg k hka
    rw [he.deriv_eq]
    exact hcurv k hka (he.self_of_nhds.symm.trans hfk)
  have hnonneg := ZeroOrientation.nonneg_on_Icc_of_deriv_pos_at_zeros
    (fun k hk => (hfa k hk).differentiableAt) hzero hf0.ge
  have hn : f h≠0 := by
    intro he
    exact ZeroOrientation.not_two_ordered_zeros_of_deriv_pos_at_zeros hh.1
      (fun k hk => (hfa k hk).differentiableAt) hzero hf0 he
  have hp : 0<f h := lt_of_le_of_ne (hnonneg h ⟨hh.1.le,le_rfl⟩) (Ne.symm hn)
  rwa [(hfg h hh).self_of_nhds] at hp

theorem normalized_upper_physical_parameters {b d : ℝ}
    (hb : 0≤b) (hb1 : b≤1/5) (hd : 0≤d) (hd1 : d≤1) :
    -1≤ -1/(1+d) ∧ -1/(1+d)≤-(1/2) ∧ 1≤1/(1-b) ∧ 1/(1-b)≤5/4 ∧
    1-1/(1/(1-b))=b ∧ -((-1/(1+d))+1)/(-1/(1+d))=d := by
  have hm : 0<1-b := by linarith
  have he : 0<1+d := by linarith
  have hD0 : 1/(1+d)≤1 := (div_le_one he).mpr (by linarith)
  have hD1 : (1/2:ℝ)≤1/(1+d) := (le_div_iff₀ he).mpr (by linarith)
  refine ⟨by rw [neg_div]; linarith,by rw [neg_div]; linarith,
    (le_div_iff₀ hm).mpr (by linarith),(div_le_iff₀ hm).mpr (by linarith),?_,?_⟩
  · field_simp
  · apply (div_eq_iff (div_ne_zero (by norm_num : (-1:ℝ)≠0) he.ne')).mpr
    field_simp [he.ne']

theorem physical_upper_period_deriv_pos_center_zero {b d h : ℝ}
    (hb : 0≤b) (hb1 : b≤1/5) (hd : 0≤d) (hd1 : d≤1/9)
    (hC : upperCenterPolynomial b d=0)
    (hh : AdmissibleEnergy (-1/(1+d)) (1/(1-b)) h) :
    0<deriv (periodQuadrature (-1/(1+d)) (1/(1-b))) h := by
  obtain ⟨hD0,hD1,hF0,hF1,hbe,hde⟩ := normalized_upper_physical_parameters hb hb1 hd (by linarith)
  have hm : 0<1-b := by linarith
  have he : 0<1+d := by linarith
  have hCphys : upperCenterPolynomial (1-1/(1/(1-b))) (-((-1/(1+d))+1)/(-1/(1+d)))≤0 := by
    rw [hbe,hde,hC]
  apply physical_period_deriv_pos_of_zero_center_and_positive_curvature _ _ h ?_
    (physical_upper_tau2_pos hb hb1 hd hd1) ?_ hh
  · rw [actual_tau1_polynomial,upper_tau1_normalization b d hm.ne' he.ne',hC,zero_div]
  · exact fun k hk hs => physical_upper_stationary_curvature_nonpositive_center _ _ k
      hD0 hD1 hF0 hF1 hCphys hk hs

theorem physical_upper_log_boundary_positive {h : ℝ} (hh : AdmissibleEnergy (-9/10) 1 h) :
    0<deriv (periodQuadrature (-9/10) 1) h := by
  have hz : upperCenterPolynomial 0 (1/9)=0 := by norm_num [upperCenterPolynomial]
  have hp := physical_upper_period_deriv_pos_center_zero (b:=0) (d:=1/9) (h:=h)
    (by norm_num) (by norm_num) (by norm_num) le_rfl hz
  norm_num at hp
  simpa only [neg_div] using hp (by simpa only [neg_div] using hh)

end LeanVerification.UpperStripCompletion
