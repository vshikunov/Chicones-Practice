import LeanVerification.UpperLeftThirdCompletion.DensityDerivativeScore

/-! The positive derivative measure is constructed from the actual normalized
ray density.  Its derivative and positivity hold at every positive energy. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion UpperLeftCompletion AnalyticTwoPartials
set_option maxHeartbeats 3800000
set_option maxRecDepth 6000

def derivativeDensityRho (p l v : ℝ) : ℝ :=
  densityOrderDensity p l v/v^(densityDerivativeAlpha p)

def derivativeDensityWeight (p l v : ℝ) : ℝ :=
  -deriv (derivativeDensityRho p l) v

def derivativeDensityRadialSpeed (p l v : ℝ) : ℝ :=
  lowAngleDeficit p l/
    rayEnergySlope p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l)
      (densityOrderInverse p l v)

theorem derivativeDensityRho_pos {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) : 0<derivativeDensityRho p l v :=
  div_pos (densityOrderDensity_pos hp hl hv) (Real.rpow_pos_of_pos hv _)

theorem derivativeDensityRadialSpeed_pos {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) : 0<derivativeDensityRadialSpeed p l v := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  exact div_pos (lowAngleDeficit_pos hp hl.le)
    (rayEnergySlope_pos hp hA hB.le hC (densityOrderInverse_pos hp hl hv))

theorem hasDerivAt_densityOrderInverse_energy {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    HasDerivAt (densityOrderInverse p l) (derivativeDensityRadialSpeed p l v) v := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hd := (hasDerivAt_rayInverse hp hA hB hC
    (mul_pos (lowAngleDeficit_pos hp hl.le) hv)).comp v
      ((hasDerivAt_id v).const_mul (lowAngleDeficit p l))
  convert hd using 1
  dsimp only [derivativeDensityRadialSpeed,id_eq]
  simp only [densityOrderInverse,mul_one,one_mul,div_eq_mul_inv,mul_comm]

theorem analyticAt_densityOrderDensity {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    AnalyticAt ℝ (fun q : ℝ×ℝ => densityOrderDensity p q.1 q.2) (l,v) := by
  have hr := densityOrderInverse_pos hp hl hv
  have hR := analyticAt_densityOrderInverse hp hl hv
  have hN : AnalyticAt ℝ (fun q : ℝ×ℝ => (densityOrderInverse p q.1 q.2)^(1-p/2)) (l,v) :=
    (analyticAt_rpow_const (1-p/2) _ hr).comp_of_eq hR rfl
  have hD : AnalyticAt ℝ (fun q : ℝ×ℝ =>
      (densityOrderInverse p q.1 q.2+1)*(q.1*p*(densityOrderInverse p q.1 q.2+1)+2)/2) (l,v) :=
    ((hR.add analyticAt_const).mul
    (((analyticAt_fst.mul analyticAt_const).mul (hR.add analyticAt_const)).add
      analyticAt_const)).div analyticAt_const (by norm_num : (2:ℝ)≠0)
  have hn : (densityOrderInverse p l v+1)*
      (l*p*(densityOrderInverse p l v+1)+2)/2≠0 := by positivity
  have he : (fun q : ℝ×ℝ => densityOrderDensity p q.1 q.2)=
      (fun q : ℝ×ℝ => (densityOrderInverse p q.1 q.2)^(1-p/2)/
        ((densityOrderInverse p q.1 q.2+1)*
          (q.1*p*(densityOrderInverse p q.1 q.2+1)+2)/2)) := by
    funext q
    exact densityOrderDensity_formula hp q.1 q.2
  rw [he]
  exact hN.div hD hn

theorem analyticAt_derivativeDensityRho {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    AnalyticAt ℝ (fun q : ℝ×ℝ => derivativeDensityRho p q.1 q.2) (l,v) := by
  exact (analyticAt_densityOrderDensity hp hl hv).div
    ((analyticAt_rpow_const (densityDerivativeAlpha p) v hv).comp_of_eq analyticAt_snd rfl)
    (Real.rpow_pos_of_pos hv _).ne'

theorem analyticAt_derivativeDensityWeight {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    AnalyticAt ℝ (fun q : ℝ×ℝ => derivativeDensityWeight p q.1 q.2) (l,v) :=
  (analyticAt_right (analyticAt_derivativeDensityRho hp hl hv)).neg

theorem hasDerivAt_densityOrderDensity_parameter {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    HasDerivAt (fun t => densityOrderDensity p t v)
      (densityOrderDensity p l v*densityOrderScore p l (densityOrderInverse p l v)) l := by
  have hd := (Real.hasDerivAt_exp (Real.log (densityOrderDensity p l v))).comp l
    (hasDerivAt_log_densityOrderDensity_parameter hp hl hv)
  rw [Real.exp_log (densityOrderDensity_pos hp hl hv)] at hd
  apply hd.congr_of_eventuallyEq
  filter_upwards [Ioi_mem_nhds hl] with t ht
  exact (Real.exp_log (densityOrderDensity_pos hp ht hv)).symm

theorem hasDerivAt_derivativeDensityRho_parameter {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    HasDerivAt (fun t => derivativeDensityRho p t v)
      (derivativeDensityRho p l v*densityOrderScore p l (densityOrderInverse p l v)) l := by
  convert (hasDerivAt_densityOrderDensity_parameter hp hl hv).div_const
    (v^(densityDerivativeAlpha p)) using 1
  unfold derivativeDensityRho
  ring

theorem hasDerivAt_derivativeDensityRho_energy {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    HasDerivAt (derivativeDensityRho p l)
      (-derivativeDensityRho p l v*
        densityDerivativeC p l (densityOrderInverse p l v)*
        derivativeDensityRadialSpeed p l v) v := by
  let r := densityOrderInverse p l v
  let A := lowAngleA p l
  let B := lowAngleB p l
  let C := lowAngleC p l
  have hr : 0<r := densityOrderInverse_pos hp hl hv
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hP : 0<rayPolynomial A B C r := rayPolynomial_pos hA hB.le hC hr
  have hE : 0<rayEulerPolynomial p A B C r := rayEulerPolynomial_pos hp hA hB.le hC hr
  have hH := lowAngleDeficit_pos hp hl.le
  have hs : 0<rayEnergySlope p A B C r := rayEnergySlope_pos hp hA hB.le hC hr
  have hR := hasDerivAt_densityOrderInverse_energy hp hl hv
  have hD := (hasDerivAt_rayDensityParam p A B C hr hE.ne').comp v hR
  have hpw := Real.hasDerivAt_rpow_const (p:=densityDerivativeAlpha p) (Or.inl hv.ne')
  have hd := hD.div hpw (Real.rpow_pos_of_pos hv _).ne'
  convert hd using 1
  change -((rayDensityParam p A B C r)/v^(densityDerivativeAlpha p))*
      rayLogGradient (densityDerivativeAlpha p) p A B C r*
      (lowAngleDeficit p l/rayEnergySlope p A B C r)=_
  have he : v=rayEnergy p A B C r/lowAngleDeficit p l := by
    exact (densityOrderEnergy_inverse hp hl hv).symm
  rw [Real.rpow_sub_one hv.ne']
  change _=(rayDensityParamSlope p A B C r*
    (lowAngleDeficit p l/rayEnergySlope p A B C r)*v^(densityDerivativeAlpha p)-
    rayDensityParam p A B C r*(densityDerivativeAlpha p*(v^(densityDerivativeAlpha p)/v)))/
    (v^(densityDerivativeAlpha p))^2
  have hpow := (Real.rpow_pos_of_pos hv (densityDerivativeAlpha p)).ne'
  have hpowr := (Real.rpow_pos_of_pos hr p).ne'
  dsimp only [rayDensityParam,rayDensityParamSlope,rayLogGradient,rayEnergySlope]
  rw [Real.rpow_sub_one hr.ne']
  generalize hV : v^(densityDerivativeAlpha p)=V
  have hV0 : V≠0 := by rwa [hV] at hpow
  rw [he]
  dsimp only [rayEnergy,densityDerivativeAlpha]
  field_simp [hV0,hE.ne',hP.ne',hr.ne',hH.ne',hpowr,hp.ne']
  dsimp only [rayPolynomial,rayEulerPolynomial,rayEulerSlope]
  ring


theorem derivativeDensityWeight_formula {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    derivativeDensityWeight p l v=derivativeDensityRho p l v*
      densityDerivativeC p l (densityOrderInverse p l v)*
        derivativeDensityRadialSpeed p l v := by
  unfold derivativeDensityWeight
  rw [(hasDerivAt_derivativeDensityRho_energy hp hl hv).deriv]
  ring

theorem derivativeDensityWeight_pos {p l v : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) (hv : 0<v) :
    0<derivativeDensityWeight p l v := by
  rw [derivativeDensityWeight_formula hp hl hv]
  exact mul_pos (mul_pos (derivativeDensityRho_pos hp hl hv)
    (densityDerivativeC_pos hp hp2 hl (densityOrderInverse_pos hp hl hv)))
    (derivativeDensityRadialSpeed_pos hp hl hv)

theorem hasDerivAt_derivativeDensityRho {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    HasDerivAt (derivativeDensityRho p l) (-derivativeDensityWeight p l v) v := by
  rw [derivativeDensityWeight_formula hp hl hv]
  convert hasDerivAt_derivativeDensityRho_energy hp hl hv using 1 <;> ring

end LeanVerification.UpperLeftThirdCompletion
