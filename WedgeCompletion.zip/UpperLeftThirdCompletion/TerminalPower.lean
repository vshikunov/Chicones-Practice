import LeanVerification.UpperLeftThirdCompletion.TerminalPolynomials

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion ExteriorCompletion ExteriorSpectralCompletion UpperLeftCompletion
set_option maxHeartbeats 4800000

private theorem hasDerivAt_majorant_weight {p r : ℝ}
    (hp : 0<p) (hpu : p<1) (hr : 0≤r) :
    HasDerivAt (fun r => terminalPowerMajorant p r*(1+r)^(-p))
      ((1+r)^(-p-1)*p*r^3*(p-1)*(p-2)*(p+1)/
        (2*(p*r-2*r-3)^2)) r := by
  have hr1 : 0<1+r := by positivity
  have hp2pos : 0<2-p := by linarith
  have hd : 0<6+2*(2-p)*r := by positivity
  have hden : p*r-2*r-3≠0 := by nlinarith
  have hN := ((((hasDerivAt_id r).const_mul (4*(p+1))).const_add 6).add
    (((hasDerivAt_id r).pow 2).const_mul (p*(p+1))))
  have hD := ((hasDerivAt_id r).const_mul (2*(2-p))).const_add 6
  have hR := hN.div hD hd.ne'
  have hW := (Real.hasDerivAt_rpow_const (p:=-p) (Or.inl hr1.ne')).comp r
    ((hasDerivAt_id r).const_add 1)
  have he : (1+r)^(-p)=(1+r)^(-p-1)*(1+r) := by
    calc
      _=(1+r)^((-p-1)+1) := by congr 1; ring
      _=_ := by rw [Real.rpow_add hr1,Real.rpow_one]
  convert hR.mul hW using 1
  simp only [id_eq,mul_one,one_mul,Nat.cast_ofNat,Nat.reduceSub,pow_one,Function.comp_apply]
  rw [he]
  field_simp
  <;> ring

theorem terminalPowerMajorant_rpow {p r : ℝ}
    (hp : 0<p) (hpu : p<1) (hr : 0≤r) :
    (1+r)^p≤terminalPowerMajorant p r := by
  have hm : MonotoneOn (fun r => terminalPowerMajorant p r*(1+r)^(-p)) (Ici 0) := by
    apply monotoneOn_of_deriv_nonneg (convex_Ici _)
    · intro x hx
      exact (hasDerivAt_majorant_weight hp hpu hx).continuousAt.continuousWithinAt
    · intro x hx
      rw [interior_Ici] at hx
      exact (hasDerivAt_majorant_weight hp hpu hx.le).differentiableAt.differentiableWithinAt
    · intro x hx
      rw [interior_Ici] at hx
      rw [(hasDerivAt_majorant_weight hp hpu hx.le).deriv]
      have hp1 : p-1≤0 := by linarith
      have hp2 : p-2≤0 := by linarith
      have hneg := mul_nonneg_of_nonpos_of_nonpos hp1 hp2
      have hx0 : 0<x := hx
      have hpow := Real.rpow_nonneg (by linarith : 0≤1+x) (-p-1)
      apply div_nonneg _ (by positivity)
      nlinarith [mul_nonneg (mul_nonneg (mul_nonneg hpow hp.le) (pow_nonneg hx.le 3))
        (mul_nonneg hneg (by linarith : 0≤p+1))]
  have hh := hm (show (0:ℝ)∈Ici 0 by simp) hr hr
  norm_num [terminalPowerMajorant] at hh
  have hr1 : 0<1+r := by positivity
  rw [Real.rpow_neg hr1.le,←div_eq_mul_inv] at hh
  simpa only [one_mul] using (le_div_iff₀ (Real.rpow_pos_of_pos hr1 p)).mp hh

def terminalEpsilon (p : ℝ) : ℝ := 4*p^p/(p+2)^(p+2)

theorem terminalEpsilon_pos {p : ℝ} (hp : 0<p) : 0<terminalEpsilon p := by
  dsimp only [terminalEpsilon]
  positivity

theorem hasDerivAt_terminalEpsilon {p : ℝ} (hp : 0<p) :
    HasDerivAt terminalEpsilon
      (terminalEpsilon p*(Real.log p-Real.log (p+2))) p := by
  have hp2 : 0<p+2 := by positivity
  have h1 := (hasDerivAt_id p).rpow (hasDerivAt_id p) hp
  have h2 := ((hasDerivAt_id p).add_const 2).rpow
    ((hasDerivAt_id p).add_const 2) hp2
  have hd := (h1.const_mul 4).div h2 (Real.rpow_pos_of_pos hp2 _).ne'
  convert hd using 1
  simp only [id_eq,one_mul,mul_one]
  dsimp only [terminalEpsilon]
  have hpw : p^(p-1)=p^p/p := by rw [Real.rpow_sub hp,Real.rpow_one]
  have hp2w : (p+2)^(p+2-1)=(p+2)^(p+2)/(p+2) := by
    rw [Real.rpow_sub hp2,Real.rpow_one]
  rw [hpw,hp2w]
  field_simp
  <;> ring

theorem terminalEpsilon_antitone : AntitoneOn terminalEpsilon (Ioi 0) := by
  apply antitoneOn_of_deriv_nonpos (convex_Ioi _)
  · intro p hp
    exact (hasDerivAt_terminalEpsilon hp).continuousAt.continuousWithinAt
  · intro p hp
    rw [interior_Ioi] at hp
    exact (hasDerivAt_terminalEpsilon hp).differentiableAt.differentiableWithinAt
  · intro p hp
    rw [interior_Ioi] at hp
    rw [(hasDerivAt_terminalEpsilon hp).deriv]
    have hl : Real.log p<Real.log (p+2) := Real.log_lt_log hp (by linarith)
    exact mul_nonpos_of_nonneg_of_nonpos (terminalEpsilon_pos hp).le (sub_nonpos.mpr hl.le)

theorem terminalEpsilon_lower_at_max : terminalEpsilonLower<terminalEpsilon (14/25) := by
  have hc : (terminalEpsilonLower*(64/25:ℝ)^((64/25:ℝ)))^25<
      (4*(14/25:ℝ)^((14/25:ℝ)))^25 := by
    rw [mul_pow,mul_pow,←Real.rpow_mul_natCast (by norm_num : (0:ℝ)≤64/25),
      ←Real.rpow_mul_natCast (by norm_num : (0:ℝ)≤14/25)]
    norm_num [terminalEpsilonLower]
  have hL : 0≤terminalEpsilonLower*(64/25:ℝ)^(64/25:ℝ) := by
    dsimp only [terminalEpsilonLower]; positivity
  have hR : 0≤4*(14/25:ℝ)^(14/25:ℝ) := by positivity
  have hlt := (pow_lt_pow_iff_left₀ hL hR (by norm_num : (25:ℕ)≠0)).mp hc
  dsimp only [terminalEpsilon]
  norm_num only [show (14/25:ℝ)+2=64/25 by norm_num]
  exact (lt_div_iff₀ (by positivity : 0<(64/25:ℝ)^(64/25:ℝ))).mpr hlt

theorem terminalEpsilon_lower {p : ℝ} (hp : 0<p) (hpu : p≤14/25) :
    terminalEpsilonLower<terminalEpsilon p := by
  exact terminalEpsilon_lower_at_max.trans_le
    (terminalEpsilon_antitone hp (by norm_num : (0:ℝ)<14/25) hpu)

theorem terminalPowerMajorant_pos {p r : ℝ}
    (hp : 0<p) (hpu : p<1) (hr : 0≤r) : 0<terminalPowerMajorant p r := by
  exact (Real.rpow_pos_of_pos (by positivity : 0<1+r) p).trans_le
    (terminalPowerMajorant_rpow hp hpu hr)

theorem terminal_center_radial_lower {p r u : ℝ}
    (hpl : 1/2≤p) (hpu : p≤14/25) (hr : 0<r) (hu : 0≤u)
    (he : terminalEpsilonLower≤r^2*(1+r)^p*(1-u)) : 459/1000≤r := by
  by_contra hh
  have hrb : r<459/1000 := lt_of_not_ge hh
  have hpow1 : (1+r)^p≤(1+(459/1000:ℝ))^p :=
    Real.rpow_le_rpow (by positivity) (by linarith) (by linarith)
  have hpow2 : (1+(459/1000:ℝ))^p≤(1+(459/1000:ℝ))^(14/25:ℝ) :=
    Real.rpow_le_rpow_of_exponent_le (by norm_num) hpu
  have hpow3 := terminalPowerMajorant_rpow (p:=14/25) (r:=459/1000)
    (by norm_num) (by norm_num) (by norm_num)
  have hsq : r^2≤(459/1000:ℝ)^2 := pow_le_pow_left₀ hr.le hrb.le 2
  have hpow := hpow1.trans (hpow2.trans hpow3)
  have hstep := mul_le_mul hsq hpow (Real.rpow_nonneg (by positivity) p) (by positivity)
  have hstep' : r^2*(1+r)^p*(1-u)≤r^2*(1+r)^p := by
    exact mul_le_of_le_one_right (by positivity) (by linarith)
  have hcert : (459/1000:ℝ)^2*terminalPowerMajorant (14/25) (459/1000)<terminalEpsilonLower := by
    norm_num [terminalPowerMajorant,terminalEpsilonLower]
  linarith

theorem terminalThirdDeficit_lower {p r u : ℝ}
    (hpl : 1/2≤p) (hpu : p≤14/25) (hr : 0<r) (hu : 0≤u) (hu1 : u<1)
    (he : terminalEpsilonLower≤r^2*(1+r)^p*(1-u)) :
    p*(p+1)*terminalDeficitCubic u<terminalThirdDeficit p r := by
  have hp : 0<p := by linarith
  have hrl := terminal_center_radial_lower hpl hpu hr hu he
  have hR := terminalPowerMajorant_pos (p:=14/25) (by norm_num) (by norm_num) hr.le
  have hpow : (1+r)^p≤terminalPowerMajorant (14/25) r :=
    (Real.rpow_le_rpow_of_exponent_le (by linarith) hpu).trans
      (terminalPowerMajorant_rpow (by norm_num) (by norm_num) hr.le)
  have hstep := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hpow (sq_nonneg r))
    (by linarith : 0≤1-u)
  have hbound : u≤1-terminalEpsilonLower/(r^2*terminalPowerMajorant (14/25) r) := by
    have hd : 0<r^2*terminalPowerMajorant (14/25) r := by positivity
    have hh : terminalEpsilonLower/(r^2*terminalPowerMajorant (14/25) r)≤1-u :=
      (div_le_iff₀ hd).mpr (by nlinarith only [he,hstep])
    linarith
  have hmono := terminalDeficitCubic_mono hu (hu.trans hbound) hbound
  have hfixed := terminalDeficitLower_fixed hrl
  have hparam := terminalDeficitNormalized_antitone_parameter (by linarith : 9/20≤r)
    hpl (by norm_num : (1/2:ℝ)≤14/25) hpu
  have hh : terminalDeficitCubic u<terminalDeficitNormalized p r :=
    lt_of_le_of_lt hmono (hfixed.trans_le hparam)
  exact mul_lt_mul_of_pos_left hh (by positivity)

end LeanVerification.UpperLeftThirdCompletion
