import LeanVerification.UpperLeftThirdCompletion.TerminalPolynomials
import LeanVerification.UpperLeftThirdCompletion.ThirdAbelKernel

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open ContourCompletion ExteriorSpectralCompletion
set_option maxHeartbeats 4800000

def thirdAbelDeficitKernel (z t : ℝ) : ℝ :=
  thirdAbelMomentKernel 0 z t*terminalDeficitCubic ((abelRootRatio z t)^2)

def thirdAbelRefinedKernel (p z t : ℝ) : ℝ :=
  thirdAbelMomentKernel 0 z t-p*(p+1)*thirdAbelDeficitKernel z t

theorem thirdAbelDeficitKernel_eq (z t : ℝ) :
    thirdAbelDeficitKernel z t=
      (1783*thirdAbelMomentKernel 0 z t+1338*thirdAbelMomentKernel 1 z t+
        1061*thirdAbelMomentKernel 2 z t+873*thirdAbelMomentKernel 3 z t)/100000 := by
  dsimp only [thirdAbelDeficitKernel,thirdAbelMomentKernel,terminalDeficitCubic]
  norm_num
  ring

theorem thirdAbelDeficitKernel_integrable {z : ℝ} (hz : 0<z) :
    IntegrableOn (thirdAbelDeficitKernel z) (Ioi 0) := by
  have hh := (((((thirdAbelMomentKernel_integrable hz 0).const_mul 1783).add
    ((thirdAbelMomentKernel_integrable hz 1).const_mul 1338)).add
    ((thirdAbelMomentKernel_integrable hz 2).const_mul 1061)).add
    ((thirdAbelMomentKernel_integrable hz 3).const_mul 873)).div_const 100000
  exact hh.congr (Filter.Eventually.of_forall (fun t => (thirdAbelDeficitKernel_eq z t).symm))

theorem integral_thirdAbelDeficitKernel {z : ℝ} (hz : 0<z) :
    (∫t in Ioi (0:ℝ),thirdAbelDeficitKernel z t)=2*terminalDeficitAverage/z^3 := by
  have h0 := (thirdAbelMomentKernel_integrable hz 0).const_mul (1783:ℝ)
  have h1 := (thirdAbelMomentKernel_integrable hz 1).const_mul (1338:ℝ)
  have h2 := (thirdAbelMomentKernel_integrable hz 2).const_mul (1061:ℝ)
  have h3 := (thirdAbelMomentKernel_integrable hz 3).const_mul (873:ℝ)
  simp_rw [thirdAbelDeficitKernel_eq]
  have h01 : IntegrableOn (fun t => 1783*thirdAbelMomentKernel 0 z t+
    1338*thirdAbelMomentKernel 1 z t) (Ioi 0) := h0.add h1
  have h012 : IntegrableOn (fun t => 1783*thirdAbelMomentKernel 0 z t+
    1338*thirdAbelMomentKernel 1 z t+1061*thirdAbelMomentKernel 2 z t) (Ioi 0) := h01.add h2
  rw [integral_div,integral_add h012 h3,integral_add h01 h2,integral_add h0 h1]
  simp only [integral_const_mul,integral_thirdAbelMomentKernel hz,
    thirdAbelMoment,terminalDeficitAverage]
  norm_num
  ring

theorem thirdAbelRefinedKernel_integrable (p : ℝ) {z : ℝ} (hz : 0<z) :
    IntegrableOn (thirdAbelRefinedKernel p z) (Ioi 0) := by
  exact (thirdAbelMomentKernel_integrable hz 0).sub
    ((thirdAbelDeficitKernel_integrable hz).const_mul (p*(p+1)))

theorem integral_thirdAbelRefinedKernel (p : ℝ) {z : ℝ} (hz : 0<z) :
    (∫t in Ioi (0:ℝ),thirdAbelRefinedKernel p z t)=
      2*(1-terminalDeficitAverage*p*(p+1))/z^3 := by
  rw [show thirdAbelRefinedKernel p z=(fun t => thirdAbelMomentKernel 0 z t-
    p*(p+1)*thirdAbelDeficitKernel z t) from rfl,
    integral_sub (thirdAbelMomentKernel_integrable hz 0)
      ((thirdAbelDeficitKernel_integrable hz).const_mul (p*(p+1))),
    integral_const_mul,integral_thirdAbelDeficitKernel hz,integral_thirdAbelMomentKernel hz]
  norm_num [thirdAbelMoment]
  ring

end LeanVerification.UpperLeftThirdCompletion
