import LeanVerification.UpperLeftThirdCompletion.TerminalActualData
import LeanVerification.UpperLeftThirdCompletion.TerminalRationalProfile
import LeanVerification.UpperLeftThirdCompletion.TerminalPower
import LeanVerification.UpperLeftThirdCompletion.ThirdAbelKernel

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion ExteriorCompletion ExteriorSpectralCompletion UpperLeftCompletion RegionalComplex
set_option maxHeartbeats 6400000
set_option maxRecDepth 6000

def terminalInverseRadius (p e : ℝ) : ℝ :=
  exteriorInverse (lowAngleParameterD p 1) (lowAngleParameterF p) e/terminalSaddle p-1

theorem terminalInverseRadius_pos {p e : ℝ} (hp : 0<p) (he : 0<e) :
    0<terminalInverseRadius p e := by
  have hm : e∈exteriorRange (lowAngleParameterD p 1) (lowAngleParameterF p) := by
    rw [physical_terminal_range hp];exact he
  have hw := exteriorInverse_mem _ _ e hm
  rw [physical_terminal_saddle hp] at hw
  dsimp only [terminalInverseRadius]
  exact sub_pos.mpr ((one_lt_div (terminalSaddle_pos hp)).mpr hw)

theorem terminalInverseRadius_coordinate {p : ℝ} (hp : 0<p) (e : ℝ) :
    exteriorInverse (lowAngleParameterD p 1) (lowAngleParameterF p) e=
      terminalSaddle p*(1+terminalInverseRadius p e) := by
  dsimp only [terminalInverseRadius]
  field_simp [(terminalSaddle_pos hp).ne']

theorem actual_terminal_third_scaled {p r : ℝ} (hp : 0<p) (hr : 0<r) :
    let D := lowAngleParameterD p 1
    let F := lowAngleParameterF p
    let w := terminalSaddle p*(1+r)
    let e := exteriorEnergy D F w
    (e^3*Real.sqrt e)*exteriorDensityJet D F
      (lowAngleParameterD_lt_neg_one hp (by norm_num)) (lowAngleParameterF_gt_one hp) 3 e=
      Real.sqrt (terminalSaddle p/2)*terminalThirdScaled p r := by
  dsimp only
  let w := terminalSaddle p*(1+r)
  have hw : terminalSaddle p<w := by
    dsimp only [w]
    nlinarith [mul_pos (terminalSaddle_pos hp) hr]
  have hw' : exteriorSaddle (lowAngleParameterD p 1)<w := by
    rw [physical_terminal_saddle hp]
    exact hw
  have hs : p*terminalSaddle p=p+2 := by dsimp only [terminalSaddle];field_simp
  have hwc : p*w=(p+2)*(1+r) := by dsimp only [w];rw [←mul_assoc,hs]
  have hrational := terminalThirdScaled_rational_of_coordinate hp hr.le hs hwc
  rw [actual_rationalJet_three _ _ _
    (lowAngleParameterD_lt_neg_one hp (by norm_num)) (lowAngleParameterF_gt_one hp) hw',
    physical_terminal_saddle hp,
    show 2*lowAngleParameterF p-2=p by dsimp only [lowAngleParameterF];ring,
    show -(lowAngleParameterD p 1+1)=p/2 by dsimp only [lowAngleParameterD];ring,
    physical_terminal_energy hp ((terminalSaddle_pos hp).trans hw),
    terminal_scaled_rationalJet hp hw,hrational]

theorem actual_terminal_third_jet_eq {p e : ℝ} (hp : 0<p) (he : 0<e) :
    exteriorDensityJet (lowAngleParameterD p 1) (lowAngleParameterF p)
      (lowAngleParameterD_lt_neg_one hp (by norm_num)) (lowAngleParameterF_gt_one hp) 3 e=
      Real.sqrt (terminalSaddle p/2)*terminalThirdScaled p (terminalInverseRadius p e)/
        (e^3*Real.sqrt e) := by
  have hr := terminalInverseRadius_pos hp he
  have hm : e∈exteriorRange (lowAngleParameterD p 1) (lowAngleParameterF p) := by
    rw [physical_terminal_range hp];exact he
  have hh := actual_terminal_third_scaled hp hr
  dsimp only at hh
  rw [←terminalInverseRadius_coordinate hp,exteriorEnergy_inverse _ _ _ hm] at hh
  apply (eq_div_iff (mul_ne_zero (pow_ne_zero _ he.ne') (Real.sqrt_pos.mpr he).ne')).mpr
  simpa only [mul_comm] using hh

theorem terminal_energy_coordinate {p e : ℝ} (hp : 0<p) (he : 0<e) :
    e=terminalQuadratic p*(terminalSaddle p)^(p+2)*
      (terminalInverseRadius p e)^2*(1+terminalInverseRadius p e)^p := by
  have hr := terminalInverseRadius_pos hp he
  have hs := terminalSaddle_pos hp
  have hm : e∈exteriorRange (lowAngleParameterD p 1) (lowAngleParameterF p) := by
    rw [physical_terminal_range hp];exact he
  have hE := exteriorEnergy_inverse (lowAngleParameterD p 1) (lowAngleParameterF p) e hm
  rw [terminalInverseRadius_coordinate hp,physical_terminal_energy hp (by positivity),
    Real.mul_rpow hs.le (by positivity)] at hE
  rw [Real.rpow_add hs,Real.rpow_two]
  linear_combination -hE

theorem terminalEpsilon_normalization {p : ℝ} (hp : 0<p) :
    terminalQuadratic p*(terminalSaddle p)^(p+2)*terminalEpsilon p=lowAngleDeficit p 1 := by
  have hp2 : 0<p+2 := by positivity
  rw [lowAngleDeficit_terminal hp]
  dsimp only [terminalQuadratic,terminalSaddle,terminalEpsilon]
  rw [Real.div_rpow hp2.le hp.le,Real.rpow_add hp,Real.rpow_two]
  have hpw := (Real.rpow_pos_of_pos hp p).ne'
  have hp2w := (Real.rpow_pos_of_pos hp2 (p+2)).ne'
  field_simp
  <;> ring

theorem terminal_center_coordinate_identity {p t : ℝ} (hp : 0<p) (ht : 0≤t) :
    let H := lowAngleDeficit p 1
    let r := terminalInverseRadius p (H+t)
    r^2*(1+r)^p*(1-(abelRootRatio H t)^2)=terminalEpsilon p := by
  dsimp only
  have hH : 0<lowAngleDeficit p 1 := lowAngleDeficit_pos hp (by norm_num)
  have he := terminal_energy_coordinate hp (add_pos_of_pos_of_nonneg hH ht)
  have hnorm := terminalEpsilon_normalization hp
  have hr := terminalInverseRadius_pos hp (add_pos_of_pos_of_nonneg hH ht)
  have hA : 0<terminalQuadratic p*(terminalSaddle p)^(p+2) := by
    exact mul_pos (terminalQuadratic_pos hp) (Real.rpow_pos_of_pos (terminalSaddle_pos hp) _)
  rw [abelRootRatio_sq hH ht]
  apply (mul_left_cancel₀ hA.ne')
  rw [show terminalQuadratic p*(terminalSaddle p)^(p+2)*
      ((terminalInverseRadius p (lowAngleDeficit p 1+t))^2*
        (1+terminalInverseRadius p (lowAngleDeficit p 1+t))^p*
          (1-t/(lowAngleDeficit p 1+t)))=
      (terminalQuadratic p*(terminalSaddle p)^(p+2)*
        (terminalInverseRadius p (lowAngleDeficit p 1+t))^2*
          (1+terminalInverseRadius p (lowAngleDeficit p 1+t))^p)*
            (1-t/(lowAngleDeficit p 1+t)) by ring,
    ←he,hnorm]
  field_simp
  <;> ring

end LeanVerification.UpperLeftThirdCompletion
