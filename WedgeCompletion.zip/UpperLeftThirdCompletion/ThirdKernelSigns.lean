import LeanVerification.UpperLeftThirdCompletion.ThirdKernelMass

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open ContourCompletion UpperLeftCompletion
set_option maxHeartbeats 2400000

theorem continuous_weightedThirdKernel {a θ : ℝ} (ha : 0≤a)
    (hθ : 0<θ) (hθu : θ<Real.pi) : Continuous (weightedThirdKernel a θ) := by
  exact (Real.continuous_rpow_const ha).mul (continuous_rayMomentKernel hθ hθu)

theorem third_phase_exists {θ γ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi)
    (hγl : -θ/2<γ) (hγu : γ<3*θ) :
    ∃v : ℝ,0<v ∧ rayMomentPhase 3 θ v=γ := by
  have he : ∀ᶠ v in atTop,γ<rayMomentPhase 3 θ v :=
    (rayMomentPhase_tendsto (k:=3) hθ hθu).eventually
      (Ioi_mem_nhds (by simpa using hγu))
  obtain ⟨R,hR,hPR⟩ := (eventually_gt_atTop (0:ℝ) |>.and he).exists
  have hP0 : rayMomentPhase 3 θ 0<γ := by
    rw [rayMomentPhase_zero hθ hθu]
    exact hγl
  obtain ⟨v,hv,hphase⟩ := intermediate_value_Ioo hR.le
    (continuous_rayMomentPhase hθ hθu).continuousOn ⟨hP0,hPR⟩
  exact ⟨v,hv.1,hphase⟩

theorem thirdKernel_two_crossings {p : ℝ} (hpl : 2/5≤p) (hpu : p<1/2) :
    ∃a b : ℝ,0<a ∧ a<b ∧
      (∀v,0<v → v<a → 0<weightedThirdKernel (1/p-1/2) (Real.pi*(1-p)) v) ∧
      (∀v,a<v → v<b → weightedThirdKernel (1/p-1/2) (Real.pi*(1-p)) v<0) ∧
      (∀v,b<v → 0<weightedThirdKernel (1/p-1/2) (Real.pi*(1-p)) v) := by
  let θ := Real.pi*(1-p)
  have hp : 0<p := by linarith
  have hθ : 0<θ := mul_pos Real.pi_pos (by linarith)
  have hθu : θ<Real.pi := by dsimp only [θ];nlinarith [Real.pi_pos]
  have hlim : 3*Real.pi/2<3*θ := by dsimp only [θ];nlinarith [Real.pi_pos]
  have hmax : 3*θ<2*Real.pi := by dsimp only [θ];nlinarith [Real.pi_pos]
  obtain ⟨a,ha,hphaseA⟩ := third_phase_exists hθ hθu
    (show -θ/2<Real.pi/2 by linarith [Real.pi_pos]) (show Real.pi/2<3*θ by linarith [Real.pi_pos])
  obtain ⟨b,hb,hphaseB⟩ := third_phase_exists hθ hθu
    (show -θ/2<3*Real.pi/2 by linarith [Real.pi_pos]) hlim
  have hab : a<b := by
    by_contra h
    have hh := (rayMomentPhase_strictMono (k:=3) hθ hθu).monotone (le_of_not_gt h)
    rw [hphaseA,hphaseB] at hh
    linarith [Real.pi_pos]
  refine ⟨a,b,ha,hab,?_,?_,?_⟩
  · intro v hv hva
    apply mul_pos (Real.rpow_pos_of_pos hv _)
    rw [rayMomentKernel_phase_identity]
    apply mul_pos (Real.exp_pos _)
    apply Real.cos_pos_of_mem_Ioo
    constructor
    · have hh := (rayMomentPhase_bounds (k:=3) hθ hθu hv).1
      linarith
    · have hh := rayMomentPhase_strictMono (k:=3) hθ hθu hva
      rwa [hphaseA] at hh
  · intro v hav hvb
    have hv : 0<v := ha.trans hav
    apply mul_neg_of_pos_of_neg (Real.rpow_pos_of_pos hv _)
    rw [rayMomentKernel_phase_identity]
    apply mul_neg_of_pos_of_neg (Real.exp_pos _)
    apply Real.cos_neg_of_pi_div_two_lt_of_lt
    · have hh := rayMomentPhase_strictMono (k:=3) hθ hθu hav
      rwa [hphaseA] at hh
    · have hh := rayMomentPhase_strictMono (k:=3) hθ hθu hvb
      rw [hphaseB] at hh
      linarith
  · intro v hbv
    have hv : 0<v := hb.trans hbv
    apply mul_pos (Real.rpow_pos_of_pos hv _)
    rw [rayMomentKernel_phase_identity,←Real.cos_sub_two_pi]
    apply mul_pos (Real.exp_pos _)
    apply Real.cos_pos_of_mem_Ioo
    have hlo := rayMomentPhase_strictMono (k:=3) hθ hθu hbv
    rw [hphaseB] at hlo
    have hhi := (rayMomentPhase_bounds (k:=3) hθ hθu hv).2
    norm_num only [Nat.cast_ofNat] at hhi
    constructor <;> linarith [Real.pi_pos]

theorem thirdKernel_terminal_single_crossing :
    ∃a : ℝ,0<a ∧
      (∀v,0<v → v<a → 0<weightedThirdKernel (3/2) (Real.pi/2) v) ∧
      (∀v,a<v → weightedThirdKernel (3/2) (Real.pi/2) v<0) := by
  have hθ : 0<Real.pi/2 := by linarith [Real.pi_pos]
  have hθu : Real.pi/2<Real.pi := by linarith [Real.pi_pos]
  obtain ⟨a,ha,hphase,hzero,hleft,hright⟩ := rayMomentKernel_single_crossing
    (k:=3) hθ hθu (by norm_num;nlinarith [Real.pi_pos]) (by norm_num;linarith)
  exact ⟨a,ha,(fun v hv hva => mul_pos (Real.rpow_pos_of_pos hv _) (hleft v hv hva)),
    fun v hav => mul_neg_of_pos_of_neg (Real.rpow_pos_of_pos (ha.trans hav) _) (hright v hav)⟩

theorem integral_weightedThirdKernel_terminal_neg :
    (∫v in Ioi (0:ℝ),weightedThirdKernel (3/2) (Real.pi/2) v)<0 := by
  rw [integral_weightedThirdKernel (by norm_num : (-1:ℝ)<3/2)
    (by norm_num : (3/2:ℝ)<5/2) (by linarith [Real.pi_pos]) (by linarith [Real.pi_pos])]
  rw [show ((3/2:ℝ)+1/2)*(Real.pi/2)=Real.pi by ring,Real.cos_pi,mul_neg_one]
  exact neg_neg_of_pos (powerCauchyMass_pos (by norm_num) (by norm_num) (by norm_num))

end LeanVerification.UpperLeftThirdCompletion
