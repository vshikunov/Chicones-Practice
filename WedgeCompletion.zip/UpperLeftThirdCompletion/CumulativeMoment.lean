import LeanVerification.UpperLeftThirdCompletion.ThirdCumulative
import LeanVerification.UpperLeftCompletion.RayMomentDensityTransfer

/-! Complete improper integration by parts for the actual third ray
moment. Both endpoint products vanish, and both integrals converge
absolutely. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion UpperLeftCompletion
set_option maxHeartbeats 3800000

def thirdScaledRayMoment (p l σ : ℝ) : ℝ :=
  ∫v in Ioi (0:ℝ),rayMomentKernel 3 (Real.pi*(1-p)) v*densityOrderDensity p l (σ*v)

theorem integrable_thirdScaledRayMoment {p l σ : ℝ}
    (hp : 0<p) (hpu : p<1) (hl : 0<l) (hσ : 0<σ) :
    IntegrableOn (fun v => rayMomentKernel 3 (Real.pi*(1-p)) v*densityOrderDensity p l (σ*v))
      (Ioi 0) := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hAp : 0<lowAngleA p l := by dsimp only [lowAngleA];positivity
  have hi := integrable_rayNormalizedMoment 3 (by norm_num) hp hpu hAp hB hC
    (mul_pos (lowAngleDeficit_pos hp hl.le) hσ)
  convert hi using 1
  funext v
  dsimp only [densityOrderDensity]
  rw [mul_assoc]

theorem third_ray_rho_identity {p l σ v : ℝ} (hσ : 0<σ) (hv : 0<v) :
    rayMomentKernel 3 (Real.pi*(1-p)) v*densityOrderDensity p l (σ*v)=
      σ^(densityDerivativeAlpha p)*(physicalWeightedThirdKernel p v*
        derivativeDensityRho p l (σ*v)) := by
  dsimp only [physicalWeightedThirdKernel,weightedThirdKernel,derivativeDensityRho]
  rw [Real.mul_rpow hσ.le hv.le]
  have hpowσ := (Real.rpow_pos_of_pos hσ (densityDerivativeAlpha p)).ne'
  have hpowv := (Real.rpow_pos_of_pos hv (densityDerivativeAlpha p)).ne'
  field_simp
  <;> ring

theorem integrable_third_weighted_rho {p l σ : ℝ}
    (hp : 0<p) (hpu : p<1) (hl : 0<l) (hσ : 0<σ) :
    IntegrableOn (fun v => physicalWeightedThirdKernel p v*derivativeDensityRho p l (σ*v)) (Ioi 0) := by
  have hi := integrable_thirdScaledRayMoment hp hpu hl hσ
  have he : IntegrableOn (fun v => σ^(densityDerivativeAlpha p)*
      (physicalWeightedThirdKernel p v*derivativeDensityRho p l (σ*v))) (Ioi 0) := by
    exact hi.congr_fun (fun v hv => third_ray_rho_identity hσ hv) measurableSet_Ioi
  exact (integrable_const_mul_iff
    (isUnit_iff_ne_zero.mpr (Real.rpow_pos_of_pos hσ (densityDerivativeAlpha p)).ne') _).mp he

theorem thirdScaledRayMoment_rho {p l σ : ℝ} (hσ : 0<σ) :
    thirdScaledRayMoment p l σ=σ^(densityDerivativeAlpha p)*
      (∫v in Ioi (0:ℝ),physicalWeightedThirdKernel p v*derivativeDensityRho p l (σ*v)) := by
  rw [thirdScaledRayMoment,←integral_const_mul]
  apply setIntegral_congr_fun measurableSet_Ioi
  intro v hv
  exact third_ray_rho_identity hσ hv

theorem derivativeDensityRho_scaled_zero_limit {p l σ : ℝ}
    (hp : 0<p) (hl : 0<l) (hσ : 0<σ) :
    Tendsto (fun v => derivativeDensityRho p l (σ*v)) (𝓝[>] (0:ℝ))
      (𝓝 (derivativeDensityRadialRho p l 0)) := by
  apply (derivativeDensityRho_tendsto_zero_endpoint hp hl).comp
  apply tendsto_nhdsWithin_iff.mpr
  constructor
  · have hh : Tendsto (fun v : ℝ => σ*v) (𝓝 0) (𝓝 (σ*0)) :=
      (continuousAt_const.mul continuousAt_id).tendsto
    simpa only [mul_zero] using hh.mono_left (show 𝓝[>] (0:ℝ)≤𝓝 0 from nhdsWithin_le_nhds)
  · filter_upwards [self_mem_nhdsWithin] with v hv
    exact mul_pos hσ hv

theorem derivativeDensityRho_scaled_infty_limit {p l σ : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) (hσ : 0<σ) :
    Tendsto (fun v => derivativeDensityRho p l (σ*v)) atTop (𝓝 0) := by
  exact (derivativeDensityRho_tendsto_atTop hp hp2 hl).comp (tendsto_id.const_mul_atTop hσ)

theorem third_cumulative_zero_bank {p l σ : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) (hl : 0<l) (hσ : 0<σ) :
    Tendsto (fun v => thirdCumulativeKernel p v*derivativeDensityRho p l (σ*v))
      (𝓝[>] (0:ℝ)) (𝓝 0) := by
  have hh := (thirdCumulativeKernel_tendsto_zero hpl hpu).mul
    (derivativeDensityRho_scaled_zero_limit (p:=p) (by linarith) hl hσ)
  simpa only [zero_mul] using hh

theorem third_cumulative_infty_bank {p l σ : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) (hl : 0<l) (hσ : 0<σ) :
    Tendsto (fun v => thirdCumulativeKernel p v*derivativeDensityRho p l (σ*v))
      atTop (𝓝 0) := by
  have hh := (thirdCumulativeKernel_tendsto_atTop hpl hpu).mul
    (derivativeDensityRho_scaled_infty_limit (p:=p) (by linarith) (by linarith) hl hσ)
  simpa only [mul_zero] using hh

theorem third_weighted_rho_integral_by_parts {p l σ : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) (hl : 0<l) (hσ : 0<σ) :
    (∫v in Ioi (0:ℝ),physicalWeightedThirdKernel p v*derivativeDensityRho p l (σ*v))=
      σ*(∫v in Ioi (0:ℝ),thirdCumulativeKernel p v*derivativeDensityWeight p l (σ*v)) := by
  have hp : 0<p := by linarith
  have hu : ∀v∈Ioi (0:ℝ),HasDerivAt (thirdCumulativeKernel p)
      (physicalWeightedThirdKernel p v) v :=
    fun v hv => thirdCumulativeKernel_hasDerivAt hpl hpu hv
  have hv : ∀v∈Ioi (0:ℝ),HasDerivAt (fun v => derivativeDensityRho p l (σ*v))
      (-σ*derivativeDensityWeight p l (σ*v)) v := by
    intro v hv
    convert (hasDerivAt_derivativeDensityRho hp hl (mul_pos hσ hv)).comp v
      ((hasDerivAt_id v).const_mul σ) using 1 <;> simp only [Function.comp_def,id_eq,one_mul,mul_comm] <;> ring
  have hi := thirdCumulative_weight_integrable hpl hpu hl hσ
  have huv : IntegrableOn (fun v => thirdCumulativeKernel p v*
      (-σ*derivativeDensityWeight p l (σ*v))) (Ioi 0) := by
    exact (hi.const_mul (-σ)).congr (Filter.Eventually.of_forall (fun v => by ring))
  have he := integral_Ioi_mul_deriv_eq_deriv_mul hu hv huv
    (integrable_third_weighted_rho hp (by linarith) hl hσ)
    (third_cumulative_zero_bank hpl hpu hl hσ) (third_cumulative_infty_bank hpl hpu hl hσ)
  have hfun : (fun v => thirdCumulativeKernel p v*(-σ*derivativeDensityWeight p l (σ*v)))=
      (fun v => -σ*(thirdCumulativeKernel p v*derivativeDensityWeight p l (σ*v))) := by
    funext v;ring
  rw [hfun,integral_const_mul] at he
  linarith only [he]

theorem thirdScaledRayMoment_cumulative {p l σ : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) (hl : 0<l) (hσ : 0<σ) :
    thirdScaledRayMoment p l σ=σ^(densityDerivativeAlpha p+1)*
      (∫v in Ioi (0:ℝ),thirdCumulativeKernel p v*derivativeDensityWeight p l (σ*v)) := by
  rw [thirdScaledRayMoment_rho hσ,third_weighted_rho_integral_by_parts hpl hpu hl hσ,
    Real.rpow_add hσ,Real.rpow_one]
  ring

end LeanVerification.UpperLeftThirdCompletion
