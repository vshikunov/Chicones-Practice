import LeanVerification.UpperLeftThirdCompletion.TerminalPolynomials

/-! The rational terminal third-jet profile is the actual exterior
inverse density derivative in the physical Loud coordinates. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion ExteriorCompletion ExteriorSpectralCompletion UpperLeftCompletion RegionalComplex
set_option maxHeartbeats 9600000
set_option maxRecDepth 6000

def terminalSaddle (p : ℝ) : ℝ := (p+2)/p
def terminalQuadratic (p : ℝ) : ℝ := p/(2*(p+2))

theorem terminalSaddle_pos {p : ℝ} (hp : 0<p) : 0<terminalSaddle p := by
  dsimp only [terminalSaddle]
  positivity

theorem terminalSaddle_gt_one {p : ℝ} (hp : 0<p) : 1<terminalSaddle p := by
  dsimp only [terminalSaddle]
  exact (one_lt_div hp).mpr (by linarith)

theorem terminalQuadratic_pos {p : ℝ} (hp : 0<p) : 0<terminalQuadratic p := by
  dsimp only [terminalQuadratic]
  positivity

theorem terminalQuadratic_saddle {p : ℝ} (hp : 0<p) :
    2*terminalQuadratic p*terminalSaddle p=1 := by
  dsimp only [terminalQuadratic,terminalSaddle]
  have hp2 : p+2≠0 := by positivity
  field_simp
  ring

theorem physical_terminal_saddle {p : ℝ} (hp : 0<p) :
    exteriorSaddle (lowAngleParameterD p 1)=terminalSaddle p := by
  rw [physical_lowAngle_saddle _ _ (lowAngleParameterD_lt_neg_one hp (by norm_num))
    (lowAngleParameterF_gt_one hp),lowAngleParameter_rayP,lowAngleParameter_rayLambda hp,
    lowAngleSaddle_terminal]
  rfl

theorem physical_terminal_energy {p w : ℝ} (hp : 0<p) (hw : 0<w) :
    exteriorEnergy (lowAngleParameterD p 1) (lowAngleParameterF p) w=
      terminalQuadratic p*w^p*(w-terminalSaddle p)^2 := by
  have hF := lowAngleParameterF_gt_one hp
  have he := exteriorEnergy_factorization (lowAngleParameterD p 1) (lowAngleParameterF p) w hF hw
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients (lowAngleParameterD p 1) (lowAngleParameterF p) hF
  rw [hA,hB,hC,show 2*lowAngleParameterF p-2=upperLeftRayP (lowAngleParameterF p) from rfl,
    lowAngleParameter_rayP,lowAngleParameter_rayLambda hp] at he
  rw [he]
  dsimp only [terminalQuadratic,terminalSaddle,lowAngleA,lowAngleB,lowAngleC]
  have hp1 : p+1≠0 := by positivity
  have hp2 : p+2≠0 := by positivity
  field_simp
  <;> ring

theorem physical_terminal_energy_saddle {p : ℝ} (hp : 0<p) :
    exteriorEnergy (lowAngleParameterD p 1) (lowAngleParameterF p)
      (exteriorSaddle (lowAngleParameterD p 1))=0 := by
  rw [physical_terminal_saddle hp,physical_terminal_energy hp (terminalSaddle_pos hp)]
  simp

theorem physical_terminal_range {p : ℝ} (hp : 0<p) :
    exteriorRange (lowAngleParameterD p 1) (lowAngleParameterF p)=Ioi 0 := by
  rw [exteriorRange_eq _ _ (lowAngleParameterD_lt_neg_one hp (by norm_num))
    (lowAngleParameterF_gt_one hp),physical_terminal_energy_saddle hp]

theorem terminal_scaled_rationalJet {p w : ℝ} (hp : 0<p)
    (hw : terminalSaddle p<w) :
    ((terminalQuadratic p*w^p*(w-terminalSaddle p)^2)^3*
      Real.sqrt (terminalQuadratic p*w^p*(w-terminalSaddle p)^2))*
        rationalJet (1-7*p/2) (8*(p/2)^4) (terminalSaddle p) 7
          (thirdJetNumerator p (terminalSaddle p)) w=
      Real.sqrt (terminalSaddle p/2)*
        (w*thirdJetNumerator p (terminalSaddle p) w/
          (4*(p+2)^4*(w-1)^7)) := by
  have hs := terminalSaddle_pos hp
  have ha := terminalQuadratic_pos hp
  have hw0 : 0<w := hs.trans hw
  have hgap : 0<w-terminalSaddle p := sub_pos.mpr hw
  have hw1 : w-1≠0 := (sub_pos.mpr ((terminalSaddle_gt_one hp).trans hw)).ne'
  have hp2 : p+2≠0 := by positivity
  have hpw : Real.sqrt (w^p)=w^(p/2) := by
    rw [Real.sqrt_eq_rpow,←Real.rpow_mul hw0.le]
    congr 1
    ring
  have hroot : Real.sqrt (terminalQuadratic p*w^p*(w-terminalSaddle p)^2)=
      Real.sqrt (terminalQuadratic p)*w^(p/2)*(w-terminalSaddle p) := by
    rw [Real.sqrt_mul (mul_nonneg ha.le (Real.rpow_nonneg hw0.le _)),
      Real.sqrt_mul ha.le,Real.sqrt_sq_eq_abs,abs_of_pos hgap,hpw]
  have hpow : (w^p)^3*w^(p/2)*w^(1-7*p/2)=w := by
    rw [←Real.rpow_mul_natCast hw0.le,←Real.rpow_add hw0,←Real.rpow_add hw0]
    convert Real.rpow_one w using 2 <;> ring
  have hroots : Real.sqrt (terminalSaddle p/2)=
      terminalSaddle p*Real.sqrt (terminalQuadratic p) := by
    have he : terminalSaddle p/2=(terminalSaddle p)^2*terminalQuadratic p := by
      dsimp only [terminalSaddle,terminalQuadratic]
      field_simp
      <;> ring
    rw [he,Real.sqrt_mul (sq_nonneg _),Real.sqrt_sq_eq_abs,abs_of_pos hs]
  rw [hroot,hroots]
  dsimp only [rationalJet,saddleDenominator]
  have hpoly :
      (terminalQuadratic p*w^p*(w-terminalSaddle p)^2)^3*
        (Real.sqrt (terminalQuadratic p)*w^(p/2)*(w-terminalSaddle p))*
        (w^(1-7*p/2)*thirdJetNumerator p (terminalSaddle p) w/
          (8*(p/2)^4*((w-1)*(w-terminalSaddle p))^7))=
      (terminalQuadratic p)^3*Real.sqrt (terminalQuadratic p)*
        ((w^p)^3*w^(p/2)*w^(1-7*p/2))*thirdJetNumerator p (terminalSaddle p) w/
          (8*(p/2)^4*(w-1)^7) := by
    field_simp
    <;> ring
  rw [hpoly,hpow]
  dsimp only [terminalQuadratic,terminalSaddle]
  field_simp
  <;> ring


end LeanVerification.UpperLeftThirdCompletion
