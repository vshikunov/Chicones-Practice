import LeanVerification.ContourCompletion.FractionalStieltjes

/-! Actual power-weighted Cauchy integrals on the principal slit plane.
The normalization is a positive convergent real integral. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open ContourCompletion
set_option maxHeartbeats 2400000

def powerCauchyWeight (a b t : ℝ) : ℝ := t^a*(1+t)^(-b)
def powerCauchyMass (a b : ℝ) : ℝ := ∫t in Ioi (0:ℝ),powerCauchyWeight a b t
def powerCauchy (a b : ℝ) (z : ℂ) : ℂ :=
  Cauchy.complexTransform (volume.restrict (Ioi 0)) (fun t => t^a) b z

theorem powerCauchyWeight_integrable {a b : ℝ}
    (ha : -1<a) (hab : a+1<b) (hb : 0<b) :
    IntegrableOn (powerCauchyWeight a b) (Ioi 0) := by
  rw [←Ioc_union_Ioi_eq_Ioi (show (0:ℝ)≤1 by norm_num),integrableOn_union]
  have hm : Measurable (powerCauchyWeight a b) := by unfold powerCauchyWeight;fun_prop
  constructor
  · have hi : IntegrableOn (fun t : ℝ => t^a) (Ioc 0 1) :=
      (intervalIntegral.intervalIntegrable_rpow' ha :
        IntervalIntegrable (fun t : ℝ => t^a) volume 0 1).1
    apply hi.mono' hm.aestronglyMeasurable
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with t ht
    dsimp only [powerCauchyWeight]
    have ht0 : 0<t := ht.1
    rw [Real.norm_of_nonneg (by positivity : 0≤t^a*(1+t)^(-b))]
    exact mul_le_of_le_one_right (Real.rpow_nonneg ht.1.le _)
      (Real.rpow_le_one_of_one_le_of_nonpos (by linarith [ht.1]) (by linarith))
  · have hi := integrableOn_Ioi_rpow_of_lt (by linarith : a-b< -1)
      (show (0:ℝ)<1 by norm_num)
    apply hi.mono' hm.aestronglyMeasurable
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    have ht0 : 0<t := lt_trans zero_lt_one ht
    dsimp only [powerCauchyWeight]
    rw [Real.norm_of_nonneg (by positivity : 0≤t^a*(1+t)^(-b)),
      Real.rpow_sub ht0,div_eq_mul_inv,←Real.rpow_neg ht0.le]
    apply mul_le_mul_of_nonneg_left _ (Real.rpow_nonneg ht0.le _)
    exact Real.rpow_le_rpow_of_nonpos ht0 (by linarith) (by linarith)

theorem powerCauchyMass_pos {a b : ℝ}
    (ha : -1<a) (hab : a+1<b) (hb : 0<b) : 0<powerCauchyMass a b := by
  have hn : 0≤ᵐ[volume.restrict (Ioi (0:ℝ))] powerCauchyWeight a b := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    have ht0 : 0<t := ht
    dsimp only [powerCauchyWeight]
    positivity
  apply (setIntegral_pos_iff_support_of_nonneg_ae hn
    (powerCauchyWeight_integrable ha hab hb)).mpr
  have he : Function.support (powerCauchyWeight a b) ∩ Ioi (0:ℝ)=Ioi 0 := by
    ext t
    constructor
    · exact fun h => h.2
    · intro ht
      refine ⟨?_,ht⟩
      apply ne_of_gt
      have ht0 : 0<t := ht
      dsimp only [powerCauchyWeight]
      positivity
  rw [he]
  simp

theorem powerCauchy_integral_real (a b : ℝ) {x : ℝ} (hx : 0<x) :
    (∫t in Ioi (0:ℝ),t^a*(x+t)^(-b))=x^(a+1-b)*powerCauchyMass a b := by
  have hs := integral_comp_mul_left_Ioi (fun t : ℝ => t^a*(x+t)^(-b)) 0 hx
  simp only [mul_zero,smul_eq_mul] at hs
  have he : (∫t in Ioi (0:ℝ),(x*t)^a*(x+x*t)^(-b))=
      (x^a*x^(-b))*powerCauchyMass a b := by
    rw [powerCauchyMass,←integral_const_mul]
    apply setIntegral_congr_fun measurableSet_Ioi
    intro t ht
    dsimp only
    have ht0 : 0<t := ht
    rw [show x+x*t=x*(1+t) by ring,
      Real.mul_rpow hx.le ht.le,Real.mul_rpow hx.le (by linarith : 0≤1+t)]
    dsimp only [powerCauchyWeight]
    ring
  calc
    _=x*(∫t in Ioi (0:ℝ),(x*t)^a*(x+x*t)^(-b)) := by rw [hs]; field_simp
    _=x*((x^a*x^(-b))*powerCauchyMass a b) := by rw [he]
    _=x^(a+1-b)*powerCauchyMass a b := by
      rw [show x*((x^a*x^(-b))*powerCauchyMass a b)=
        (x^a*x*x^(-b))*powerCauchyMass a b by ring,
        show x^a*x*x^(-b)=x^(a+1-b) by
          calc
            _=x^a*x^(1:ℝ)*x^(-b) := by rw [Real.rpow_one]
            _=_ := by rw [←Real.rpow_add hx,←Real.rpow_add hx];congr 1 <;> ring]

theorem powerCauchy_analytic {a b : ℝ}
    (ha : -1<a) (hab : a+1<b) (hb : 0<b) :
    AnalyticOnNhd ℂ (powerCauchy a b) Complex.slitPlane := by
  intro z hz
  apply Cauchy.analyticAt_complexTransform hb hz (measurable_id.pow_const a)
  · filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact ht.le
  · exact powerCauchyWeight_integrable ha hab hb

theorem powerCauchy_integrable {a b : ℝ}
    (ha : -1<a) (hab : a+1<b) (hb : 0<b) {z : ℂ} (hz : z∈Complex.slitPlane) :
    IntegrableOn (Cauchy.complexKernel (fun t => t^a) b z) (Ioi 0) := by
  apply Cauchy.integrable_complexTransform hb.le hz (measurable_id.pow_const a)
  · filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact ht.le
  · exact powerCauchyWeight_integrable ha hab hb

theorem powerCauchy_eq_cpow {a b : ℝ}
    (ha : -1<a) (hab : a+1<b) (hb : 0<b) {z : ℂ} (hz : z∈Complex.slitPlane) :
    powerCauchy a b z=(powerCauchyMass a b:ℂ)*z^((a+1-b:ℝ):ℂ) := by
  have hg : AnalyticOnNhd ℂ (fun z : ℂ =>
      (powerCauchyMass a b:ℂ)*z^((a+1-b:ℝ):ℂ)) Complex.slitPlane := by
    intro z hz
    exact analyticAt_const.mul (analyticAt_id.cpow analyticAt_const hz)
  apply RealComplexification.eqOn_of_eqOn_real_slice (powerCauchy_analytic ha hab hb)
    hg Complex.isOpen_slitPlane isPreconnected_slitPlane (r:=1) (by simp) ?_ hz
  intro x hx
  have hx0 := Complex.ofReal_mem_slitPlane.mp hx
  rw [powerCauchy,Cauchy.complexTransform_ofReal hx0 (by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact ht.le)]
  dsimp only [Cauchy.transform]
  rw [powerCauchy_integral_real a b hx0,←Complex.ofReal_cpow hx0.le]
  push_cast
  ring

end LeanVerification.UpperLeftThirdCompletion
