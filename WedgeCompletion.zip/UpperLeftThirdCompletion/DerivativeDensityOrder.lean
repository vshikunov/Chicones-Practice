import LeanVerification.UpperLeftThirdCompletion.DerivativeDensityBasic

/-! Strict likelihood-ratio order for the actual positive derivative measure.
The parameter derivative is derived by commuting the mixed derivatives of
the jointly analytic density, and not supplied as a measure hypothesis. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion UpperLeftCompletion AnalyticTwoPartials
set_option maxHeartbeats 3200000
set_option maxRecDepth 5000

theorem hasDerivAt_derivativeDensityWeight_parameter {p l v : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) (hv : 0<v) :
    HasDerivAt (fun t => derivativeDensityWeight p t v)
      (derivativeDensityWeight p l v*
        densityDerivativeScore p l (densityOrderInverse p l v)) l := by
  let f : ℝ×ℝ→ℝ := fun q => derivativeDensityRho p q.1 q.2
  let r := densityOrderInverse p l v
  have hr : 0<r := densityOrderInverse_pos hp hl hv
  have ha : AnalyticAt ℝ f (l,v) := analyticAt_derivativeDensityRho hp hl hv
  have hs : HasDerivAt (fun x => densityOrderScore p l (densityOrderInverse p l x))
      (-densityDerivativeA p l r*derivativeDensityRadialSpeed p l v) v := by
    have hS : HasDerivAt (densityOrderScore p l) (-densityDerivativeA p l r) r := by
      convert hasDerivAt_densityOrderScore hp hl hr using 1
      unfold densityDerivativeA
      ring
    exact hS.comp v (hasDerivAt_densityOrderInverse_energy hp hl hv)
  have hprod := (hasDerivAt_derivativeDensityRho hp hl hv).mul hs
  have he : (fun x => left f (l,x))=ᶠ[𝓝 v]
      (fun x => derivativeDensityRho p l x*
        densityOrderScore p l (densityOrderInverse p l x)) := by
    filter_upwards [Ioi_mem_nhds hv] with x hx
    exact (hasDerivAt_derivativeDensityRho_parameter hp hl hx).deriv
  have hval : right (left f) (l,v)=
      -derivativeDensityWeight p l v*densityOrderScore p l r+
        derivativeDensityRho p l v*
          (-densityDerivativeA p l r*derivativeDensityRadialSpeed p l v) :=
    (hprod.congr_of_eventuallyEq he).deriv
  have hd := ((analyticAt_right ha).curry_left.differentiableAt.hasDerivAt).neg
  change HasDerivAt (fun t => derivativeDensityWeight p t v)
    (-left (right f) (l,v)) l at hd
  rw [mixed_partials_commute ha,hval] at hd
  convert hd using 1
  unfold densityDerivativeScore
  rw [derivativeDensityWeight_formula hp hl hv]
  have hc := (densityDerivativeC_pos hp hp2 hl hr).ne'
  change _= _
  dsimp only [r] at hc ⊢
  field_simp [hc]
  <;> ring

theorem hasDerivAt_log_derivativeDensityWeight_parameter {p l v : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) (hv : 0<v) :
    HasDerivAt (fun t => Real.log (derivativeDensityWeight p t v))
      (densityDerivativeScore p l (densityOrderInverse p l v)) l := by
  have hw := derivativeDensityWeight_pos hp hp2 hl hv
  convert (hasDerivAt_derivativeDensityWeight_parameter hp hp2 hl hv).log hw.ne' using 1
  field_simp

theorem derivativeDensityWeight_log_increment_strictAntiOn {p u v : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hu : 0<u) (huv : u<v) :
    StrictAntiOn (fun l => Real.log (derivativeDensityWeight p l v)-
      Real.log (derivativeDensityWeight p l u)) (Ioi (0:ℝ)) := by
  have hv : 0<v := hu.trans huv
  apply strictAntiOn_of_deriv_neg (convex_Ioi _)
  · intro l hl
    exact ((hasDerivAt_log_derivativeDensityWeight_parameter hp hp2 hl hv).sub
      (hasDerivAt_log_derivativeDensityWeight_parameter hp hp2 hl hu)).continuousAt.continuousWithinAt
  · intro l hl
    rw [interior_Ioi] at hl
    rw [((hasDerivAt_log_derivativeDensityWeight_parameter hp hp2 hl hv).sub
      (hasDerivAt_log_derivativeDensityWeight_parameter hp hp2 hl hu)).deriv]
    exact sub_neg.mpr (densityDerivativeScore_strictAntiOn hp hp2 hl
      (densityOrderInverse_pos hp hl hu) (densityOrderInverse_pos hp hl hv)
      (densityOrderInverse_strictMonoOn hp hl hu hv huv))

/-- Strict likelihood-ratio order of the constructed derivative density for
every positive energy and every 0<λ<Λ.  In particular Λ=1 is included. -/
theorem derivativeDensityWeight_ratio_strictMonoOn {p l L : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) (hlL : l<L) :
    StrictMonoOn (fun v => derivativeDensityWeight p l v/derivativeDensityWeight p L v)
      (Ioi (0:ℝ)) := by
  have hL : 0<L := hl.trans hlL
  intro u hu v hv huv
  have hlu := derivativeDensityWeight_pos hp hp2 hl hu
  have hlv := derivativeDensityWeight_pos hp hp2 hl hv
  have hLu := derivativeDensityWeight_pos hp hp2 hL hu
  have hLv := derivativeDensityWeight_pos hp hp2 hL hv
  apply (Real.log_lt_log_iff (div_pos hlu hLu) (div_pos hlv hLv)).mp
  rw [Real.log_div hlu.ne' hLu.ne',Real.log_div hlv.ne' hLv.ne']
  have hi := derivativeDensityWeight_log_increment_strictAntiOn hp hp2 hu huv hl hL hlL
  dsimp only at hi
  linarith only [hi]

end LeanVerification.UpperLeftThirdCompletion
