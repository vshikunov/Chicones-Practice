import LeanVerification.UpperLeftCompletion.RayKernelCrossing
import Mathlib.MeasureTheory.Integral.IntegralEqImproper
import Mathlib.Analysis.Calculus.Deriv.MeanValue

/-! The cumulative of a continuous integrable kernel with two sign
changes has one strict crossing when its total mass is nonpositive.
Positive tail mass supplies the strict terminal sign, including zero
total mass. The one-sign-change limiting case is included separately. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
set_option maxHeartbeats 1800000

def cumulativeFromZero (f:ℝ→ℝ) (v:ℝ):ℝ := ∫t in (0:ℝ)..v,f t

theorem cumulativeFromZero_hasDerivAt {f:ℝ→ℝ}
    (hc:ContinuousOn f (Ici 0)) {v:ℝ} (hv:0<v) :
    HasDerivAt (cumulativeFromZero f) (f v) v := by
  have hcont:∀x∈Ioi (0:ℝ),ContinuousAt f x := by
    intro x hx
    have hxp:0<x := hx
    exact (hc x hxp.le).continuousAt (Ici_mem_nhds hxp)
  apply intervalIntegral.integral_hasDerivAt_right
  · exact (hc.mono (Icc_subset_Ici_self : Icc (0:ℝ) v⊆Ici 0)).intervalIntegrable_of_Icc hv.le
  · exact ContinuousAt.stronglyMeasurableAtFilter isOpen_Ioi hcont v hv
  · exact hcont v hv

theorem cumulativeFromZero_continuousOn_positive {f:ℝ→ℝ}
    (hc:ContinuousOn f (Ici 0)) : ContinuousOn (cumulativeFromZero f) (Ioi 0) := by
  intro v hv
  exact (cumulativeFromZero_hasDerivAt hc hv).continuousAt.continuousWithinAt

theorem cumulativeFromZero_abs_bound {f:ℝ→ℝ}
    (hi:IntegrableOn f (Ioi 0)) {v:ℝ} (hv:0≤v) :
    |cumulativeFromZero f v|≤∫t in Ioi (0:ℝ),|f t| := by
  rw [cumulativeFromZero,←Real.norm_eq_abs]
  apply (intervalIntegral.norm_integral_le_integral_norm_uIoc).trans
  rw [uIoc_of_le hv]
  simpa only [Real.norm_eq_abs] using setIntegral_mono_set hi.norm
    (Eventually.of_forall (fun t => norm_nonneg (f t))) Ioc_subset_Ioi_self.eventuallyLE

theorem cumulativeFromZero_tendsto {f:ℝ→ℝ} (hi:IntegrableOn f (Ioi 0)) :
    Tendsto (cumulativeFromZero f) atTop (𝓝 (∫t in Ioi (0:ℝ),f t)) :=
  intervalIntegral_tendsto_integral_Ioi 0 hi tendsto_id

theorem cumulativeFromZero_tail_identity {f:ℝ→ℝ}
    (hi:IntegrableOn f (Ioi 0)) {v:ℝ} (hv:0≤v) :
    cumulativeFromZero f v+(∫t in Ioi v,f t)=∫t in Ioi (0:ℝ),f t := by
  rw [cumulativeFromZero,intervalIntegral.integral_of_le hv,←Ioc_union_Ioi_eq_Ioi hv]
  symm
  apply setIntegral_union _ measurableSet_Ioi
    (hi.mono_set Ioc_subset_Ioi_self) (hi.mono_set (Ioi_subset_Ioi hv))
  exact disjoint_left.mpr (fun t ht hu => not_lt_of_ge ht.2 hu)

theorem positive_tail_integral {f:ℝ→ℝ} {v:ℝ}
    (hi:IntegrableOn f (Ioi v)) (hp:∀t,v<t→0<f t) :
    0<∫t in Ioi v,f t := by
  have hp':∀ᵐt∂volume.restrict (Ioi v),0<f t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact hp t ht
  apply (integral_pos_iff_support_of_nonneg_ae (hp'.mono fun _ ht => ht.le) hi).mpr
  have hs:Function.support f=ᵐ[volume.restrict (Ioi v)] univ := by
    filter_upwards [hp'] with t ht
    exact propext (iff_true_intro ht.ne')
  rw [measure_congr hs]
  simp

theorem cumulativeFromZero_neg_of_positive_tail {f:ℝ→ℝ}
    (hi:IntegrableOn f (Ioi 0)) (htotal:(∫t in Ioi (0:ℝ),f t)≤0)
    {v:ℝ} (hv:0≤v) (hp:∀t,v<t→0<f t) : cumulativeFromZero f v<0 := by
  have htail := positive_tail_integral (hi.mono_set (Ioi_subset_Ioi hv)) hp
  have hid := cumulativeFromZero_tail_identity hi hv
  linarith

theorem cumulativeFromZero_pos_before {f:ℝ→ℝ} {a v:ℝ}
    (hc:ContinuousOn f (Ici 0)) (ha:0<a)
    (hp:∀t∈Ioo (0:ℝ) a,0<f t) (hv:0<v) (hva:v≤a) :
    0<cumulativeFromZero f v := by
  exact intervalIntegral.intervalIntegral_pos_of_pos_on
    ((hc.mono (Icc_subset_Ici_self : Icc (0:ℝ) v⊆Ici 0)).intervalIntegrable_of_Icc hv.le)
    (fun t ht => hp t ⟨ht.1,ht.2.trans_le hva⟩) hv

theorem cumulativeFromZero_strictAntiOn_interval {f:ℝ→ℝ} {a b:ℝ}
    (hc:ContinuousOn f (Ici 0)) (ha:0<a)
    (hn:∀t∈Ioo a b,f t<0) : StrictAntiOn (cumulativeFromZero f) (Icc a b) := by
  apply strictAntiOn_of_deriv_neg (convex_Icc a b)
  · intro v hv
    exact (cumulativeFromZero_hasDerivAt hc (ha.trans_le hv.1)).continuousAt.continuousWithinAt
  · intro v hv
    rw [interior_Icc] at hv
    rw [(cumulativeFromZero_hasDerivAt hc (ha.trans hv.1)).deriv]
    exact hn v hv

theorem cumulativeFromZero_strictAntiOn_tail {f:ℝ→ℝ} {a:ℝ}
    (hc:ContinuousOn f (Ici 0)) (ha:0<a)
    (hn:∀t,a<t→f t<0) : StrictAntiOn (cumulativeFromZero f) (Ici a) := by
  apply strictAntiOn_of_deriv_neg (convex_Ici a)
  · intro v hv
    exact (cumulativeFromZero_hasDerivAt hc (ha.trans_le hv)).continuousAt.continuousWithinAt
  · intro v hv
    rw [interior_Ici] at hv
    rw [(cumulativeFromZero_hasDerivAt hc (ha.trans hv)).deriv]
    exact hn v hv

theorem cumulativeFromZero_two_sign_changes {f:ℝ→ℝ} {a b:ℝ}
    (hc:ContinuousOn f (Ici 0)) (hi:IntegrableOn f (Ioi 0))
    (ha:0<a) (hab:a<b)
    (hp:∀t∈Ioo (0:ℝ) a,0<f t) (hn:∀t∈Ioo a b,f t<0)
    (htail:∀t,b<t→0<f t) (htotal:(∫t in Ioi (0:ℝ),f t)≤0) :
    ∃c∈Ioo a b,cumulativeFromZero f c=0 ∧
      (∀v,0<v→v<c→0<cumulativeFromZero f v) ∧
      (∀v,c<v→cumulativeFromZero f v<0) := by
  have hKa := cumulativeFromZero_pos_before hc ha hp ha le_rfl
  have hKb := cumulativeFromZero_neg_of_positive_tail hi htotal (ha.trans hab).le htail
  have hKcont:ContinuousOn (cumulativeFromZero f) (Icc a b) := by
    intro v hv
    exact (cumulativeFromZero_hasDerivAt hc (ha.trans_le hv.1)).continuousAt.continuousWithinAt
  obtain ⟨c,hcI,hc0⟩ := intermediate_value_Icc' hab.le hKcont ⟨hKb.le,hKa.le⟩
  have hac:a<c := lt_of_le_of_ne hcI.1 (by intro he;rw [←he] at hc0;linarith)
  have hcb:c<b := lt_of_le_of_ne hcI.2 (by intro he;rw [he] at hc0;linarith)
  have hanti := cumulativeFromZero_strictAntiOn_interval hc ha hn
  refine ⟨c,⟨hac,hcb⟩,hc0,?_,?_⟩
  · intro v hv hvc
    by_cases hva:v≤a
    · exact cumulativeFromZero_pos_before hc ha hp hv hva
    have hbound := hanti ⟨(lt_of_not_ge hva).le,(hvc.trans hcb).le⟩ hcI hvc
    rwa [hc0] at hbound
  · intro v hcv
    by_cases hvb:v<b
    · have hbound := hanti hcI ⟨(hac.trans hcv).le,hvb.le⟩ hcv
      rwa [hc0] at hbound
    · exact cumulativeFromZero_neg_of_positive_tail hi htotal (ha.trans (hac.trans hcv)).le
        (fun t ht => htail t ((le_of_not_gt hvb).trans_lt ht))

theorem cumulativeFromZero_one_sign_change {f:ℝ→ℝ} {a:ℝ}
    (hc:ContinuousOn f (Ici 0)) (hi:IntegrableOn f (Ioi 0))
    (ha:0<a) (hp:∀t∈Ioo (0:ℝ) a,0<f t)
    (hn:∀t,a<t→f t<0) (htotal:(∫t in Ioi (0:ℝ),f t)<0) :
    ∃c,a<c ∧ cumulativeFromZero f c=0 ∧
      (∀v,0<v→v<c→0<cumulativeFromZero f v) ∧
      (∀v,c<v→cumulativeFromZero f v<0) := by
  have hKa := cumulativeFromZero_pos_before hc ha hp ha le_rfl
  have hevent := (cumulativeFromZero_tendsto hi).eventually (Iio_mem_nhds htotal)
  obtain ⟨b,hab,hKb⟩ := ((eventually_gt_atTop a).and hevent).exists
  have hKcont:ContinuousOn (cumulativeFromZero f) (Icc a b) := by
    intro v hv
    exact (cumulativeFromZero_hasDerivAt hc (ha.trans_le hv.1)).continuousAt.continuousWithinAt
  obtain ⟨c,hcI,hc0⟩ := intermediate_value_Icc' hab.le hKcont ⟨hKb.le,hKa.le⟩
  have hac:a<c := lt_of_le_of_ne hcI.1 (by intro he;rw [←he] at hc0;linarith)
  have hanti := cumulativeFromZero_strictAntiOn_tail hc ha hn
  refine ⟨c,hac,hc0,?_,?_⟩
  · intro v hv hvc
    by_cases hva:v≤a
    · exact cumulativeFromZero_pos_before hc ha hp hv hva
    have hb := hanti (le_of_not_ge hva) hac.le hvc
    rwa [hc0] at hb
  · intro v hcv
    have hb := hanti hac.le (hac.trans hcv).le hcv
    rwa [hc0] at hb

end LeanVerification.UpperLeftThirdCompletion
