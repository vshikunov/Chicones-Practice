import LeanVerification.ExteriorSpectralCompletion.SecondAbelKernel

/-! Exact third-fold Abel moments, including the polynomial deficit used
in the terminal real-density comparison. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open ContourCompletion ExteriorSpectralCompletion
set_option maxHeartbeats 4800000

def thirdAbelMomentKernel (n : ℕ) (z t : ℝ) : ℝ :=
  15*(abelRootRatio z t)^(2*n)/(8*Real.sqrt t*(z+t)^3*Real.sqrt (z+t))

def thirdAbelMomentPrimitive (n : ℕ) (z t : ℝ) : ℝ :=
  15/(4*z^3)*((abelRootRatio z t)^(2*n+1)/(2*(n:ℝ)+1)-
    2*(abelRootRatio z t)^(2*n+3)/(2*(n:ℝ)+3)+
    (abelRootRatio z t)^(2*n+5)/(2*(n:ℝ)+5))

def thirdAbelMoment (n : ℕ) : ℝ :=
  15/((2*(n:ℝ)+1)*(2*(n:ℝ)+3)*(2*(n:ℝ)+5))

theorem abelRootRatio_sq {z t : ℝ} (hz : 0<z) (ht : 0≤t) :
    (abelRootRatio z t)^2=t/(z+t) := by
  dsimp only [abelRootRatio]
  rw [div_pow,Real.sq_sqrt ht,Real.sq_sqrt (by linarith)]

theorem abelRootRatio_nonneg {z t : ℝ} : 0≤abelRootRatio z t := by
  dsimp only [abelRootRatio]
  positivity

theorem abelRootRatio_le_one {z t : ℝ} (hz : 0<z) (ht : 0≤t) :
    abelRootRatio z t≤1 := by
  have hsq := abelRootRatio_sq hz ht
  have hdiv : t/(z+t)≤1 := (div_le_one (by linarith)).mpr (by linarith)
  have hn := abelRootRatio_nonneg (z:=z) (t:=t)
  nlinarith

theorem thirdAbelMomentPrimitive_continuous_zero {z : ℝ} (hz : 0<z) (n : ℕ) :
    ContinuousWithinAt (thirdAbelMomentPrimitive n z) (Ici 0) 0 := by
  have h := abelRootRatio_continuous_zero hz
  have hc : ContinuousAt (thirdAbelMomentPrimitive n z) 0 := (((((h.pow (2*n+1)).div_const (2*(n:ℝ)+1)).sub
    (((h.pow (2*n+3)).const_mul 2).div_const (2*(n:ℝ)+3))).add
    ((h.pow (2*n+5)).div_const (2*(n:ℝ)+5))).const_mul (15/(4*z^3)))
  exact hc.continuousWithinAt

theorem hasDerivAt_thirdAbelMomentPrimitive {z t : ℝ}
    (hz : 0<z) (ht : 0<t) (n : ℕ) :
    HasDerivAt (thirdAbelMomentPrimitive n z) (thirdAbelMomentKernel n z t) t := by
  have h := hasDerivAt_abelRootRatio hz ht
  have hh := (((((h.pow (2*n+1)).div_const (2*(n:ℝ)+1)).sub
    (((h.pow (2*n+3)).const_mul 2).div_const (2*(n:ℝ)+3))).add
    ((h.pow (2*n+5)).div_const (2*(n:ℝ)+5))).const_mul (15/(4*z^3)))
  convert hh using 1
  dsimp only [thirdAbelMomentKernel]
  simp only [Nat.cast_add,Nat.cast_mul,Nat.cast_ofNat,Nat.cast_one,
    Nat.add_sub_cancel,Nat.reduceAdd,show 2*n+3-1=2*n+2 by omega,
    show 2*n+5-1=2*n+4 by omega]
  rw [pow_add _ (2*n) 2,pow_add _ (2*n) 4,
    show (abelRootRatio z t)^4=((abelRootRatio z t)^2)^2 by ring,
    abelRootRatio_sq hz ht.le]
  have h1 : (2*(n:ℝ)+1)≠0 := by positivity
  have h3 : (2*(n:ℝ)+3)≠0 := by positivity
  have h5 : (2*(n:ℝ)+5)≠0 := by positivity
  have hzt : z+t≠0 := (add_pos hz ht).ne'
  field_simp
  <;> ring

theorem thirdAbelMomentPrimitive_tendsto {z : ℝ} (hz : 0<z) (n : ℕ) :
    Tendsto (thirdAbelMomentPrimitive n z) atTop (𝓝 (2*thirdAbelMoment n/z^3)) := by
  have h := abelRootRatio_tendsto hz
  have hh := (((((h.pow (2*n+1)).div_const (2*(n:ℝ)+1)).sub
    (((h.pow (2*n+3)).const_mul 2).div_const (2*(n:ℝ)+3))).add
    ((h.pow (2*n+5)).div_const (2*(n:ℝ)+5))).const_mul (15/(4*z^3)))
  convert hh using 1
  simp only [one_pow]
  dsimp only [thirdAbelMoment]
  have h1 : (2*(n:ℝ)+1)≠0 := by positivity
  have h3 : (2*(n:ℝ)+3)≠0 := by positivity
  have h5 : (2*(n:ℝ)+5)≠0 := by positivity
  field_simp
  <;> ring

theorem thirdAbelMomentKernel_nonneg {z t : ℝ}
    (hz : 0<z) (ht : 0<t) (n : ℕ) :
    0≤thirdAbelMomentKernel n z t := by
  dsimp only [thirdAbelMomentKernel]
  have h := abelRootRatio_nonneg (z:=z) (t:=t)
  positivity

theorem thirdAbelMomentKernel_integrable {z : ℝ} (hz : 0<z) (n : ℕ) :
    IntegrableOn (thirdAbelMomentKernel n z) (Ioi 0) := by
  apply integrableOn_Ioi_deriv_of_nonneg
    (thirdAbelMomentPrimitive_continuous_zero hz n)
    (fun t ht => hasDerivAt_thirdAbelMomentPrimitive hz ht n)
    (fun t ht => thirdAbelMomentKernel_nonneg hz ht n)
    (thirdAbelMomentPrimitive_tendsto hz n)

theorem integral_thirdAbelMomentKernel {z : ℝ} (hz : 0<z) (n : ℕ) :
    (∫t in Ioi (0:ℝ),thirdAbelMomentKernel n z t)=2*thirdAbelMoment n/z^3 := by
  have hh := integral_Ioi_of_hasDerivAt_of_nonneg
    (thirdAbelMomentPrimitive_continuous_zero hz n)
    (fun t ht => hasDerivAt_thirdAbelMomentPrimitive hz ht n)
    (fun t ht => thirdAbelMomentKernel_nonneg hz ht n)
    (thirdAbelMomentPrimitive_tendsto hz n)
  simpa only [thirdAbelMomentPrimitive,abelRootRatio,Real.sqrt_zero,zero_div,
    zero_pow (by omega : 2*n+1≠0),zero_pow (by omega : 2*n+3≠0),
    zero_pow (by omega : 2*n+5≠0),mul_zero,sub_zero,add_zero] using hh

end LeanVerification.UpperLeftThirdCompletion
