import LeanVerification.UpperLeftThirdCompletion.DerivativeDensityElasticity

/-! At λ=1 the normalized derivative density has a strictly decreasing
elasticity.  The rational certificate is valid throughout the positive ray. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion UpperLeftCompletion
set_option maxHeartbeats 4800000
set_option maxRecDepth 6000

def terminalDerivativeElasticity (p z : ℝ) : ℝ :=
  (1+z)/(p+(p+2)*z)*
    (1-p-(2/p+2)*z/(1+z)+(p+2)^2*z/(p*(p+4)+(p+2)^2*z)-
      3*(p+2)*z/(p+(p+2)*z))

def terminalDerivativeElasticityNumerator (p z : ℝ) : ℝ :=
  p^2*(p+3)*(p+4)*(p+6)+
    p*(p+1)*(p+2)*(p+4)*(3*p+14)*z+
    (p+2)^3*(p+4)*(3*p+1)*z^2+(p+1)*(p+2)^4*z^3

def terminalDerivativeCoordinate (p v : ℝ) : ℝ :=
  p/(p+2)*densityOrderInverse p 1 v

def actualTerminalDerivativeElasticity (p v : ℝ) : ℝ :=
  terminalDerivativeElasticity p (terminalDerivativeCoordinate p v)

theorem hasDerivAt_terminalDerivativeElasticity {p z : ℝ}
    (hp : 0<p) (hz : 0<z) :
    HasDerivAt (terminalDerivativeElasticity p)
      (-2*p*terminalDerivativeElasticityNumerator p z/
        ((p+(p+2)*z)^3*(p*(p+4)+(p+2)^2*z)^2)) z := by
  have hZ : 1+z≠0 := by positivity
  have hB : p+(p+2)*z≠0 := by positivity
  have hC : p*(p+4)+(p+2)^2*z≠0 := by positivity
  have hOne := (hasDerivAt_id z).const_add 1
  have hB' := ((hasDerivAt_id z).const_mul (p+2)).const_add p
  have hC' := ((hasDerivAt_id z).const_mul ((p+2)^2)).const_add (p*(p+4))
  have hQ := (((hasDerivAt_const z (1-p)).sub
    (((hasDerivAt_id z).const_mul (2/p+2)).div hOne hZ)).add
    (((hasDerivAt_id z).const_mul ((p+2)^2)).div hC' hC)).sub
    (((hasDerivAt_id z).const_mul (3*(p+2))).div hB' hB)
  have hd := (hOne.div hB' hB).mul hQ
  convert hd using 1
  simp only [id_eq,mul_one,terminalDerivativeElasticityNumerator]
  field_simp
  <;> ring

theorem terminalDerivativeElasticityNumerator_pos {p z : ℝ}
    (hp : 0<p) (hz : 0<z) : 0<terminalDerivativeElasticityNumerator p z := by
  unfold terminalDerivativeElasticityNumerator
  positivity

theorem terminalDerivativeElasticity_strictAntiOn {p : ℝ} (hp : 0<p) :
    StrictAntiOn (terminalDerivativeElasticity p) (Ioi (0:ℝ)) := by
  apply strictAntiOn_of_deriv_neg (convex_Ioi _)
  · intro z hz
    exact (hasDerivAt_terminalDerivativeElasticity hp hz).continuousAt.continuousWithinAt
  · intro z hz
    rw [interior_Ioi] at hz
    change 0<z at hz
    rw [(hasDerivAt_terminalDerivativeElasticity hp hz).deriv]
    apply div_neg_of_neg_of_pos
    · exact mul_neg_of_neg_of_pos (by nlinarith only [hp])
        (terminalDerivativeElasticityNumerator_pos hp hz)
    · positivity

theorem densityDerivativeC_terminal {p r : ℝ} (hp : 0<p) (hr : 0<r) :
    densityDerivativeC p 1 r=2/(p*r+p+2)+1/(r+1) := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp (by norm_num : (0:ℝ)≤1)
  have hP := (rayPolynomial_pos hA hB.le hC hr).ne'
  have hE := (rayEulerPolynomial_pos hp hA hB.le hC hr).ne'
  have hp1 : p+1≠0 := by positivity
  have hp2 : p+2≠0 := by positivity
  have hR : p*r+p+2≠0 := by positivity
  have hR1 : r+1≠0 := by positivity
  dsimp only [densityDerivativeC,rayLogGradient,densityDerivativeAlpha]
  field_simp
  dsimp only [rayPolynomial,rayEulerPolynomial,rayEulerSlope,lowAngleA,lowAngleB,lowAngleC]
  field_simp
  <;> ring

theorem densityDerivativeCPrime_terminal {p r : ℝ} (hp : 0<p) (hr : 0<r) :
    densityDerivativeCPrime p 1 r= -2*p/(p*r+p+2)^2-1/(r+1)^2 := by
  have hR : p*r+p+2≠0 := by positivity
  have hR1 : r+1≠0 := by positivity
  have h1 := (hasDerivAt_const r 2).div
    ((((hasDerivAt_id r).const_mul p).add_const p).add_const 2) hR
  have h2 := (hasDerivAt_const r 1).div ((hasDerivAt_id r).add_const 1) hR1
  have he : densityDerivativeC p 1=ᶠ[𝓝 r]
      (fun x => 2/(p*x+p+2)+1/(x+1)) := by
    filter_upwards [Ioi_mem_nhds hr] with x hx
    exact densityDerivativeC_terminal hp hx
  have hi := (hasDerivAt_densityDerivativeC hp (by norm_num : (0:ℝ)<1) hr).unique
    ((h1.add h2).congr_of_eventuallyEq he)
  rw [hi]
  simp only [id_eq,mul_one,zero_mul,one_mul,zero_sub]
  ring

theorem derivativeDensityElasticity_terminal {p r : ℝ}
    (hp : 0<p) (hr : 0<r) :
    derivativeDensityElasticity p 1 r=
      terminalDerivativeElasticity p (p/(p+2)*r) := by
  have hp0 := hp.ne'
  have hp1 : p+1≠0 := by positivity
  have hp2 : p+2≠0 := by positivity
  have hR : p*r+p+2≠0 := by positivity
  have hR1 : r+1≠0 := by positivity
  have hC : 2/(p*r+p+2)+1/(r+1)≠0 := by positivity
  have hT : p*r+p+2+2*(r+1)≠0 := by positivity
  have hBz : p+(p+2)*(p/(p+2)*r)≠0 := by positivity
  have hCz : p*(p+4)+(p+2)^2*(p/(p+2)*r)≠0 := by positivity
  have hZ : 1+p/(p+2)*r≠0 := by positivity
  dsimp only [derivativeDensityElasticity]
  rw [densityDerivativeC_terminal hp hr,densityDerivativeCPrime_terminal hp hr]
  rw [lowAngle_euler_factor hp]
  dsimp only [terminalDerivativeElasticity,rayPolynomial,rayEulerSlope,
    lowAngleA,lowAngleB,lowAngleC]
  field_simp
  <;> ring

theorem terminalDerivativeCoordinate_pos {p v : ℝ} (hp : 0<p) (hv : 0<v) :
    0<terminalDerivativeCoordinate p v :=
  mul_pos (div_pos hp (by positivity)) (densityOrderInverse_pos hp (by norm_num) hv)

theorem actualTerminalDerivativeElasticity_strictAntiOn {p : ℝ} (hp : 0<p) :
    StrictAntiOn (actualTerminalDerivativeElasticity p) (Ioi (0:ℝ)) := by
  intro u hu v hv huv
  apply terminalDerivativeElasticity_strictAntiOn hp
    (terminalDerivativeCoordinate_pos hp hu) (terminalDerivativeCoordinate_pos hp hv)
  exact mul_lt_mul_of_pos_left (densityOrderInverse_strictMonoOn hp (by norm_num) hu hv huv)
    (div_pos hp (by positivity))

theorem hasDerivAt_terminalDerivativeDensityWeight {p v : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hv : 0<v) :
    HasDerivAt (derivativeDensityWeight p 1)
      (actualTerminalDerivativeElasticity p v*derivativeDensityWeight p 1 v/v) v := by
  have hd := hasDerivAt_derivativeDensityWeight_energy hp hp2 (by norm_num : (0:ℝ)<1) hv
  rw [derivativeDensityElasticity_terminal hp (densityOrderInverse_pos hp (by norm_num) hv)] at hd
  exact hd

end LeanVerification.UpperLeftThirdCompletion
