import LeanVerification.UpperLeftThirdCompletion.PowerCauchy
import LeanVerification.UpperLeftCompletion.RayKernelCrossing

/-! The complete weighted third-ray integral, proved from the actual
principal-power Cauchy transform.  This supplies the cumulative-kernel
endpoint sign in the two-crossing range. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open ContourCompletion UpperLeftCompletion
set_option maxHeartbeats 3200000

def weightedThirdKernel (a θ v : ℝ) : ℝ := v^a*rayMomentKernel 3 θ v

theorem thirdKernel_complex_formula {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) (t : ℝ) :
    (rayMomentUnit θ)^3/(principalSquareRoot ((t:ℂ)+rayMomentUnit θ))^7=
      (rayMomentUnit θ)^3*((rayMomentUnit θ+(t:ℂ))^((-7/2:ℝ):ℂ)) := by
  have hn := rayMoment_shift_ne_zero hθ hθu t
  rw [add_comm (rayMomentUnit θ),Complex.cpow_def_of_ne_zero hn]
  dsimp only [principalSquareRoot]
  rw [←Complex.exp_nat_mul,div_eq_mul_inv,←Complex.exp_neg]
  congr 2
  push_cast
  ring

theorem weightedThirdKernel_eq_re {a θ : ℝ}
    (hθ : 0<θ) (hθu : θ<Real.pi) (t : ℝ) :
    weightedThirdKernel a θ t=
      ((rayMomentUnit θ)^3*Cauchy.complexKernel (fun t => t^a) (7/2)
        (rayMomentUnit θ) t).re := by
  dsimp only [weightedThirdKernel,rayMomentKernel,Cauchy.complexKernel]
  norm_num only [show 2*3+1=(7:ℕ) by norm_num]
  rw [thirdKernel_complex_formula hθ hθu]
  push_cast
  simp only [Complex.mul_re,Complex.mul_im,Complex.ofReal_re,Complex.ofReal_im,mul_zero,sub_zero,zero_add]
  ring

theorem weightedThirdKernel_integrable {a θ : ℝ}
    (ha : -1<a) (hau : a<5/2) (hθ : 0<θ) (hθu : θ<Real.pi) :
    IntegrableOn (weightedThirdKernel a θ) (Ioi 0) := by
  have hz : rayMomentUnit θ∈Complex.slitPlane :=
    Or.inr (by rw [rayMomentUnit_im];exact (Real.sin_pos_of_pos_of_lt_pi hθ hθu).ne')
  have hi := (powerCauchy_integrable ha (by linarith : a+1<(7/2:ℝ))
    (by norm_num : (0:ℝ)<7/2) hz).const_mul ((rayMomentUnit θ)^3)
  exact hi.re.congr (Filter.Eventually.of_forall (fun t =>
    (weightedThirdKernel_eq_re hθ hθu t).symm))

theorem rayMomentUnit_third_power {a θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) :
    (rayMomentUnit θ)^3*(rayMomentUnit θ)^((a+1-7/2:ℝ):ℂ)=
      Complex.exp ((((a+1/2)*θ:ℝ):ℂ)*Complex.I) := by
  have hn : rayMomentUnit θ≠0 := Complex.exp_ne_zero _
  rw [Complex.cpow_def_of_ne_zero hn]
  have hl : Complex.log (rayMomentUnit θ)=(θ:ℂ)*Complex.I := by
    apply Complex.log_exp
    · simp only [Complex.mul_im,Complex.ofReal_re,Complex.I_im,mul_one,
        Complex.ofReal_im,Complex.I_re,mul_zero,add_zero]
      linarith [Real.pi_pos]
    · simp only [Complex.mul_im,Complex.ofReal_re,Complex.I_im,mul_one,
        Complex.ofReal_im,Complex.I_re,mul_zero,add_zero]
      exact hθu.le
  rw [hl,rayMomentUnit,←Complex.exp_nat_mul,←Complex.exp_add]
  congr 1
  push_cast
  ring

theorem integral_weightedThirdKernel {a θ : ℝ}
    (ha : -1<a) (hau : a<5/2) (hθ : 0<θ) (hθu : θ<Real.pi) :
    (∫v in Ioi (0:ℝ),weightedThirdKernel a θ v)=
      powerCauchyMass a (7/2)*Real.cos ((a+1/2)*θ) := by
  have hz : rayMomentUnit θ∈Complex.slitPlane :=
    Or.inr (by rw [rayMomentUnit_im];exact (Real.sin_pos_of_pos_of_lt_pi hθ hθu).ne')
  have hi := (powerCauchy_integrable ha (by linarith : a+1<(7/2:ℝ))
    (by norm_num : (0:ℝ)<7/2) hz).const_mul ((rayMomentUnit θ)^3)
  have he : (∫v in Ioi (0:ℝ),weightedThirdKernel a θ v)=
      (∫v in Ioi (0:ℝ),(rayMomentUnit θ)^3*
        Cauchy.complexKernel (fun v => v^a) (7/2) (rayMomentUnit θ) v).re := by
    calc
      _=(∫v in Ioi (0:ℝ),((rayMomentUnit θ)^3*
        Cauchy.complexKernel (fun v => v^a) (7/2) (rayMomentUnit θ) v).re) := by
          apply setIntegral_congr_fun measurableSet_Ioi
          intro v hv
          exact weightedThirdKernel_eq_re hθ hθu v
      _=_ := integral_re hi
  rw [he,integral_const_mul]
  change ((rayMomentUnit θ)^3*powerCauchy a (7/2) (rayMomentUnit θ)).re=_
  rw [powerCauchy_eq_cpow ha (by linarith : a+1<(7/2:ℝ)) (by norm_num) hz]
  rw [show (rayMomentUnit θ)^3*((powerCauchyMass a (7/2):ℂ)*
      (rayMomentUnit θ)^((a+1-7/2:ℝ):ℂ))=
    (powerCauchyMass a (7/2):ℂ)*((rayMomentUnit θ)^3*
      (rayMomentUnit θ)^((a+1-7/2:ℝ):ℂ)) by ring,
    rayMomentUnit_third_power hθ hθu]
  simp only [Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero,
    Complex.exp_re,Complex.mul_im,Complex.I_im,mul_one,Complex.I_re,mul_zero,
    add_zero,Complex.mul_re,sub_self,Real.exp_zero,one_mul]

theorem integral_weightedThirdKernel_nonpos {p : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) :
    (∫v in Ioi (0:ℝ),weightedThirdKernel (1/p-1/2) (Real.pi*(1-p)) v)≤0 := by
  have hp : 0<p := by linarith
  have hθ : 0<Real.pi*(1-p) := mul_pos Real.pi_pos (by linarith)
  have hθu : Real.pi*(1-p)<Real.pi := by nlinarith [Real.pi_pos]
  have hinvlo : (2:ℝ)≤1/p := (le_div_iff₀ hp).mpr (by linarith)
  have hinvhi : 1/p≤(5/2:ℝ) := (div_le_iff₀ hp).mpr (by linarith)
  rw [integral_weightedThirdKernel (by linarith : -1<1/p-1/2)
    (by linarith : 1/p-1/2<5/2) hθ hθu]
  have hmass := (powerCauchyMass_pos (by linarith : -1<1/p-1/2)
    (by linarith : (1/p-1/2)+1<(7/2:ℝ)) (by norm_num : (0:ℝ)<7/2)).le
  have he : (1/p-1/2+1/2)*(Real.pi*(1-p))=Real.pi*(1/p-1) := by
    field_simp
    <;> ring
  rw [he]
  apply mul_nonpos_of_nonneg_of_nonpos hmass
  apply Real.cos_nonpos_of_pi_div_two_le_of_le
  · nlinarith [Real.pi_pos]
  · nlinarith [Real.pi_pos]

end LeanVerification.UpperLeftThirdCompletion
