import LeanVerification.ExteriorSpectralCompletion.SecondWeightedJets
import LeanVerification.UpperLeftCompletion.PhysicalLowAngleData

/-! Exact real polynomial certificates for the third exterior jet on the
terminal parameter lambda=1.  No spectral representation is used. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion ExteriorCompletion ExteriorSpectralCompletion UpperLeftCompletion
set_option maxHeartbeats 6400000
set_option maxRecDepth 6000

def terminalJetDenominator (p r : ℝ) : ℝ := 2+(p+2)*r

def terminalDeficitNumerator (p r : ℝ) : ℝ :=
  (192 + (960*(r^5)) + (1344*r) + (3648*(r^4)) + (3840*(r^2)) + (5376*(r^3)) + (p*(192 + (2208*r) + (2880*(r^5)) + (8608*(r^2)) + (10528*(r^4)) + (14240*(r^3)) + (p*((864*r) + (3600*(r^5)) + (6288*(r^2)) + (11744*(r^4)) + (13568*(r^3)) + (p*((1520*(r^2)) + (2400*(r^5)) + (5512*(r^3)) + (6392*(r^4)) + (p*((808*(r^3)) + (900*(r^5)) + (1708*(r^4)) + (p*((180*(r^4)) + (180*(r^5)) + (15*p*(r^5)))))))))))))

def terminalDeficitParameterNumerator (p r : ℝ) : ℝ :=
  (-384 + (-1856*r) + (-384*(r^2)) + (2880*(r^5)) + (6144*(r^3)) + (7936*(r^4)) + (p*(-768 + (-4608*r) + (2944*(r^2)) + (10560*(r^5)) + (27200*(r^3)) + (30976*(r^4)) + (p*(-384 + (-3648*r) + (9792*(r^2)) + (16560*(r^5)) + (45472*(r^3)) + (48976*(r^4)) + (p*((-896*r) + (9216*(r^2)) + (14400*(r^5)) + (35712*(r^3)) + (40000*(r^4)) + (p*((2752*(r^2)) + (7500*(r^5)) + (13088*(r^3)) + (17836*(r^4)) + (p*((1792*(r^3)) + (2340*(r^5)) + (4132*(r^4)) + (p*((390*(r^4)) + (405*(r^5)) + (30*p*(r^5)))))))))))))))

def terminalDeficitNormalized (p r : ℝ) : ℝ :=
  r^2*terminalDeficitNumerator p r/
    (15*(p+1)*(terminalJetDenominator p r)^7)

def terminalThirdDeficit (p r : ℝ) : ℝ :=
  p*(p+1)*terminalDeficitNormalized p r

def terminalThirdScaled (p r : ℝ) : ℝ :=
  (15/8)*(1-terminalThirdDeficit p r)

def terminalPowerMajorant (p r : ℝ) : ℝ :=
  (6+4*(p+1)*r+p*(p+1)*r^2)/(6+2*(2-p)*r)

def terminalEpsilonLower : ℝ := 13029/50000

def terminalDeficitCubic (u : ℝ) : ℝ :=
  (1783+1338*u+1061*u^2+873*u^3)/100000

def terminalDeficitAverage : ℝ := 472063/23100000

theorem terminalJetDenominator_pos {p r : ℝ} (hp : 0<p) (hr : 0≤r) :
    0<terminalJetDenominator p r := by
  dsimp only [terminalJetDenominator]
  positivity

theorem terminalDeficitNumerator_pos {p r : ℝ} (hp : 0<p) (hr : 0≤r) :
    0<terminalDeficitNumerator p r := by
  dsimp only [terminalDeficitNumerator]
  positivity

theorem terminalThirdDeficit_pos {p r : ℝ} (hp : 0<p) (hr : 0<r) :
    0<terminalThirdDeficit p r := by
  have hQ := terminalDeficitNumerator_pos hp hr.le
  have hq := terminalJetDenominator_pos hp hr.le
  dsimp only [terminalThirdDeficit,terminalDeficitNormalized]
  positivity

theorem terminalThirdScaled_lt_fold {p r : ℝ} (hp : 0<p) (hr : 0<r) :
    terminalThirdScaled p r<15/8 := by
  have hD := terminalThirdDeficit_pos hp hr
  dsimp only [terminalThirdScaled]
  linarith

theorem terminalDeficitParameterNumerator_pos {p r : ℝ}
    (hp : 1/2≤p) (hr : 9/20≤r) :
    0<terminalDeficitParameterNumerator p r := by
  have hx : 0≤p-1/2 := by linarith
  have hy : 0≤r-9/20 := by linarith
  have he : terminalDeficitParameterNumerator p r=
      30*(p-1/2)^7*(r-9/20)^5 +
      (135/2)*(p-1/2)^7*(r-9/20)^4 +
      (243/4)*(p-1/2)^7*(r-9/20)^3 +
      (2187/80)*(p-1/2)^7*(r-9/20)^2 +
      (19683/3200)*(p-1/2)^7*(r-9/20)^1 +
      (177147/320000)*(p-1/2)^7 +
      510*(p-1/2)^6*(r-9/20)^5 +
      (3075/2)*(p-1/2)^6*(r-9/20)^4 +
      (6939/4)*(p-1/2)^6*(r-9/20)^3 +
      (75087/80)*(p-1/2)^6*(r-9/20)^2 +
      (789507/3200)*(p-1/2)^6*(r-9/20)^1 +
      (8129079/320000)*(p-1/2)^6 +
      (7425/2)*(p-1/2)^5*(r-9/20)^5 +
      (109241/8)*(p-1/2)^5*(r-9/20)^4 +
      (1508273/80)*(p-1/2)^5*(r-9/20)^3 +
      (19590633/1600)*(p-1/2)^5*(r-9/20)^2 +
      (242073441/64000)*(p-1/2)^5*(r-9/20)^1 +
      (574998021/1280000)*(p-1/2)^5 +
      15000*(p-1/2)^4*(r-9/20)^5 +
      (126757/2)*(p-1/2)^4*(r-9/20)^4 +
      (1012743/10)*(p-1/2)^4*(r-9/20)^3 +
      (30454471/400)*(p-1/2)^4*(r-9/20)^2 +
      (27024417/1000)*(p-1/2)^4*(r-9/20)^1 +
      (1167971157/320000)*(p-1/2)^4 +
      (290625/8)*(p-1/2)^3*(r-9/20)^5 +
      (5398889/32)*(p-1/2)^3*(r-9/20)^4 +
      (94877137/320)*(p-1/2)^3*(r-9/20)^3 +
      (1555826297/6400)*(p-1/2)^3*(r-9/20)^2 +
      (23506451809/256000)*(p-1/2)^3*(r-9/20)^1 +
      (65855184309/5120000)*(p-1/2)^3 +
      (421875/8)*(p-1/2)^2*(r-9/20)^5 +
      (8317215/32)*(p-1/2)^2*(r-9/20)^4 +
      (30845967/64)*(p-1/2)^2*(r-9/20)^3 +
      (105129231/256)*(p-1/2)^2*(r-9/20)^2 +
      (7973546631/51200)*(p-1/2)^2*(r-9/20)^1 +
      (21270048807/1024000)*(p-1/2)^2 +
      (1359375/32)*(p-1/2)^1*(r-9/20)^5 +
      (27624375/128)*(p-1/2)^1*(r-9/20)^4 +
      (104705235/256)*(p-1/2)^1*(r-9/20)^3 +
      (358067295/1024)*(p-1/2)^1*(r-9/20)^2 +
      (5212735623/40960)*(p-1/2)^1*(r-9/20)^1 +
      (11888463843/819200)*(p-1/2)^1 +
      (234375/16)*(r-9/20)^5 +
      (4792125/64)*(r-9/20)^4 +
      (18120375/128)*(r-9/20)^3 +
      (60593265/512)*(r-9/20)^2 +
      (162266571/4096)*(r-9/20)^1 +
      (253793061/81920) := by
    dsimp only [terminalDeficitParameterNumerator]
    ring
  rw [he]
  positivity


theorem hasDerivAt_terminalDeficitNormalized_parameter {p r : ℝ}
    (hp : 0<p) (hr : 0≤r) :
    HasDerivAt (fun p => terminalDeficitNormalized p r)
      (-r^3*terminalDeficitParameterNumerator p r/
        (15*(p+1)^2*(terminalJetDenominator p r)^8)) p := by
  have hq : terminalJetDenominator p r≠0 := (terminalJetDenominator_pos hp hr).ne'
  have hp1 : p+1≠0 := by positivity
  have hQ := (((((((((((((hasDerivAt_const p ((15*(r^5)))).mul (hasDerivAt_id p)).add_const (((180*(r^4)) + (180*(r^5))))).mul (hasDerivAt_id p)).add_const (((808*(r^3)) + (900*(r^5)) + (1708*(r^4))))).mul (hasDerivAt_id p)).add_const (((1520*(r^2)) + (2400*(r^5)) + (5512*(r^3)) + (6392*(r^4))))).mul (hasDerivAt_id p)).add_const (((864*r) + (3600*(r^5)) + (6288*(r^2)) + (11744*(r^4)) + (13568*(r^3))))).mul (hasDerivAt_id p)).add_const ((192 + (2208*r) + (2880*(r^5)) + (8608*(r^2)) + (10528*(r^4)) + (14240*(r^3))))).mul (hasDerivAt_id p)).add_const ((192 + (960*(r^5)) + (1344*r) + (3648*(r^4)) + (3840*(r^2)) + (5376*(r^3)))))
  have hq' := (((hasDerivAt_id p).add_const 2).mul_const r).const_add 2
  have hd := (hQ.const_mul (r^2)).div
    ((((hasDerivAt_id p).add_const 1).mul (hq'.pow 7)).const_mul 15)
    (by dsimp only [terminalJetDenominator] at hq; exact mul_ne_zero (by norm_num) (mul_ne_zero hp1 (pow_ne_zero _ hq)))
  convert hd using 1
  · ext y
    dsimp only [terminalDeficitNormalized,terminalDeficitNumerator,terminalJetDenominator,id_eq]
    congr 1 <;> ring
  · simp only [id_eq,one_mul,mul_one,Nat.cast_ofNat,Nat.reduceSub]
    dsimp only [terminalDeficitParameterNumerator,terminalJetDenominator]
    dsimp only [terminalJetDenominator] at hq
    field_simp
    <;> ring

theorem terminalDeficitNormalized_antitone_parameter {r : ℝ} (hr : 9/20≤r) :
    AntitoneOn (fun p => terminalDeficitNormalized p r) (Ici (1/2:ℝ)) := by
  apply antitoneOn_of_deriv_nonpos (convex_Ici _)
  · intro p hp
    change 1/2≤p at hp
    exact (hasDerivAt_terminalDeficitNormalized_parameter (by linarith [hp])
      (by linarith)).continuousAt.continuousWithinAt
  · intro p hp
    rw [interior_Ici] at hp
    change 1/2<p at hp
    exact (hasDerivAt_terminalDeficitNormalized_parameter (by linarith)
      (by linarith)).differentiableAt.differentiableWithinAt
  · intro p hp
    rw [interior_Ici] at hp
    change 1/2<p at hp
    rw [(hasDerivAt_terminalDeficitNormalized_parameter (by linarith : 0<p)
      (by linarith : 0≤r)).deriv]
    have hQ := terminalDeficitParameterNumerator_pos hp.le hr
    have hq := terminalJetDenominator_pos (by linarith : 0<p) (by linarith : 0≤r)
    exact div_nonpos_of_nonpos_of_nonneg (by nlinarith [pow_nonneg (by linarith : 0≤r) 3]) (by positivity)

theorem terminalDeficitCubic_mono : MonotoneOn terminalDeficitCubic (Ici (0:ℝ)) := by
  intro x hx y hy hxy
  have h2 := pow_le_pow_left₀ hx hxy 2
  have h3 := pow_le_pow_left₀ hx hxy 3
  dsimp only [terminalDeficitCubic]
  nlinarith

theorem terminalDeficitLower_fixed {r : ℝ} (hr : 459/1000≤r) :
    terminalDeficitCubic
      (1-terminalEpsilonLower/(r^2*terminalPowerMajorant (14/25) r))<
        terminalDeficitNormalized (14/25) r := by
  have hr0 : 0<r := by linarith
  have hx : 0≤r-459/1000 := by linarith
  have he : terminalDeficitNormalized (14/25) r-
      terminalDeficitCubic
        (1-terminalEpsilonLower/(r^2*terminalPowerMajorant (14/25) r))=
      (161448555925491700203520000000000*(r-459/1000)^19 +
      5340280095305653714466897920000000*(r-459/1000)^18 +
      76842046542670000818236707307520000*(r-459/1000)^17 +
      638850690220834442079975711674859520*(r-459/1000)^16 +
      (86224615408537483762661047326516051968/25)*(r-459/1000)^15 +
      (40324069993888405827481652020469676244992/3125)*(r-459/1000)^14 +
      (13603961441504340052459858501277289209698304/390625)*(r-459/1000)^13 +
      (3394566466512316865435166063579884066642188928/48828125)*(r-459/1000)^12 +
      (635409671689643507109590581485694392703695659616/6103515625)*(r-459/1000)^11 +
      (89677087539775444314624390788213686398291259693072/762939453125)*(r-459/1000)^10 +
      (19012837125465585540491738777897335729933632706501887/190734863281250)*(r-459/1000)^9 +
      (47757493945588229207934506493491009223366559626881278083/762939453125000000)*(r-459/1000)^8 +
      (5392389769472079835122474449816505196928659845617028653037/190734863281250000000)*(r-459/1000)^7 +
      (414692753811964103820021865556623038466300103753002592082303/47683715820312500000000)*(r-459/1000)^6 +
      (311732373853366603849227862698989458168641774464453316148285257/190734863281250000000000000)*(r-459/1000)^5 +
      (54300456341634457989531764224645103640117290656736604254488573017/381469726562500000000000000000)*(r-459/1000)^4 +
      (57348244992872649166980497129547720224020415438532656605723502241/190734863281250000000000000000000)*(r-459/1000)^3 +
      (10537043516946850236291362304473344297697014250779181538691863031521/190734863281250000000000000000000000)*(r-459/1000)^2 +
      (922847888449707996245071304108555663550338315016461132006371300101321/190734863281250000000000000000000000000)*(r-459/1000)^1 +
      (307416930153927594176255797438082300404658734850285182911823583986337373/1525878906250000000000000000000000000000000))/((31200000000000000*(r^6)*((25 + (32*r))^7)*((625 + (91*(r^2)) + (650*r))^3))) := by
    dsimp only [terminalDeficitNormalized,terminalDeficitNumerator,terminalJetDenominator,
      terminalDeficitCubic,terminalEpsilonLower,terminalPowerMajorant]
    have h1 : 0<6+2*(2-(14/25:ℝ))*r := by positivity
    have h2 : 0<6+4*((14/25:ℝ)+1)*r+(14/25:ℝ)*((14/25:ℝ)+1)*r^2 := by positivity
    have h3 : 0<2+((14/25:ℝ)+2)*r := by positivity
    field_simp
    <;> ring
  have hpos : 0<terminalDeficitNormalized (14/25) r-
      terminalDeficitCubic
        (1-terminalEpsilonLower/(r^2*terminalPowerMajorant (14/25) r)) := by
    rw [he]
    positivity
  linarith only [hpos]

end LeanVerification.UpperLeftThirdCompletion
