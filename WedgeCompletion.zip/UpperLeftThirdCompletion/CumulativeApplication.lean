import LeanVerification.UpperLeftThirdCompletion.CumulativeMoment
import LeanVerification.UpperLeftThirdCompletion.TerminalAbel
import LeanVerification.UpperLeftThirdCompletion.TerminalDensityScaling

/-! The cumulative kernel, actual terminal center comparison, and both
likelihood-ratio orders imply the strict third-ray sign everywhere in
the lower half of regional row 18. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion ExteriorCompletion UpperLeftCompletion RegionalComplex
set_option maxHeartbeats 3200000

theorem third_cumulative_terminal_center_neg {p : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) :
    (∫v in Ioi (0:ℝ),thirdCumulativeKernel p v*derivativeDensityWeight p 1 v)<0 := by
  have hp : 0<p := by linarith
  have hcenter := actual_ray_two_center_terminal_pos hpl (by linarith : p≤14/25)
  have hneg : densityOrderMoment 3 p 1<0 := by
    apply (densityOrder_signedJetIntegral_neg_iff 2 hp (by linarith) (by norm_num : (0:ℝ)<1)).mp
    norm_num
    exact hcenter
  have hs : thirdScaledRayMoment p 1 1=densityOrderMoment 3 p 1 := by
    rw [densityOrderMoment_eq]
    simp only [thirdScaledRayMoment,one_mul]
  have hi := thirdScaledRayMoment_cumulative hpl hpu (by norm_num : (0:ℝ)<1)
    (by norm_num : (0:ℝ)<1)
  simp only [Real.one_rpow,one_mul] at hi
  rw [hs] at hi
  rw [←hi]
  exact hneg

theorem third_cumulative_terminal_energy_neg {p σ : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) (hσ : 0<σ) (hσ1 : σ≤1) :
    (∫v in Ioi (0:ℝ),thirdCumulativeKernel p v*derivativeDensityWeight p 1 (σ*v))<0 := by
  by_cases he : σ=1
  · simpa only [he,one_mul] using third_cumulative_terminal_center_neg hpl hpu
  have hσlt : σ<1 := lt_of_le_of_ne hσ1 he
  have hp : 0<p := by linarith
  have hp2 : p≤2/3 := by linarith
  obtain ⟨c,hc,hzero,hleft,hright⟩ := thirdCumulativeKernel_single_crossing hpl hpu
  have hint : IntegrableOn (fun v => thirdCumulativeKernel p v * derivativeDensityWeight p 1 v)
      (Ioi (0 : ℝ)) := by
    simpa only [one_mul] using
      (thirdCumulative_weight_integrable hpl hpu
        (by norm_num : (0 : ℝ) < 1) (by norm_num : (0 : ℝ) < 1))
  exact integral_one_crossing_likelihood_neg hc hzero hleft hright
    (fun v hv => derivativeDensityWeight_pos hp hp2 (by norm_num) (mul_pos hσ hv))
    (fun v hv => derivativeDensityWeight_pos hp hp2 (by norm_num) hv)
    (terminalDerivativeDensity_scaling_ratio_strictMonoOn hp hp2 hσ hσlt).monotoneOn
    (thirdCumulative_weight_integrable hpl hpu (by norm_num) hσ)
    hint
    (third_cumulative_terminal_center_neg hpl hpu)

theorem third_cumulative_parameter_energy_neg {p l σ : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) (hl : 0<l) (hlu : l<1)
    (hσ : 0<σ) (hσ1 : σ≤1) :
    (∫v in Ioi (0:ℝ),thirdCumulativeKernel p v*derivativeDensityWeight p l (σ*v))<0 := by
  have hp : 0<p := by linarith
  have hp2 : p≤2/3 := by linarith
  obtain ⟨c,hc,hzero,hleft,hright⟩ := thirdCumulativeKernel_single_crossing hpl hpu
  have hmono : MonotoneOn (fun v => derivativeDensityWeight p l (σ*v)/
      derivativeDensityWeight p 1 (σ*v)) (Ioi (0:ℝ)) := by
    intro u hu v hv huv
    exact (derivativeDensityWeight_ratio_strictMonoOn hp hp2 hl hlu).monotoneOn
      (mul_pos hσ hu) (mul_pos hσ hv) (mul_le_mul_of_nonneg_left huv hσ.le)
  exact integral_one_crossing_likelihood_neg hc hzero hleft hright
    (fun v hv => derivativeDensityWeight_pos hp hp2 hl (mul_pos hσ hv))
    (fun v hv => derivativeDensityWeight_pos hp hp2 (by norm_num) (mul_pos hσ hv)) hmono
    (thirdCumulative_weight_integrable hpl hpu hl hσ)
    (thirdCumulative_weight_integrable hpl hpu (by norm_num) hσ)
    (third_cumulative_terminal_energy_neg hpl hpu hσ hσ1)

theorem thirdScaledRayMoment_neg {p l σ : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) (hl : 0<l) (hlu : l<1)
    (hσ : 0<σ) (hσ1 : σ≤1) : thirdScaledRayMoment p l σ<0 := by
  rw [thirdScaledRayMoment_cumulative hpl hpu hl hσ]
  exact mul_neg_of_pos_of_neg (Real.rpow_pos_of_pos hσ _)
    (third_cumulative_parameter_energy_neg hpl hpu hl hlu hσ hσ1)

theorem thirdScaledRayMoment_eq_normalized {p l δ : ℝ} (hp : 0<p) (hl : 0<l) :
    thirdScaledRayMoment p l (δ/lowAngleDeficit p l)=
      rayNormalizedMoment 3 p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) δ := by
  dsimp only [thirdScaledRayMoment,rayNormalizedMoment]
  apply setIntegral_congr_fun measurableSet_Ioi
  intro v hv
  dsimp only [densityOrderDensity]
  rw [show lowAngleDeficit p l*(δ/lowAngleDeficit p l*v)=δ*v by
    field_simp [(lowAngleDeficit_pos hp hl.le).ne']]

theorem actual_ray_two_positive_low_third_strip {p l δ : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) (hl : 0<l) (hlu : l<1)
    (hδ : 0<δ) (hδH : δ≤lowAngleDeficit p l) :
    0<negativeRayJetIntegral 2 p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) δ := by
  have hp : 0<p := by linarith
  have hH : 0<lowAngleDeficit p l := lowAngleDeficit_pos hp hl.le
  have hσ : 0<δ/lowAngleDeficit p l := div_pos hδ hH
  have hσ1 : δ/lowAngleDeficit p l≤1 := (div_le_one hH).mpr hδH
  have hneg := thirdScaledRayMoment_neg hpl hpu hl hlu hσ hσ1
  rw [thirdScaledRayMoment_eq_normalized hp hl] at hneg
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hn := negativeRayJetIntegral_normalized 2 hp (by linarith : p<1) hA hB hC hδ
  norm_num only [Nat.reduceAdd,show (-1:ℝ)^3=-1 by norm_num,neg_one_mul] at hn
  have hcoef := mul_pos (negativeRayCoefficient_pos 3) (Real.rpow_pos_of_pos hδ (-(5/2 : ℝ)))
  have hh := mul_neg_of_pos_of_neg hcoef hneg
  rw [←hn] at hh
  exact neg_neg_iff_pos.mp hh

theorem physical_ray_two_positive_low_third_strip (D F δ : ℝ)
    (hD : D< -1) (hFl : 6/5≤F) (hFu : F≤5/4) (hDF : -F<D)
    (hδ : 0<δ) (hδH : δ≤zeroEndpointHeight D F) :
    0<negativeRayJetIntegral 2 (2*F-2) (loudTurnA D F) (loudTurnB D F)
      (loudTurnC D F) δ := by
  have hF : 1<F := by linarith
  obtain ⟨hp,hl,hlu⟩ := physical_lowAngle_parameters hD hF hDF
  have hpl : 2/5≤upperLeftRayP F := by dsimp only [upperLeftRayP];linarith
  have hpu : upperLeftRayP F≤1/2 := by dsimp only [upperLeftRayP];linarith
  rw [physical_lowAngle_center_height D F hF] at hδH
  have hh := actual_ray_two_positive_low_third_strip hpl hpu hl hlu hδ hδH
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  rw [hA,hB,hC,show 2*F-2=upperLeftRayP F from rfl]
  exact hh

end LeanVerification.UpperLeftThirdCompletion
