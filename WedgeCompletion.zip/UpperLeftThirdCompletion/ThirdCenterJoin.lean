import LeanVerification.UpperLeftCompletion.PhysicalCenterJoin
import LeanVerification.UpperLeftThirdCompletion.TerminalCenterCertificates
import LeanVerification.UpperLeftThirdCompletion.TerminalActualData

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion ExteriorCompletion ExteriorSpectralCompletion UpperLeftCompletion Sharpness
set_option maxHeartbeats 4800000

theorem actual_contour_third_center {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2) :
    Real.sqrt 2*(exteriorAbelJet D F hD hF 2 (zeroEndpointHeight D F)+
      negativeRayJetIntegral 2 (2*F-2) (loudTurnA D F) (loudTurnB D F)
        (loudTurnC D F) (zeroEndpointHeight D F))=
      12*Real.pi*tau3Polynomial D F := by
  have he := physicalContourPeriodJet_center_eq hD hF hFu 2
  have hc := actual_tau3_polynomial D F
  have hπ : 12*Real.pi≠0 := mul_ne_zero (by norm_num) Real.pi_ne_zero
  dsimp only [periodCoefficient] at hc
  norm_num [Nat.factorial] at hc
  have hc' : iteratedDeriv 3 (centerPeriod D F) 0=12*Real.pi*tau3Polynomial D F := by
    have hden : (6:ℝ)*(2*Real.pi)=12*Real.pi := by ring
    rw [hden] at hc
    exact (div_eq_iff hπ).mp hc |>.trans (mul_comm _ _)
  simpa only [physicalContourPeriodJet,sub_zero,even_two.neg_one_pow,one_mul] using he.trans hc'

theorem actual_ray_two_center {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2) :
    negativeRayJetIntegral 2 (2*F-2) (loudTurnA D F) (loudTurnB D F)
      (loudTurnC D F) (zeroEndpointHeight D F)=
        6*Real.sqrt 2*Real.pi*tau3Polynomial D F-
          exteriorAbelJet D F hD hF 2 (zeroEndpointHeight D F) := by
  have he := actual_contour_third_center hD hF hFu
  have hs := Real.sq_sqrt (by norm_num : (0:ℝ)≤2)
  have hm := congrArg (fun x : ℝ => Real.sqrt 2*x) he
  dsimp only at hm
  rw [←mul_assoc,←pow_two,hs] at hm
  linarith

theorem terminalCenterRatio_pole_ratio {p : ℝ} (hp : 0<p) :
    terminalCenterRatio p=
      6*Real.sqrt 2*Real.pi*terminalTauThree p*(lowAngleDeficit p 1)^3/
        (2*Real.sqrt (terminalSaddle p/2)) := by
  have hp2 : 0<p+2 := by positivity
  have hw : 0<(p+2)/p := by positivity
  have hs0 := (Real.sqrt_pos.mpr hp).ne'
  have hs2 := (Real.sqrt_pos.mpr hp2).ne'
  have h2 := (Real.sqrt_pos.mpr (by norm_num : (0:ℝ)<2)).ne'
  rw [lowAngleDeficit_terminal hp]
  dsimp only [terminalCenterRatio,terminalTauThree,terminalSaddle]
  rw [Real.sqrt_div hw.le,Real.sqrt_div hp2.le,Real.sqrt_mul hp.le]
  field_simp [hp.ne',hp2.ne']
  ring_nf
  simp only [Real.sq_sqrt hp.le,Real.sq_sqrt (show (0:ℝ)≤2 by norm_num)]
  <;> ring

theorem terminal_center_pole_lt_low {p : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) :
    2*Real.sqrt (terminalSaddle p/2)/(lowAngleDeficit p 1)^3<
      6*Real.sqrt 2*Real.pi*terminalTauThree p := by
  have hp : 0<p := by linarith
  have hA : 0<2*Real.sqrt (terminalSaddle p/2) := by
    have hs := terminalSaddle_pos hp
    positivity
  have hH : 0<(lowAngleDeficit p 1)^3 := pow_pos (lowAngleDeficit_pos hp (by norm_num)) 3
  have hR := terminalCenterRatio_gt_one hpl hpu
  rw [terminalCenterRatio_pole_ratio hp] at hR
  exact (div_lt_iff₀ hH).mpr ((one_lt_div hA).mp hR)

theorem terminal_center_refined_pole_lt_high {p : ℝ}
    (hpl : 1/2≤p) (hpu : p≤14/25) :
    2*Real.sqrt (terminalSaddle p/2)*(1-terminalDeficitAverage*p*(p+1))/
      (lowAngleDeficit p 1)^3<6*Real.sqrt 2*Real.pi*terminalTauThree p := by
  have hp : 0<p := by linarith
  have hA : 0<2*Real.sqrt (terminalSaddle p/2) := by
    have hs := terminalSaddle_pos hp
    positivity
  have hH : 0<(lowAngleDeficit p 1)^3 := pow_pos (lowAngleDeficit_pos hp (by norm_num)) 3
  have hR := terminalCenterRatio_plus_average_gt_one hpl hpu
  rw [terminalCenterRatio_pole_ratio hp] at hR
  have hh : 1-terminalDeficitAverage*p*(p+1)<
    6*Real.sqrt 2*Real.pi*terminalTauThree p*(lowAngleDeficit p 1)^3/
      (2*Real.sqrt (terminalSaddle p/2)) := by linarith only [hR]
  have hm := (lt_div_iff₀ hA).mp hh
  exact (div_lt_iff₀ hH).mpr (by nlinarith only [hm])

end LeanVerification.UpperLeftThirdCompletion
