import LeanVerification.UpperLeftThirdCompletion.DerivativeDensityOrder

/-! Actual energy differentiation of the derivative density, reduced to a
rational elasticity in the globally selected positive ray coordinate. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion UpperLeftCompletion
set_option maxHeartbeats 3600000
set_option maxRecDepth 6000

def derivativeDensityElasticity (p l r : ℝ) : ℝ :=
  (r*rayPolynomial (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r/
    rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r)*
  (-densityDerivativeC p l r+densityDerivativeCPrime p l r/densityDerivativeC p l r-
    (p-1)/r-rayEulerSlope p (lowAngleA p l) (lowAngleB p l) r/
      rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r)

theorem hasDerivAt_rayEnergySlope_logarithmic {p A B C r : ℝ}
    (hr : 0<r) (hE : rayEulerPolynomial p A B C r≠0) :
    HasDerivAt (rayEnergySlope p A B C)
      (rayEnergySlope p A B C r*((p-1)/r+
        rayEulerSlope p A B r/rayEulerPolynomial p A B C r)) r := by
  have hd := (Real.hasDerivAt_rpow_const (p:=p-1) (Or.inl hr.ne')).mul
    (hasDerivAt_rayEulerPolynomial p A B C r)
  convert hd using 1
  dsimp only [rayEnergySlope]
  rw [Real.rpow_sub_one hr.ne' (p-1)]
  field_simp
  <;> ring

theorem hasDerivAt_derivativeDensityRadialSpeed {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    HasDerivAt (derivativeDensityRadialSpeed p l)
      (-(derivativeDensityRadialSpeed p l v)^2*
        ((p-1)/densityOrderInverse p l v+
          rayEulerSlope p (lowAngleA p l) (lowAngleB p l) (densityOrderInverse p l v)/
          rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l)
            (densityOrderInverse p l v))) v := by
  let r := densityOrderInverse p l v
  have hr : 0<r := densityOrderInverse_pos hp hl hv
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hE := rayEulerPolynomial_pos hp hA hB.le hC hr
  have hS := rayEnergySlope_pos hp hA hB.le hC hr
  have hSlope : HasDerivAt
      (fun x => rayEnergySlope p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l)
        (densityOrderInverse p l x))
      ((rayEnergySlope p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r*
        ((p-1)/r+rayEulerSlope p (lowAngleA p l) (lowAngleB p l) r/
          rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r))*
            derivativeDensityRadialSpeed p l v) v := by
    have hout := @hasDerivAt_rayEnergySlope_logarithmic p (lowAngleA p l) (lowAngleB p l)
      (lowAngleC p l) r hr hE.ne'
    have hin := hasDerivAt_densityOrderInverse_energy hp hl hv
    exact hout.comp v hin
  have hd := (hasDerivAt_const v (lowAngleDeficit p l)).div hSlope hS.ne'
  convert hd using 1
  dsimp only [derivativeDensityRadialSpeed]
  field_simp [hS.ne']
  <;> ring

theorem derivativeDensityRadialEnergy_identity {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    v*derivativeDensityRadialSpeed p l v=
      densityOrderInverse p l v*
        rayPolynomial (lowAngleA p l) (lowAngleB p l) (lowAngleC p l)
          (densityOrderInverse p l v)/
        rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l)
          (densityOrderInverse p l v) := by
  let r := densityOrderInverse p l v
  have hr : 0<r := densityOrderInverse_pos hp hl hv
  have he : v=rayEnergy p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r/
      lowAngleDeficit p l := (densityOrderEnergy_inverse hp hl hv).symm
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hE := rayEulerPolynomial_pos hp hA hB.le hC hr
  have hH := lowAngleDeficit_pos hp hl.le
  have hpow := (Real.rpow_pos_of_pos hr p).ne'
  change v*(lowAngleDeficit p l/rayEnergySlope p (lowAngleA p l) (lowAngleB p l)
    (lowAngleC p l) r)=r*rayPolynomial (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r/
    rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r
  rw [he]
  dsimp only [rayEnergy,rayEnergySlope]
  rw [Real.rpow_sub_one hr.ne']
  field_simp
  <;> ring

theorem hasDerivAt_derivativeDensityWeight_energy {p l v : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) (hv : 0<v) :
    HasDerivAt (derivativeDensityWeight p l)
      (derivativeDensityElasticity p l (densityOrderInverse p l v)*
        derivativeDensityWeight p l v/v) v := by
  let r := densityOrderInverse p l v
  have hr : 0<r := densityOrderInverse_pos hp hl hv
  have hR := hasDerivAt_derivativeDensityRho hp hl hv
  have hC := (hasDerivAt_densityDerivativeC hp hl hr).comp v
    (hasDerivAt_densityOrderInverse_energy hp hl hv)
  have hd := (hR.mul hC).mul (hasDerivAt_derivativeDensityRadialSpeed hp hl hv)
  have he : derivativeDensityWeight p l=ᶠ[𝓝 v]
      (fun x => derivativeDensityRho p l x*
        densityDerivativeC p l (densityOrderInverse p l x)*
        derivativeDensityRadialSpeed p l x) := by
    filter_upwards [Ioi_mem_nhds hv] with x hx
    exact derivativeDensityWeight_formula hp hl hx
  have hd' := hd.congr_of_eventuallyEq he
  convert hd' using 1
  dsimp only [derivativeDensityElasticity]
  rw [←derivativeDensityRadialEnergy_identity hp hl hv,
    derivativeDensityWeight_formula hp hl hv]
  have hc := (densityDerivativeC_pos hp hp2 hl hr).ne'
  dsimp only [r] at hc ⊢
  field_simp [hc,hv.ne']
  <;> ring

end LeanVerification.UpperLeftThirdCompletion
