import LeanVerification.UpperLeftCompletion.DensityOrder
import LeanVerification.AnalyticTwoPartials

/-! A strict spatial score comparison for the derivative of the normalized
ray density.  All functions are explicit rational functions of the actual
positive ray coordinate. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion UpperLeftCompletion
set_option maxHeartbeats 3200000
set_option maxRecDepth 5000

def densityDerivativeAlpha (p : ℝ) : ℝ := 1/p-1/2

def rayLogGradient (a p A B C r : ℝ) : ℝ :=
  a*(2*A*r+B)/rayPolynomial A B C r+
    rayEulerSlope p A B r/rayEulerPolynomial p A B C r

def rayLogGradientSlope (a p A B C r : ℝ) : ℝ :=
  a*(2*A*rayPolynomial A B C r-(2*A*r+B)^2)/(rayPolynomial A B C r)^2+
    (2*(p+2)*A*rayEulerPolynomial p A B C r-(rayEulerSlope p A B r)^2)/
      (rayEulerPolynomial p A B C r)^2

def densityDerivativeC (p l r : ℝ) : ℝ :=
  rayLogGradient (densityDerivativeAlpha p) p (lowAngleA p l) (lowAngleB p l)
    (lowAngleC p l) r

def densityDerivativeCPrime (p l r : ℝ) : ℝ :=
  rayLogGradientSlope (densityDerivativeAlpha p) p (lowAngleA p l) (lowAngleB p l)
    (lowAngleC p l) r

def densityDerivativeA (p l r : ℝ) : ℝ :=
  p*(l*p^2*(r+1)+4*l*p+2*p+8)/((l*p+p+2)*(l*p*(r+1)+2)^3)

def densityDerivativeAPrime (p l r : ℝ) : ℝ :=
  -2*l*p^2*(l*p^2*(r+1)+6*l*p+2*p+12)/
    ((l*p+p+2)*(l*p*(r+1)+2)^4)

def densityDerivativeScore (p l r : ℝ) : ℝ :=
  densityOrderScore p l r+(densityDerivativeC p l r)⁻¹*densityDerivativeA p l r

theorem densityDerivativeAlpha_ge_one {p : ℝ} (hp : 0<p) (hp2 : p≤2/3) :
    1≤densityDerivativeAlpha p := by
  have h : (3/2:ℝ)≤1/p := (le_div_iff₀ hp).2 (by linarith)
  unfold densityDerivativeAlpha
  linarith

theorem hasDerivAt_rayLogGradient {a p A B C r : ℝ}
    (hP : rayPolynomial A B C r≠0) (hE : rayEulerPolynomial p A B C r≠0) :
    HasDerivAt (rayLogGradient a p A B C) (rayLogGradientSlope a p A B C r) r := by
  have hS := ((hasDerivAt_id r).const_mul (2*A)).add_const B
  have hP' := hasDerivAt_rayPolynomial A B C r
  have hE' := hasDerivAt_rayEulerPolynomial p A B C r
  have hd := ((hS.const_mul a).div hP' hP).add
    ((hasDerivAt_rayEulerSlope p A B r).div hE' hE)
  convert hd using 1
  simp only [rayLogGradientSlope,id_eq,mul_one]
  ring

theorem rayLogGradient_pos {a p A B C r : ℝ}
    (ha : 0<a) (hp : 0<p) (hA : 0<A) (hB : 0<B) (hC : 0<C) (hr : 0<r) :
    0<rayLogGradient a p A B C r := by
  have hP := rayPolynomial_pos hA.le hB.le hC hr
  have hE := rayEulerPolynomial_pos hp hA.le hB.le hC hr
  dsimp only [rayLogGradient,rayEulerSlope]
  positivity

theorem rayLogGradient_square_add_slope_pos {a p A B C r : ℝ}
    (ha : 1≤a) (hp : 0<p) (hA : 0<A) (hB : 0<B) (hC : 0<C) (hr : 0<r) :
    0<(rayLogGradient a p A B C r)^2+rayLogGradientSlope a p A B C r := by
  have hP := rayPolynomial_pos hA.le hB.le hC hr
  have hE := rayEulerPolynomial_pos hp hA.le hB.le hC hr
  have hS : 0<2*A*r+B := by positivity
  have hT : 0<rayEulerSlope p A B r := by unfold rayEulerSlope; positivity
  have ha0 : 0<a := lt_of_lt_of_le (by norm_num) ha
  have ha1 : 0≤a-1 := sub_nonneg.mpr ha
  have he : (rayLogGradient a p A B C r)^2+rayLogGradientSlope a p A B C r=
      a*(a-1)*((2*A*r+B)/rayPolynomial A B C r)^2+
      a*(2*A)/rayPolynomial A B C r+
      (2*(p+2)*A)/rayEulerPolynomial p A B C r+
      2*a*((2*A*r+B)/rayPolynomial A B C r)*
        (rayEulerSlope p A B r/rayEulerPolynomial p A B C r) := by
    unfold rayLogGradient rayLogGradientSlope
    field_simp
    <;> ring
  rw [he]
  positivity

theorem densityDerivativeC_pos {p l r : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) (hr : 0<r) :
    0<densityDerivativeC p l r := by
  obtain ⟨_,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hA : 0<lowAngleA p l := by unfold lowAngleA; positivity
  exact rayLogGradient_pos (lt_of_lt_of_le (by norm_num)
    (densityDerivativeAlpha_ge_one hp hp2)) hp hA hB hC hr

theorem hasDerivAt_densityDerivativeC {p l r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) :
    HasDerivAt (densityDerivativeC p l) (densityDerivativeCPrime p l r) r := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  exact hasDerivAt_rayLogGradient (rayPolynomial_pos hA hB.le hC hr).ne'
    (rayEulerPolynomial_pos hp hA hB.le hC hr).ne'

theorem densityDerivative_inverse_C_slope_lt_one {p l r : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) (hr : 0<r) :
    -densityDerivativeCPrime p l r/(densityDerivativeC p l r)^2<1 := by
  obtain ⟨_,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hA : 0<lowAngleA p l := by unfold lowAngleA; positivity
  have hs := rayLogGradient_square_add_slope_pos
    (densityDerivativeAlpha_ge_one hp hp2) hp hA hB hC hr
  have hc := densityDerivativeC_pos hp hp2 hl hr
  apply (div_lt_one (sq_pos_of_pos hc)).2
  change 0<(densityDerivativeC p l r)^2+densityDerivativeCPrime p l r at hs
  linarith only [hs]

theorem densityDerivativeA_pos {p l r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) : 0<densityDerivativeA p l r := by
  unfold densityDerivativeA
  positivity

theorem hasDerivAt_densityDerivativeA {p l r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) :
    HasDerivAt (densityDerivativeA p l) (densityDerivativeAPrime p l r) r := by
  have hK : l*p+p+2≠0 := by positivity
  have hT : l*p*(r+1)+2≠0 := by positivity
  have hD : (l*p+p+2)*(l*p*(r+1)+2)^3≠0 := by positivity
  have hS := (hasDerivAt_id r).add_const 1
  have hN := (((hS.const_mul (l*p^2)).add_const (4*l*p)).add_const (2*p)).add_const 8
  have hT' := (hS.const_mul (l*p)).add_const 2
  have hd := (hN.const_mul p).div ((hT'.pow 3).const_mul (l*p+p+2)) hD
  convert hd using 1
  simp only [densityDerivativeAPrime,id_eq,one_mul]
  field_simp
  <;> ring

theorem densityDerivativeAPrime_nonpos {p l r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) : densityDerivativeAPrime p l r≤0 := by
  apply le_of_lt
  unfold densityDerivativeAPrime
  apply div_neg_of_neg_of_pos
  · have : 0<2*l*p^2*(l*p^2*(r+1)+6*l*p+2*p+12) := by positivity
    linarith only [this]
  · positivity

theorem hasDerivAt_densityDerivativeScore {p l r : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) (hr : 0<r) :
    HasDerivAt (densityDerivativeScore p l)
      (-densityDerivativeA p l r+
        (-densityDerivativeCPrime p l r/(densityDerivativeC p l r)^2)*
          densityDerivativeA p l r+
        (densityDerivativeC p l r)⁻¹*densityDerivativeAPrime p l r) r := by
  have hs : HasDerivAt (densityOrderScore p l) (-densityDerivativeA p l r) r := by
    convert hasDerivAt_densityOrderScore hp hl hr using 1
    unfold densityDerivativeA
    ring
  have hc := (hasDerivAt_densityDerivativeC hp hl hr).inv
    (densityDerivativeC_pos hp hp2 hl hr).ne'
  convert hs.add (hc.mul (hasDerivAt_densityDerivativeA hp hl hr)) using 1
  ring

theorem densityDerivativeScore_deriv_neg {p l r : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) (hr : 0<r) :
    deriv (densityDerivativeScore p l) r<0 := by
  rw [(hasDerivAt_densityDerivativeScore hp hp2 hl hr).deriv]
  have hA := densityDerivativeA_pos hp hl hr
  have hC := inv_pos.mpr (densityDerivativeC_pos hp hp2 hl hr)
  have hD := densityDerivative_inverse_C_slope_lt_one hp hp2 hl hr
  have hprod := mul_lt_mul_of_pos_right hD hA
  have hneg := mul_nonpos_of_nonneg_of_nonpos hC.le
    (densityDerivativeAPrime_nonpos hp hl hr)
  linarith only [hprod,hneg]

theorem densityDerivativeScore_strictAntiOn {p l : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) :
    StrictAntiOn (densityDerivativeScore p l) (Ioi (0:ℝ)) := by
  apply strictAntiOn_of_deriv_neg (convex_Ioi _)
  · intro r hr
    exact (hasDerivAt_densityDerivativeScore hp hp2 hl hr).continuousAt.continuousWithinAt
  · intro r hr
    rw [interior_Ioi] at hr
    exact densityDerivativeScore_deriv_neg hp hp2 hl hr

end LeanVerification.UpperLeftThirdCompletion
