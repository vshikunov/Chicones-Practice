import LeanVerification.UpperLeftThirdCompletion.TerminalAbel
import LeanVerification.UpperLeftCompletion.CompleteRows

/-! The upper part of row 18: the actual third ray kernel has one crossing.
The actual density order transfers the proved terminal center sign, and
the spatial Euler identity propagates it throughout the interior. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion ExteriorCompletion UpperLeftCompletion RegionalComplex
set_option maxHeartbeats 2200000

theorem third_ray_angle_bounds {p : ℝ} (hp : 1/2≤p) (hpu : p<5/6) :
    Real.pi/2<(3:ℝ)*(Real.pi*(1-p)) ∧
      (3:ℝ)*(Real.pi*(1-p))≤3*Real.pi/2 := by
  constructor
  · nlinarith [mul_pos Real.pi_pos (show 0<5/6-p by linarith)]
  · nlinarith [mul_nonneg Real.pi_pos.le (show 0≤p-1/2 by linarith)]

theorem negativeRayJet_three_crossing {p A B C δ : ℝ}
    (hp : 1/2≤p) (hpu : p<5/6) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hδ : 0<δ) :
    ∃r₀ : ℝ,0<r₀ ∧ (negativeRayJet 3 p A B C δ r₀).re=0 ∧
      (∀r,0<r → r<r₀ → 0<(-1:ℝ)*(negativeRayJet 3 p A B C δ r).re) ∧
      (∀r,r₀<r → (-1:ℝ)*(negativeRayJet 3 p A B C δ r).re<0) := by
  have hp0 : 0<p := by linarith
  have hp1 : p<1 := by linarith
  have hθ : 0<Real.pi*(1-p) := mul_pos Real.pi_pos (by linarith)
  have hθu : Real.pi*(1-p)<Real.pi := by nlinarith [mul_pos Real.pi_pos hp0]
  have ha := third_ray_angle_bounds hp hpu
  obtain ⟨v₀,hv₀,_,hz,hpos,hneg⟩ := rayMomentKernel_single_crossing (k:=3) hθ hθu ha.1 ha.2
  refine ⟨rayInverse p A B C (δ*v₀),?_⟩
  convert negativeRayJet_crossing_of_kernel 3 hp0 hp1 hA hB hC hδ hv₀ hz hpos hneg using 1 <;>
    norm_num

theorem actual_third_ray_deriv_pos_at_zero {p A B C δ : ℝ}
    (hp : 1/2≤p) (hpu : p<5/6) (hA : 0<A) (hB : 0<B) (hC : 0<C)
    (hdisc : 4*A*C≤B^2) (hδ : 0<δ)
    (hz : -negativeRayJetIntegral 2 p A B C δ=0) :
    0<deriv (fun d => -negativeRayJetIntegral 2 p A B C d) δ := by
  have hp0 : 0<p := by linarith
  have hp1 : p<1 := by linarith
  obtain ⟨r,hr,_,hl,hu⟩ := negativeRayJet_three_crossing hp hpu hA.le hB hC hδ
  have hi := actual_rayEuler_one_crossing 2 (-1) hp0 hp1 hA hB hC hdisc hδ hr hl hu
  rw [neg_eq_zero.mp hz,mul_zero,sub_zero] at hi
  rw [((hasDerivAt_negativeRayJetIntegral 2 hp0 hp1 hA hB.le hC.le hδ).neg).deriv]
  apply (mul_pos_iff_of_pos_left hδ).mp
  nlinarith only [hi]

theorem actual_ray_two_positive_of_center_high {p A B C δ H : ℝ}
    (hp : 1/2≤p) (hpu : p<5/6) (hA : 0<A) (hB : 0<B) (hC : 0<C)
    (hdisc : 4*A*C≤B^2) (hδ : 0<δ) (hδH : δ≤H)
    (hcenter : 0<negativeRayJetIntegral 2 p A B C H) :
    0<negativeRayJetIntegral 2 p A B C δ := by
  have hi := neg_left_of_deriv_pos_at_zeros hδH
    (f:=fun d => -negativeRayJetIntegral 2 p A B C d)
    (fun d hd => ((hasDerivAt_negativeRayJetIntegral 2 (by linarith) (by linarith)
      hA hB.le hC.le (hδ.trans_le hd.1)).neg).differentiableAt)
    (fun d hd hz => actual_third_ray_deriv_pos_at_zero hp hpu hA hB hC hdisc
      (hδ.trans_le hd.1) hz) (neg_neg_of_pos hcenter)
  exact neg_neg_iff_pos.mp hi

theorem actual_ray_two_center_high_mixture_pos {p l : ℝ}
    (hpl : 1/2≤p) (hpu : p≤14/25) (hl : 0<l) (hl1 : l<1) :
    0<negativeRayJetIntegral 2 p (lowAngleA p l) (lowAngleB p l)
      (lowAngleC p l) (lowAngleDeficit p l) := by
  have hp : 0<p := by linarith
  have hpu' : p<5/6 := by linarith
  have ha := third_ray_angle_bounds hpl hpu'
  have hcenter := actual_ray_two_center_terminal_pos (by linarith : 2/5≤p) hpu
  have hs : (-1:ℝ)^(2+1)*negativeRayJetIntegral 2 p (lowAngleA p 1) (lowAngleB p 1)
      (lowAngleC p 1) (lowAngleDeficit p 1)<0 := by
    norm_num only [show (-1:ℝ)^(2+1)= -1 by norm_num,neg_one_mul,neg_neg_iff_pos]
    exact hcenter
  have ht := densityOrder_signedJetIntegral_neg_transfer 2 hp (by linarith) hl hl1 ha.1 ha.2 hs
  simpa only [show (-1:ℝ)^(2+1)= -1 by norm_num,neg_one_mul,neg_neg_iff_pos] using ht

theorem physical_ray_two_center_high_third_strip_pos (D F : ℝ)
    (hD : D< -1) (hFl : 5/4≤F) (hFu : F≤32/25) (hDF : -F<D) :
    0<negativeRayJetIntegral 2 (2*F-2) (loudTurnA D F) (loudTurnB D F)
      (loudTurnC D F) (zeroEndpointHeight D F) := by
  have hF : 1<F := by linarith
  obtain ⟨_,hl0,hl1⟩ := physical_lowAngle_parameters hD hF hDF
  have hpl : 1/2≤upperLeftRayP F := by dsimp only [upperLeftRayP];linarith
  have hpu : upperLeftRayP F≤14/25 := by dsimp only [upperLeftRayP];linarith
  have hc := actual_ray_two_center_high_mixture_pos hpl hpu hl0 hl1
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  simpa only [hA,hB,hC,physical_lowAngle_center_height D F hF,upperLeftRayP] using hc

/-- The actual second ray integral is positive at every positive deficit
up to the center, including F=5/4 and F=32/25. -/
theorem physical_ray_two_positive_high_third_strip (D F δ : ℝ)
    (hD : D< -1) (hFl : 5/4≤F) (hFu : F≤32/25) (hDF : -F<D)
    (hδ : 0<δ) (hδH : δ≤zeroEndpointHeight D F) :
    0<negativeRayJetIntegral 2 (2*F-2) (loudTurnA D F) (loudTurnB D F)
      (loudTurnC D F) δ := by
  have hF : 1<F := by linarith
  obtain ⟨hA,hB,hC⟩ := loudTurn_coefficients_pos D F hD hF
  exact actual_ray_two_positive_of_center_high (by linarith) (by linarith) hA hB hC
    (loudTurn_discriminant_pos hD hF hDF).le hδ hδH
    (physical_ray_two_center_high_third_strip_pos D F hD hFl hFu hDF)

end LeanVerification.UpperLeftThirdCompletion
