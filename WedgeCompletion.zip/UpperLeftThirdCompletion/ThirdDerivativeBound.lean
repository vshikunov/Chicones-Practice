import LeanVerification.BoundaryAssembly.ZeroInput
import LeanVerification.MultiplicitySignVariation

/-! A strictly positive actual third period derivative bounds the zeros
of the first derivative by two. The stronger statement controls the sum
of their analytic multiplicities; the regional table counts distinct
isolated critical energies. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud AnalyticMultiplicity
set_option maxHeartbeats 900000

theorem actual_period_derivative_multiplicityBound_two_of_third_positive (D F:ℝ)
    (hthird:∀h,AdmissibleEnergy D F h→0 < iteratedDeriv 3 (periodQuadrature D F) h) :
    MultiplicityBound 2 (deriv (periodQuadrature D F)) {h|AdmissibleEnergy D F h} := by
  have hconv:Convex ℝ {h|AdmissibleEnergy D F h} := (ordConnected_admissibleEnergy D F).convex
  have ha:AnalyticOnNhd ℝ (deriv (periodQuadrature D F)) {h|AdmissibleEnergy D F h} :=
    fun h hh => (analyticAt_periodQuadrature_energy D F h hh).deriv
  have haa:AnalyticOnNhd ℝ (deriv (deriv (periodQuadrature D F))) {h|AdmissibleEnergy D F h} :=
    fun h hh => (analyticAt_periodQuadrature_energy D F h hh).deriv.deriv
  apply multiplicityBound_of_derivative (n:=1) hconv ha
  apply multiplicityBound_of_derivative (n:=0) hconv haa
  apply MultiplicityBound.of_nonvanishing
  intro h hh
  have hp:0<deriv (deriv (deriv (periodQuadrature D F))) h := by
    simpa only [iteratedDeriv_succ,iteratedDeriv_zero] using hthird h hh
  exact hp.ne'

theorem criticalPeriodBound_two_of_actual_third_positive (D F:ℝ)
    (hthird:∀h,AdmissibleEnergy D F h→0 < iteratedDeriv 3 (periodQuadrature D F) h) :
    CriticalPeriodBound 2 D F := by
  have hb := actual_period_derivative_multiplicityBound_two_of_third_positive D F hthird
  intro s hs
  exact hb.card_zeros_le
    (fun h hh => (analyticAt_periodQuadrature_energy D F h hh).deriv) s
    (fun h hh => ⟨(hs h hh).1,(hs h hh).2.1⟩)

end LeanVerification.UpperLeftThirdCompletion
