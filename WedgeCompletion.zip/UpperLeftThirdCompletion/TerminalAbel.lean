import LeanVerification.UpperLeftThirdCompletion.TerminalCoordinates
import LeanVerification.UpperLeftThirdCompletion.ThirdAbelDeficit
import LeanVerification.UpperLeftThirdCompletion.ThirdCenterJoin

/-! Direct actual exterior Abel bounds at the terminal Loud parameter.
The quantitative deficit is integrated with its exact elementary moments. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion ExteriorCompletion ExteriorSpectralCompletion UpperLeftCompletion RegionalComplex Sharpness
set_option maxHeartbeats 4800000

theorem actual_terminal_abel_kernel_formula {p e t : ℝ}
    (hp : 0<p) (he : 0<e) (ht : 0<t) :
    exteriorAbelKernel (lowAngleParameterD p 1) (lowAngleParameterF p)
      (lowAngleParameterD_lt_neg_one hp (by norm_num)) (lowAngleParameterF_gt_one hp) 2 e t=
      Real.sqrt (terminalSaddle p/2)*thirdAbelMomentKernel 0 e t*
        (1-terminalThirdDeficit p (terminalInverseRadius p (e+t))) := by
  dsimp only [exteriorAbelKernel]
  rw [actual_terminal_third_jet_eq hp (add_pos he ht)]
  dsimp only [terminalThirdScaled,thirdAbelMomentKernel]
  norm_num only [Nat.mul_zero,pow_zero,mul_one]
  rw [Real.rpow_neg ht.le,←Real.sqrt_eq_rpow]
  simp only [div_eq_mul_inv,mul_inv_rev]
  ring

theorem actual_terminal_abel_kernel_fold_le {p e t : ℝ}
    (hp : 0<p) (he : 0<e) (ht : 0<t) :
    exteriorAbelKernel (lowAngleParameterD p 1) (lowAngleParameterF p)
      (lowAngleParameterD_lt_neg_one hp (by norm_num)) (lowAngleParameterF_gt_one hp) 2 e t≤
      Real.sqrt (terminalSaddle p/2)*thirdAbelMomentKernel 0 e t := by
  rw [actual_terminal_abel_kernel_formula hp he ht]
  have hD := terminalThirdDeficit_pos hp (terminalInverseRadius_pos hp (add_pos he ht))
  apply mul_le_of_le_one_right
  · exact mul_nonneg (Real.sqrt_nonneg _) (thirdAbelMomentKernel_nonneg he ht 0)
  · linarith

theorem actual_terminal_abel_two_fold_bound {p e : ℝ} (hp : 0<p) (he : 0<e) :
    exteriorAbelJet (lowAngleParameterD p 1) (lowAngleParameterF p)
      (lowAngleParameterD_lt_neg_one hp (by norm_num)) (lowAngleParameterF_gt_one hp) 2 e≤
      2*Real.sqrt (terminalSaddle p/2)/e^3 := by
  have hm : e∈exteriorRange (lowAngleParameterD p 1) (lowAngleParameterF p) := by
    rw [physical_terminal_range hp];exact he
  have hi := exteriorAbelKernel_integrable _ _ e
    (lowAngleParameterD_lt_neg_one hp (by norm_num)) (lowAngleParameterF_gt_one hp) 2 hm
  have hk := (thirdAbelMomentKernel_integrable he 0).const_mul (Real.sqrt (terminalSaddle p/2))
  have hh := integral_mono_ae hi hk (show _≤ᵐ[volume.restrict (Ioi (0:ℝ))] _ from by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact actual_terminal_abel_kernel_fold_le hp he ht)
  rw [integral_const_mul,integral_thirdAbelMomentKernel he] at hh
  change exteriorAbelJet _ _ _ _ 2 e≤_
  norm_num only [thirdAbelMoment,Nat.cast_zero,mul_zero,zero_add] at hh
  convert hh using 1 <;> ring

theorem actual_terminal_abel_center_kernel_refined_le {p t : ℝ}
    (hpl : 1/2≤p) (hpu : p≤14/25) (ht : 0<t) :
    exteriorAbelKernel (lowAngleParameterD p 1) (lowAngleParameterF p)
      (lowAngleParameterD_lt_neg_one (by linarith : 0<p) (by norm_num))
      (lowAngleParameterF_gt_one (by linarith : 0<p)) 2 (lowAngleDeficit p 1) t≤
        Real.sqrt (terminalSaddle p/2)*thirdAbelRefinedKernel p (lowAngleDeficit p 1) t := by
  have hp : 0<p := by linarith
  have hH : 0<lowAngleDeficit p 1 := lowAngleDeficit_pos hp (by norm_num)
  have htH : 0<lowAngleDeficit p 1+t := add_pos hH ht
  let r := terminalInverseRadius p (lowAngleDeficit p 1+t)
  let u := (abelRootRatio (lowAngleDeficit p 1) t)^2
  have hr : 0<r := terminalInverseRadius_pos hp htH
  have hu : 0≤u := sq_nonneg _
  have hu1 : u<1 := by
    dsimp only [u]
    rw [abelRootRatio_sq hH ht.le]
    exact (div_lt_one htH).mpr (by linarith)
  have he : terminalEpsilonLower≤r^2*(1+r)^p*(1-u) := by
    dsimp only [r,u]
    rw [terminal_center_coordinate_identity hp ht.le]
    exact (terminalEpsilon_lower hp hpu).le
  have hD := terminalThirdDeficit_lower hpl hpu hr hu hu1 he
  rw [actual_terminal_abel_kernel_formula hp hH ht]
  have hB : 0≤Real.sqrt (terminalSaddle p/2)*thirdAbelMomentKernel 0 (lowAngleDeficit p 1) t :=
    mul_nonneg (Real.sqrt_nonneg _) (thirdAbelMomentKernel_nonneg hH ht 0)
  have hh := mul_le_mul_of_nonneg_left (show 1-terminalThirdDeficit p r≤
    1-p*(p+1)*terminalDeficitCubic u from by linarith) hB
  dsimp only [thirdAbelRefinedKernel,thirdAbelDeficitKernel]
  dsimp only [r,u] at hh
  nlinarith only [hh]

theorem actual_terminal_abel_two_center_refined_bound {p : ℝ}
    (hpl : 1/2≤p) (hpu : p≤14/25) :
    exteriorAbelJet (lowAngleParameterD p 1) (lowAngleParameterF p)
      (lowAngleParameterD_lt_neg_one (by linarith : 0<p) (by norm_num))
      (lowAngleParameterF_gt_one (by linarith : 0<p)) 2 (lowAngleDeficit p 1)≤
      2*Real.sqrt (terminalSaddle p/2)*(1-terminalDeficitAverage*p*(p+1))/
        (lowAngleDeficit p 1)^3 := by
  have hp : 0<p := by linarith
  have hH : 0<lowAngleDeficit p 1 := lowAngleDeficit_pos hp (by norm_num)
  have hm : lowAngleDeficit p 1∈exteriorRange (lowAngleParameterD p 1) (lowAngleParameterF p) := by
    rw [physical_terminal_range hp];exact hH
  have hi := exteriorAbelKernel_integrable _ _ _
    (lowAngleParameterD_lt_neg_one hp (by norm_num)) (lowAngleParameterF_gt_one hp) 2 hm
  have hk := (thirdAbelRefinedKernel_integrable p hH).const_mul (Real.sqrt (terminalSaddle p/2))
  have hh := integral_mono_ae hi hk (show _≤ᵐ[volume.restrict (Ioi (0:ℝ))] _ from by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact actual_terminal_abel_center_kernel_refined_le hpl hpu ht)
  rw [integral_const_mul,integral_thirdAbelRefinedKernel p hH] at hh
  change exteriorAbelJet _ _ _ _ 2 (lowAngleDeficit p 1)≤_
  convert hh using 1 <;> ring

theorem actual_ray_two_center_terminal_pos {p : ℝ}
    (hpl : 2/5≤p) (hpu : p≤14/25) :
    0<negativeRayJetIntegral 2 p (lowAngleA p 1) (lowAngleB p 1)
      (lowAngleC p 1) (lowAngleDeficit p 1) := by
  have hp : 0<p := by linarith
  let D := lowAngleParameterD p 1
  let F := lowAngleParameterF p
  have hD : D< -1 := lowAngleParameterD_lt_neg_one hp (by norm_num)
  have hF : 1<F := lowAngleParameterF_gt_one hp
  have hFu : F<3/2 := by dsimp only [F,lowAngleParameterF];linarith
  have hb : exteriorAbelJet D F hD hF 2 (lowAngleDeficit p 1)<
      6*Real.sqrt 2*Real.pi*terminalTauThree p := by
    rcases le_total p (1/2) with hpL | hpH
    · exact (actual_terminal_abel_two_fold_bound hp (lowAngleDeficit_pos hp (by norm_num))).trans_lt
        (terminal_center_pole_lt_low hpl hpL)
    · exact (actual_terminal_abel_two_center_refined_bound hpH hpu).trans_lt
        (terminal_center_refined_pole_lt_high hpH hpu)
  have hc := actual_ray_two_center hD hF hFu
  have ht : tau3Polynomial D F=terminalTauThree p := tau3_lowAngle_terminal p
  rw [ht] at hc
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  rw [hA,hB,hC,physical_lowAngle_center_height D F hF,
    show 2*F-2=upperLeftRayP F from rfl,lowAngleParameter_rayP,
    lowAngleParameter_rayLambda hp] at hc
  linarith

end LeanVerification.UpperLeftThirdCompletion
