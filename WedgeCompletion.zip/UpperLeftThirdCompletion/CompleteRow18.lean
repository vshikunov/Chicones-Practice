import LeanVerification.UpperLeftThirdCompletion.CumulativeApplication
import LeanVerification.UpperLeftThirdCompletion.ThirdRawOrientation
import LeanVerification.UpperLeftThirdCompletion.ThirdDerivativeBound

/-! Full regional row 18 for the actual original-time physical period.
The two ray comparisons cover the full interval, including all shared
and terminal F edges. The actual third period derivative is positive. -/
noncomputable section
open Set
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion ExteriorCompletion UpperLeftCompletion
set_option maxHeartbeats 1500000

theorem physical_ray_two_positive_third_strip (D F δ : ℝ)
    (hD : D< -1) (hFl : 6/5≤F) (hFu : F≤32/25) (hDF : -F<D)
    (hδ : 0<δ) (hδH : δ≤zeroEndpointHeight D F) :
    0<negativeRayJetIntegral 2 (2*F-2) (loudTurnA D F) (loudTurnB D F)
      (loudTurnC D F) δ := by
  by_cases hmid : F≤5/4
  · exact physical_ray_two_positive_low_third_strip D F δ hD hFl hmid hDF hδ hδH
  · exact physical_ray_two_positive_high_third_strip D F δ hD (le_of_not_ge hmid) hFu hDF hδ hδH

/-- A proved interior sign on every actual admissible physical energy. -/
theorem physical_period_third_derivative_pos_third_strip (D F h : ℝ)
    (hD : D< -1) (hFl : 6/5≤F) (hFu : F≤32/25) (hDF : -F<D)
    (hh : AdmissibleEnergy D F h) :
    0 < iteratedDeriv 3 (periodQuadrature D F) h := by
  have hF : 1<F := by linarith
  have hδ := loudTurn_actual_deficit_pos D F h hD hF hh
  have hδH : zeroEndpointHeight D F-h≤zeroEndpointHeight D F := sub_le_self _ hh.1.le
  have hraw := physical_ray_two_positive_third_strip D F (zeroEndpointHeight D F-h)
    hD hFl hFu hDF hδ hδH
  have hm := exteriorAbelJet_pos D F (zeroEndpointHeight D F-h) hD hF 2
    (physical_deficit_mem_exteriorRange D F h hD hF hh)
  rw [actual_physical_period_all_contour_derivatives hD hF (by linarith) hh 2]
  simpa only [physicalContourPeriodJet,neg_one_sq,one_mul] using
    mul_pos (Real.sqrt_pos.mpr (by norm_num : (0:ℝ)<2)) (add_pos hm hraw)

theorem physical_period_derivative_multiplicityBound_two_third_strip (D F : ℝ)
    (hD : D< -1) (hFl : 6/5≤F) (hFu : F≤32/25) (hDF : -F<D) :
    AnalyticMultiplicity.MultiplicityBound 2 (deriv (periodQuadrature D F))
      {h | AdmissibleEnergy D F h} :=
  actual_period_derivative_multiplicityBound_two_of_third_positive D F
    (fun h hh => physical_period_third_derivative_pos_third_strip D F h hD hFl hFu hDF hh)

theorem criticalPeriodBound_two_upper_left_third_strip (D F : ℝ)
    (hD : D< -1) (hFl : 6/5≤F) (hFu : F≤32/25) (hDF : -F<D) :
    CriticalPeriodBound 2 D F :=
  criticalPeriodBound_two_of_actual_third_positive D F
    (fun h hh => physical_period_third_derivative_pos_third_strip D F h hD hFl hFu hDF hh)

theorem full_regional_row18 (D F : ℝ) (hp : parameterRegion 18 D F) :
    CriticalPeriodBound (parameterRegionBound 18) D F :=
  criticalPeriodBound_two_upper_left_third_strip D F hp.2.2.2 hp.1 hp.2.1 hp.2.2.1

end LeanVerification.UpperLeftThirdCompletion
