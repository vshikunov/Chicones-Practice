import LeanVerification.UpperLeftThirdCompletion.TerminalDensityElasticity

/-! Energy scaling is an actual likelihood-ratio order for the terminal
derivative density.  It follows from the proved strict elasticity order,
without differentiating any unbounded integral. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open UpperLeftCompletion
set_option maxHeartbeats 1800000

theorem hasDerivAt_log_terminalDerivativeDensityWeight {p v : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hv : 0<v) :
    HasDerivAt (fun x => Real.log (derivativeDensityWeight p 1 x))
      (actualTerminalDerivativeElasticity p v/v) v := by
  have hw := derivativeDensityWeight_pos hp hp2 (by norm_num : (0:ℝ)<1) hv
  convert (hasDerivAt_terminalDerivativeDensityWeight hp hp2 hv).log hw.ne' using 1
  field_simp
  <;> ring

theorem hasDerivAt_terminalDerivativeDensity_scaling_logratio {p σ v : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hσ : 0<σ) (hv : 0<v) :
    HasDerivAt (fun x => Real.log (derivativeDensityWeight p 1 (σ*x))-
        Real.log (derivativeDensityWeight p 1 x))
      ((actualTerminalDerivativeElasticity p (σ*v)-actualTerminalDerivativeElasticity p v)/v) v := by
  have hscaled := (hasDerivAt_log_terminalDerivativeDensityWeight hp hp2 (mul_pos hσ hv)).comp v
    ((hasDerivAt_id v).const_mul σ)
  convert hscaled.sub (hasDerivAt_log_terminalDerivativeDensityWeight hp hp2 hv) using 1
  simp only [mul_one]
  field_simp
  <;> ring

theorem terminalDerivativeDensity_scaling_ratio_strictMonoOn {p σ : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hσ : 0<σ) (hσ1 : σ<1) :
    StrictMonoOn (fun v => derivativeDensityWeight p 1 (σ*v)/derivativeDensityWeight p 1 v)
      (Ioi (0:ℝ)) := by
  have hlog : StrictMonoOn (fun v => Real.log (derivativeDensityWeight p 1 (σ*v))-
      Real.log (derivativeDensityWeight p 1 v)) (Ioi (0:ℝ)) := by
    apply strictMonoOn_of_deriv_pos (convex_Ioi _)
    · intro v hv
      exact (hasDerivAt_terminalDerivativeDensity_scaling_logratio hp hp2 hσ hv).continuousAt.continuousWithinAt
    · intro v hv
      rw [interior_Ioi] at hv
      rw [(hasDerivAt_terminalDerivativeDensity_scaling_logratio hp hp2 hσ hv).deriv]
      apply div_pos _ hv
      apply sub_pos.mpr
      exact actualTerminalDerivativeElasticity_strictAntiOn hp (mul_pos hσ hv) hv
        (by simpa only [one_mul] using mul_lt_mul_of_pos_right hσ1 hv)
  intro u hu v hv huv
  have hsu := derivativeDensityWeight_pos hp hp2 (by norm_num : (0:ℝ)<1) (mul_pos hσ hu)
  have hsv := derivativeDensityWeight_pos hp hp2 (by norm_num : (0:ℝ)<1) (mul_pos hσ hv)
  have hu' := derivativeDensityWeight_pos hp hp2 (by norm_num : (0:ℝ)<1) hu
  have hv' := derivativeDensityWeight_pos hp hp2 (by norm_num : (0:ℝ)<1) hv
  apply (Real.log_lt_log_iff (div_pos hsu hu') (div_pos hsv hv')).mp
  rw [Real.log_div hsu.ne' hu'.ne',Real.log_div hsv.ne' hv'.ne']
  exact hlog hu hv huv

end LeanVerification.UpperLeftThirdCompletion
