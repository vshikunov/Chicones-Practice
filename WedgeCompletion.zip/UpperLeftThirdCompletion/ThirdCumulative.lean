import LeanVerification.UpperLeftThirdCompletion.ThirdKernelSigns
import LeanVerification.UpperLeftThirdCompletion.CumulativeCrossing
import LeanVerification.UpperLeftThirdCompletion.DerivativeDensityEndpoints

/-! The actual cumulative third-ray kernel has one strict crossing.
Its primitive, endpoint limits, global bound, and products with all actual
scaled derivative densities are established here. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open ContourCompletion UpperLeftCompletion
set_option maxHeartbeats 600000

def physicalWeightedThirdKernel (p : ℝ) : ℝ→ℝ :=
  weightedThirdKernel (densityDerivativeAlpha p) (Real.pi*(1-p))
def thirdCumulativeKernel (p : ℝ) : ℝ→ℝ := cumulativeFromZero (physicalWeightedThirdKernel p)

theorem continuous_physicalWeightedThirdKernel {p : ℝ} (hpl : 2/5≤p) (hpu : p≤1/2) :
    Continuous (physicalWeightedThirdKernel p) := by
  have hp : 0<p := by linarith
  apply continuous_weightedThirdKernel
  · exact (densityDerivativeAlpha_ge_one hp (by linarith)).trans' zero_le_one
  · exact mul_pos Real.pi_pos (by linarith)
  · nlinarith [Real.pi_pos]

theorem physicalWeightedThirdKernel_integrable {p : ℝ} (hpl : 2/5≤p) (hpu : p≤1/2) :
    IntegrableOn (physicalWeightedThirdKernel p) (Ioi 0) := by
  have hp : 0<p := by linarith
  have hinvlo : (2:ℝ)≤1/p := (le_div_iff₀ hp).mpr (by linarith)
  have hinvhi : 1/p≤(5/2:ℝ) := (div_le_iff₀ hp).mpr (by linarith)
  exact weightedThirdKernel_integrable (by dsimp only [densityDerivativeAlpha];linarith)
    (by dsimp only [densityDerivativeAlpha];linarith)
    (mul_pos Real.pi_pos (by linarith)) (by nlinarith [Real.pi_pos])

theorem thirdCumulativeKernel_hasDerivAt {p v : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) (hv : 0<v) :
    HasDerivAt (thirdCumulativeKernel p) (physicalWeightedThirdKernel p v) v :=
  cumulativeFromZero_hasDerivAt (continuous_physicalWeightedThirdKernel hpl hpu).continuousOn hv

theorem thirdCumulativeKernel_continuous {p : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) : Continuous (thirdCumulativeKernel p) :=
  intervalIntegral.continuous_primitive
    (fun a b => (continuous_physicalWeightedThirdKernel hpl hpu).intervalIntegrable a b) 0

theorem thirdCumulativeKernel_zero (p : ℝ) : thirdCumulativeKernel p 0=0 := by
  simp only [thirdCumulativeKernel,cumulativeFromZero,intervalIntegral.integral_same]

theorem thirdCumulativeKernel_tendsto_zero {p : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) :
    Tendsto (thirdCumulativeKernel p) (𝓝[>] (0:ℝ)) (𝓝 0) := by
  have hh := (thirdCumulativeKernel_continuous hpl hpu).continuousAt (x:=0) |>.tendsto
  rw [thirdCumulativeKernel_zero] at hh
  exact hh.mono_left nhdsWithin_le_nhds

theorem thirdCumulativeKernel_tendsto_atTop {p : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) :
    Tendsto (thirdCumulativeKernel p) atTop (𝓝 (∫v in Ioi (0:ℝ),physicalWeightedThirdKernel p v)) :=
  cumulativeFromZero_tendsto (physicalWeightedThirdKernel_integrable hpl hpu)

theorem thirdCumulativeKernel_abs_bound {p v : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) (hv : 0≤v) :
    |thirdCumulativeKernel p v|≤∫t in Ioi (0:ℝ),|physicalWeightedThirdKernel p t| :=
  cumulativeFromZero_abs_bound (physicalWeightedThirdKernel_integrable hpl hpu) hv

theorem thirdCumulativeKernel_single_crossing {p : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) :
    ∃c : ℝ,0<c ∧ thirdCumulativeKernel p c=0 ∧
      (∀v,0<v → v<c → 0<thirdCumulativeKernel p v) ∧
      (∀v,c<v → thirdCumulativeKernel p v<0) := by
  have hc : ContinuousOn (physicalWeightedThirdKernel p) (Ici 0) :=
    (continuous_physicalWeightedThirdKernel hpl hpu).continuousOn
  have hi := physicalWeightedThirdKernel_integrable hpl hpu
  by_cases hhalf : p=1/2
  · subst p
    have he : physicalWeightedThirdKernel (1/2)=weightedThirdKernel (3/2) (Real.pi/2) := by
      funext v
      dsimp only [physicalWeightedThirdKernel,densityDerivativeAlpha]
      rw [show (1/(1/2:ℝ)-1/2)=(3/2:ℝ) by norm_num,
        show Real.pi*(1-(1/2:ℝ))=Real.pi/2 by ring]
    rw [he] at hc hi
    obtain ⟨a,ha,hpos,hneg⟩ := thirdKernel_terminal_single_crossing
    obtain ⟨c,hac,hzero,hleft,hright⟩ := cumulativeFromZero_one_sign_change hc hi ha
      (fun v hv => hpos v hv.1 hv.2) hneg integral_weightedThirdKernel_terminal_neg
    refine ⟨c,ha.trans hac,?_,?_,?_⟩
    · simpa only [thirdCumulativeKernel,he] using hzero
    · simpa only [thirdCumulativeKernel,he] using hleft
    · simpa only [thirdCumulativeKernel,he] using hright
  · have hpstrict : p<1/2 := lt_of_le_of_ne hpu hhalf
    obtain ⟨a,b,ha,hab,hpos,hneg,htail⟩ := thirdKernel_two_crossings hpl hpstrict
    obtain ⟨c,hcI,hzero,hleft,hright⟩ := cumulativeFromZero_two_sign_changes hc hi ha hab
      (fun v hv => hpos v hv.1 hv.2) (fun v hv => hneg v hv.1 hv.2) htail
      (integral_weightedThirdKernel_nonpos hpl hpu)
    exact ⟨c,ha.trans hcI.1,hzero,hleft,hright⟩

theorem thirdCumulative_weight_integrable {p l σ : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) (hl : 0<l) (hσ : 0<σ) :
    IntegrableOn (fun v => thirdCumulativeKernel p v*derivativeDensityWeight p l (σ*v)) (Ioi 0) := by
  have hp : 0<p := by linarith
  have hp2 : p≤2/3 := by linarith
  let B := ∫t in Ioi (0:ℝ),|physicalWeightedThirdKernel p t|
  have hi := (derivativeDensityWeight_scaled_integrable hp hp2 hl hσ).const_mul B
  have hwI := derivativeDensityWeight_scaled_integrable hp hp2 hl hσ
  apply hi.mono' ((thirdCumulativeKernel_continuous hpl hpu).aestronglyMeasurable.mul
    hwI.aestronglyMeasurable)
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with v hv
  dsimp only [Pi.mul_apply]
  rw [norm_mul,Real.norm_eq_abs,Real.norm_of_nonneg
    (derivativeDensityWeight_pos hp hp2 hl (mul_pos hσ hv)).le]
  exact mul_le_mul_of_nonneg_right (thirdCumulativeKernel_abs_bound hpl hpu hv.le)
    (derivativeDensityWeight_pos hp hp2 hl (mul_pos hσ hv)).le

end LeanVerification.UpperLeftThirdCompletion
