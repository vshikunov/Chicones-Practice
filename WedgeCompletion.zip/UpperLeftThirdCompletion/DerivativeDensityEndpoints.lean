import LeanVerification.UpperLeftThirdCompletion.DerivativeDensityOrder
import Mathlib.MeasureTheory.Integral.IntegralEqImproper

/-! The actual differentiated density has finite total mass.  Its two
endpoint limits are proved from the global positive inverse. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion UpperLeftCompletion
set_option maxHeartbeats 4800000
set_option maxRecDepth 5000

def derivativeDensityRadialRho (p l r : ℝ) : ℝ :=
  (lowAngleDeficit p l)^(densityDerivativeAlpha p)/
    ((rayPolynomial (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r)^(densityDerivativeAlpha p)*
      rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r)

theorem derivativeDensityRho_radial {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    derivativeDensityRho p l v=derivativeDensityRadialRho p l (densityOrderInverse p l v) := by
  let r := densityOrderInverse p l v
  have hr : 0<r := densityOrderInverse_pos hp hl hv
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hP := rayPolynomial_pos hA hB.le hC hr
  have hE := rayEulerPolynomial_pos hp hA hB.le hC hr
  have hH := lowAngleDeficit_pos hp hl.le
  have he : v=rayEnergy p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r/
      lowAngleDeficit p l := (densityOrderEnergy_inverse hp hl hv).symm
  have hpow : p*densityDerivativeAlpha p=1-p/2 := by
    dsimp only [densityDerivativeAlpha]
    field_simp
    ring
  have hV : v^(densityDerivativeAlpha p)=
      r^(1-p/2)*(rayPolynomial (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r)^(densityDerivativeAlpha p)/
        (lowAngleDeficit p l)^(densityDerivativeAlpha p) := by
    rw [he,Real.div_rpow (rayEnergy_pos hA hB.le hC hr).le hH.le]
    dsimp only [rayEnergy]
    rw [Real.mul_rpow (Real.rpow_nonneg hr.le _) hP.le,
      ←Real.rpow_mul hr.le,hpow]
  change (r^(1-p/2)/rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r)/
    v^(densityDerivativeAlpha p)=_
  rw [hV]
  dsimp only [derivativeDensityRadialRho]
  have hpr := (Real.rpow_pos_of_pos hr (1-p/2)).ne'
  have hPP := (Real.rpow_pos_of_pos hP (densityDerivativeAlpha p)).ne'
  have hHP := (Real.rpow_pos_of_pos hH (densityDerivativeAlpha p)).ne'
  field_simp
  <;> ring

theorem densityOrderEnergy_pos {p l r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) : 0<densityOrderEnergy p l r := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  exact div_pos (rayEnergy_pos hA hB.le hC hr) (lowAngleDeficit_pos hp hl.le)

theorem densityOrderInverse_tendsto_zero {p l : ℝ} (hp : 0<p) (hl : 0<l) :
    Tendsto (densityOrderInverse p l) (𝓝[>] (0:ℝ)) (𝓝 0) := by
  apply Metric.tendsto_nhds.mpr
  intro ε hε
  have hq := densityOrderEnergy_pos hp hl hε
  filter_upwards [self_mem_nhdsWithin,
    nhdsWithin_le_nhds (Iio_mem_nhds hq)] with v hv hvq
  have hr := densityOrderInverse_pos hp hl hv
  rw [Real.dist_eq,sub_zero,abs_of_pos hr]
  have hh := densityOrderInverse_strictMonoOn hp hl hv hq hvq
  rw [densityOrderInverse_eq_of_energy hp hl hε rfl] at hh
  exact hh

theorem densityOrderInverse_tendsto_atTop {p l : ℝ} (hp : 0<p) (hl : 0<l) :
    Tendsto (densityOrderInverse p l) atTop atTop := by
  apply tendsto_atTop.2
  intro b
  let R := max b 1
  have hR : 0<R := lt_of_lt_of_le zero_lt_one (le_max_right _ _)
  have hq := densityOrderEnergy_pos hp hl hR
  filter_upwards [eventually_ge_atTop (densityOrderEnergy p l R),eventually_gt_atTop (0:ℝ)] with v hv hv0
  have hh := (densityOrderInverse_strictMonoOn hp hl).monotoneOn hq hv0 hv
  rw [densityOrderInverse_eq_of_energy hp hl hR rfl] at hh
  exact (le_max_left b 1).trans hh

theorem derivativeDensityRadialRho_continuous_zero {p l : ℝ}
    (hp : 0<p) (hl : 0<l) : ContinuousAt (derivativeDensityRadialRho p l) 0 := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hP : rayPolynomial (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) 0≠0 := by
    simpa only [rayPolynomial,mul_zero,zero_pow (by norm_num : (2:ℕ)≠0),zero_add] using hC.ne'
  have hE : rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) 0≠0 := by
    simpa only [rayEulerPolynomial,mul_zero,zero_pow (by norm_num : (2:ℕ)≠0),zero_add] using
      (mul_pos hp hC).ne'
  have hPP0 : 0<rayPolynomial (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) 0 := by
    simpa only [rayPolynomial,mul_zero,zero_pow (by norm_num : (2:ℕ)≠0),zero_add] using hC
  have hPow := (Real.rpow_pos_of_pos hPP0 (densityDerivativeAlpha p)).ne'
  exact continuousAt_const.div
    (((hasDerivAt_rayPolynomial _ _ _ (0:ℝ)).continuousAt.rpow_const (Or.inl hP)).mul
      (hasDerivAt_rayEulerPolynomial _ _ _ _ (0:ℝ)).continuousAt) (mul_ne_zero hPow hE)

theorem derivativeDensityRho_tendsto_zero_endpoint {p l : ℝ}
    (hp : 0<p) (hl : 0<l) :
    Tendsto (derivativeDensityRho p l) (𝓝[>] (0:ℝ)) (𝓝 (derivativeDensityRadialRho p l 0)) := by
  have hh := (derivativeDensityRadialRho_continuous_zero hp hl).tendsto.comp
    (densityOrderInverse_tendsto_zero hp hl)
  apply hh.congr'
  filter_upwards [self_mem_nhdsWithin] with v hv
  exact (derivativeDensityRho_radial hp hl hv).symm

theorem derivativeDensityRadialRho_tendsto_atTop {p l : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) :
    Tendsto (derivativeDensityRadialRho p l) atTop (𝓝 0) := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have ha : 0<densityDerivativeAlpha p := lt_of_lt_of_le zero_lt_one
    (densityDerivativeAlpha_ge_one hp hp2)
  have hc : 0<(lowAngleC p l)^(densityDerivativeAlpha p)*((p+1)*lowAngleB p l) := by
    exact mul_pos (Real.rpow_pos_of_pos hC _) (mul_pos (by positivity) hB)
  have hd : Tendsto (fun r : ℝ =>
      (rayPolynomial (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r)^(densityDerivativeAlpha p)*
        rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r) atTop atTop := by
    apply tendsto_atTop_mono' atTop ?_ (tendsto_id.const_mul_atTop hc)
    filter_upwards [eventually_gt_atTop (0:ℝ)] with r hr
    have hP : lowAngleC p l≤rayPolynomial (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r := by
      dsimp only [rayPolynomial]
      nlinarith [mul_nonneg hA (sq_nonneg r),mul_nonneg hB.le hr.le]
    have hE : (p+1)*lowAngleB p l*r≤
      rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r := by
      dsimp only [rayEulerPolynomial]
      nlinarith [mul_nonneg (mul_nonneg (by positivity : 0≤p+2) hA) (sq_nonneg r),mul_pos hp hC]
    have hh := mul_le_mul (Real.rpow_le_rpow hC.le hP ha.le) hE
      (by positivity : 0≤(p+1)*lowAngleB p l*r)
      (Real.rpow_nonneg (hC.le.trans hP) _)
    convert hh using 1 <;> simp only [id_eq] <;> ring
  exact tendsto_const_nhds.div_atTop hd

theorem derivativeDensityRho_tendsto_atTop {p l : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) :
    Tendsto (derivativeDensityRho p l) atTop (𝓝 0) := by
  have hh := (derivativeDensityRadialRho_tendsto_atTop hp hp2 hl).comp
    (densityOrderInverse_tendsto_atTop hp hl)
  apply hh.congr'
  filter_upwards [eventually_gt_atTop (0:ℝ)] with v hv
  exact (derivativeDensityRho_radial hp hl hv).symm

theorem derivativeDensityWeight_integrable {p l : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) :
    IntegrableOn (derivativeDensityWeight p l) (Ioi 0) := by
  let F := Function.update (fun v => -derivativeDensityRho p l v) 0
    (-derivativeDensityRadialRho p l 0)
  have hzero := (derivativeDensityRho_tendsto_zero_endpoint hp hl).neg
  rw [←Ici_diff_left] at hzero
  have hc : ContinuousWithinAt F (Ici 0) 0 := continuousWithinAt_update_same.mpr hzero
  have hd : ∀v∈Ioi (0:ℝ),HasDerivAt F (derivativeDensityWeight p l v) v := by
    intro v hv
    have h := (hasDerivAt_derivativeDensityRho hp hl hv).neg
    simp only [neg_neg] at h
    apply h.congr_of_eventuallyEq
    filter_upwards [eventually_ne_nhds (ne_of_gt hv)] with x hx
    exact Function.update_of_ne hx _ _
  have ht : Tendsto F atTop (𝓝 0) := by
    have hh := (derivativeDensityRho_tendsto_atTop hp hp2 hl).neg
    simp only [neg_zero] at hh
    apply hh.congr'
    filter_upwards [eventually_ne_atTop (0:ℝ)] with x hx
    exact (Function.update_of_ne hx (-derivativeDensityRadialRho p l 0)
      (fun v => -derivativeDensityRho p l v)).symm
  exact integrableOn_Ioi_deriv_of_nonneg hc hd
    (fun v hv => (derivativeDensityWeight_pos hp hp2 hl hv).le) ht

theorem derivativeDensityWeight_scaled_integrable {p l σ : ℝ}
    (hp : 0<p) (hp2 : p≤2/3) (hl : 0<l) (hσ : 0<σ) :
    IntegrableOn (fun v => derivativeDensityWeight p l (σ*v)) (Ioi 0) := by
  apply (integrableOn_Ioi_comp_mul_left_iff (derivativeDensityWeight p l) 0 hσ).mpr
  simpa only [mul_zero] using derivativeDensityWeight_integrable hp hp2 hl

end LeanVerification.UpperLeftThirdCompletion
