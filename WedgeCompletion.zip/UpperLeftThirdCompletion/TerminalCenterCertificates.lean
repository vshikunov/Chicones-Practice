import LeanVerification.UpperLeftThirdCompletion.TerminalPolynomials

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftThirdCompletion
open Loud ContourCompletion ExteriorCompletion ExteriorSpectralCompletion UpperLeftCompletion Sharpness
set_option maxHeartbeats 9600000
set_option maxRecDepth 6000

def terminalCenterQuartic (p : ℝ) : ℝ :=
  2399*p^4+9596*p^3+9912*p^2+632*p-139

def terminalTauThree (p : ℝ) : ℝ :=
  (p+1)^2*terminalCenterQuartic p/311040

def terminalCenterRatio (p : ℝ) : ℝ :=
  Real.pi*(p+1)^2*terminalCenterQuartic p/
    (6480*p^2*(p+2)^3*Real.sqrt (p*(p+2)))

theorem tau3_lowAngle_terminal (p : ℝ) :
    tau3Polynomial (lowAngleParameterD p 1) (lowAngleParameterF p)=terminalTauThree p := by
  dsimp only [tau3Polynomial,lowAngleParameterD,lowAngleParameterF,
    terminalTauThree,terminalCenterQuartic]
  ring

theorem terminalCenterQuartic_pos {p : ℝ} (hp : 2/5≤p) :
    0<terminalCenterQuartic p := by
  have hx : 0≤p-2/5 := by linarith
  have he : terminalCenterQuartic p=((1484549/625) + (2399*((p-2/5)^4)) + ((67172/5)*((p-2/5)^3)) + ((593256/25)*((p-2/5)^2)) + ((1722728/125)*(p-2/5))) := by
    dsimp only [terminalCenterQuartic]
    ring
  rw [he]
  positivity


theorem terminal_center_low_certificate {p : ℝ}
    (hpl : (2/5)≤p) (hpu : p≤(1/2)) :
    0<(314159/100000:ℝ)^2*(p+1)^4*(terminalCenterQuartic p)^2-
      6480^2*p^5*(p+2)^7*1^2 := by
  let t : ℝ := (p-(2/5))/((1/10))
  have ht : 0≤t := by dsimp only [t]; nlinarith
  have htu : t≤1 := by dsimp only [t]; nlinarith
  have he : (314159/100000:ℝ)^2*(p+1)^4*(terminalCenterQuartic p)^2-
      6480^2*p^5*(p+2)^7*1^2=
      (40782736354281360809197081/2441406250000000000)*t^0*(1-t)^12 +
      (50238395594754471261074277/244140625000000000)*t^1*(1-t)^11 +
      (8991574671299744329095771/7812500000000000)*t^2*(1-t)^10 +
      (6028424468536776077707407/1562500000000000)*t^3*(1-t)^9 +
      (538365792135419195183154351/62500000000000000)*t^4*(1-t)^8 +
      (1681230438629452739434797/125000000000000)*t^5*(1-t)^7 +
      (37473058090076212851956109/2500000000000000)*t^6*(1-t)^6 +
      (1192577790517075248608583/100000000000000)*t^7*(1-t)^5 +
      (10626322720844114053771671/1600000000000000)*t^8*(1-t)^4 +
      (78979314880461347126541/32000000000000)*t^9*(1-t)^3 +
      (14144028614301433204071/25600000000000)*t^10*(1-t)^2 +
      (1466106426306113822163/25600000000000)*t^11*(1-t)^1 +
      (12616479131471223201/40960000000000)*t^12*(1-t)^0 := by
    dsimp only [t,terminalCenterQuartic,terminalDeficitAverage]
    ring
  rw [he]
  have h1 : 0≤1-t := by linarith
  by_cases ht0 : t=0
  · rw [ht0]
    norm_num
  · have htp : 0<t := lt_of_le_of_ne ht (Ne.symm ht0)
    positivity


theorem terminal_center_high_certificate {p : ℝ}
    (hpl : (1/2)≤p) (hpu : p≤(14/25)) :
    0<(314159/100000:ℝ)^2*(p+1)^4*(terminalCenterQuartic p)^2-
      6480^2*p^5*(p+2)^7*(1-terminalDeficitAverage*p*(p+1))^2 := by
  let t : ℝ := (p-(1/2))/((3/50))
  have ht : 0≤t := by dsimp only [t]; nlinarith
  have htu : t≤1 := by dsimp only [t]; nlinarith
  have he : (314159/100000:ℝ)^2*(p+1)^4*(terminalCenterQuartic p)^2-
      6480^2*p^5*(p+2)^7*(1-terminalDeficitAverage*p*(p+1))^2=
      (5991233513613223851108729/242851840000000000)*t^0*(1-t)^16 +
      (584603827561436442294889143/1517824000000000000)*t^1*(1-t)^15 +
      (42585885227920843499040493947/15178240000000000000)*t^2*(1-t)^14 +
      (342881449648335922316641247943/27104000000000000000)*t^3*(1-t)^13 +
      (535089089339387437624198388831727/13552000000000000000000)*t^4*(1-t)^12 +
      (153076115145326778136829384922969/1694000000000000000000)*t^5*(1-t)^11 +
      (15078751861726235994873079639137579/96250000000000000000000)*t^6*(1-t)^10 +
      (1941010001599838186003684590342766331/9264062500000000000000000)*t^7*(1-t)^9 +
      (504792643209866256176955697155760938879/2316015625000000000000000000)*t^8*(1-t)^8 +
      (127656512122092205466667741396996386223/723754882812500000000000000)*t^9*(1-t)^7 +
      (56944838280801486027829160885079851001/516967773437500000000000000)*t^10*(1-t)^6 +
      (18806453492090416247823363225590727069/360608100891113281250000000)*t^11*(1-t)^5 +
      (20924454834222245748716643794704015228311/1153945922851562500000000000000)*t^12*(1-t)^4 +
      (631494432452591244585029946751679860947/144243240356445312500000000000)*t^13*(1-t)^3 +
      (2377906749463380045190060457915656971471/3606081008911132812500000000000)*t^14*(1-t)^2 +
      (1076907737547753907155063905565178707303/22538006305694580078125000000000)*t^15*(1-t)^1 +
      (318375907953415828393963920757814837241/1126900315284729003906250000000000)*t^16*(1-t)^0 := by
    dsimp only [t,terminalCenterQuartic,terminalDeficitAverage]
    ring
  rw [he]
  have h1 : 0≤1-t := by linarith
  by_cases ht0 : t=0
  · rw [ht0]
    norm_num
  · have htp : 0<t := lt_of_le_of_ne ht (Ne.symm ht0)
    positivity


theorem terminal_center_ratio_of_certificate {p c : ℝ}
    (hp : 2/5≤p) (hc : 0≤c)
    (hcert : 0<(314159/100000:ℝ)^2*(p+1)^4*(terminalCenterQuartic p)^2-
      6480^2*p^5*(p+2)^7*c^2) : c<terminalCenterRatio p := by
  have hp0 : 0<p := by linarith
  have hq := terminalCenterQuartic_pos hp
  have hroot : 0<Real.sqrt (p*(p+2)) := Real.sqrt_pos.mpr (by positivity)
  have hπ : (314159/100000:ℝ)<Real.pi := by linarith [Real.pi_gt_d6]
  have hπ2 : (314159/100000:ℝ)^2<Real.pi^2 := by nlinarith [Real.pi_pos]
  have hmult : 0≤(p+1)^4*(terminalCenterQuartic p)^2 := by positivity
  have hs := mul_le_mul_of_nonneg_right hπ2.le hmult
  have hN : 0<Real.pi*(p+1)^2*terminalCenterQuartic p := by positivity
  have hD : 0<6480*p^2*(p+2)^3*Real.sqrt (p*(p+2)) := by positivity
  have hroot2 := Real.sq_sqrt (by positivity : 0≤p*(p+2))
  have hsq : (6480*p^2*(p+2)^3*Real.sqrt (p*(p+2))*c)^2=
      6480^2*p^5*(p+2)^7*c^2 := by
    calc
      _=6480^2*p^4*(p+2)^6*(Real.sqrt (p*(p+2)))^2*c^2 := by ring
      _=_ := by rw [hroot2]; ring
  have hNsq : (314159/100000:ℝ)^2*(p+1)^4*(terminalCenterQuartic p)^2≤
      (Real.pi*(p+1)^2*terminalCenterQuartic p)^2 := by nlinarith only [hs]
  have hgap : (6480*p^2*(p+2)^3*Real.sqrt (p*(p+2))*c)^2<
      (Real.pi*(p+1)^2*terminalCenterQuartic p)^2 := by
    rw [hsq]
    linarith only [hcert,hNsq]
  have hprod : 0≤6480*p^2*(p+2)^3*Real.sqrt (p*(p+2))*c := mul_nonneg hD.le hc
  have hh : 6480*p^2*(p+2)^3*Real.sqrt (p*(p+2))*c<
      Real.pi*(p+1)^2*terminalCenterQuartic p := by
    nlinarith only [hgap,hN,hprod]
  dsimp only [terminalCenterRatio]
  apply (lt_div_iff₀ hD).mpr
  simpa only [mul_comm] using hh

theorem terminalCenterRatio_gt_one {p : ℝ}
    (hpl : 2/5≤p) (hpu : p≤1/2) : 1<terminalCenterRatio p := by
  exact terminal_center_ratio_of_certificate hpl (by norm_num)
    (terminal_center_low_certificate hpl hpu)

theorem terminalCenterRatio_plus_average_gt_one {p : ℝ}
    (hpl : 1/2≤p) (hpu : p≤14/25) :
    1<terminalCenterRatio p+terminalDeficitAverage*p*(p+1) := by
  have hc : 0≤1-terminalDeficitAverage*p*(p+1) := by
    have hp0 : 0≤p := by linarith
    have hm := mul_self_le_mul_self hp0 hpu
    dsimp only [terminalDeficitAverage]
    nlinarith
  have hh := terminal_center_ratio_of_certificate (by linarith : 2/5≤p) hc
    (terminal_center_high_certificate hpl hpu)
  linarith only [hh]

end LeanVerification.UpperLeftThirdCompletion
