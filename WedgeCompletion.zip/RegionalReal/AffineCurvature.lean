import LeanVerification.RegionalReal.PhysicalNonstationarity
import LeanVerification.Loud.ForceJets

/-! Exact actual-potential curvature for the affine comparison function
`1 + F X`. The calculation is valid at every real parameter F, including
the logarithmic coordinate F=0. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal
open Loud
set_option maxHeartbeats 2000000

def affineAux (F X : ℝ) : ℝ := 1+F*X
def mixtureSum (D w : ℝ) : ℝ := (2*D+1)*w-2*D
def affineHModel (D F X : ℝ) : ℝ :=
  affineAux F X*mixtureSum D (inversePosition F X)/(inversePosition F X)^2
def affineH1 (D F w : ℝ) : ℝ :=
  ((2*D+1)*(F-1)*w-2*D*(F-2))/w^2
def affineH2 (D F w : ℝ) : ℝ :=
  (-(2*D+1)*(F-1)*w+4*D*(F-2))/(w^F*w^2)
def affineCurvatureNumerator (D F w : ℝ) : ℝ :=
  2*(1-F)*(4*F-1)*((2*D+1)*w)^2+
  (-16*F^2+30*F-5)*((2*D+1)*w)*(-2*D)+
  4*(2*F-1)*(2-F)*(-2*D)^2

theorem mechanicalDomain_eventually {F X : ℝ} (hX : mechanicalDomain F X) :
    ∀ᶠ Z in 𝓝 X,mechanicalDomain F Z := by
  exact (continuousAt_const.add (continuousAt_const.mul continuousAt_id)).eventually
    (Ioi_mem_nhds hX)

theorem hasDerivAt_affineAux (F X : ℝ) : HasDerivAt (affineAux F) F X := by
  simpa only [affineAux,mul_one] using ((hasDerivAt_id X).const_mul F).const_add 1

theorem deriv_affineAux (F : ℝ) : deriv (affineAux F)=fun _ => F := by
  funext X
  exact (hasDerivAt_affineAux F X).deriv

theorem second_deriv_affineAux (F : ℝ) : deriv (deriv (affineAux F))=fun _ => 0 := by
  rw [deriv_affineAux]
  funext X
  simp

theorem analyticAt_affineAux (F X : ℝ) : AnalyticAt ℝ (affineAux F) X :=
  analyticAt_const.add (analyticAt_const.mul analyticAt_id)

theorem affineAux_eq_rpow (F X : ℝ) (hX : mechanicalDomain F X) :
    affineAux F X=(inversePosition F X)^F := by
  by_cases hF : F=0
  · simp [affineAux,hF]
  · calc
      affineAux F X=1+F*position F (inversePosition F X) := by
        rw [position_inverse F X hX]; rfl
      _ = (inversePosition F X)^F := one_add_mul_position F _ hF

theorem inversePosition_derivative_quotient (F X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (inversePosition F) (inversePosition F X/(inversePosition F X)^F) X := by
  have hd := hasDerivAt_inversePosition F X hX
  rw [Real.rpow_sub (inversePosition_pos F X hX),Real.rpow_one] at hd
  exact hd

theorem physical_potential_second_jet (D F X : ℝ) (hX : mechanicalDomain F X) :
    CriticalEnergy.jet (fun Z => potential D F (inversePosition F Z)) 2 X=
      forceSpatialSlope D F (inversePosition F X) := by
  have he : deriv (fun Z => potential D F (inversePosition F Z)) =ᶠ[𝓝 X]
      forceInPosition D F := by
    filter_upwards [mechanicalDomain_eventually hX] with Z hZ
    exact (hasDerivAt_potentialInPosition D F Z hZ).deriv
  exact he.deriv_eq.trans (hasDerivAt_forceInPosition D F X hX).deriv

theorem actual_affineH_eq_model (D F L X : ℝ) (hX : mechanicalDomain F X) :
    CriticalEnergy.coefficientH (fun Z => potential D F (inversePosition F Z))
      (affineAux F) L X=affineHModel D F X := by
  have hW1 := (hasDerivAt_potentialInPosition D F X hX).deriv
  have hW2 := physical_potential_second_jet D F X hX
  have hφ1 : CriticalEnergy.jet (affineAux F) 1 X=F :=
    (hasDerivAt_affineAux F X).deriv
  have hφ2 : CriticalEnergy.jet (affineAux F) 2 X=0 := by
    change deriv (deriv (affineAux F)) X=0
    rw [second_deriv_affineAux]
  have hW1' : CriticalEnergy.jet (fun Z => potential D F (inversePosition F Z)) 1 X=
      forceInPosition D F X := hW1
  rw [CriticalEnergy.coefficientH,hW2,hφ1,hφ2,hW1']
  simp only [mul_zero,add_zero]
  rw [affineHModel,affineAux_eq_rpow F X hX]
  unfold forceInPosition forceSpatialSlope forceSlopeNumerator force mixtureSum
  rw [Real.rpow_sub (inversePosition_pos F X hX),Real.rpow_two]
  field_simp
  ring

theorem hasDerivAt_affineHModel (D F X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (affineHModel D F) (affineH1 D F (inversePosition F X)) X := by
  let w := inversePosition F X
  have hw : w≠0 := (inversePosition_pos F X hX).ne'
  have hwF : w^F≠0 := (Real.rpow_pos_of_pos (inversePosition_pos F X hX) F).ne'
  have hdw := inversePosition_derivative_quotient F X hX
  have hd := ((hasDerivAt_affineAux F X).mul
    ((hdw.const_mul (2*D+1)).sub_const (2*D))).div (hdw.pow 2) (pow_ne_zero 2 hw)
  convert hd using 1
  rw [affineAux_eq_rpow F X hX]
  dsimp [affineH1,w]
  field_simp
  ring

theorem hasDerivAt_affineH1_position (D F X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (fun Z => affineH1 D F (inversePosition F Z))
      (affineH2 D F (inversePosition F X)) X := by
  let w := inversePosition F X
  have hw : w≠0 := (inversePosition_pos F X hX).ne'
  have hwF : w^F≠0 := (Real.rpow_pos_of_pos (inversePosition_pos F X hX) F).ne'
  have hdw := inversePosition_derivative_quotient F X hX
  have hd := ((hdw.const_mul ((2*D+1)*(F-1))).sub_const (2*D*(F-2))).div
    (hdw.pow 2) (pow_ne_zero 2 hw)
  convert hd using 1
  dsimp [affineH2,w]
  field_simp
  ring

theorem hasDerivAt_actual_affineH (D F L X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (CriticalEnergy.coefficientH
      (fun Z => potential D F (inversePosition F Z)) (affineAux F) L)
      (affineH1 D F (inversePosition F X)) X := by
  apply (hasDerivAt_affineHModel D F X hX).congr_of_eventuallyEq
  filter_upwards [mechanicalDomain_eventually hX] with Z hZ
  exact actual_affineH_eq_model D F L Z hZ

theorem second_deriv_actual_affineH (D F L X : ℝ) (hX : mechanicalDomain F X) :
    deriv (deriv (CriticalEnergy.coefficientH
      (fun Z => potential D F (inversePosition F Z)) (affineAux F) L)) X=
      affineH2 D F (inversePosition F X) := by
  have he : deriv (CriticalEnergy.coefficientH
      (fun Z => potential D F (inversePosition F Z)) (affineAux F) L) =ᶠ[𝓝 X]
      (fun Z => affineH1 D F (inversePosition F Z)) := by
    filter_upwards [mechanicalDomain_eventually hX] with Z hZ
    exact (hasDerivAt_actual_affineH D F L Z hZ).deriv
  exact he.deriv_eq.trans (hasDerivAt_affineH1_position D F X hX).deriv

theorem actual_affineCurvature_eq (D F L X : ℝ) (hX : mechanicalDomain F X)
    (hS : mixtureSum D (inversePosition F X)≠0) :
    CriticalEnergy.coefficientQ (fun Z => potential D F (inversePosition F Z))
      (affineAux F) L X=
      affineCurvatureNumerator D F (inversePosition F X)/
        (9*((inversePosition F X)^F)^2*(mixtureSum D (inversePosition F X))^2) := by
  rw [CriticalEnergy.coefficientQ_eq_spatial_derivatives
    (analyticAt_potentialInPosition D F X hX) (analyticAt_affineAux F X),
    (hasDerivAt_actual_affineH D F L X hX).deriv,
    second_deriv_actual_affineH D F L X hX,actual_affineH_eq_model D F L X hX,
    second_deriv_affineAux,deriv_affineAux]
  rw [affineHModel,affineAux_eq_rpow F X hX]
  have hw : inversePosition F X≠0 := (inversePosition_pos F X hX).ne'
  have hwF : (inversePosition F X)^F≠0 :=
    (Real.rpow_pos_of_pos (inversePosition_pos F X hX) F).ne'
  dsimp only [affineH1,affineH2]
  field_simp [hw,hwF,hS]
  dsimp [mixtureSum,affineCurvatureNumerator]
  ring

end LeanVerification.RegionalReal
