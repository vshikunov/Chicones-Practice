import LeanVerification.RegionalReal.SaddleBarrier

/-! A three-term square certificate for the actual saddle-auxiliary
curvature, including the quarter-line endpoint and logarithmic F=0 seam. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal
open Loud
set_option maxHeartbeats 3200000

def saddleCurvatureQuadratic (D F S t : ℝ) : ℝ :=
  (2*F-1)*((F+1)*S+3*D)*t^2+4*(F+1)*S*t-10*S

def normalizedSaddleH (D F L X : ℝ) : ℝ :=
  saddleHModel D F L X*(inversePosition F X)^2/
    (affineAux F X*(D+F)*saddleFactor D (inversePosition F X))

theorem saddleCurvatureQuadratic_square (D F S t : ℝ) :
    saddleCurvatureQuadratic D F S t=
      -(F+1)*S/2*(t-4)^2+(4*F-1)*S*((F+1)*t^2/2+2)-3*D*(1-2*F)*t^2 := by
  dsimp [saddleCurvatureQuadratic]
  ring

theorem saddleCurvatureQuadratic_neg {D F S t : ℝ}
    (hD : 0<D) (hF0 : 0≤F) (hFq : F≤1/4) (hS : 0<S) (ht : 0<t) :
    saddleCurvatureQuadratic D F S t<0 := by
  rw [saddleCurvatureQuadratic_square]
  have ha : -(F+1)*S/2*(t-4)^2≤0 :=
    mul_nonpos_of_nonpos_of_nonneg
      (div_nonpos_of_nonpos_of_nonneg
        (mul_nonpos_of_nonpos_of_nonneg (by linarith) hS.le) (by norm_num)) (sq_nonneg _)
  have hb : (4*F-1)*S*((F+1)*t^2/2+2)≤0 :=
    mul_nonpos_of_nonpos_of_nonneg
      (mul_nonpos_of_nonpos_of_nonneg (by linarith) hS.le)
      (by positivity)
  have hc : 0<3*D*(1-2*F)*t^2 :=
    mul_pos (mul_pos (mul_pos (by norm_num) hD) (by linarith)) (sq_pos_of_pos ht)
  linarith

theorem saddle_curvature_algebra (D F w q S H : ℝ)
    (hw : w≠0) (hq : q≠0) (hS : S≠0) (hH : H≠0) (hDF : D+F≠0) :
    (2*(D+F)*(D-(F+2)*S)/(q*w^2)+(F+1)*(2*F+1)*H/q^2)/(3*H)-
      5*(2*(D+F)*S/w^2-(F+1)*H/q)^2/(9*H^2)-
      ((F*S+D)/w)*(2*(D+F)*S/w^2-(F+1)*H/q)/(3*(q*S/w)*H)+
      (D*(F-1)/(q*w))/(q*S/w)=
      2*saddleCurvatureQuadratic D F S (H*w^2/(q*(D+F)*S))/
        (9*q^2*S*(H*w^2/(q*(D+F)*S))^2) := by
  dsimp only [saddleCurvatureQuadratic]
  field_simp
  ring

theorem actual_saddleCurvature_eq (D F L X : ℝ) (hX : mechanicalDomain F X)
    (hS : saddleFactor D (inversePosition F X)≠0)
    (hH : saddleHModel D F L X≠0) (hDF : D+F≠0) :
    CriticalEnergy.coefficientQ (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) L X=
      2*saddleCurvatureQuadratic D F (saddleFactor D (inversePosition F X))
          (normalizedSaddleH D F L X)/
        (9*(affineAux F X)^2*saddleFactor D (inversePosition F X)*
          (normalizedSaddleH D F L X)^2) := by
  rw [CriticalEnergy.coefficientQ_eq_spatial_derivatives
    (analyticAt_potentialInPosition D F X hX) (analyticAt_saddleAux D F X hX),
    (hasDerivAt_actual_saddleH D F L X hX).deriv,
    second_deriv_actual_saddleH D F L X hX,actual_saddleH_eq_model D F L X hX,
    second_deriv_saddleAux D F X hX,(hasDerivAt_saddleAux D F X hX).deriv]
  dsimp only [saddleH1,saddleH2,saddleAux,saddleAux1,saddleAux2,normalizedSaddleH]
  exact saddle_curvature_algebra D F _ _ _ _ (inversePosition_pos F X hX).ne'
    hX.ne' hS hH hDF

theorem actual_saddleCurvature_neg (D F L X : ℝ)
    (hD : 0<D) (hF0 : 0≤F) (hFq : F≤1/4) (hL : L<saddleHeight D F)
    (hX : mechanicalDomain F X) (hc : inCentralInterval D (inversePosition F X)) :
    CriticalEnergy.coefficientQ (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) L X<0 := by
  have hH := actual_saddleH_pos_below_saddle D F L X hD hF0 (by linarith) hL hX hc
  rw [actual_saddleH_eq_model D F L X hX] at hH
  have hDF : 0<D+F := by linarith
  have ht : 0<normalizedSaddleH D F L X :=
    div_pos (mul_pos hH (sq_pos_of_pos hc.1)) (mul_pos (mul_pos hX hDF) hc.2)
  rw [actual_saddleCurvature_eq D F L X hX hc.2.ne' hH.ne' hDF.ne']
  exact div_neg_of_neg_of_pos
    (mul_neg_of_pos_of_neg (by norm_num) (saddleCurvatureQuadratic_neg hD hF0 hFq hc.2 ht))
    (mul_pos (mul_pos (mul_pos (by norm_num) (sq_pos_of_pos hX)) hc.2) (sq_pos_of_pos ht))

theorem physical_saddleCurvature_neg (D F h : ℝ)
    (hD : 0<D) (hF0 : 0≤F) (hFq : F≤1/4) (hh : AdmissibleEnergy D F h)
    {X : ℝ} (hX : X ∈ Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h)))) :
    CriticalEnergy.coefficientQ (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) h X<0 := by
  obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
  exact actual_saddleCurvature_neg D F h X hD hF0 hFq
    (admissibleEnergy_lt_saddleHeight D F h hD hh) hd hc

end LeanVerification.RegionalReal
