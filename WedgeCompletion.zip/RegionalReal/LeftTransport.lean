import LeanVerification.RegionalReal.LeftBlock

/-! A transport from the actual right turn completes the low-F left
block, including F=0, with no external monotonicity premise. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal
open Loud
set_option maxHeartbeats 3200000

def leftCurvatureTransport (D F L X : ℝ) : ℝ :=
  2*(affineAux F X)^2*(saddleFactor D (inversePosition F X))^2/inversePosition F X-
    D*(1-2*F)*saddleHModel D F L X*affineAux F X*inversePosition F X/(D+F)

theorem hasDerivAt_leftCurvatureTransport (D F L X : ℝ)
    (hDF : D+F≠0) (hX : mechanicalDomain F X) :
    HasDerivAt (leftCurvatureTransport D F L)
      (2*(2*F+1)*(D+1)*affineAux F X*saddleFactor D (inversePosition F X)) X := by
  have hw := (inversePosition_pos F X hX).ne'
  have hq : affineAux F X≠0 := hX.ne'
  have hdw := hasDerivAt_inversePosition_affine F X hX
  have hS := (hdw.const_mul (D+1)).sub_const D
  have hd := ((((hasDerivAt_affineAux F X).pow 2).const_mul 2).mul
    (hS.pow 2)).div hdw hw
  have he := hd.sub ((((hasDerivAt_saddleHModel D F L X hX).const_mul
    (D*(1-2*F))).mul (hasDerivAt_affineAux F X)).mul hdw |>.div_const (D+F))
  convert he using 1
  dsimp only [saddleH1,saddleFactor,id_eq]
  field_simp
  ring

theorem leftCurvatureTransport_normalized (D F L X : ℝ)
    (hDF : D+F≠0) (hX : mechanicalDomain F X)
    (hS : saddleFactor D (inversePosition F X)≠0) :
    leftCurvatureTransport D F L X=
      (affineAux F X)^2*(saddleFactor D (inversePosition F X))^2/inversePosition F X*
        (2-D*(1-2*F)*normalizedSaddleH D F L X/saddleFactor D (inversePosition F X)) := by
  have hw := (inversePosition_pos F X hX).ne'
  have hq : affineAux F X≠0 := hX.ne'
  dsimp only [leftCurvatureTransport,normalizedSaddleH]
  field_simp
  ring

theorem leftCurvatureTransport_pos_at_turn (D F L X : ℝ)
    (hD : D≤-1) (hF0 : 0≤F) (hFh : F<1/2)
    (hX : mechanicalDomain F X) (hc : inCentralInterval D (inversePosition F X))
    (hw1 : 1 ≤ inversePosition F X) (hL : potential D F (inversePosition F X)=L) :
    0<leftCurvatureTransport D F L X := by
  have hDF : D+F<0 := by linarith
  have hDFne : D+F≠0 := hDF.ne
  have hw := hc.1.ne'
  have hq : affineAux F X≠0 := hX.ne'
  have hN : 2*inversePosition F X*(D+F)-D*(1-2*F)<0 := by
    have ha := mul_nonpos_of_nonpos_of_nonneg hDF.le
      (show 0 ≤ inversePosition F X-1 by linarith)
    have hb := mul_le_mul_of_nonneg_right hD (show 0≤1+2*F by linarith)
    nlinarith
  have hb : D*(1-2*F)/(inversePosition F X*(D+F))<2 := by
    apply (div_lt_iff_of_neg (mul_neg_of_pos_of_neg hc.1 hDF)).mpr
    nlinarith
  have he : leftCurvatureTransport D F L X=
      (affineAux F X)^2*(saddleFactor D (inversePosition F X))^2/inversePosition F X*
        (2-D*(1-2*F)/(inversePosition F X*(D+F))) := by
    dsimp only [leftCurvatureTransport,saddleHModel]
    rw [hL,sub_self,mul_zero,zero_mul,add_zero]
    field_simp [hDFne,hw,hq]
    ring
  rw [he]
  exact mul_pos (div_pos (mul_pos (sq_pos_of_pos hX) (sq_pos_of_pos hc.2)) hc.1)
    (by linarith)

theorem physical_leftCurvatureTransport_pos (D F h X : ℝ)
    (hD : D≤-1) (hF0 : 0≤F) (hFh : F<1/2) (hh : AdmissibleEnergy D F h)
    (hX : X ∈ Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h)))) :
    0<leftCurvatureTransport D F h X := by
  let a := morsePosition D F (-Real.sqrt (2*h))
  let b := morsePosition D F (Real.sqrt (2*h))
  have hDF : D+F<0 := by linarith
  have hr : 0<Real.sqrt (2*h) := Real.sqrt_pos.mpr (by linarith [hh.1])
  have hab : a<b := (physical_regular_turn_data D F h _ hh le_rfl hr).1
  have hm : AntitoneOn (leftCurvatureTransport D F h) (Icc a b) := by
    apply antitoneOn_of_deriv_nonpos (convex_Icc _ _)
    · intro Z hZ
      exact (hasDerivAt_leftCurvatureTransport D F h Z hDF.ne
        (physical_turn_interval_coordinate_data D F h hh hZ).1).continuousAt.continuousWithinAt
    · intro Z hZ
      exact (hasDerivAt_leftCurvatureTransport D F h Z hDF.ne
        (physical_turn_interval_coordinate_data D F h hh (interior_subset hZ)).1).differentiableAt.differentiableWithinAt
    · intro Z hZ
      obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh (interior_subset hZ)
      rw [(hasDerivAt_leftCurvatureTransport D F h Z hDF.ne hd).deriv]
      exact mul_nonpos_of_nonpos_of_nonneg
        (mul_nonpos_of_nonpos_of_nonneg
          (mul_nonpos_of_nonneg_of_nonpos (by positivity) (by linarith)) hd.le) hc.2.le
  have hbmem : b ∈ Icc a b := ⟨hab.le,le_rfl⟩
  obtain ⟨hbd,hbc⟩ := physical_turn_interval_coordinate_data D F h hh hbmem
  have he : inversePosition F b=rightTurn D F h := by
    dsimp only [b,morsePosition]
    rw [morseInverse_right_amplitude D F h hh,
      inverse_position F _ (rightTurn_spec D F h hh).1.1]
  have hbpos : 0<leftCurvatureTransport D F h b := by
    apply leftCurvatureTransport_pos_at_turn D F h b hD hF0 hFh hbd hbc
    · rw [he]
      exact (rightTurn_spec D F h hh).2.1.le
    · rw [he]
      exact (rightTurn_spec D F h hh).2.2
  exact lt_of_lt_of_le hbpos (hm hX hbmem hX.2)

theorem saddleCurvatureQuadratic_left_square (D F S u : ℝ) :
    saddleCurvatureQuadratic D F S (-u)=
      3*u*((1-2*F)*(-D)*u-2*S)-
        (1-2*F)*S*((u-1)^2+F*u^2)-(9+2*F)*S := by
  dsimp only [saddleCurvatureQuadratic]
  ring

theorem saddleCurvatureQuadratic_neg_left_low (D F S t : ℝ)
    (hF0 : 0≤F) (hFh : F<1/2) (hS : 0<S) (ht : t<0)
    (hbound : (1-2*F)*(-D)*(-t)<2*S) : saddleCurvatureQuadratic D F S t<0 := by
  rw [show t= -(-t) by ring,saddleCurvatureQuadratic_left_square]
  have ha : 3*(-t)*((1-2*F)*(-D)*(-t)-2*S)<0 :=
    mul_neg_of_pos_of_neg (mul_pos (by norm_num) (by linarith)) (by linarith)
  have h1F : 0<1-2*F := by linarith
  have hb : 0≤(1-2*F)*S*((-t-1)^2+F*(-t)^2) := by positivity
  have hc : 0<(9+2*F)*S := mul_pos (by linarith) hS
  linarith

theorem physical_saddleCurvature_neg_left_low (D F h X : ℝ)
    (hD : D≤-1) (hF0 : 0≤F) (hFh : F<1/2) (hh : AdmissibleEnergy D F h)
    (hX : X ∈ Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h)))) :
    CriticalEnergy.coefficientQ (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) h X<0 := by
  obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
  have hH := saddleHModel_pos_left D F h X hD (by linarith) hd hc
    (physical_potential_le_energy D F h hh hX)
  have hDF : D+F<0 := by linarith
  have ht : normalizedSaddleH D F h X<0 :=
    div_neg_of_pos_of_neg (mul_pos hH (sq_pos_of_pos hc.1))
      (mul_neg_of_neg_of_pos (mul_neg_of_pos_of_neg hd hDF) hc.2)
  have hb := physical_leftCurvatureTransport_pos D F h X hD hF0 hFh hh hX
  rw [leftCurvatureTransport_normalized D F h X hDF.ne hd hc.2.ne'] at hb
  have hp : 0<(affineAux F X)^2*(saddleFactor D (inversePosition F X))^2/inversePosition F X :=
    div_pos (mul_pos (sq_pos_of_pos hd) (sq_pos_of_pos hc.2)) hc.1
  have hbr := (mul_pos_iff_of_pos_left hp).mp hb
  have hratio : D*(1-2*F)*normalizedSaddleH D F h X/saddleFactor D (inversePosition F X)<2 := by
    linarith
  have hbound : (1-2*F)*(-D)*(-normalizedSaddleH D F h X)<
      2*saddleFactor D (inversePosition F X) := by
    have he := (div_lt_iff₀ hc.2).mp hratio
    convert he using 1 <;> ring
  rw [actual_saddleCurvature_eq D F h X hd hc.2.ne' hH.ne' hDF.ne]
  exact div_neg_of_neg_of_pos
    (mul_neg_of_pos_of_neg (by norm_num)
      (saddleCurvatureQuadratic_neg_left_low D F _ _ hF0 hFh hc.2 ht hbound))
    (mul_pos (mul_pos (mul_pos (by norm_num) (sq_pos_of_pos hd)) hc.2) (sq_pos_of_ne_zero ht.ne))

theorem physical_period_deriv_ne_zero_left_low (D F h : ℝ)
    (hD : D≤-1) (hF0 : 0≤F) (hFh : F<1/2) (hh : AdmissibleEnergy D F h) :
    deriv (periodQuadrature D F) h≠0 := by
  apply physical_period_deriv_ne_zero_of_signed_curvature D F h (-1) (saddleAux D F) hh
  · intro X hX
    exact analyticAt_saddleAux D F X (physical_turn_interval_coordinate_data D F h hh hX).1
  · intro X hX
    obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
    exact div_pos (mul_pos hd hc.2) hc.1
  · intro X hX
    obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
    rw [actual_saddleH_eq_model D F h X hd]
    exact saddleHModel_pos_left D F h X hD (by linarith) hd hc
      (physical_potential_le_energy D F h hh hX)
  · intro X hX
    simpa only [neg_one_mul,neg_pos] using
      physical_saddleCurvature_neg_left_low D F h X hD hF0 hFh hh hX

theorem physical_period_deriv_ne_zero_left_block (D F h : ℝ)
    (hD : D≤-1) (hF0 : 0≤F) (hF1 : F≤1) (hh : AdmissibleEnergy D F h) :
    deriv (periodQuadrature D F) h≠0 := by
  by_cases hFh : F<1/2
  · exact physical_period_deriv_ne_zero_left_low D F h hD hF0 hFh hh
  · exact physical_period_deriv_ne_zero_left_halfblock D F h hD (le_of_not_gt hFh) hF1 hh

theorem criticalPeriodBound_zero_left_block (D F : ℝ)
    (hD : D≤-1) (hF0 : 0≤F) (hF1 : F≤1) : CriticalPeriodBound 0 D F :=
  criticalPeriodBound_zero_of_deriv_ne_zero
    (fun h hh => physical_period_deriv_ne_zero_left_block D F h hD hF0 hF1 hh)

end LeanVerification.RegionalReal
