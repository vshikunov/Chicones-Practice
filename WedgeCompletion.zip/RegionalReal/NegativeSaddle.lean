import LeanVerification.RegionalReal.PeriodSigns

/-! Actual saddle-height and auxiliary positivity on D≤-F,F>1,
and the resulting complete physical period increase for 1<F≤2. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal
open Loud Sharpness
set_option maxHeartbeats 2800000

theorem strictMonoOn_potential_center_to_negative_saddle (D F : ℝ) (hD : D< -1) :
    StrictMonoOn (potential D F) (Icc 1 (D/(D+1))) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc _ _)
  · intro w hw
    exact (hasDerivAt_potential D F w (by linarith [hw.1])).continuousAt.continuousWithinAt
  · intro w hw
    have hwi : w ∈ Ioo 1 (D/(D+1)) := by simpa only [interior_Icc] using hw
    have hc := (inCentralInterval_iff_of_lt_neg_one D w hD).mpr ⟨by linarith [hwi.1],hwi.2⟩
    rw [(hasDerivAt_potential D F w hc.1).deriv]
    exact potentialSlope_pos_of_central D F w hc hwi.1

theorem admissibleEnergy_lt_negative_saddleHeight (D F h : ℝ) (hD : D< -1)
    (hh : AdmissibleEnergy D F h) : h<saddleHeight D F := by
  have hs := extra_root_gt_one_of_lt_neg_one D hD
  have hr := rightTurn_spec D F h hh
  have hb := (inCentralInterval_iff_of_lt_neg_one D _ hD).mp hr.1
  have he := strictMonoOn_potential_center_to_negative_saddle D F hD
    ⟨hr.2.1.le,hb.2.le⟩ ⟨hs.le,le_rfl⟩ hb.2
  simpa only [hr.2.2,saddleHeight] using he

theorem saddleBarrier_at_nonzero_saddle (D F : ℝ) (hD : D+1≠0) :
    saddleBarrier D F (D/(D+1))=0 := by
  have hS : saddleFactor D (D/(D+1))=0 := by
    dsimp only [saddleFactor]
    field_simp
  simp only [saddleBarrier,saddleHeight,hS,zero_pow (by norm_num : (2:ℕ)≠0),
    mul_zero,zero_div,sub_self,add_zero]

theorem saddleBarrier_nonneg_negative (D F w : ℝ)
    (hF : 1<F) (hDF : D+F≤0) (hw : inCentralInterval D w) :
    0≤saddleBarrier D F w := by
  have hD : D< -1 := by linarith
  have hD0 : D≠0 := by linarith
  have hD1 : D+1≠0 := by linarith
  have hb := (inCentralInterval_iff_of_lt_neg_one D w hD).mp hw
  have hm : AntitoneOn (saddleBarrier D F) (Icc w (D/(D+1))) := by
    apply antitoneOn_of_deriv_nonpos (convex_Icc _ _)
    · intro x hx
      exact (hasDerivAt_saddleBarrier D F x hD0 hF.ne' (lt_of_lt_of_le hw.1 hx.1)).continuousAt.continuousWithinAt
    · intro x hx
      exact (hasDerivAt_saddleBarrier D F x hD0 hF.ne'
        (lt_of_lt_of_le hw.1 (interior_subset hx).1)).differentiableAt.differentiableWithinAt
    · intro x hx
      have hxi : x ∈ Ioo w (D/(D+1)) := by simpa only [interior_Icc] using hx
      have hc := (inCentralInterval_iff_of_lt_neg_one D x hD).mpr ⟨lt_trans hw.1 hxi.1,hxi.2⟩
      rw [(hasDerivAt_saddleBarrier D F x hD0 hF.ne' hc.1).deriv]
      exact div_nonpos_of_nonpos_of_nonneg
        (mul_nonpos_of_nonneg_of_nonpos (mul_pos (Real.rpow_pos_of_pos hc.1 _) hc.2).le hDF)
        (mul_nonneg_of_nonpos_of_nonpos (by linarith) (by linarith))
  have he := hm ⟨le_rfl,hb.2.le⟩ ⟨hb.2.le,le_rfl⟩ hb.2.le
  simpa only [saddleBarrier_at_nonzero_saddle D F hD1] using he

theorem actual_saddleH_pos_negative (D F L X : ℝ)
    (hF : 1<F) (hDF : D+F≤0) (hL : L<saddleHeight D F)
    (hX : mechanicalDomain F X) (hc : inCentralInterval D (inversePosition F X)) :
    0<CriticalEnergy.coefficientH (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) L X := by
  have hD : D<0 := by linarith
  rw [actual_saddleH_eq_model D F L X hX,
    saddleHModel_eq_barrier D F L X hD.ne hF.ne' hX]
  have hb := saddleBarrier_nonneg_negative D F _ hF hDF hc
  exact mul_pos (div_pos
    (mul_pos_of_neg_of_neg (mul_neg_of_pos_of_neg (by norm_num) hD) (by linarith))
    (mul_pos hX hc.1)) (by linarith)

theorem physical_saddleH_pos_negative (D F h X : ℝ)
    (hF : 1<F) (hDF : D+F≤0) (hh : AdmissibleEnergy D F h)
    (hX : X ∈ Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h)))) :
    0<CriticalEnergy.coefficientH (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) h X := by
  obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
  exact actual_saddleH_pos_negative D F h X hF hDF
    (admissibleEnergy_lt_negative_saddleHeight D F h (by linarith) hh) hd hc

theorem saddleCurvatureNumerator_neg_negative_saddle (D F w q S H : ℝ)
    (hF : 1<F) (hF2 : F≤2) (hDF : D+F≤0)
    (hw : 0<w) (hq : 0<q) (hS : 0<S) (hSmax : S< -D) (hH : 0<H) :
    saddleCurvatureNumerator D F w q S H<0 := by
  have hB : (F+1)*S+3*D<0 := by
    have h1 := mul_neg_of_pos_of_neg (show 0<F+1 by linarith) (show S+D<0 by linarith)
    have h2 := mul_nonpos_of_nonneg_of_nonpos (show 0≤2-F by linarith) (show D≤0 by linarith)
    nlinarith
  have hA : (2*F-1)*((F+1)*S+3*D)*H^2*w^4<0 :=
    mul_neg_of_neg_of_pos (mul_neg_of_neg_of_pos
      (mul_neg_of_pos_of_neg (by linarith) hB) (sq_pos_of_pos hH)) (pow_pos hw 4)
  have hC : 4*(F+1)*q*(D+F)*S^2*H*w^2≤0 :=
    mul_nonpos_of_nonpos_of_nonneg
      (mul_nonpos_of_nonpos_of_nonneg
        (mul_nonpos_of_nonpos_of_nonneg
          (mul_nonpos_of_nonneg_of_nonpos (by positivity) hDF) (sq_nonneg _)) hH.le)
      (sq_nonneg _)
  have hE : 0≤10*q^2*(D+F)^2*S^3 := by positivity
  dsimp only [saddleCurvatureNumerator]
  linarith

theorem physical_saddleCurvature_neg_negative (D F h X : ℝ)
    (hF : 1<F) (hF2 : F≤2) (hDF : D+F≤0) (hh : AdmissibleEnergy D F h)
    (hX : X ∈ Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h)))) :
    CriticalEnergy.coefficientQ (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) h X<0 := by
  obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
  have hH := physical_saddleH_pos_negative D F h X hF hDF hh hX
  rw [actual_saddleH_eq_model D F h X hd] at hH
  have hSmax : saddleFactor D (inversePosition F X)< -D := by
    have hz := mul_neg_of_neg_of_pos (show D+1<0 by linarith) hc.1
    dsimp only [saddleFactor]
    linarith
  rw [actual_saddleCurvature_eq_numerator D F h X hd hc.2.ne' hH.ne']
  exact div_neg_of_neg_of_pos
    (mul_neg_of_pos_of_neg (by norm_num)
      (saddleCurvatureNumerator_neg_negative_saddle D F _ _ _ _ hF hF2 hDF hc.1 hd hc.2 hSmax hH))
    (mul_pos (mul_pos (mul_pos (mul_pos (by norm_num) (sq_pos_of_pos hd)) hc.2)
      (sq_pos_of_pos hH)) (pow_pos hc.1 4))

theorem physical_period_deriv_ne_zero_negative_saddle_low (D F h : ℝ)
    (hF : 1<F) (hF2 : F≤2) (hDF : D+F≤0) (hh : AdmissibleEnergy D F h) :
    deriv (periodQuadrature D F) h≠0 := by
  apply physical_period_deriv_ne_zero_of_signed_curvature D F h (-1) (saddleAux D F) hh
  · intro X hX
    exact analyticAt_saddleAux D F X (physical_turn_interval_coordinate_data D F h hh hX).1
  · intro X hX
    obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
    exact div_pos (mul_pos hd hc.2) hc.1
  · intro X hX
    exact physical_saddleH_pos_negative D F h X hF hDF hh hX
  · intro X hX
    simpa only [neg_one_mul,neg_pos] using
      physical_saddleCurvature_neg_negative D F h X hF hF2 hDF hh hX

theorem criticalPeriodBound_zero_negative_saddle_low (D F : ℝ)
    (hF : 1<F) (hF2 : F≤2) (hDF : D+F≤0) : CriticalPeriodBound 0 D F :=
  criticalPeriodBound_zero_of_deriv_ne_zero
    (fun h hh => physical_period_deriv_ne_zero_negative_saddle_low D F h hF hF2 hDF hh)

theorem tau1_pos_negative_saddle (D F : ℝ) (hF : 1<F) (hDF : D+F≤0) :
    0<tau1Polynomial D F := by
  have hd : 0≤-D-F := by linarith
  have he : 12*tau1Polynomial D F=10*(-D-F)^2+(10*F+1)*(-D-F)+(2*F-1)^2 := by
    dsimp only [tau1Polynomial]
    ring
  have h1 : 0≤10*(-D-F)^2+(10*F+1)*(-D-F) := by positivity
  have h2 : 0<(2*F-1)^2 := sq_pos_of_pos (by linarith)
  linarith

theorem physical_period_deriv_pos_negative_saddle_low (D F h : ℝ)
    (hF : 1<F) (hF2 : F≤2) (hDF : D+F≤0) (hh : AdmissibleEnergy D F h) :
    0<deriv (periodQuadrature D F) h := by
  have hc : 0<(1:ℝ)*periodCoefficient D F 1 := by
    rw [one_mul,actual_tau1_polynomial]
    exact tau1_pos_negative_saddle D F hF hDF
  simpa only [one_mul] using physical_period_deriv_signed_of_center D F 1 h hc
    (fun k hk => physical_period_deriv_ne_zero_negative_saddle_low D F k hF hF2 hDF hk) hh

end LeanVerification.RegionalReal
