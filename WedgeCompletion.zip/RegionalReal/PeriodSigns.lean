import LeanVerification.RegionalReal.LeftTransport
import LeanVerification.Sharpness.PeriodTaylorRemainder
import LeanVerification.Sharpness.TauPolynomials

/-! Actual increasing/decreasing period signs. The center sign is taken
from the proved joint signed-energy extension and transported along the
entire actual regular annulus; no derivative of a totalized endpoint is used. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal
open Loud Sharpness
set_option maxHeartbeats 2000000

theorem physical_period_deriv_signed_of_center (D F ε h : ℝ)
    (hcenter : 0<ε*periodCoefficient D F 1)
    (hn : ∀ k,AdmissibleEnergy D F k → deriv (periodQuadrature D F) k≠0)
    (hh : AdmissibleEnergy D F h) : 0<ε*deriv (periodQuadrature D F) h := by
  classical
  have hc : ContinuousAt (fun k : ℝ => ε*normalizedSlope ((D,F),k)) 0 :=
    continuousAt_const.mul ((analyticAt_normalizedSlope
      (jointCenterDomain_contains_center D F)).continuousAt.comp
        (continuousAt_const.prodMk continuousAt_id))
  have hcen : 0<ε*normalizedSlope ((D,F),0) := by
    rw [(slope_center_jets (D,F)).1]
    exact hcenter
  have ht : Tendsto (fun k:ℝ => (((D,F),k):PeriodParameterSpace)) (𝓝 0) (𝓝 ((D,F),0)) :=
    (continuousAt_const.prodMk continuousAt_id).tendsto
  have hnear : ∀ᶠ k in 𝓝 (0:ℝ),
      0<ε*normalizedSlope ((D,F),k) ∧ ((D,F),k) ∈ jointCenterDomain ∧ k<h := by
    filter_upwards [hc.eventually (Ioi_mem_nhds hcen),
      ht.eventually (isOpen_jointCenterDomain.mem_nhds (jointCenterDomain_contains_center D F)),
      Iio_mem_nhds hh.1] with k hk hd hkh
    exact ⟨hk,hd,hkh⟩
  have hkpos : ∀ᶠ k:ℝ in 𝓝[>] (0:ℝ), 0<k := self_mem_nhdsWithin
  have hright : ∀ᶠ k in 𝓝[>] (0:ℝ), 0<k ∧
      0<ε*normalizedSlope ((D,F),k) ∧ ((D,F),k) ∈ jointCenterDomain ∧ k<h :=
    hkpos.and (hnear.filter_mono nhdsWithin_le_nhds)
  obtain ⟨k,hk,hks,hkd,hkh⟩ := hright.exists
  have hkp : 0<ε*deriv (periodQuadrature D F) k := by
    rw [normalizedSlope_eq_physical_derivative hkd hk,←mul_div_assoc] at hks
    exact (div_pos_iff_of_pos_right (mul_pos (by norm_num) Real.pi_pos)).mp hks
  by_contra hbad
  have hbad' := le_of_not_gt hbad
  have hf : ContinuousOn (fun z => ε*deriv (periodQuadrature D F) z) (Icc k h) := by
    intro z hz
    exact (continuousAt_const.mul
      (analyticAt_periodQuadrature_energy D F z
        (admissibleEnergy_downward D F h z hh (lt_of_lt_of_le hk hz.1) hz.2)).deriv.continuousAt).continuousWithinAt
  obtain ⟨z,hz,hzero⟩ := intermediate_value_Icc' hkh.le hf ⟨hbad',hkp.le⟩
  have hε : ε≠0 := by intro he; rw [he,zero_mul] at hcenter; exact lt_irrefl _ hcenter
  exact hn z (admissibleEnergy_downward D F h z hh (lt_of_lt_of_le hk hz.1) hz.2)
    ((mul_eq_zero.mp hzero).resolve_left hε)

theorem affineCurvatureNumerator_center (D F : ℝ) :
    affineCurvatureNumerator D F 1 = -24*tau1Polynomial D F := by
  dsimp only [affineCurvatureNumerator,tau1Polynomial]
  ring

theorem physical_period_deriv_signed_of_affine_numerator (D F h ε : ℝ)
    (hh : AdmissibleEnergy D F h) (hD0 : -(1/2)≤D) (hD1 : D≤0)
    (hN : ∀ w,0<w → 0<ε*affineCurvatureNumerator D F w) :
    0<(-ε)*deriv (periodQuadrature D F) h := by
  apply physical_period_deriv_signed_of_center D F (-ε) h ?_
    (fun k hk => physical_period_deriv_ne_zero_of_affine_numerator D F k ε hk hD0 hD1 hN) hh
  rw [actual_tau1_polynomial]
  have hn := hN 1 (by norm_num)
  rw [affineCurvatureNumerator_center] at hn
  nlinarith

theorem physical_period_deriv_neg_rectangle (D F h : ℝ)
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF0 : 1/2≤F) (hF1 : F≤1)
    (hiso : ¬IsKnownIsochronousParameter D F) (hh : AdmissibleEnergy D F h) :
    deriv (periodQuadrature D F) h<0 := by
  have hp := physical_period_deriv_signed_of_affine_numerator D F h 1 hh hD0 hD1
    (fun w hw => by simpa only [one_mul] using
      affineCurvatureNumerator_pos_rectangle hD0 hD1 hF0 hF1 hiso hw)
  simpa only [neg_one_mul,neg_pos] using hp

theorem physical_period_deriv_pos_lower_exterior_strip (D F h : ℝ)
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF : F≤0) (hh : AdmissibleEnergy D F h) :
    0<deriv (periodQuadrature D F) h := by
  have hp := physical_period_deriv_signed_of_affine_numerator D F h (-1) hh hD0 hD1
    (fun w hw => by simpa only [neg_one_mul,neg_pos] using
      affineCurvatureNumerator_neg_lower_exterior hD0 hD1 hF hw)
  simpa only [neg_neg,one_mul] using hp

theorem physical_period_deriv_pos_upper_exterior_strip (D F h : ℝ)
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF : 2≤F)
    (hiso : ¬IsKnownIsochronousParameter D F) (hh : AdmissibleEnergy D F h) :
    0<deriv (periodQuadrature D F) h := by
  have hp := physical_period_deriv_signed_of_affine_numerator D F h (-1) hh hD0 hD1
    (fun w hw => by simpa only [neg_one_mul,neg_pos] using
      affineCurvatureNumerator_neg_upper_exterior hD0 hD1 hF hiso hw)
  simpa only [neg_neg,one_mul] using hp

theorem physical_period_deriv_signed_zero_line (F h : ℝ)
    (hFq : F≠1/4) (hF1 : F≠1) (hh : AdmissibleEnergy 0 F h) :
    0<((F-1)*(4*F-1))*deriv (periodQuadrature 0 F) h := by
  have hp := physical_period_deriv_signed_of_affine_numerator 0 F h
    (2*(1-F)*(4*F-1)) hh (by norm_num) le_rfl
    (fun w hw => affineCurvatureNumerator_signed_zero hw hFq hF1)
  nlinarith

theorem physical_period_deriv_signed_negHalf_line (F h : ℝ)
    (hFh : F≠1/2) (hF2 : F≠2) (hh : AdmissibleEnergy (-(1/2)) F h) :
    0<((2*F-1)*(F-2))*deriv (periodQuadrature (-(1/2)) F) h := by
  have hp := physical_period_deriv_signed_of_affine_numerator (-(1/2)) F h
    (4*(2*F-1)*(2-F)) hh le_rfl (by norm_num)
    (fun w hw => affineCurvatureNumerator_signed_negHalf hFh hF2)
  nlinarith

theorem saddleCurvatureQuadratic_center (D F : ℝ) (hDF : D+F≠0) :
    (D+F)^2*saddleCurvatureQuadratic D F 1 (1/(D+F)) = -12*tau1Polynomial D F := by
  dsimp only [saddleCurvatureQuadratic,tau1Polynomial]
  field_simp
  ring

theorem tau1_pos_quarter (D F : ℝ) (hD : 0<D) (hF0 : 0≤F) (hFq : F≤1/4) :
    0<tau1Polynomial D F := by
  have hDF : 0<D+F := by linarith
  have hn := saddleCurvatureQuadratic_neg hD hF0 hFq (by norm_num : (0:ℝ)<1)
    (one_div_pos.mpr hDF)
  have hp := mul_neg_of_pos_of_neg (sq_pos_of_pos hDF) hn
  rw [saddleCurvatureQuadratic_center D F hDF.ne'] at hp
  linarith

theorem tau1_pos_left_block (D F : ℝ) (hD : D≤-1) (hF0 : 0≤F) (hF1 : F≤1) :
    0<tau1Polynomial D F := by
  have hd : 0≤-D-1 := by linarith
  have hf : 0≤1-F := by linarith
  have he : 12*tau1Polynomial D F=
      10*(-D-1)^2+(11+10*(1-F))*(-D-1)+4*(1-F)^2+7*(1-F)+1 := by
    dsimp only [tau1Polynomial]
    ring
  have hp : 0<10*(-D-1)^2+(11+10*(1-F))*(-D-1)+4*(1-F)^2+7*(1-F)+1 := by
    positivity
  linarith

theorem physical_period_deriv_pos_quarter (D F h : ℝ)
    (hD : 0<D) (hF0 : 0≤F) (hFq : F≤1/4) (hh : AdmissibleEnergy D F h) :
    0<deriv (periodQuadrature D F) h := by
  have hc : 0<(1:ℝ)*periodCoefficient D F 1 := by
    rw [one_mul,actual_tau1_polynomial]
    exact tau1_pos_quarter D F hD hF0 hFq
  simpa only [one_mul] using physical_period_deriv_signed_of_center D F 1 h hc
    (fun k hk => physical_period_deriv_ne_zero_quarter D F k hD hF0 hFq hk) hh

theorem physical_period_deriv_pos_left_block (D F h : ℝ)
    (hD : D≤-1) (hF0 : 0≤F) (hF1 : F≤1) (hh : AdmissibleEnergy D F h) :
    0<deriv (periodQuadrature D F) h := by
  have hc : 0<(1:ℝ)*periodCoefficient D F 1 := by
    rw [one_mul,actual_tau1_polynomial]
    exact tau1_pos_left_block D F hD hF0 hF1
  simpa only [one_mul] using physical_period_deriv_signed_of_center D F 1 h hc
    (fun k hk => physical_period_deriv_ne_zero_left_block D F k hD hF0 hF1 hk) hh

end LeanVerification.RegionalReal
