import LeanVerification.RegionalReal.QuarterCurvature
import LeanVerification.RegionalReal.AffineRegions

/-! The full positive-D quarter region, in the actual physical period.
The proof includes F=0 directly and does not import an exterior theorem. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal
open Loud
set_option maxHeartbeats 1400000

theorem physical_period_deriv_ne_zero_quarter (D F h : ℝ)
    (hD : 0<D) (hF0 : 0≤F) (hFq : F≤1/4) (hh : AdmissibleEnergy D F h) :
    deriv (periodQuadrature D F) h≠0 := by
  apply physical_period_deriv_ne_zero_of_signed_curvature D F h (-1) (saddleAux D F) hh
  · intro X hX
    exact analyticAt_saddleAux D F X (physical_turn_interval_coordinate_data D F h hh hX).1
  · intro X hX
    obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
    exact div_pos (mul_pos hd hc.2) hc.1
  · intro X hX
    exact physical_saddleH_pos D F h hD hF0 (by linarith) hh hX
  · intro X hX
    simpa only [neg_one_mul,neg_pos] using
      physical_saddleCurvature_neg D F h hD hF0 hFq hh hX

theorem criticalPeriodBound_zero_quarter (D F : ℝ)
    (hD : 0<D) (hF0 : 0≤F) (hFq : F≤1/4) : CriticalPeriodBound 0 D F :=
  criticalPeriodBound_zero_of_deriv_ne_zero
    (fun h hh => physical_period_deriv_ne_zero_quarter D F h hD hF0 hFq hh)

theorem parameter_region_one_bound (D F : ℝ) (hp : parameterRegion 1 D F) :
    CriticalPeriodBound (parameterRegionBound 1) D F :=
  criticalPeriodBound_zero_quarter D F hp.2.2 hp.1.le hp.2.1

theorem criticalPeriodBound_zero_logarithmic_positive (D : ℝ) (hD : 0<D) :
    CriticalPeriodBound 0 D 0 :=
  criticalPeriodBound_zero_quarter D 0 hD le_rfl (by norm_num)

end LeanVerification.RegionalReal
