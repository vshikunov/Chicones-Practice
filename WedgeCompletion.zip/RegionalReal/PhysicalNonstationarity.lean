import LeanVerification.Loud.PhysicalGreenCoefficients
import LeanVerification.Loud.ParameterCover

/-! A strict signed curvature criterion for the actual Loud period.
The endpoint integrability and zero-flux identity come from the constructed
physical critical mode, so no clock or integrability premise is added. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.RegionalReal
open Loud
set_option maxHeartbeats 1600000

theorem physical_period_deriv_ne_zero_of_signed_curvature
    (D F h ε : ℝ) (φ : ℝ → ℝ) (hh : AdmissibleEnergy D F h)
    (hφ : AnalyticOnNhd ℝ φ (Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h)))))
    (hφpos : ∀ X ∈ Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h))), 0<φ X)
    (hHpos : ∀ X ∈ Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h))),
      0<CriticalEnergy.coefficientH (fun Z => potential D F (inversePosition F Z)) φ h X)
    (hQpos : ∀ X ∈ Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h))),
      0<ε*CriticalEnergy.coefficientQ (fun Z => potential D F (inversePosition F Z)) φ h X) :
    deriv (periodQuadrature D F) h≠0 := by
  intro hstat
  let r := Real.sqrt (2*h)
  let a := morsePosition D F (-r)
  let b := morsePosition D F r
  let W : ℝ → ℝ := fun X => potential D F (inversePosition F X)
  let V : ℝ → ℝ := fun X => h-W X
  let H := CriticalEnergy.coefficientH W φ h
  let p := CriticalMode.weight V φ H
  let Q := CriticalEnergy.coefficientQ W φ h
  have hr : 0<r := Real.sqrt_pos.mpr (by linarith [hh.1])
  have he : r^2/2=h := by dsimp [r];rw [Real.sq_sqrt (by linarith [hh.1])];ring
  have hs : amplitudeDerivative D F 1 r=0 := by
    rw [deriv_periodQuadrature_eq_amplitude D F h hh] at hstat
    exact (div_eq_zero_iff).mp hstat |>.resolve_right hr.ne'
  obtain ⟨U,hUa,hUp,hUi,hUz,hUf⟩ :=
    physical_critical_mode_zero_integral D F h r φ hh le_rfl hr hs hφ hφpos
      (by simpa only [he] using hHpos)
  dsimp only at hUa hUp hUi hUz hUf
  rw [he] at hUi hUz hUf
  obtain ⟨hab,hWa,hWb,hga,hgb,hV⟩ := physical_regular_turn_data D F h r hh le_rfl hr
  rw [he] at hWa hWb hV
  have hW : AnalyticOnNhd ℝ W (Icc a b) :=
    analyticOnNhd_physicalPotential_turn_interval D F h hh
  have hH : ∀ X ∈ Icc a b, AnalyticAt ℝ H X := fun X hX =>
    analyticAt_criticalAuxiliary (hW X hX) (hφ X hX)
  have hp : ContinuousOn p (Icc a b) := by
    intro X hX
    exact ((((continuousAt_const.sub (hW X hX).continuousAt).rpow_const
      (p := (3 : ℝ)/2) (Or.inr (by norm_num))).mul
      ((hH X hX).continuousAt.rpow_const (Or.inl (hHpos X hX).ne'))).div
      (hφ X hX).continuousAt (hφpos X hX).ne').continuousWithinAt
  have hQc : ContinuousOn Q (Icc a b) := fun X hX =>
    (analyticAt_criticalCurvature (hW X hX) (hφ X hX)
      (hφpos X hX).ne' (hHpos X hX).ne').continuousAt.continuousWithinAt
  have hUc : ContinuousOn U (Icc a b) :=
    fun X hX => (hUa X hX).continuousAt.continuousWithinAt
  have hpnonneg : ∀ X ∈ Icc a b, 0≤p X := by
    intro X hX
    have hV0 : 0≤V X := by
      by_cases ha : X=a
      · rw [ha]; exact le_of_eq (sub_eq_zero.mpr hWa.symm).symm
      by_cases hb : X=b
      · rw [hb]; exact le_of_eq (sub_eq_zero.mpr hWb.symm).symm
      exact (hV X ⟨lt_of_le_of_ne hX.1 (Ne.symm ha),lt_of_le_of_ne hX.2 hb⟩).le
    exact div_nonneg (mul_nonneg (Real.rpow_nonneg hV0 _)
      (Real.rpow_nonneg (hHpos X hX).le _)) (hφpos X hX).le
  have hc : (a+b)/2 ∈ Ioo a b := ⟨by linarith,by linarith⟩
  have hcc := Ioo_subset_Icc_self hc
  have hpc : 0<p ((a+b)/2) := CriticalMode.weight_pos (hV _ hc)
    (hφpos _ hcc) (hHpos _ hcc)
  have hpos : 0<∫ X in a..b,p X*(ε*Q X)*U X := by
    apply intervalIntegral.integral_pos hab ((hp.mul (continuousOn_const.mul hQc)).mul hUc)
    · intro X hX
      have hX' := Ioc_subset_Icc_self hX
      exact mul_nonneg (mul_nonneg (hpnonneg X hX') (hQpos X hX').le) (hUp X hX').le
    · exact ⟨(a+b)/2,hcc,mul_pos (mul_pos hpc (hQpos _ hcc)) (hUp _ hcc)⟩
  have hz : (∫ X in a..b,p X*(ε*Q X)*U X)=0 := by
    calc
      _ = ε*(∫ X in a..b,p X*Q X*U X) := by
        rw [← intervalIntegral.integral_const_mul]
        apply intervalIntegral.integral_congr
        intro X hX
        ring
      _ = 0 := by rw [hUz,mul_zero]
  exact hpos.ne' hz

theorem criticalPeriodBound_zero_of_deriv_ne_zero {D F : ℝ}
    (hn : ∀ h,AdmissibleEnergy D F h → deriv (periodQuadrature D F) h≠0) :
    CriticalPeriodBound 0 D F := by
  intro s hs
  have he : s=∅ := Finset.eq_empty_iff_forall_not_mem.mpr (by
    intro h hh
    exact hn h (hs h hh).1 (hs h hh).2.1)
  simp [he]

end LeanVerification.RegionalReal
