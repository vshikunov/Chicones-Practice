import LeanVerification.RegionalReal.Schaaf.TwoSided
import LeanVerification.Sharpness.ForceTaylor
import LeanVerification.Loud.PairedStrip

/-! The removable profile belongs to the actual physical inverse coordinate. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal.Schaaf
open Loud
set_option maxHeartbeats 2400000

def physicalProfile (D F X : ℝ) : ℝ :=
  deriv (deriv (morsePosition D F)) (signedMorse D F X)

theorem forceInPosition_pos_of_pos (D F X : ℝ)
    (hX : mechanicalDomain F X) (hw : inCentralInterval D (inversePosition F X)) (hx : 0<X) :
    0<forceInPosition D F X := by
  have hwp : 1 < inversePosition F X := by
    by_contra hn
    have hm := (strictMonoOn_position F).monotoneOn hw.1 (by norm_num) (le_of_not_gt hn)
    rw [position_inverse F X hX,position_one] at hm
    linarith
  exact force_pos_of_central D F _ hw hwp

theorem forceInPosition_neg_of_neg (D F X : ℝ)
    (hX : mechanicalDomain F X) (hw : inCentralInterval D (inversePosition F X)) (hx : X<0) :
    forceInPosition D F X<0 := by
  have hwp : inversePosition F X<1 := by
    by_contra hn
    have hm := (strictMonoOn_position F).monotoneOn (by norm_num) hw.1 (le_of_not_gt hn)
    rw [position_one,position_inverse F X hX] at hm
    linarith
  exact force_neg_of_central D F _ hw hwp

theorem analyticAt_physicalProfile (D F X : ℝ)
    (hX : mechanicalDomain F X) (hw : inCentralInterval D (inversePosition F X)) :
    AnalyticAt ℝ (physicalProfile D F) X := by
  have hu : signedMorse D F X∈morseRange D F := ⟨inversePosition F X,hw,rfl⟩
  have hsm : AnalyticAt ℝ (signedMorse D F) X :=
    (analyticAt_signedMorse_joint D F X hX hw).comp_of_eq
      (f:=fun x:ℝ => ((D,F),x)) (analyticAt_const.prod analyticAt_id) rfl
  exact (analyticAt_morsePosition D F _ hu).deriv.deriv.comp hsm

theorem physicalProfile_eq (D F X : ℝ)
    (hX : mechanicalDomain F X) (hw : inCentralInterval D (inversePosition F X)) (hx : X≠0) :
    physicalProfile D F X = profile (fun t => potential D F (inversePosition F t))
      (forceInPosition D F) (deriv (forceInPosition D F)) X := by
  let u := signedMorse D F X
  have hu : u∈morseRange D F := ⟨inversePosition F X,hw,rfl⟩
  have hPX : morsePosition D F u=X := morsePosition_signedMorse D F X hX hw
  have hP := analyticAt_morsePosition D F u hu
  have hg := (Sharpness.analyticAt_forceInPosition D F X hX).differentiableAt.hasDerivAt
  have hg' : HasDerivAt (forceInPosition D F) (deriv (forceInPosition D F) X)
      (morsePosition D F u) := by rw [hPX]; exact hg
  have hd := (hg'.comp u hP.differentiableAt.hasDerivAt).mul hP.deriv.differentiableAt.hasDerivAt
  have he : (fun v => forceInPosition D F (morsePosition D F v)*deriv (morsePosition D F) v)
      =ᶠ[𝓝 u] id := by
    filter_upwards [(isOpen_morseRange D F).mem_nhds hu] with v hv
    rw [force_morsePosition D F v hv,div_mul_cancel₀ _ (morsePosition_deriv_pos D F v hv).ne']
    rfl
  have hj := (hd.congr_of_eventuallyEq he.symm).unique (hasDerivAt_id u)
  simp only [Function.comp_apply] at hj
  rw [hPX] at hj
  have hrel : forceInPosition D F X*deriv (morsePosition D F) u=u := by
    rw [←hPX,force_morsePosition D F u hu,
      div_mul_cancel₀ _ (morsePosition_deriv_pos D F u hu).ne']
  have hsq := congrArg (fun t:ℝ => t^2) hrel
  have hV := potential_morsePosition D F u hu
  rw [hPX] at hV
  have hn : forceInPosition D F X≠0 := by
    rcases lt_or_gt_of_ne hx with hn|hp
    · exact (forceInPosition_neg_of_neg D F X hX hw hn).ne
    · exact (forceInPosition_pos_of_pos D F X hX hw hp).ne'
  change deriv (deriv (morsePosition D F)) u=
    ((forceInPosition D F X)^2-2*potential D F (inversePosition F X)*
      deriv (forceInPosition D F) X)/(forceInPosition D F X)^3
  apply (eq_div_iff (pow_ne_zero _ hn)).mpr
  linear_combination (forceInPosition D F X)^2*hj-
    deriv (forceInPosition D F) X*hsq+2*deriv (forceInPosition D F) X*hV

theorem physicalProfile_morsePosition (D F u : ℝ) (hu : u∈morseRange D F) :
    physicalProfile D F (morsePosition D F u)=deriv (deriv (morsePosition D F)) u := by
  simp only [physicalProfile,signedMorse_morsePosition D F u hu]

theorem physical_turn_endpoints_straddle_zero (D F h : ℝ) (hh : AdmissibleEnergy D F h) :
    morsePosition D F (-Real.sqrt (2*h))<0 ∧ 0<morsePosition D F (Real.sqrt (2*h)) := by
  have hr : 0<Real.sqrt (2*h) := Real.sqrt_pos.mpr (by linarith [hh.1])
  have hm := strictMonoOn_morsePosition_amplitude D F h (Real.sqrt (2*h)) hh le_rfl
  have h0 : (0:ℝ)∈Icc (-Real.sqrt (2*h)) (Real.sqrt (2*h)) := ⟨by linarith,hr.le⟩
  have hl := hm ⟨le_rfl,by linarith⟩ h0 (by linarith)
  have hh' := hm h0 ⟨by linarith,le_rfl⟩ hr
  exact ⟨by simpa only [morsePosition_zero] using hl,by simpa only [morsePosition_zero] using hh'⟩

theorem physical_schaaf_well (D F h : ℝ) (hh : AdmissibleEnergy D F h)
    (hS : ∀ X∈Icc (morsePosition D F (-Real.sqrt (2*h))) (morsePosition D F (Real.sqrt (2*h))),
      0<deriv (forceInPosition D F) X →
      0<5*(deriv (deriv (forceInPosition D F)) X)^2-
        3*deriv (forceInPosition D F) X*deriv (deriv (deriv (forceInPosition D F))) X)
    (hz : ∀ X∈Icc (morsePosition D F (-Real.sqrt (2*h))) (morsePosition D F (Real.sqrt (2*h))),
      deriv (forceInPosition D F) X=0 →
      forceInPosition D F X*deriv (deriv (forceInPosition D F)) X<0) :
    Well (fun X => potential D F (inversePosition F X))
      (forceInPosition D F) (deriv (forceInPosition D F))
      (deriv (deriv (forceInPosition D F))) (deriv (deriv (deriv (forceInPosition D F))))
      (physicalProfile D F) (morsePosition D F (-Real.sqrt (2*h))) (morsePosition D F (Real.sqrt (2*h))) := by
  have ht := physical_turn_endpoints_straddle_zero D F h hh
  have hcoord : ∀ {X : ℝ}, X∈Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h))) →
      mechanicalDomain F X ∧ inCentralInterval D (inversePosition F X) :=
    fun hX => physical_turn_interval_coordinate_data D F h hh hX
  have ha : ∀ X∈Icc (morsePosition D F (-Real.sqrt (2*h))) (morsePosition D F (Real.sqrt (2*h))),
      AnalyticAt ℝ (forceInPosition D F) X := by
    intro X hX
    exact Sharpness.analyticAt_forceInPosition D F X (hcoord hX).1
  refine ⟨ht.1,ht.2,?_,?_,?_,?_,?_,forceInPosition_zero D F,?_,?_,?_,hS,hz,?_,?_⟩
  · intro X hX
    exact hasDerivAt_potentialInPosition D F X (hcoord hX).1
  · intro X hX
    exact (ha X hX).differentiableAt.hasDerivAt
  · intro X hX
    exact (ha X hX).deriv.differentiableAt.hasDerivAt
  · intro X hX
    exact (ha X hX).deriv.deriv.differentiableAt.hasDerivAt
  · simp only [inversePosition_zero,potential_one]
  · rw [deriv_forceInPosition_zero]; norm_num
  · intro X hX
    have hXi := (hcoord (show X∈Icc _ _ from ⟨ht.1.le.trans hX.1.le,hX.2⟩))
    exact forceInPosition_pos_of_pos D F X hXi.1 hXi.2 hX.1
  · intro X hX
    have hXi := (hcoord (show X∈Icc _ _ from ⟨hX.1,hX.2.le.trans ht.2.le⟩))
    exact forceInPosition_neg_of_neg D F X hXi.1 hXi.2 hX.2
  · intro X hX
    exact (analyticAt_physicalProfile D F X (hcoord hX).1 (hcoord hX).2).continuousAt.continuousWithinAt
  · intro X hX hn
    exact physicalProfile_eq D F X (hcoord hX).1 (hcoord hX).2 hn

end LeanVerification.RegionalReal.Schaaf
