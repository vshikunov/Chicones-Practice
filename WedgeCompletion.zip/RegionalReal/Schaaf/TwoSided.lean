import LeanVerification.RegionalReal.Schaaf.Exterior

/-! Reflection supplies the comparison on both halves of the well. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal.Schaaf
set_option maxHeartbeats 2200000

structure Well (V g g₁ g₂ g₃ φ : ℝ → ℝ) (a b : ℝ) : Prop where
  left_neg : a<0
  right_pos : 0<b
  V_deriv : ∀ x∈Icc a b, HasDerivAt V (g x) x
  g_deriv : ∀ x∈Icc a b, HasDerivAt g (g₁ x) x
  g₁_deriv : ∀ x∈Icc a b, HasDerivAt g₁ (g₂ x) x
  g₂_deriv : ∀ x∈Icc a b, HasDerivAt g₂ (g₃ x) x
  V_zero : V 0=0
  g_zero : g 0=0
  g₁_zero_pos : 0<g₁ 0
  g_right : ∀ x∈Ioc 0 b, 0<g x
  g_left : ∀ x∈Ico a 0, g x<0
  schaaf_pos : ∀ x∈Icc a b, 0<g₁ x → 0<S g₁ g₂ g₃ x
  crossing_neg : ∀ x∈Icc a b, g₁ x=0 → g x*g₂ x<0
  profile_cont : ContinuousOn φ (Icc a b)
  profile_eq : ∀ x∈Icc a b, x≠0 → φ x=profile V g g₁ x

variable {V g g₁ g₂ g₃ φ : ℝ → ℝ} {a b : ℝ}

theorem Well.right_half (h : Well V g g₁ g₂ g₃ φ a b) : HalfWell V g g₁ g₂ g₃ φ b where
  endpoint_pos := h.right_pos
  V_deriv x hx := h.V_deriv x ⟨h.left_neg.le.trans hx.1,hx.2⟩
  g_deriv x hx := h.g_deriv x ⟨h.left_neg.le.trans hx.1,hx.2⟩
  g₁_deriv x hx := h.g₁_deriv x ⟨h.left_neg.le.trans hx.1,hx.2⟩
  g₂_deriv x hx := h.g₂_deriv x ⟨h.left_neg.le.trans hx.1,hx.2⟩
  V_zero := h.V_zero
  g_zero := h.g_zero
  g₁_zero_pos := h.g₁_zero_pos
  g_pos := h.g_right
  schaaf_pos x hx := h.schaaf_pos x ⟨h.left_neg.le.trans hx.1,hx.2⟩
  crossing_neg x hx := h.crossing_neg x ⟨h.left_neg.le.trans hx.1,hx.2⟩
  profile_cont := h.profile_cont.mono (fun _ hx => ⟨h.left_neg.le.trans hx.1,hx.2⟩)
  profile_eq x hx := h.profile_eq x ⟨h.left_neg.le.trans hx.1.le,hx.2⟩ hx.1.ne'

theorem Well.reflected_half (h : Well V g g₁ g₂ g₃ φ a b) :
    HalfWell (fun x => V (-x)) (fun x => -g (-x)) (fun x => g₁ (-x))
      (fun x => -g₂ (-x)) (fun x => g₃ (-x)) (fun x => -φ (-x)) (-a) := by
  have hmap : ∀ x∈Icc 0 (-a), -x∈Icc a b := by
    intro x hx
    constructor <;> linarith [h.right_pos,hx.1,hx.2]
  refine ⟨neg_pos.mpr h.left_neg,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_,?_⟩
  · intro x hx
    simpa using (h.V_deriv (-x) (hmap x hx)).comp x (hasDerivAt_id x).neg
  · intro x hx
    simpa using ((h.g_deriv (-x) (hmap x hx)).comp x (hasDerivAt_id x).neg).neg
  · intro x hx
    simpa using (h.g₁_deriv (-x) (hmap x hx)).comp x (hasDerivAt_id x).neg
  · intro x hx
    simpa using ((h.g₂_deriv (-x) (hmap x hx)).comp x (hasDerivAt_id x).neg).neg
  · simpa only [neg_zero] using h.V_zero
  · simp only [neg_zero,h.g_zero]
  · simpa only [neg_zero] using h.g₁_zero_pos
  · intro x hx
    exact neg_pos.mpr (h.g_left (-x) ⟨by linarith [hx.2],neg_neg_of_pos hx.1⟩)
  · intro x hx hgp
    simpa only [S,neg_sq] using h.schaaf_pos (-x) (hmap x hx) hgp
  · intro x hx hz
    simpa only [neg_mul_neg] using h.crossing_neg (-x) (hmap x hx) hz
  · exact (h.profile_cont.comp continuous_neg.continuousOn hmap).neg
  · intro x hx
    rw [h.profile_eq (-x) (hmap x ⟨hx.1.le,hx.2⟩) (neg_ne_zero.mpr hx.1.ne')]
    dsimp only [profile]
    rw [neg_sq,show (-g (-x))^3=-(g (-x)^3) by ring,div_neg]

theorem Well.profile_gt_center_of_pos (h : Well V g g₁ g₂ g₃ φ a b)
    {x : ℝ} (hx : x∈Ioc 0 b) : φ 0<φ x :=
  (h.right_half.restrict hx.1 hx.2).profile_above_center

theorem Well.profile_lt_center_of_neg (h : Well V g g₁ g₂ g₃ φ a b)
    {x : ℝ} (hx : x∈Ico a 0) : φ x<φ 0 := by
  have hc := (h.reflected_half.restrict (neg_pos.mpr hx.2)
    (neg_le_neg hx.1)).profile_above_center
  simpa only [neg_zero,neg_neg,neg_lt_neg_iff] using hc

end LeanVerification.RegionalReal.Schaaf
