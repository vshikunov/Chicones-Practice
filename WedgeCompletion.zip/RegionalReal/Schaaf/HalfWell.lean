import LeanVerification.RegionalReal.Schaaf.Identities
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Analysis.Calculus.Deriv.MeanValue

/-! The center comparison on one half of a mechanical well. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal.Schaaf
set_option maxHeartbeats 2000000

structure HalfWell (V g g₁ g₂ g₃ φ : ℝ → ℝ) (b : ℝ) : Prop where
  endpoint_pos : 0<b
  V_deriv : ∀ x∈Icc 0 b, HasDerivAt V (g x) x
  g_deriv : ∀ x∈Icc 0 b, HasDerivAt g (g₁ x) x
  g₁_deriv : ∀ x∈Icc 0 b, HasDerivAt g₁ (g₂ x) x
  g₂_deriv : ∀ x∈Icc 0 b, HasDerivAt g₂ (g₃ x) x
  V_zero : V 0=0
  g_zero : g 0=0
  g₁_zero_pos : 0<g₁ 0
  g_pos : ∀ x∈Ioc 0 b, 0<g x
  schaaf_pos : ∀ x∈Icc 0 b, 0<g₁ x → 0<S g₁ g₂ g₃ x
  crossing_neg : ∀ x∈Icc 0 b, g₁ x=0 → g x*g₂ x<0
  profile_cont : ContinuousOn φ (Icc 0 b)
  profile_eq : ∀ x∈Ioc 0 b, φ x=profile V g g₁ x

variable {V g g₁ g₂ g₃ φ : ℝ → ℝ} {b : ℝ}

theorem HalfWell.restrict (h : HalfWell V g g₁ g₂ g₃ φ b) {c : ℝ}
    (hc : 0<c) (hcb : c≤b) : HalfWell V g g₁ g₂ g₃ φ c where
  endpoint_pos := hc
  V_deriv x hx := h.V_deriv x ⟨hx.1,hx.2.trans hcb⟩
  g_deriv x hx := h.g_deriv x ⟨hx.1,hx.2.trans hcb⟩
  g₁_deriv x hx := h.g₁_deriv x ⟨hx.1,hx.2.trans hcb⟩
  g₂_deriv x hx := h.g₂_deriv x ⟨hx.1,hx.2.trans hcb⟩
  V_zero := h.V_zero
  g_zero := h.g_zero
  g₁_zero_pos := h.g₁_zero_pos
  g_pos x hx := h.g_pos x ⟨hx.1,hx.2.trans hcb⟩
  schaaf_pos x hx := h.schaaf_pos x ⟨hx.1,hx.2.trans hcb⟩
  crossing_neg x hx := h.crossing_neg x ⟨hx.1,hx.2.trans hcb⟩
  profile_cont := h.profile_cont.mono (fun x hx => ⟨hx.1,hx.2.trans hcb⟩)
  profile_eq x hx := h.profile_eq x ⟨hx.1,hx.2.trans hcb⟩

theorem HalfWell.A_pos (h : HalfWell V g g₁ g₂ g₃ φ b)
    (hp : ∀ x∈Icc 0 b,0<g₁ x) : ∀ x∈Icc 0 b,0<A g g₁ g₂ x := by
  have ha0 : 0<A g g₁ g₂ 0 := by
    simp only [A,h.g_zero,zero_mul,sub_zero]
    exact mul_pos (by norm_num) (sq_pos_of_pos h.g₁_zero_pos)
  apply positive_on_Icc_of_positive_zero_orientation
  · intro x hx
    exact (hasDerivAt_A (h.g_deriv x hx) (h.g₁_deriv x hx) (h.g₂_deriv x hx)).differentiableAt
  · intro x hx ha
    have hxp : 0<x := lt_of_le_of_ne hx.1 (by intro he; subst x; exact ha0.ne' ha)
    rw [A_deriv_at_zero (h.g_deriv x hx) (h.g₁_deriv x hx) (h.g₂_deriv x hx) ha (hp x hx).ne']
    exact div_pos (mul_pos (h.g_pos x ⟨hxp,hx.2⟩) (h.schaaf_pos x hx (hp x hx)))
      (mul_pos (by norm_num) (hp x hx))
  · exact ha0

theorem HalfWell.N_pos (h : HalfWell V g g₁ g₂ g₃ φ b)
    (hp : ∀ x∈Icc 0 b,0<g₁ x) : 0<N V g g₁ g₂ b := by
  have ha := h.A_pos hp
  have hd : ∀ x∈Icc 0 b, HasDerivAt (fun t => N V g g₁ g₂ t/A g g₁ g₂ t)
      ((g x)^3*S g₁ g₂ g₃ x/(A g g₁ g₂ x)^2) x := by
    intro x hx
    exact hasDerivAt_N_div_A (h.V_deriv x hx) (h.g_deriv x hx)
      (h.g₁_deriv x hx) (h.g₂_deriv x hx) (ha x hx).ne'
  have hm : StrictMonoOn (fun t => N V g g₁ g₂ t/A g g₁ g₂ t) (Icc 0 b) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc 0 b)
      (fun x hx => (hd x hx).continuousAt.continuousWithinAt)
    intro x hx
    have hx' : x∈Ioo 0 b := by simpa only [interior_Icc] using hx
    have hxc : x∈Icc 0 b := ⟨hx'.1.le,hx'.2.le⟩
    rw [(hd x hxc).deriv]
    exact div_pos (mul_pos (pow_pos (h.g_pos x ⟨hx'.1,hx'.2.le⟩) 3)
      (h.schaaf_pos x hxc (hp x hxc))) (sq_pos_of_pos (ha x hxc))
  have hN0 : N V g g₁ g₂ 0=0 := by simp only [N,h.V_zero,h.g_zero,mul_zero,zero_mul,zero_pow (by norm_num : (2:ℕ)≠0),sub_self]
  have hratio := hm ⟨le_rfl,h.endpoint_pos.le⟩ ⟨h.endpoint_pos.le,le_rfl⟩ h.endpoint_pos
  simp only [hN0,zero_div] at hratio
  exact (div_pos_iff_of_pos_right (ha b ⟨h.endpoint_pos.le,le_rfl⟩)).mp hratio

theorem HalfWell.profile_deriv (h : HalfWell V g g₁ g₂ g₃ φ b) {x : ℝ}
    (hx : x∈Ioo 0 b) : deriv φ x=N V g g₁ g₂ x/(g x)^4 := by
  have he : φ =ᶠ[𝓝 x] profile V g g₁ := by
    filter_upwards [isOpen_Ioo.mem_nhds hx] with t ht
    exact h.profile_eq t ⟨ht.1,ht.2.le⟩
  rw [he.deriv_eq]
  have hxc : x∈Icc 0 b := ⟨hx.1.le,hx.2.le⟩
  exact (hasDerivAt_profile (h.V_deriv x hxc) (h.g_deriv x hxc)
    (h.g₁_deriv x hxc) (h.g_pos x ⟨hx.1,hx.2.le⟩).ne').deriv

theorem HalfWell.central_profile_pos (h : HalfWell V g g₁ g₂ g₃ φ b)
    (hp : ∀ x∈Ioo 0 b,0<g₁ x) : φ 0<φ b := by
  have hm : StrictMonoOn φ (Icc 0 b) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc 0 b) h.profile_cont
    intro x hx
    have hx' : x∈Ioo 0 b := by simpa only [interior_Icc] using hx
    have hr := h.restrict hx'.1 hx'.2.le
    have hgp : ∀ t∈Icc 0 x,0<g₁ t := by
      intro t ht
      by_cases ht0 : t=0
      · simpa only [ht0] using h.g₁_zero_pos
      · exact hp t ⟨lt_of_le_of_ne ht.1 (Ne.symm ht0),ht.2.trans_lt hx'.2⟩
    rw [h.profile_deriv hx']
    exact div_pos (hr.N_pos hgp) (pow_pos (h.g_pos x ⟨hx'.1,hx'.2.le⟩) 4)
  exact hm ⟨le_rfl,h.endpoint_pos.le⟩ ⟨h.endpoint_pos.le,le_rfl⟩ h.endpoint_pos

theorem HalfWell.V_pos (h : HalfWell V g g₁ g₂ g₃ φ b) : 0<V b := by
  have hm : StrictMonoOn V (Icc 0 b) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc 0 b)
      (fun x hx => (h.V_deriv x hx).continuousAt.continuousWithinAt)
    intro x hx
    have hx' : x∈Ioo 0 b := by simpa only [interior_Icc] using hx
    rw [(h.V_deriv x ⟨hx'.1.le,hx'.2.le⟩).deriv]
    exact h.g_pos x ⟨hx'.1,hx'.2.le⟩
  have hz := hm ⟨le_rfl,h.endpoint_pos.le⟩ ⟨h.endpoint_pos.le,le_rfl⟩ h.endpoint_pos
  simpa only [h.V_zero] using hz

end LeanVerification.RegionalReal.Schaaf
