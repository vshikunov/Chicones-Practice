import LeanVerification.ZeroOrientation
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.Analysis.Calculus.Deriv.Pow
import Mathlib.Tactic.FieldSimp

/-! Differential identities behind the strict Schaaf criterion. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal.Schaaf
set_option maxHeartbeats 1800000

def A (g g₁ g₂ : ℝ → ℝ) (x : ℝ) : ℝ := 3*(g₁ x)^2-g x*g₂ x
def S (g₁ g₂ g₃ : ℝ → ℝ) (x : ℝ) : ℝ := 5*(g₂ x)^2-3*g₁ x*g₃ x
def N (V g g₁ g₂ : ℝ → ℝ) (x : ℝ) : ℝ :=
  2*V x*A g g₁ g₂ x-3*(g x)^2*g₁ x
def profile (V g g₁ : ℝ → ℝ) (x : ℝ) : ℝ :=
  ((g x)^2-2*V x*g₁ x)/(g x)^3

theorem hasDerivAt_A {g g₁ g₂ g₃ : ℝ → ℝ} {x : ℝ}
    (h0 : HasDerivAt g (g₁ x) x) (h1 : HasDerivAt g₁ (g₂ x) x)
    (h2 : HasDerivAt g₂ (g₃ x) x) :
    HasDerivAt (A g g₁ g₂) (5*g₁ x*g₂ x-g x*g₃ x) x := by
  have hd := ((h1.pow 2).const_mul 3).sub (h0.mul h2)
  convert hd using 1 <;> dsimp only [A] <;> ring

theorem A_deriv_at_zero {g g₁ g₂ g₃ : ℝ → ℝ} {x : ℝ}
    (h0 : HasDerivAt g (g₁ x) x) (h1 : HasDerivAt g₁ (g₂ x) x)
    (h2 : HasDerivAt g₂ (g₃ x) x) (ha : A g g₁ g₂ x=0)
    (hp : g₁ x≠0) :
    deriv (A g g₁ g₂) x = g x*S g₁ g₂ g₃ x/(3*g₁ x) := by
  rw [(hasDerivAt_A h0 h1 h2).deriv]
  apply (eq_div_iff (mul_ne_zero (by norm_num) hp)).mpr
  dsimp only [A] at ha
  dsimp only [S]
  linear_combination 5*g₂ x*ha

theorem hasDerivAt_N {V g g₁ g₂ g₃ : ℝ → ℝ} {x : ℝ}
    (hV : HasDerivAt V (g x) x) (h0 : HasDerivAt g (g₁ x) x)
    (h1 : HasDerivAt g₁ (g₂ x) x) (h2 : HasDerivAt g₂ (g₃ x) x) :
    HasDerivAt (N V g g₁ g₂)
      (2*V x*(5*g₁ x*g₂ x-g x*g₃ x)-5*(g x)^2*g₂ x) x := by
  have hd := ((hV.const_mul 2).mul (hasDerivAt_A h0 h1 h2)).sub
    (((h0.pow 2).const_mul 3).mul h1)
  convert hd using 1 <;> dsimp only [A,N] <;> ring

theorem hasDerivAt_N_div_A {V g g₁ g₂ g₃ : ℝ → ℝ} {x : ℝ}
    (hV : HasDerivAt V (g x) x) (h0 : HasDerivAt g (g₁ x) x)
    (h1 : HasDerivAt g₁ (g₂ x) x) (h2 : HasDerivAt g₂ (g₃ x) x)
    (ha : A g g₁ g₂ x≠0) :
    HasDerivAt (fun t => N V g g₁ g₂ t/A g g₁ g₂ t)
      ((g x)^3*S g₁ g₂ g₃ x/(A g g₁ g₂ x)^2) x := by
  have hd := (hasDerivAt_N hV h0 h1 h2).div (hasDerivAt_A h0 h1 h2) ha
  convert hd using 1
  dsimp only [N,A,S]
  congr 1
  ring

theorem hasDerivAt_profile {V g g₁ g₂ : ℝ → ℝ} {x : ℝ}
    (hV : HasDerivAt V (g x) x) (h0 : HasDerivAt g (g₁ x) x)
    (h1 : HasDerivAt g₁ (g₂ x) x) (hg : g x≠0) :
    HasDerivAt (profile V g g₁) (N V g g₁ g₂ x/(g x)^4) x := by
  have hd := ((h0.pow 2).sub ((hV.const_mul 2).mul h1)).div (h0.pow 3) (pow_ne_zero _ hg)
  convert hd using 1
  dsimp only [profile,N,A]
  field_simp
  ring

theorem positive_on_Icc_of_positive_zero_orientation {f : ℝ → ℝ} {a b : ℝ}
    (hf : ∀ t∈Icc a b, DifferentiableAt ℝ f t)
    (hz : ∀ t∈Icc a b, f t=0 → 0<deriv f t) (ha : 0<f a) :
    ∀ t∈Icc a b, 0<f t := by
  have hn := ZeroOrientation.nonneg_on_Icc_of_deriv_pos_at_zeros hf hz ha.le
  intro t ht
  by_contra hnp
  have hft : f t=0 := le_antisymm (le_of_not_gt hnp) (hn t ht)
  have hat : a<t := lt_of_le_of_ne ht.1 (by intro he; subst t; exact ha.ne' hft)
  have hd := (hf t ht).hasDerivAt
  have hl : Tendsto (slope f t) (𝓝[<] t) (𝓝 (deriv f t)) :=
    (hasDerivAt_iff_tendsto_slope.mp hd).mono_left (nhdsLT_le_nhdsNE t)
  have hs : ∀ᶠ y in 𝓝[<] t, slope f t y≤0 := by
    filter_upwards [Ico_mem_nhdsLT hat] with y hy
    rw [slope_def_field,hft,sub_zero]
    exact div_nonpos_of_nonneg_of_nonpos (hn y ⟨hy.1,hy.2.le.trans ht.2⟩)
      (sub_nonpos.mpr hy.2.le)
  exact (not_le_of_gt (hz t ht hft)) (le_of_tendsto hl hs)

end LeanVerification.RegionalReal.Schaaf
