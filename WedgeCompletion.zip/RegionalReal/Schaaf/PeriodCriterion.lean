import LeanVerification.RegionalReal.Schaaf.PhysicalProfile
import Mathlib.Analysis.SpecialFunctions.Integrals

/-! Schaaf's strict criterion for the actual physical period. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.RegionalReal.Schaaf
open Loud
set_option maxHeartbeats 2600000

theorem inverse_second_center_comparison (D F h : ℝ) (hh : AdmissibleEnergy D F h)
    (hw : Well (fun X => potential D F (inversePosition F X))
      (forceInPosition D F) (deriv (forceInPosition D F))
      (deriv (deriv (forceInPosition D F))) (deriv (deriv (deriv (forceInPosition D F))))
      (physicalProfile D F) (morsePosition D F (-Real.sqrt (2*h))) (morsePosition D F (Real.sqrt (2*h))))
    {u : ℝ} (hu : u∈Icc (-Real.sqrt (2*h)) (Real.sqrt (2*h))) :
    (0<u → deriv (deriv (morsePosition D F)) 0<deriv (deriv (morsePosition D F)) u) ∧
    (u<0 → deriv (deriv (morsePosition D F)) u<deriv (deriv (morsePosition D F)) 0) := by
  have hr : 0<Real.sqrt (2*h) := Real.sqrt_pos.mpr (by linarith [hh.1])
  have hm := strictMonoOn_morsePosition_amplitude D F h (Real.sqrt (2*h)) hh le_rfl
  have h0 : (0:ℝ)∈Icc (-Real.sqrt (2*h)) (Real.sqrt (2*h)) := ⟨by linarith,hr.le⟩
  have hur := morse_amplitude_in_range D F h hh hu
  have hφ0 : physicalProfile D F 0=deriv (deriv (morsePosition D F)) 0 := by
    simpa only [morsePosition_zero] using physicalProfile_morsePosition D F 0 (morseRange_zero D F)
  constructor
  · intro hup
    have hXp : 0<morsePosition D F u := by simpa only [morsePosition_zero] using hm h0 hu hup
    have hXb := hm.monotoneOn hu ⟨by linarith,le_rfl⟩ hu.2
    have he := hw.profile_gt_center_of_pos ⟨hXp,hXb⟩
    simpa only [hφ0,physicalProfile_morsePosition D F u hur] using he
  · intro hun
    have hXn : morsePosition D F u<0 := by simpa only [morsePosition_zero] using hm hu h0 hun
    have haX := hm.monotoneOn ⟨le_rfl,by linarith⟩ hu hu.1
    have he := hw.profile_lt_center_of_neg ⟨haX,hXn⟩
    simpa only [hφ0,physicalProfile_morsePosition D F u hur] using he

theorem physical_period_deriv_pos_of_schaaf (D F h : ℝ) (hh : AdmissibleEnergy D F h)
    (hS : ∀ X∈Icc (morsePosition D F (-Real.sqrt (2*h))) (morsePosition D F (Real.sqrt (2*h))),
      0<deriv (forceInPosition D F) X →
      0<5*(deriv (deriv (forceInPosition D F)) X)^2-
        3*deriv (forceInPosition D F) X*deriv (deriv (deriv (forceInPosition D F))) X)
    (hz : ∀ X∈Icc (morsePosition D F (-Real.sqrt (2*h))) (morsePosition D F (Real.sqrt (2*h))),
      deriv (forceInPosition D F) X=0 →
      forceInPosition D F X*deriv (deriv (forceInPosition D F)) X<0) :
    0<deriv (periodQuadrature D F) h := by
  let r := Real.sqrt (2*h)
  let c := deriv (deriv (morsePosition D F)) 0
  let K : ℝ → ℝ := fun θ => deriv (deriv (morsePosition D F)) (r*Real.sin θ)*Real.sin θ
  have hr : 0<r := Real.sqrt_pos.mpr (by linarith [hh.1])
  have hw := physical_schaaf_well D F h hh hS hz
  have hcomp : ∀ {u : ℝ}, u∈Icc (-r) r →
      (0<u → deriv (deriv (morsePosition D F)) 0<deriv (deriv (morsePosition D F)) u) ∧
      (u<0 → deriv (deriv (morsePosition D F)) u<deriv (deriv (morsePosition D F)) 0) :=
    fun hu => inverse_second_center_comparison D F h hh hw hu
  have hK : Continuous K := by
    rw [continuous_iff_continuousAt]
    intro θ
    have hu := morse_amplitude_in_range D F h hh (sqrt_mul_sin_mem_amplitude h θ)
    have harg : ContinuousAt (fun t:ℝ => r*Real.sin t) θ :=
      continuousAt_const.mul Real.continuous_sin.continuousAt
    exact (((analyticAt_morsePosition D F _ hu).deriv.deriv.continuousAt.comp_of_eq
      harg rfl).mul Real.continuous_sin.continuousAt)
  have hc : Continuous (fun θ => c*Real.sin θ) := continuous_const.mul Real.continuous_sin
  have hge : ∀ θ, c*Real.sin θ≤K θ := by
    intro θ
    have hu := sqrt_mul_sin_mem_amplitude h θ
    have hs := hcomp hu
    rcases lt_trichotomy (Real.sin θ) 0 with hsn|hs0|hsp
    · have huv : r*Real.sin θ<0 := mul_neg_of_pos_of_neg hr hsn
      have hlt := mul_lt_mul_of_neg_right (hs.2 huv) hsn
      exact hlt.le
    · simp only [K,hs0,mul_zero,le_refl]
    · have huv : 0<r*Real.sin θ := mul_pos hr hsp
      have hlt := mul_lt_mul_of_pos_right (hs.1 huv) hsp
      exact hlt.le
  have hstrict : c*Real.sin (Real.pi/2)<K (Real.pi/2) := by
    have hs := (hcomp (show r∈Icc (-r) r from ⟨by linarith,le_rfl⟩)).1 hr
    simpa only [K,Real.sin_pi_div_two,mul_one,c] using hs
  have hint := intervalIntegral.integral_lt_integral_of_continuousOn_of_le_of_exists_lt
    (show -(Real.pi/2)<Real.pi/2 by linarith [Real.pi_pos]) hc.continuousOn hK.continuousOn
    (fun θ _ => hge θ) ⟨Real.pi/2,⟨by linarith [Real.pi_pos],le_rfl⟩,hstrict⟩
  have hcint : (∫ θ in -(Real.pi/2)..Real.pi/2,c*Real.sin θ)=0 := by
    rw [intervalIntegral.integral_const_mul,integral_sin,Real.cos_neg,sub_self,mul_zero]
  rw [hcint] at hint
  rw [(hasDerivAt_periodQuadrature_fixed_endpoint D F h hh).deriv]
  exact mul_pos (div_pos (by norm_num) hr) hint

end LeanVerification.RegionalReal.Schaaf
