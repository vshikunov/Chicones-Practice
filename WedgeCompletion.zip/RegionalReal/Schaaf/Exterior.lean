import LeanVerification.RegionalReal.Schaaf.HalfWell

/-! The possible outer nonconvex piece preserves the center comparison. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal.Schaaf
set_option maxHeartbeats 2000000

variable {V g g₁ g₂ g₃ φ : ℝ → ℝ} {b : ℝ}

theorem HalfWell.g₂_neg_at_g₁_zero (h : HalfWell V g g₁ g₂ g₃ φ b)
    {x : ℝ} (hx : x∈Icc 0 b) (hz : g₁ x=0) : g₂ x<0 := by
  have hxp : 0<x := lt_of_le_of_ne hx.1 (by intro he; subst x; exact h.g₁_zero_pos.ne' hz)
  have hgp := h.g_pos x ⟨hxp,hx.2⟩
  have hn := h.crossing_neg x hx hz
  by_contra hnp
  exact (not_le_of_gt hn) (mul_nonneg hgp.le (le_of_not_gt hnp))

theorem HalfWell.g₁_zero_unique (h : HalfWell V g g₁ g₂ g₃ φ b) :
    ZeroCounting.AtMostOneZeroOn g₁ (Icc 0 b) := by
  have hz := ZeroOrientation.atMostOneZeroOn_of_deriv_pos_at_zeros (convex_Icc 0 b)
    (f:=fun x => -g₁ x)
    (fun x hx => (h.g₁_deriv x hx).neg.differentiableAt)
    (fun x hx he => by
      rw [((h.g₁_deriv x hx).neg).deriv]
      exact neg_pos.mpr (h.g₂_neg_at_g₁_zero hx (neg_eq_zero.mp he)))
  intro x y hx hy hzx hzy
  exact hz hx hy (by simp only [hzx,neg_zero]) (by simp only [hzy,neg_zero])

theorem HalfWell.exists_g₁_zero_before_nonpos (h : HalfWell V g g₁ g₂ g₃ φ b)
    {x : ℝ} (hx : x∈Icc 0 b) (hn : g₁ x≤0) :
    ∃ c∈Icc 0 x,g₁ c=0 := by
  apply intermediate_value_Icc' hx.1
    (fun t ht => (h.g₁_deriv t ⟨ht.1,ht.2.trans hx.2⟩).continuousAt.continuousWithinAt)
  exact ⟨hn,h.g₁_zero_pos.le⟩

theorem HalfWell.g₁_pos_before_zero (h : HalfWell V g g₁ g₂ g₃ φ b)
    {c : ℝ} (hc : c∈Icc 0 b) (hcz : g₁ c=0) :
    ∀ x∈Ioo 0 c,0<g₁ x := by
  intro x hx
  by_contra hn
  obtain ⟨d,hd,hdz⟩ := h.exists_g₁_zero_before_nonpos
    ⟨hx.1.le,hx.2.le.trans hc.2⟩ (le_of_not_gt hn)
  have he := h.g₁_zero_unique ⟨hd.1,(hd.2.trans hx.2.le).trans hc.2⟩ hc hdz hcz
  exact (not_le_of_gt hx.2) (he ▸ hd.2)

theorem HalfWell.g₁_nonpos_after_zero (h : HalfWell V g g₁ g₂ g₃ φ b)
    {c : ℝ} (hc : c∈Icc 0 b) (hcz : g₁ c=0) :
    ∀ x∈Icc c b,g₁ x≤0 := by
  have hn := ZeroOrientation.nonneg_on_Icc_of_deriv_pos_at_zeros
    (f:=fun x => -g₁ x)
    (fun x hx => (h.g₁_deriv x ⟨hc.1.trans hx.1,hx.2⟩).neg.differentiableAt)
    (fun x hx hz => by
      rw [((h.g₁_deriv x ⟨hc.1.trans hx.1,hx.2⟩).neg).deriv]
      exact neg_pos.mpr (h.g₂_neg_at_g₁_zero ⟨hc.1.trans hx.1,hx.2⟩ (neg_eq_zero.mp hz)))
    (by simp only [hcz,neg_zero,le_refl])
  intro x hx
  exact neg_nonneg.mp (hn x hx)

theorem HalfWell.profile_ge_at_outer_endpoint (h : HalfWell V g g₁ g₂ g₃ φ b)
    {c : ℝ} (hcp : 0<c) (hcb : c≤b) (hcz : g₁ c=0) : φ c≤φ b := by
  have hc : c∈Icc 0 b := ⟨hcp.le,hcb⟩
  have hnonpos := h.g₁_nonpos_after_zero hc hcz
  have hg : AntitoneOn g (Icc c b) := by
    apply antitoneOn_of_deriv_nonpos (convex_Icc c b)
      (fun x hx => (h.g_deriv x ⟨hcp.le.trans hx.1,hx.2⟩).continuousAt.continuousWithinAt)
      (fun x hx => (h.g_deriv x ⟨hcp.le.trans (interior_subset hx).1,(interior_subset hx).2⟩).differentiableAt.differentiableWithinAt)
    intro x hx
    have hxi : x∈Icc c b := interior_subset hx
    rw [(h.g_deriv x ⟨hcp.le.trans hxi.1,hxi.2⟩).deriv]
    exact hnonpos x hxi
  have hgb : 0<g b := h.g_pos b ⟨h.endpoint_pos,le_rfl⟩
  have hgc : 0<g c := h.g_pos c ⟨hcp,hcb⟩
  have hgcgb : g b≤g c := hg ⟨le_rfl,hcb⟩ ⟨hcb,le_rfl⟩ hcb
  have hpbc : 1/g c≤1/g b := one_div_le_one_div_of_le hgb hgcgb
  have hpc : φ c=1/g c := by
    rw [h.profile_eq c ⟨hcp,hcb⟩]
    dsimp only [profile]
    rw [hcz,mul_zero,sub_zero]
    field_simp
    ring
  have hpb : 1/g b≤φ b := by
    rw [h.profile_eq b ⟨h.endpoint_pos,le_rfl⟩]
    dsimp only [profile]
    apply (le_div_iff₀ (pow_pos hgb 3)).mpr
    have hn : 2*V b*g₁ b≤0 := mul_nonpos_of_nonneg_of_nonpos
      (mul_nonneg (by norm_num) h.V_pos.le) (hnonpos b ⟨hcb,le_rfl⟩)
    have he : (1/g b)*(g b)^3=(g b)^2 := by field_simp; ring
    rw [he]
    linarith
  rw [hpc]
  exact hpbc.trans hpb

theorem HalfWell.profile_above_center (h : HalfWell V g g₁ g₂ g₃ φ b) : φ 0<φ b := by
  by_cases hz : ∃ c∈Icc 0 b,g₁ c=0
  · obtain ⟨c,hc,hcz⟩ := hz
    have hcp : 0<c := lt_of_le_of_ne hc.1 (by intro he; subst c; exact h.g₁_zero_pos.ne' hcz)
    have hcentral := (h.restrict hcp hc.2).central_profile_pos (h.g₁_pos_before_zero hc hcz)
    exact hcentral.trans_le (h.profile_ge_at_outer_endpoint hcp hc.2 hcz)
  · apply h.central_profile_pos
    intro x hx
    by_contra hn
    obtain ⟨c,hc,hcz⟩ := h.exists_g₁_zero_before_nonpos ⟨hx.1.le,hx.2.le⟩ (le_of_not_gt hn)
    exact hz ⟨c,⟨hc.1,hc.2.trans hx.2.le⟩,hcz⟩

end LeanVerification.RegionalReal.Schaaf
