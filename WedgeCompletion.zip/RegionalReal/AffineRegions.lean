import LeanVerification.RegionalReal.AffineSigns

/-! Complete physical-period applications of the affine curvature.
These final regional theorems have only the original parameter hypotheses.
They include the logarithmic seam and all four constant-period exceptions. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal
open Loud
set_option maxHeartbeats 1600000

theorem mechanicalDomain_of_mem_turn_interval (D F h X : ℝ)
    (hh : AdmissibleEnergy D F h)
    (hX : X ∈ Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h)))) : mechanicalDomain F X := by
  have hr : 0<Real.sqrt (2*h) := Real.sqrt_pos.mpr (by linarith [hh.1])
  obtain ⟨θ,hθ,rfl⟩ := exists_angle_of_mem_mechanical_interval
    D F h (Real.sqrt (2*h)) X hh le_rfl hr hX
  exact mechanicalDomain_morsePosition D F _
    (morse_amplitude_in_range D F h hh (sqrt_mul_sin_mem_amplitude h θ))

theorem physical_period_deriv_ne_zero_of_affine_numerator
    (D F h ε : ℝ) (hh : AdmissibleEnergy D F h)
    (hD0 : -(1/2)≤D) (hD1 : D≤0)
    (hN : ∀ w,0<w → 0<ε*affineCurvatureNumerator D F w) :
    deriv (periodQuadrature D F) h≠0 := by
  apply physical_period_deriv_ne_zero_of_signed_curvature D F h ε (affineAux F) hh
  · intro X hX
    exact analyticAt_affineAux F X
  · intro X hX
    exact mechanicalDomain_of_mem_turn_interval D F h X hh hX
  · intro X hX
    have hdom := mechanicalDomain_of_mem_turn_interval D F h X hh hX
    have hw := inversePosition_pos F X hdom
    rw [actual_affineH_eq_model D F h X hdom]
    exact div_pos (mul_pos hdom (mixtureSum_pos hD0 hD1 hw)) (sq_pos_of_pos hw)
  · intro X hX
    have hdom := mechanicalDomain_of_mem_turn_interval D F h X hh hX
    have hw := inversePosition_pos F X hdom
    have hS := mixtureSum_pos hD0 hD1 hw
    rw [actual_affineCurvature_eq D F h X hdom hS.ne',←mul_div_assoc]
    exact div_pos (hN _ hw)
      (mul_pos (mul_pos (by norm_num) (sq_pos_of_pos (Real.rpow_pos_of_pos hw F)))
        (sq_pos_of_pos hS))

theorem physical_period_deriv_ne_zero_zero_line (F h : ℝ)
    (hFq : F≠1/4) (hF1 : F≠1) (hh : AdmissibleEnergy 0 F h) :
    deriv (periodQuadrature 0 F) h≠0 := by
  apply physical_period_deriv_ne_zero_of_affine_numerator 0 F h
    (2*(1-F)*(4*F-1)) hh (by norm_num) le_rfl
  intro w hw
  exact affineCurvatureNumerator_signed_zero hw hFq hF1

theorem physical_period_deriv_ne_zero_negHalf_line (F h : ℝ)
    (hFh : F≠1/2) (hF2 : F≠2) (hh : AdmissibleEnergy (-(1/2)) F h) :
    deriv (periodQuadrature (-(1/2)) F) h≠0 := by
  apply physical_period_deriv_ne_zero_of_affine_numerator (-(1/2)) F h
    (4*(2*F-1)*(2-F)) hh le_rfl (by norm_num)
  intro w hw
  exact affineCurvatureNumerator_signed_negHalf hFh hF2

theorem physical_period_deriv_ne_zero_rectangle (D F h : ℝ)
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF0 : 1/2≤F) (hF1 : F≤1)
    (hiso : ¬IsKnownIsochronousParameter D F) (hh : AdmissibleEnergy D F h) :
    deriv (periodQuadrature D F) h≠0 := by
  apply physical_period_deriv_ne_zero_of_affine_numerator D F h 1 hh hD0 hD1
  intro w hw
  simpa only [one_mul] using affineCurvatureNumerator_pos_rectangle hD0 hD1 hF0 hF1 hiso hw

theorem physical_period_deriv_ne_zero_lower_exterior_strip (D F h : ℝ)
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF : F≤0) (hh : AdmissibleEnergy D F h) :
    deriv (periodQuadrature D F) h≠0 := by
  apply physical_period_deriv_ne_zero_of_affine_numerator D F h (-1) hh hD0 hD1
  intro w hw
  simpa only [neg_one_mul,neg_pos] using
    affineCurvatureNumerator_neg_lower_exterior hD0 hD1 hF hw

theorem physical_period_deriv_ne_zero_upper_exterior_strip (D F h : ℝ)
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF : 2≤F)
    (hiso : ¬IsKnownIsochronousParameter D F) (hh : AdmissibleEnergy D F h) :
    deriv (periodQuadrature D F) h≠0 := by
  apply physical_period_deriv_ne_zero_of_affine_numerator D F h (-1) hh hD0 hD1
  intro w hw
  simpa only [neg_one_mul,neg_pos] using
    affineCurvatureNumerator_neg_upper_exterior hD0 hD1 hF hiso hw

theorem criticalPeriodBound_zero_of_no_isolated {D F : ℝ}
    (hn : ∀ h,¬IsolatedCriticalEnergy D F h) : CriticalPeriodBound 0 D F := by
  intro s hs
  have he : s=∅ := Finset.eq_empty_iff_forall_not_mem.mpr (by
    intro h hh
    exact hn h (hs h hh))
  simp [he]

theorem criticalPeriodBound_zero_known_isochrone {D F : ℝ}
    (hiso : IsKnownIsochronousParameter D F) : CriticalPeriodBound 0 D F :=
  criticalPeriodBound_zero_of_no_isolated (no_isolatedCriticalEnergy_known_isochrone hiso)

theorem criticalPeriodBound_zero_zero_line (F : ℝ) : CriticalPeriodBound 0 0 F := by
  by_cases hiso : IsKnownIsochronousParameter 0 F
  · exact criticalPeriodBound_zero_known_isochrone hiso
  apply criticalPeriodBound_zero_of_deriv_ne_zero
  intro h hh
  apply physical_period_deriv_ne_zero_zero_line F h ?_ ?_ hh
  · intro hF
    exact hiso (Or.inl ⟨rfl,hF⟩)
  · intro hF
    exact hiso (Or.inr (Or.inl ⟨rfl,hF⟩))

theorem criticalPeriodBound_zero_negHalf_line (F : ℝ) :
    CriticalPeriodBound 0 (-(1/2)) F := by
  by_cases hiso : IsKnownIsochronousParameter (-(1/2)) F
  · exact criticalPeriodBound_zero_known_isochrone hiso
  apply criticalPeriodBound_zero_of_deriv_ne_zero
  intro h hh
  apply physical_period_deriv_ne_zero_negHalf_line F h ?_ ?_ hh
  · intro hF
    exact hiso (Or.inr (Or.inr (Or.inl ⟨rfl,hF⟩)))
  · intro hF
    exact hiso (Or.inr (Or.inr (Or.inr ⟨rfl,hF⟩)))

theorem criticalPeriodBound_zero_rectangle (D F : ℝ)
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF0 : 1/2≤F) (hF1 : F≤1) :
    CriticalPeriodBound 0 D F := by
  by_cases hiso : IsKnownIsochronousParameter D F
  · exact criticalPeriodBound_zero_known_isochrone hiso
  exact criticalPeriodBound_zero_of_deriv_ne_zero
    (fun h hh => physical_period_deriv_ne_zero_rectangle D F h hD0 hD1 hF0 hF1 hiso hh)

theorem criticalPeriodBound_zero_lower_exterior_strip (D F : ℝ)
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF : F≤0) : CriticalPeriodBound 0 D F :=
  criticalPeriodBound_zero_of_deriv_ne_zero
    (fun h hh => physical_period_deriv_ne_zero_lower_exterior_strip D F h hD0 hD1 hF hh)

theorem criticalPeriodBound_zero_upper_exterior_strip (D F : ℝ)
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF : 2≤F) : CriticalPeriodBound 0 D F := by
  by_cases hiso : IsKnownIsochronousParameter D F
  · exact criticalPeriodBound_zero_known_isochrone hiso
  exact criticalPeriodBound_zero_of_deriv_ne_zero
    (fun h hh => physical_period_deriv_ne_zero_upper_exterior_strip D F h hD0 hD1 hF hiso hh)

theorem parameter_region_four_bound (D F : ℝ) (hp : parameterRegion 4 D F) :
    CriticalPeriodBound (parameterRegionBound 4) D F := by
  change D=0 ∨ D=-(1/2) at hp
  rcases hp with rfl|rfl
  · exact criticalPeriodBound_zero_zero_line F
  · exact criticalPeriodBound_zero_negHalf_line F

theorem parameter_region_nine_bound (D F : ℝ) (hp : parameterRegion 9 D F) :
    CriticalPeriodBound (parameterRegionBound 9) D F := by
  exact criticalPeriodBound_zero_rectangle D F hp.2.2.1 hp.2.2.2 hp.1 hp.2.1

end LeanVerification.RegionalReal
