import LeanVerification.RegionalReal.QuarterRegion

/-! An actual physical critical-mode proof on the left half-block.
No Schaaf criterion or externally asserted monotonicity theorem is used. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal
open Loud
set_option maxHeartbeats 2600000

def saddleCurvatureNumerator (D F w q S H : ℝ) : ℝ :=
  (2*F-1)*((F+1)*S+3*D)*H^2*w^4+
    4*(F+1)*q*(D+F)*S^2*H*w^2-10*q^2*(D+F)^2*S^3

theorem saddle_curvature_numerator_algebra (D F w q S H : ℝ)
    (hw : w≠0) (hq : q≠0) (hS : S≠0) (hH : H≠0) :
    (2*(D+F)*(D-(F+2)*S)/(q*w^2)+(F+1)*(2*F+1)*H/q^2)/(3*H)-
      5*(2*(D+F)*S/w^2-(F+1)*H/q)^2/(9*H^2)-
      ((F*S+D)/w)*(2*(D+F)*S/w^2-(F+1)*H/q)/(3*(q*S/w)*H)+
      (D*(F-1)/(q*w))/(q*S/w)=
      2*saddleCurvatureNumerator D F w q S H/(9*q^2*S*H^2*w^4) := by
  dsimp only [saddleCurvatureNumerator]
  field_simp
  ring

theorem actual_saddleCurvature_eq_numerator (D F L X : ℝ)
    (hX : mechanicalDomain F X) (hS : saddleFactor D (inversePosition F X)≠0)
    (hH : saddleHModel D F L X≠0) :
    CriticalEnergy.coefficientQ (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) L X=
      2*saddleCurvatureNumerator D F (inversePosition F X) (affineAux F X)
        (saddleFactor D (inversePosition F X)) (saddleHModel D F L X)/
      (9*(affineAux F X)^2*saddleFactor D (inversePosition F X)*
        (saddleHModel D F L X)^2*(inversePosition F X)^4) := by
  rw [CriticalEnergy.coefficientQ_eq_spatial_derivatives
    (analyticAt_potentialInPosition D F X hX) (analyticAt_saddleAux D F X hX),
    (hasDerivAt_actual_saddleH D F L X hX).deriv,
    second_deriv_actual_saddleH D F L X hX,actual_saddleH_eq_model D F L X hX,
    second_deriv_saddleAux D F X hX,(hasDerivAt_saddleAux D F X hX).deriv]
  dsimp only [saddleH1,saddleH2,saddleAux,saddleAux1,saddleAux2]
  exact saddle_curvature_numerator_algebra D F _ _ _ _
    (inversePosition_pos F X hX).ne' hX.ne' hS hH

theorem saddleHModel_pos_left (D F L X : ℝ)
    (hD : D≤-1) (hF : F≤1) (hX : mechanicalDomain F X)
    (hc : inCentralInterval D (inversePosition F X))
    (hL : potential D F (inversePosition F X)≤L) : 0<saddleHModel D F L X := by
  have hDF : 0≤D*(F-1) := mul_nonneg_of_nonpos_of_nonpos (by linarith) (by linarith)
  have hφ2 : 0≤saddleAux2 D F X := div_nonneg hDF (mul_pos hX hc.1).le
  dsimp only [saddleHModel]
  exact add_pos_of_pos_of_nonneg
    (div_pos (mul_pos hX (sq_pos_of_pos hc.2)) (pow_pos hc.1 3))
    (mul_nonneg (mul_nonneg (by norm_num) (sub_nonneg.mpr hL)) hφ2)

theorem saddleCurvatureNumerator_neg_left (D F w q S H : ℝ)
    (hD : D≤-1) (hF0 : 1/2≤F) (hF1 : F≤1)
    (hw : 0<w) (hq : 0<q) (hS : 0<S) (hSmax : S≤-D) (hH : 0<H) :
    saddleCurvatureNumerator D F w q S H<0 := by
  have hFp : 0<F+1 := by linarith
  have hB : (F+1)*S+3*D<0 := by
    have h1 := mul_nonpos_of_nonneg_of_nonpos hFp.le (show S+D≤0 by linarith)
    have h2 := mul_neg_of_pos_of_neg (show 0<2-F by linarith) (show D<0 by linarith)
    nlinarith
  have hDF : D+F≤0 := by linarith
  have hA : (2*F-1)*((F+1)*S+3*D)*H^2*w^4≤0 :=
    mul_nonpos_of_nonpos_of_nonneg
      (mul_nonpos_of_nonpos_of_nonneg
        (mul_nonpos_of_nonneg_of_nonpos (by linarith) hB.le) (sq_nonneg _))
      (pow_nonneg hw.le 4)
  have hC : 4*(F+1)*q*(D+F)*S^2*H*w^2≤0 :=
    mul_nonpos_of_nonpos_of_nonneg
      (mul_nonpos_of_nonpos_of_nonneg
        (mul_nonpos_of_nonpos_of_nonneg
          (mul_nonpos_of_nonneg_of_nonpos (by positivity) hDF) (sq_nonneg _)) hH.le)
      (sq_nonneg _)
  have hE : 0≤10*q^2*(D+F)^2*S^3 := by positivity
  dsimp only [saddleCurvatureNumerator]
  by_cases hF : F=1/2
  · have hn : D+F≠0 := by rw [hF]; linarith
    have hp : 0<10*q^2*(D+F)^2*S^3 :=
      mul_pos (mul_pos (mul_pos (by norm_num) (sq_pos_of_pos hq)) (sq_pos_of_ne_zero hn))
        (pow_pos hS 3)
    linarith
  · have hFl : 1/2<F := lt_of_le_of_ne hF0 (Ne.symm hF)
    have hp : 0<2*F-1 := by linarith
    have hn : (2*F-1)*((F+1)*S+3*D)*H^2*w^4<0 :=
      mul_neg_of_neg_of_pos
        (mul_neg_of_neg_of_pos (mul_neg_of_pos_of_neg hp hB) (sq_pos_of_pos hH))
        (pow_pos hw 4)
    linarith

theorem physical_saddleCurvature_neg_left (D F h X : ℝ)
    (hD : D≤-1) (hF0 : 1/2≤F) (hF1 : F≤1) (hh : AdmissibleEnergy D F h)
    (hX : X ∈ Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h)))) :
    CriticalEnergy.coefficientQ (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) h X<0 := by
  obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
  have hH := saddleHModel_pos_left D F h X hD hF1 hd hc
    (physical_potential_le_energy D F h hh hX)
  have hSmax : saddleFactor D (inversePosition F X)≤-D := by
    have hz := mul_nonpos_of_nonpos_of_nonneg (show D+1≤0 by linarith) hc.1.le
    dsimp only [saddleFactor]
    linarith
  rw [actual_saddleCurvature_eq_numerator D F h X hd hc.2.ne' hH.ne']
  exact div_neg_of_neg_of_pos
    (mul_neg_of_pos_of_neg (by norm_num)
      (saddleCurvatureNumerator_neg_left D F _ _ _ _ hD hF0 hF1 hc.1 hd hc.2 hSmax hH))
    (mul_pos (mul_pos (mul_pos (mul_pos (by norm_num) (sq_pos_of_pos hd)) hc.2)
      (sq_pos_of_pos hH)) (pow_pos hc.1 4))

theorem physical_period_deriv_ne_zero_left_halfblock (D F h : ℝ)
    (hD : D≤-1) (hF0 : 1/2≤F) (hF1 : F≤1) (hh : AdmissibleEnergy D F h) :
    deriv (periodQuadrature D F) h≠0 := by
  apply physical_period_deriv_ne_zero_of_signed_curvature D F h (-1) (saddleAux D F) hh
  · intro X hX
    exact analyticAt_saddleAux D F X (physical_turn_interval_coordinate_data D F h hh hX).1
  · intro X hX
    obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
    exact div_pos (mul_pos hd hc.2) hc.1
  · intro X hX
    obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
    rw [actual_saddleH_eq_model D F h X hd]
    exact saddleHModel_pos_left D F h X hD hF1 hd hc
      (physical_potential_le_energy D F h hh hX)
  · intro X hX
    simpa only [neg_one_mul,neg_pos] using
      physical_saddleCurvature_neg_left D F h X hD hF0 hF1 hh hX

theorem criticalPeriodBound_zero_left_halfblock (D F : ℝ)
    (hD : D≤-1) (hF0 : 1/2≤F) (hF1 : F≤1) : CriticalPeriodBound 0 D F :=
  criticalPeriodBound_zero_of_deriv_ne_zero
    (fun h hh => physical_period_deriv_ne_zero_left_halfblock D F h hD hF0 hF1 hh)

theorem parameter_region_ten_bound (D F : ℝ) (hp : parameterRegion 10 D F) :
    CriticalPeriodBound (parameterRegionBound 10) D F := by
  exact criticalPeriodBound_zero_left_halfblock D F hp.2 (by rw [hp.1]; norm_num) hp.1.le

end LeanVerification.RegionalReal
