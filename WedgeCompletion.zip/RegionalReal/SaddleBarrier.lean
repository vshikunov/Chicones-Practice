import LeanVerification.RegionalReal.SaddleAuxCalculus

/-! A strictly increasing barrier proves positivity of the actual saddle
auxiliary denominator below the proved physical saddle height. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal
open Loud
set_option maxHeartbeats 2200000

def saddleBarrier (D F w : ℝ) : ℝ :=
  potential D F w-saddleHeight D F+
    w^(2*F-2)*(saddleFactor D w)^2/(2*D*(1-F))

theorem hasDerivAt_saddleBarrier (D F w : ℝ) (hD : D≠0) (hF : F≠1) (hw : 0<w) :
    HasDerivAt (saddleBarrier D F)
      (w^(2*F-2)*saddleFactor D w*(D+F)/(D*(1-F))) w := by
  have h1F : 1-F≠0 := sub_ne_zero.mpr hF.symm
  have hp := Real.hasDerivAt_rpow_const (x:=w) (p:=2*F-2) (Or.inl hw.ne')
  have hS := ((hasDerivAt_id w).const_mul (D+1)).sub_const D
  have hd := ((hasDerivAt_potential D F w hw).sub_const (saddleHeight D F)).add
    ((hp.mul (hS.pow 2)).div_const (2*D*(1-F)))
  convert hd using 1
  dsimp only [potentialSlope,saddleFactor,id_eq]
  rw [show 2*F-2-1=2*F-3 by ring,
    show 2*F-2=(2*F-3)+1 by ring,Real.rpow_add hw,Real.rpow_one]
  field_simp [hD,h1F]
  ring

theorem saddleBarrier_at_saddle (D F : ℝ) (hD : 0<D) :
    saddleBarrier D F (D/(D+1))=0 := by
  have hS : saddleFactor D (D/(D+1))=0 := by
    dsimp [saddleFactor]
    field_simp
  simp [saddleBarrier,saddleHeight,hS]

theorem saddleBarrier_pos (D F w : ℝ) (hD : 0<D) (hF0 : 0≤F) (hF1 : F<1)
    (hw : inCentralInterval D w) : 0<saddleBarrier D F w := by
  have hs := extra_root_bounds_of_pos D hD
  have hl := (inCentralInterval_iff_of_pos D w hD).mp hw
  have hm : StrictMonoOn (saddleBarrier D F) (Icc (D/(D+1)) w) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc _ _)
    · intro x hx
      exact (hasDerivAt_saddleBarrier D F x hD.ne' hF1.ne
        (lt_of_lt_of_le hs.1 hx.1)).continuousAt.continuousWithinAt
    · intro x hx
      have hxi : x ∈ Ioo (D/(D+1)) w := by simpa only [interior_Icc] using hx
      have hc := (inCentralInterval_iff_of_pos D x hD).mpr hxi.1
      rw [(hasDerivAt_saddleBarrier D F x hD.ne' hF1.ne hc.1).deriv]
      exact div_pos (mul_pos (mul_pos (Real.rpow_pos_of_pos hc.1 _) hc.2)
        (by linarith)) (mul_pos hD (by linarith))
  have hh := hm ⟨le_rfl,hl.le⟩ ⟨hl.le,le_rfl⟩ hl
  simpa only [saddleBarrier_at_saddle D F hD] using hh

theorem saddleHModel_eq_barrier (D F L X : ℝ) (hD : D≠0) (hF : F≠1)
    (hX : mechanicalDomain F X) :
    saddleHModel D F L X=
      (2*D*(1-F)/(affineAux F X*inversePosition F X))*
        (saddleBarrier D F (inversePosition F X)+saddleHeight D F-L) := by
  have h1F : 1-F≠0 := sub_ne_zero.mpr hF.symm
  have hw := (inversePosition_pos F X hX).ne'
  have hq : affineAux F X≠0 := hX.ne'
  have hp : (inversePosition F X)^(2*F-2)=
      (affineAux F X)^2/(inversePosition F X)^2 := by
    rw [affineAux_eq_rpow F X hX,Real.rpow_sub (inversePosition_pos F X hX),
      Real.rpow_two,show 2*F=F+F by ring,Real.rpow_add (inversePosition_pos F X hX),pow_two]
    ring
  dsimp only [saddleHModel,saddleBarrier,saddleAux2]
  rw [hp]
  field_simp [hD,h1F,hw,hq]
  ring

theorem actual_saddleH_pos_below_saddle (D F L X : ℝ)
    (hD : 0<D) (hF0 : 0≤F) (hF1 : F<1) (hL : L<saddleHeight D F)
    (hX : mechanicalDomain F X) (hc : inCentralInterval D (inversePosition F X)) :
    0<CriticalEnergy.coefficientH (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) L X := by
  rw [actual_saddleH_eq_model D F L X hX,
    saddleHModel_eq_barrier D F L X hD.ne' hF1.ne hX]
  have hb := saddleBarrier_pos D F _ hD hF0 hF1 hc
  exact mul_pos (div_pos (mul_pos (mul_pos (by norm_num) hD) (by linarith))
    (mul_pos hX hc.1)) (by linarith)

theorem physical_saddleH_pos (D F h : ℝ) (hD : 0<D) (hF0 : 0≤F) (hF1 : F<1)
    (hh : AdmissibleEnergy D F h)
    {X : ℝ} (hX : X ∈ Icc (morsePosition D F (-Real.sqrt (2*h)))
      (morsePosition D F (Real.sqrt (2*h)))) :
    0<CriticalEnergy.coefficientH (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) h X := by
  obtain ⟨hd,hc⟩ := physical_turn_interval_coordinate_data D F h hh hX
  exact actual_saddleH_pos_below_saddle D F h X hD hF0 hF1
    (admissibleEnergy_lt_saddleHeight D F h hD hh) hd hc

end LeanVerification.RegionalReal
