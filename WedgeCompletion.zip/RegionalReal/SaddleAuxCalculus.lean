import LeanVerification.RegionalReal.AffineCurvature
import LeanVerification.Loud.PairedStrip

/-! Original-coordinate derivatives for the positive saddle-factor auxiliary.
No time or spatial normalization is used in the physical applications. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.RegionalReal
open Loud
set_option maxHeartbeats 3000000

def saddleFactor (D w : ℝ) : ℝ := (D+1)*w-D
def saddleAux (D F X : ℝ) : ℝ :=
  affineAux F X*saddleFactor D (inversePosition F X)/inversePosition F X
def saddleAux1 (D F X : ℝ) : ℝ :=
  (F*saddleFactor D (inversePosition F X)+D)/inversePosition F X
def saddleAux2 (D F X : ℝ) : ℝ :=
  D*(F-1)/(affineAux F X*inversePosition F X)
def saddleAux3 (D F X : ℝ) : ℝ :=
  -D*(F-1)*(F+1)/(affineAux F X^2*inversePosition F X)
def saddleHModel (D F L X : ℝ) : ℝ :=
  affineAux F X*(saddleFactor D (inversePosition F X))^2/(inversePosition F X)^3+
    2*(L-potential D F (inversePosition F X))*saddleAux2 D F X
def saddleH1 (D F L X : ℝ) : ℝ :=
  2*(D+F)*saddleFactor D (inversePosition F X)/(inversePosition F X)^2-
    (F+1)*saddleHModel D F L X/affineAux F X
def saddleH2 (D F L X : ℝ) : ℝ :=
  2*(D+F)*(D-(F+2)*saddleFactor D (inversePosition F X))/
      (affineAux F X*(inversePosition F X)^2)+
    (F+1)*(2*F+1)*saddleHModel D F L X/(affineAux F X)^2

theorem hasDerivAt_inversePosition_affine (F X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (inversePosition F) (inversePosition F X/affineAux F X) X := by
  rw [affineAux_eq_rpow F X hX]
  exact inversePosition_derivative_quotient F X hX

theorem analyticAt_saddleAux (D F X : ℝ) (hX : mechanicalDomain F X) :
    AnalyticAt ℝ (saddleAux D F) X := by
  have hw := analyticAt_inversePosition F X hX
  exact ((analyticAt_affineAux F X).mul
    ((analyticAt_const.mul hw).sub analyticAt_const)).div hw
      (inversePosition_pos F X hX).ne'

theorem hasDerivAt_saddleAux (D F X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (saddleAux D F) (saddleAux1 D F X) X := by
  have hw := (inversePosition_pos F X hX).ne'
  have hq : affineAux F X≠0 := hX.ne'
  have hdw := hasDerivAt_inversePosition_affine F X hX
  have hd := ((hasDerivAt_affineAux F X).mul
    ((hdw.const_mul (D+1)).sub_const D)).div hdw hw
  convert hd using 1
  dsimp only [saddleAux1,saddleFactor]
  field_simp
  ring

theorem hasDerivAt_saddleAux1 (D F X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (saddleAux1 D F) (saddleAux2 D F X) X := by
  have hw := (inversePosition_pos F X hX).ne'
  have hq : affineAux F X≠0 := hX.ne'
  have hdw := hasDerivAt_inversePosition_affine F X hX
  have hd := (((((hdw.const_mul (D+1)).sub_const D).const_mul F).add_const D)).div hdw hw
  convert hd using 1
  dsimp only [saddleAux2,saddleFactor]
  field_simp
  ring

theorem hasDerivAt_saddleAux2 (D F X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (saddleAux2 D F) (saddleAux3 D F X) X := by
  have hw := (inversePosition_pos F X hX).ne'
  have hq : affineAux F X≠0 := hX.ne'
  have hdw := hasDerivAt_inversePosition_affine F X hX
  have hd := (hasDerivAt_const X (D*(F-1))).div
    ((hasDerivAt_affineAux F X).mul hdw) (mul_ne_zero hq hw)
  convert hd using 1
  dsimp only [saddleAux3]
  field_simp
  ring

theorem second_deriv_saddleAux (D F X : ℝ) (hX : mechanicalDomain F X) :
    deriv (deriv (saddleAux D F)) X=saddleAux2 D F X := by
  have he : deriv (saddleAux D F) =ᶠ[𝓝 X] saddleAux1 D F := by
    filter_upwards [mechanicalDomain_eventually hX] with Z hZ
    exact (hasDerivAt_saddleAux D F Z hZ).deriv
  exact he.deriv_eq.trans (hasDerivAt_saddleAux1 D F X hX).deriv

theorem physical_force_eq_saddle_factor (D F X : ℝ) (hX : mechanicalDomain F X) :
    forceInPosition D F X=affineAux F X/(inversePosition F X)^2*
      (inversePosition F X-1)*saddleFactor D (inversePosition F X) := by
  rw [affineAux_eq_rpow F X hX]
  unfold forceInPosition force saddleFactor
  rw [Real.rpow_sub (inversePosition_pos F X hX),Real.rpow_two]

theorem actual_saddleH_eq_model (D F L X : ℝ) (hX : mechanicalDomain F X) :
    CriticalEnergy.coefficientH (fun Z => potential D F (inversePosition F Z))
      (saddleAux D F) L X=saddleHModel D F L X := by
  have hW1 : CriticalEnergy.jet (fun Z => potential D F (inversePosition F Z)) 1 X=
      forceInPosition D F X := (hasDerivAt_potentialInPosition D F X hX).deriv
  have hφ1 : CriticalEnergy.jet (saddleAux D F) 1 X=saddleAux1 D F X :=
    (hasDerivAt_saddleAux D F X hX).deriv
  have hφ2 : CriticalEnergy.jet (saddleAux D F) 2 X=saddleAux2 D F X :=
    second_deriv_saddleAux D F X hX
  rw [CriticalEnergy.coefficientH,physical_potential_second_jet D F X hX,hW1,hφ1,hφ2,
    physical_force_eq_saddle_factor D F X hX]
  dsimp only [saddleAux,saddleAux1,saddleHModel,CriticalEnergy.gap,
    forceSpatialSlope,forceSlopeNumerator,saddleFactor]
  field_simp
  ring

theorem hasDerivAt_saddleHModel (D F L X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (saddleHModel D F L) (saddleH1 D F L X) X := by
  have hw := (inversePosition_pos F X hX).ne'
  have hq : affineAux F X≠0 := hX.ne'
  have hdw := hasDerivAt_inversePosition_affine F X hX
  have hdS := (hdw.const_mul (D+1)).sub_const D
  have hdp := (hasDerivAt_affineAux F X).mul (hdS.pow 2)
  have hdV := (hasDerivAt_potentialInPosition D F X hX).const_sub L
  have hd := (hdp.div (hdw.pow 3) (pow_ne_zero 3 hw)).add
    ((hdV.const_mul 2).mul (hasDerivAt_saddleAux2 D F X hX))
  convert hd using 1
  rw [physical_force_eq_saddle_factor D F X hX]
  dsimp only [saddleH1,saddleHModel,saddleAux2,saddleAux3,saddleFactor]
  field_simp
  ring

theorem hasDerivAt_saddleH1 (D F L X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (saddleH1 D F L) (saddleH2 D F L X) X := by
  have hw := (inversePosition_pos F X hX).ne'
  have hq : affineAux F X≠0 := hX.ne'
  have hdw := hasDerivAt_inversePosition_affine F X hX
  have hdS := (hdw.const_mul (D+1)).sub_const D
  have hd := ((hdS.const_mul (2*(D+F))).div (hdw.pow 2) (pow_ne_zero 2 hw)).sub
    (((hasDerivAt_saddleHModel D F L X hX).const_mul (F+1)).div
      (hasDerivAt_affineAux F X) hq)
  convert hd using 1
  dsimp only [saddleH1,saddleH2,saddleFactor]
  field_simp
  ring

theorem hasDerivAt_actual_saddleH (D F L X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (CriticalEnergy.coefficientH
      (fun Z => potential D F (inversePosition F Z)) (saddleAux D F) L)
      (saddleH1 D F L X) X := by
  apply (hasDerivAt_saddleHModel D F L X hX).congr_of_eventuallyEq
  filter_upwards [mechanicalDomain_eventually hX] with Z hZ
  exact actual_saddleH_eq_model D F L Z hZ

theorem second_deriv_actual_saddleH (D F L X : ℝ) (hX : mechanicalDomain F X) :
    deriv (deriv (CriticalEnergy.coefficientH
      (fun Z => potential D F (inversePosition F Z)) (saddleAux D F) L)) X=
      saddleH2 D F L X := by
  have he : deriv (CriticalEnergy.coefficientH
      (fun Z => potential D F (inversePosition F Z)) (saddleAux D F) L) =ᶠ[𝓝 X]
      saddleH1 D F L := by
    filter_upwards [mechanicalDomain_eventually hX] with Z hZ
    exact (hasDerivAt_actual_saddleH D F L Z hZ).deriv
  exact he.deriv_eq.trans (hasDerivAt_saddleH1 D F L X hX).deriv

end LeanVerification.RegionalReal
