import LeanVerification.RegionalReal.AffineCurvature

/-! Parameter-uniform signs of the exact actual affine curvature. -/

noncomputable section
namespace LeanVerification.RegionalReal
open Loud
set_option maxHeartbeats 1600000

theorem mixtureSum_pos {D w : ℝ} (hD0 : -(1/2)≤D) (hD1 : D≤0) (hw : 0<w) :
    0<mixtureSum D w := by
  have hB : 0≤2*D+1 := by linarith
  have hm := mul_nonneg hB hw.le
  by_cases hD : D=0
  · simpa only [mixtureSum,hD,mul_zero,zero_add,one_mul,sub_zero] using hw
  · have hd : D<0 := lt_of_le_of_ne hD1 hD
    dsimp [mixtureSum]
    linarith

theorem affineCurvatureNumerator_zero (F w : ℝ) :
    affineCurvatureNumerator 0 F w=2*(1-F)*(4*F-1)*w^2 := by
  dsimp [affineCurvatureNumerator]
  ring

theorem affineCurvatureNumerator_negHalf (F w : ℝ) :
    affineCurvatureNumerator (-(1/2)) F w=4*(2*F-1)*(2-F) := by
  dsimp [affineCurvatureNumerator]
  ring

theorem affineCurvatureNumerator_signed_zero {F w : ℝ} (hw : 0<w)
    (hFq : F≠1/4) (hF1 : F≠1) :
    0<(2*(1-F)*(4*F-1))*affineCurvatureNumerator 0 F w := by
  have h1 : 1-F≠0 := sub_ne_zero.mpr (Ne.symm hF1)
  have h4 : 4*F-1≠0 := by intro h;apply hFq;linarith
  have hc : 2*(1-F)*(4*F-1)≠0 :=
    mul_ne_zero (mul_ne_zero (by norm_num) h1) h4
  rw [affineCurvatureNumerator_zero]
  convert mul_pos (sq_pos_of_ne_zero hc) (sq_pos_of_pos hw) using 1 <;> ring

theorem affineCurvatureNumerator_signed_negHalf {F w : ℝ}
    (hFh : F≠1/2) (hF2 : F≠2) :
    0<(4*(2*F-1)*(2-F))*affineCurvatureNumerator (-(1/2)) F w := by
  have h2 : 2-F≠0 := sub_ne_zero.mpr (Ne.symm hF2)
  have hh : 2*F-1≠0 := by intro h;apply hFh;linarith
  have hc : 4*(2*F-1)*(2-F)≠0 :=
    mul_ne_zero (mul_ne_zero (by norm_num) hh) h2
  rw [affineCurvatureNumerator_negHalf]
  simpa only [pow_two] using sq_pos_of_ne_zero hc

theorem affineCurvature_cross_pos {F : ℝ} (hF0 : 1/2≤F) (hF1 : F≤1) :
    0< -16*F^2+30*F-5 := by
  have hp := mul_nonneg (show 0≤F-1/2 by linarith) (show 0≤1-F by linarith)
  nlinarith

theorem affineCurvatureNumerator_pos_rectangle {D F w : ℝ}
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF0 : 1/2≤F) (hF1 : F≤1)
    (hiso : ¬IsKnownIsochronousParameter D F) (hw : 0<w) :
    0<affineCurvatureNumerator D F w := by
  by_cases hD : D=0
  · have hF : F<1 := lt_of_le_of_ne hF1 (by
      intro h;exact hiso (Or.inr (Or.inl ⟨hD,h⟩)))
    rw [hD,affineCurvatureNumerator_zero]
    exact mul_pos (mul_pos (mul_pos (by norm_num) (by linarith))
      (by linarith)) (sq_pos_of_pos hw)
  by_cases hDh : D=-(1/2)
  · have hF : 1/2<F := lt_of_le_of_ne hF0 (by
      intro h;exact hiso (Or.inr (Or.inr (Or.inl ⟨hDh,h.symm⟩))))
    rw [hDh,affineCurvatureNumerator_negHalf]
    exact mul_pos (mul_pos (by norm_num) (by linarith)) (by linarith)
  have hA : 0<(2*D+1)*w := mul_pos (by
    have hh := lt_of_le_of_ne hD0 (Ne.symm hDh)
    linarith) hw
  have hC : 0< -2*D := by have hh := lt_of_le_of_ne hD1 hD;linarith
  have hca : 0≤2*(1-F)*(4*F-1) :=
    mul_nonneg (mul_nonneg (by norm_num) (by linarith)) (by linarith)
  have hcc : 0≤4*(2*F-1)*(2-F) :=
    mul_nonneg (mul_nonneg (by norm_num) (by linarith)) (by linarith)
  have ha := mul_nonneg hca (sq_nonneg ((2*D+1)*w))
  have hb := mul_pos (mul_pos (affineCurvature_cross_pos hF0 hF1) hA) hC
  have hc := mul_nonneg hcc (sq_nonneg (-2*D))
  exact add_pos_of_pos_of_nonneg (add_pos_of_nonneg_of_pos ha hb) hc

theorem affineCurvatureNumerator_neg_lower_exterior {D F w : ℝ}
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF : F≤0) (hw : 0<w) :
    affineCurvatureNumerator D F w<0 := by
  by_cases hD : D=0
  · rw [hD,affineCurvatureNumerator_zero]
    exact mul_neg_of_neg_of_pos
      (mul_neg_of_pos_of_neg (mul_pos (by norm_num) (by linarith)) (by linarith))
      (sq_pos_of_pos hw)
  have hA : 0≤(2*D+1)*w := mul_nonneg (by linarith) hw.le
  have hC : 0< -2*D := by have hh := lt_of_le_of_ne hD1 hD;linarith
  have hca : 2*(1-F)*(4*F-1)<0 :=
    mul_neg_of_pos_of_neg (mul_pos (by norm_num) (by linarith)) (by linarith)
  have hcb : -16*F^2+30*F-5<0 := by nlinarith [sq_nonneg F]
  have hcc : 4*(2*F-1)*(2-F)<0 :=
    mul_neg_of_neg_of_pos (mul_neg_of_pos_of_neg (by norm_num) (by linarith)) (by linarith)
  have ha := mul_nonpos_of_nonpos_of_nonneg hca.le (sq_nonneg ((2*D+1)*w))
  have hb := mul_nonpos_of_nonpos_of_nonneg
    (mul_nonpos_of_nonpos_of_nonneg hcb.le hA) hC.le
  have hc := mul_neg_of_neg_of_pos hcc (sq_pos_of_pos hC)
  exact add_neg_of_nonpos_of_neg (add_nonpos ha hb) hc

theorem affineCurvatureNumerator_neg_upper_exterior {D F w : ℝ}
    (hD0 : -(1/2)≤D) (hD1 : D≤0) (hF : 2≤F)
    (hiso : ¬IsKnownIsochronousParameter D F) (hw : 0<w) :
    affineCurvatureNumerator D F w<0 := by
  by_cases hD : D=-(1/2)
  · have hF2 : 2<F := lt_of_le_of_ne hF (by
      intro h;exact hiso (Or.inr (Or.inr (Or.inr ⟨hD,h.symm⟩))))
    rw [hD,affineCurvatureNumerator_negHalf]
    exact mul_neg_of_pos_of_neg (mul_pos (by norm_num) (by linarith)) (by linarith)
  have hA : 0<(2*D+1)*w := mul_pos (by
    have hh := lt_of_le_of_ne hD0 (Ne.symm hD)
    linarith) hw
  have hC : 0≤ -2*D := by linarith
  have hca : 2*(1-F)*(4*F-1)<0 :=
    mul_neg_of_neg_of_pos (mul_neg_of_pos_of_neg (by norm_num) (by linarith)) (by linarith)
  have hcb : -16*F^2+30*F-5<0 := by
    have hp := mul_nonneg (show 0≤F by linarith) (show 0≤F-2 by linarith)
    nlinarith
  have hcc : 4*(2*F-1)*(2-F)≤0 :=
    mul_nonpos_of_nonneg_of_nonpos (mul_nonneg (by norm_num) (by linarith)) (by linarith)
  have ha := mul_neg_of_neg_of_pos hca (sq_pos_of_pos hA)
  have hb := mul_nonpos_of_nonpos_of_nonneg
    (mul_nonpos_of_nonpos_of_nonneg hcb.le hA.le) hC
  have hc := mul_nonpos_of_nonpos_of_nonneg hcc (sq_nonneg (-2*D))
  exact add_neg_of_neg_of_nonpos (add_neg_of_neg_of_nonpos ha hb) hc

end LeanVerification.RegionalReal
