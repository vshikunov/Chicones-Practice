import LeanVerification.UpperLeftCompletion.RayMomentNormalization
import Mathlib.MeasureTheory.Function.Jacobian

/-! The global ray-energy substitution, absolute integrability, and the
correct integrated normalization of each actual negative-ray moment. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 4000

def rayNormalizedEnergy (p A B C δ r : ℝ) : ℝ := rayEnergy p A B C r/δ

def rayNormalizedMoment (k : ℕ) (p A B C δ : ℝ) : ℝ :=
  ∫v in Ioi (0:ℝ),rayMomentKernel k (Real.pi*(1-p)) v*rayDensity p A B C (δ*v)

def densityOrderMoment (k : ℕ) (p l : ℝ) : ℝ :=
  rayNormalizedMoment k p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l)
    (lowAngleDeficit p l)

theorem hasDerivAt_rayNormalizedEnergy (p A B C δ : ℝ) {r : ℝ} (hr : 0<r) :
    HasDerivAt (rayNormalizedEnergy p A B C δ) (rayEnergySlope p A B C r/δ) r :=
  (hasDerivAt_rayEnergy p A B C hr).div_const δ

theorem strictMonoOn_rayNormalizedEnergy {p A B C δ : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hδ : 0<δ) :
    StrictMonoOn (rayNormalizedEnergy p A B C δ) (Ioi (0:ℝ)) := by
  intro r hr s hs hrs
  exact (div_lt_div_iff_of_pos_right hδ).mpr (strictMonoOn_rayEnergy hp hA hB.le hC hr hs hrs)

theorem rayNormalizedEnergy_range {p A B C δ : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hδ : 0<δ) :
    rayNormalizedEnergy p A B C δ '' Ioi (0:ℝ)=Ioi (0:ℝ) := by
  ext v
  constructor
  · rintro ⟨r,hr,rfl⟩
    exact div_pos (rayEnergy_pos hA hB.le hC hr) hδ
  · intro hv
    refine ⟨rayInverse p A B C (δ*v),rayInverse_pos hp hA hB hC (mul_pos hδ hv),?_⟩
    rw [rayNormalizedEnergy,rayEnergy_inverse hp hA hB hC (mul_pos hδ hv)]
    exact mul_div_cancel_left₀ v hδ.ne'

theorem rayMoment_density_jacobian (k : ℕ) {p A B C δ r : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hδ : 0<δ) (hr : 0<r) :
    |rayEnergySlope p A B C r/δ| •
      (rayMomentKernel k (Real.pi*(1-p)) (rayNormalizedEnergy p A B C δ r)*
        rayDensity p A B C (δ*rayNormalizedEnergy p A B C δ r))=
      r^(p/2)/δ*rayMomentKernel k (Real.pi*(1-p)) (rayNormalizedEnergy p A B C δ r) := by
  have hH : rayEulerPolynomial p A B C r≠0 := (rayEulerPolynomial_pos hp hA hB.le hC hr).ne'
  have hu : δ*rayNormalizedEnergy p A B C δ r=rayEnergy p A B C r := by
    dsimp only [rayNormalizedEnergy]
    exact mul_div_cancel₀ _ hδ.ne'
  rw [abs_of_pos (div_pos (rayEnergySlope_pos hp hA hB.le hC hr) hδ),hu]
  dsimp only [rayDensity]
  rw [rayInverse_energy hp hA hB hC hr]
  have hpow : r^(p-1)*r^(1-p/2)=r^(p/2) := by
    rw [←Real.rpow_add hr]
    congr 1
    ring
  dsimp only [rayEnergySlope,rayDensityParam,smul_eq_mul]
  calc
    _ = (r^(p-1)*r^(1-p/2)/δ)*
        rayMomentKernel k (Real.pi*(1-p)) (rayNormalizedEnergy p A B C δ r) := by
          field_simp [hH,hδ.ne']
          <;> ring
    _ = _ := by rw [hpow]

theorem rayMoment_deficit_factor (k : ℕ) {δ : ℝ} (hδ : 0<δ) :
    δ^(1/2-(k:ℝ))=δ*δ^(-(k:ℝ)-1/2) := by
  calc
    _ = δ^(1+(-(k:ℝ)-1/2)) := by congr 1;ring
    _ = _ := by rw [Real.rpow_add hδ,Real.rpow_one]

theorem negativeRayJet_normalized_jacobian (k : ℕ) {p A B C δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0≤A) (hB : 0<B) (hC : 0<C)
    (hδ : 0<δ) (hr : 0<r) :
    (negativeRayCoefficient k*δ^(1/2-(k:ℝ)))*
      (|rayEnergySlope p A B C r/δ| •
        (rayMomentKernel k (Real.pi*(1-p)) (rayNormalizedEnergy p A B C δ r)*
          rayDensity p A B C (δ*rayNormalizedEnergy p A B C δ r)))=
      (-1:ℝ)^k*(negativeRayJet k p A B C δ r).re := by
  rw [rayMoment_density_jacobian k hp hA hB hC hδ hr,
    negativeRayJet_signed_normalized k A B C hp hpu hδ hr,rayMoment_deficit_factor k hδ]
  dsimp only [rayNormalizedEnergy]
  field_simp
  <;> ring

/-- Every positive-order normalized moment is an absolutely convergent
integral. This follows from the actual ray-jet estimates under the proved
global change of variables. -/
theorem integrable_rayNormalizedMoment (k : ℕ) (hk : 0<k) {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0<A) (hB : 0<B) (hC : 0<C) (hδ : 0<δ) :
    IntegrableOn (fun v => rayMomentKernel k (Real.pi*(1-p)) v*rayDensity p A B C (δ*v))
      (Ioi (0:ℝ)) := by
  have hj : IntegrableOn (fun r => (negativeRayJet k p A B C δ r).re) (Ioi (0:ℝ)) := by
    cases k with
    | zero => omega
    | succ n => exact (integrableOn_negativeRayJet n hp hpu hA hB.le hC.le hδ).re
  have hjs : IntegrableOn (fun r => (-1:ℝ)^k*(negativeRayJet k p A B C δ r).re)
      (Ioi (0:ℝ)) := hj.const_mul ((-1:ℝ)^k)
  have hpre : IntegrableOn (fun r => (negativeRayCoefficient k*δ^(1/2-(k:ℝ)))*
      (|rayEnergySlope p A B C r/δ| •
        (rayMomentKernel k (Real.pi*(1-p)) (rayNormalizedEnergy p A B C δ r)*
          rayDensity p A B C (δ*rayNormalizedEnergy p A B C δ r)))) (Ioi (0:ℝ)) :=
    hjs.congr_fun
      (fun r hr => (negativeRayJet_normalized_jacobian k hp hpu hA.le hB hC hδ hr).symm)
      measurableSet_Ioi
  have hconst : negativeRayCoefficient k*δ^(1/2-(k:ℝ))≠0 :=
    (mul_pos (negativeRayCoefficient_pos k) (Real.rpow_pos_of_pos hδ _)).ne'
  have hi : IntegrableOn (fun r => |rayEnergySlope p A B C r/δ| •
      (rayMomentKernel k (Real.pi*(1-p)) (rayNormalizedEnergy p A B C δ r)*
        rayDensity p A B C (δ*rayNormalizedEnergy p A B C δ r))) (Ioi (0:ℝ)) :=
    (integrable_const_mul_iff (isUnit_iff_ne_zero.mpr hconst) _).mp hpre
  have hdf : ∀r∈Ioi (0:ℝ),HasDerivWithinAt (rayNormalizedEnergy p A B C δ)
      (rayEnergySlope p A B C r/δ) (Ioi (0:ℝ)) r :=
    fun r hr => (hasDerivAt_rayNormalizedEnergy p A B C δ hr).hasDerivWithinAt
  have himg := (integrableOn_image_iff_integrableOn_abs_deriv_smul measurableSet_Ioi hdf
    (strictMonoOn_rayNormalizedEnergy hp hA.le hB hC hδ).injOn
    (fun v => rayMomentKernel k (Real.pi*(1-p)) v*rayDensity p A B C (δ*v))).mpr hi
  rwa [rayNormalizedEnergy_range hp hA.le hB hC hδ] at himg

/-- Integrated normalization includes the Jacobian factor δ. -/
theorem negativeRayJet_integral_normalized (k : ℕ) {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hδ : 0<δ) :
    (-1:ℝ)^k*(∫r in Ioi (0:ℝ),(negativeRayJet k p A B C δ r).re)=
      negativeRayCoefficient k*δ^(1/2-(k:ℝ))*rayNormalizedMoment k p A B C δ := by
  have hdf : ∀r∈Ioi (0:ℝ),HasDerivWithinAt (rayNormalizedEnergy p A B C δ)
      (rayEnergySlope p A B C r/δ) (Ioi (0:ℝ)) r :=
    fun r hr => (hasDerivAt_rayNormalizedEnergy p A B C δ hr).hasDerivWithinAt
  have he := integral_image_eq_integral_abs_deriv_smul measurableSet_Ioi hdf
    (strictMonoOn_rayNormalizedEnergy hp hA hB hC hδ).injOn
    (fun v => rayMomentKernel k (Real.pi*(1-p)) v*rayDensity p A B C (δ*v))
  rw [rayNormalizedEnergy_range hp hA hB hC hδ] at he
  rw [rayNormalizedMoment,he,←integral_const_mul,←integral_const_mul]
  apply setIntegral_congr_fun measurableSet_Ioi
  intro r hr
  exact (negativeRayJet_normalized_jacobian k hp hpu hA hB hC hδ hr).symm

theorem negativeRayJetIntegral_normalized (n : ℕ) {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hδ : 0<δ) :
    (-1:ℝ)^(n+1)*negativeRayJetIntegral n p A B C δ=
      negativeRayCoefficient (n+1)*δ^(-(n:ℝ)-1/2)*rayNormalizedMoment (n+1) p A B C δ := by
  have he := negativeRayJet_integral_normalized (n+1) hp hpu hA hB hC hδ
  have hex : 1/2-((n+1:ℕ):ℝ)= -(n:ℝ)-1/2 := by push_cast;ring
  simpa only [negativeRayJetIntegral,hex] using he

theorem densityOrderMoment_eq (k : ℕ) (p l : ℝ) :
    densityOrderMoment k p l=
      ∫v in Ioi (0:ℝ),rayMomentKernel k (Real.pi*(1-p)) v*densityOrderDensity p l v := rfl

theorem integrable_densityOrderMoment (k : ℕ) (hk : 0<k) {p l : ℝ}
    (hp : 0<p) (hpu : p<1) (hl : 0<l) :
    IntegrableOn (fun v => rayMomentKernel k (Real.pi*(1-p)) v*densityOrderDensity p l v)
      (Ioi (0:ℝ)) := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hAp : 0<lowAngleA p l := by dsimp only [lowAngleA];positivity
  exact integrable_rayNormalizedMoment k hk hp hpu hAp hB hC (lowAngleDeficit_pos hp hl.le)

theorem densityOrderMoment_actual_normalization (n : ℕ) {p l : ℝ}
    (hp : 0<p) (hpu : p<1) (hl : 0<l) :
    (-1:ℝ)^(n+1)*negativeRayJetIntegral n p (lowAngleA p l) (lowAngleB p l)
      (lowAngleC p l) (lowAngleDeficit p l)=
      negativeRayCoefficient (n+1)*(lowAngleDeficit p l)^(-(n:ℝ)-1/2)*
        densityOrderMoment (n+1) p l := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  exact negativeRayJetIntegral_normalized n hp hpu hA hB hC (lowAngleDeficit_pos hp hl.le)

end LeanVerification.UpperLeftCompletion
