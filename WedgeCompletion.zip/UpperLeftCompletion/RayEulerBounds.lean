import LeanVerification.UpperLeftCompletion.RaySpatialDerivative
import Mathlib.MeasureTheory.Integral.IntegralEqImproper

/-! Endpoint decay and absolute convergence for the actual Euler primitive
on the negative ray.  These estimates justify its improper integration by
parts at both ends. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 1200000

theorem rayPolynomial_div_Euler_bounds {p A B C r : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0≤B) (hC : 0<C) (hr : 0<r) :
    0≤rayPolynomial A B C r/rayEulerPolynomial p A B C r ∧
      rayPolynomial A B C r/rayEulerPolynomial p A B C r≤1/p := by
  have hP := rayPolynomial_pos hA hB hC hr
  have hH := rayEulerPolynomial_pos hp hA hB hC hr
  refine ⟨div_nonneg hP.le hH.le, (div_le_div_iff₀ hH hp).2 ?_⟩
  dsimp only [rayPolynomial,rayEulerPolynomial]
  nlinarith [mul_nonneg hA (sq_nonneg r),mul_nonneg hB hr.le]

theorem rayEulerSlope_ratio_bounds {p A B C r : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0≤B) (hC : 0<C) (hr : 0<r) :
    0≤r*rayEulerSlope p A B r/rayEulerPolynomial p A B C r ∧
      r*rayEulerSlope p A B r/rayEulerPolynomial p A B C r≤2 := by
  have hH := rayEulerPolynomial_pos hp hA hB hC hr
  have hS : 0≤rayEulerSlope p A B r := by dsimp only [rayEulerSlope]; positivity
  refine ⟨div_nonneg (mul_nonneg hr.le hS) hH.le,(div_le_iff₀ hH).2 ?_⟩
  dsimp only [rayEulerSlope,rayEulerPolynomial]
  nlinarith [mul_nonneg (mul_nonneg (by linarith : 0≤p+1) hB) hr.le,
    mul_pos hp hC]

theorem rayElasticity_abs_bound {p A B C r : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0≤A) (hB : 0≤B) (hC : 0<C) (hr : 0<r) :
    |rayElasticity p A B C r|≤2/p := by
  have hH := rayEulerPolynomial_pos hp hA hB hC hr
  have hP := rayPolynomial_div_Euler_bounds hp hA hB hC hr
  have hS := rayEulerSlope_ratio_bounds hp hA hB hC hr
  have he : rayElasticity p A B C r =
      (rayPolynomial A B C r/rayEulerPolynomial p A B C r)*
        ((1-p/2)-r*rayEulerSlope p A B r/rayEulerPolynomial p A B C r) := by
    unfold rayElasticity
    field_simp [hH.ne']
    left
    ring
  rw [he,abs_mul,abs_of_nonneg hP.1]
  have hinner : |(1-p/2)-r*rayEulerSlope p A B r/rayEulerPolynomial p A B C r|≤2 :=
    abs_le.mpr ⟨by linarith,by linarith⟩
  calc
    _ ≤ (1/p)*2 := mul_le_mul hP.2 hinner (abs_nonneg _) (by positivity)
    _ = 2/p := by ring

theorem rayEulerPrimitiveFactor_bounds {p A B C r : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0≤B) (hC : 0<C) (hr : 0<r) :
    0≤rayEulerPrimitiveFactor p A B C r ∧ rayEulerPrimitiveFactor p A B C r≤r/p := by
  have hb := rayPolynomial_div_Euler_bounds hp hA hB hC hr
  unfold rayEulerPrimitiveFactor
  rw [mul_div_assoc]
  exact ⟨mul_nonneg hr.le hb.1,by simpa using mul_le_mul_of_nonneg_left hb.2 hr.le⟩

def rayEulerJetPrimitive (n : ℕ) (p A B C δ r : ℝ) : ℝ :=
  rayEulerPrimitiveFactor p A B C r*(negativeRayJet (n+1) p A B C δ r).re

theorem rayEulerJetPrimitive_zero (n : ℕ) (p A B C δ : ℝ) :
    rayEulerJetPrimitive n p A B C δ 0=0 := by
  simp [rayEulerJetPrimitive,rayEulerPrimitiveFactor]

theorem rayEulerJetPrimitive_bound (n : ℕ) {p A B C δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0<A) (hB : 0≤B) (hC : 0<C)
    (hδ : 0<δ) (hr : 0<r) :
    ‖rayEulerJetPrimitive n p A B C δ r‖≤
      (2*negativeRayBoundConstant n p A δ/p)*r/(1+r^2) := by
  have hb := rayEulerPrimitiveFactor_bounds hp hA.le hB hC hr
  have hj := negativeRayJet_uniform_majorant n hp hpu hA hB hC.le hδ le_rfl hr
  rw [rayEulerJetPrimitive,norm_mul,Real.norm_of_nonneg hb.1]
  calc
    _ ≤ (r/p)*negativeRayMajorant n p A δ r :=
      mul_le_mul hb.2 ((Complex.abs_re_le_norm _).trans hj) (abs_nonneg _) (by positivity)
    _ = _ := by unfold negativeRayMajorant; ring

theorem rayEulerJetPrimitive_small_bound (n : ℕ) {p A B C δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0<A) (hB : 0≤B) (hC : 0<C)
    (hδ : 0<δ) (hr : 0≤r) :
    ‖rayEulerJetPrimitive n p A B C δ r‖≤
      (2*negativeRayBoundConstant n p A δ/p)*r := by
  rcases hr.eq_or_lt with rfl|hr
  · simp [rayEulerJetPrimitive_zero]
  · apply (rayEulerJetPrimitive_bound n hp hpu hA hB hC hδ hr).trans
    have hk := negativeRayBoundConstant_pos n hp hpu hA hδ
    apply div_le_self (by positivity)
    nlinarith [sq_nonneg r]

theorem rayEulerJetPrimitive_large_bound (n : ℕ) {p A B C δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0<A) (hB : 0≤B) (hC : 0<C)
    (hδ : 0<δ) (hr : 0<r) :
    ‖rayEulerJetPrimitive n p A B C δ r‖≤
      (2*negativeRayBoundConstant n p A δ/p)/r := by
  apply (rayEulerJetPrimitive_bound n hp hpu hA hB hC hδ hr).trans
  apply (div_le_div_iff₀ (by positivity : 0<1+r^2) hr).2
  have hk := (div_pos (mul_pos (by norm_num : 0<(2:ℝ))
    (negativeRayBoundConstant_pos n hp hpu hA hδ)) hp).le
  nlinarith

theorem rayEulerJetPrimitive_continuous_zero (n : ℕ) {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0<A) (hB : 0≤B) (hC : 0<C) (hδ : 0<δ) :
    ContinuousWithinAt (rayEulerJetPrimitive n p A B C δ) (Ici 0) 0 := by
  change Tendsto _ (𝓝[Ici 0] 0) (𝓝 _)
  rw [rayEulerJetPrimitive_zero]
  apply squeeze_zero_norm' _ (by
    simpa only [mul_zero] using
      ((tendsto_id : Tendsto (fun r : ℝ => r) (𝓝 0) (𝓝 0)).mono_left
        nhdsWithin_le_nhds).const_mul
        (2*negativeRayBoundConstant n p A δ/p))
  filter_upwards [self_mem_nhdsWithin] with r hr
  exact rayEulerJetPrimitive_small_bound n hp hpu hA hB hC hδ hr

theorem rayEulerJetPrimitive_tendsto_top (n : ℕ) {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0<A) (hB : 0≤B) (hC : 0<C) (hδ : 0<δ) :
    Tendsto (rayEulerJetPrimitive n p A B C δ) atTop (𝓝 0) := by
  apply squeeze_zero_norm' _ (by
    simpa only [div_eq_mul_inv,mul_zero] using
      tendsto_inv_atTop_zero.const_mul (2*negativeRayBoundConstant n p A δ/p))
  filter_upwards [eventually_gt_atTop 0] with r hr
  exact rayEulerJetPrimitive_large_bound n hp hpu hA hB hC hδ hr

theorem integrable_rayElasticity_jet (n : ℕ) {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0<A) (hB : 0≤B) (hC : 0<C) (hδ : 0<δ) :
    IntegrableOn (fun r => rayElasticity p A B C r*
      (negativeRayJet (n+1) p A B C δ r).re) (Ioi 0) := by
  apply (integrableOn_negativeRayJet n hp hpu hA hB hC.le hδ).re.bdd_mul'
  · apply ContinuousOn.aestronglyMeasurable _ measurableSet_Ioi
    intro r hr
    exact (hasDerivAt_rayElasticity p A B C r
      (rayEulerPolynomial_pos hp hA.le hB hC hr).ne').continuousAt.continuousWithinAt
  · filter_upwards [ae_restrict_mem measurableSet_Ioi] with r hr
    exact rayElasticity_abs_bound hp hpu hA.le hB hC hr

end LeanVerification.UpperLeftCompletion
