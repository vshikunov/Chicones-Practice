import LeanVerification.UpperLeftCompletion.LowAngleBoundsPreimage

/-! The principal complex ray kernels and their exact single sign change.
The phase is computed from the actual principal square root. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 4000

def rayMomentUnit (θ : ℝ) : ℂ := Complex.exp ((θ:ℂ)*Complex.I)

def rayMomentKernel (k : ℕ) (θ v : ℝ) : ℝ :=
  ((rayMomentUnit θ)^k/(principalSquareRoot ((v:ℂ)+rayMomentUnit θ))^(2*k+1)).re

def rayMomentPhase (k : ℕ) (θ v : ℝ) : ℝ :=
  (k:ℝ)*θ-((k:ℝ)+1/2)*((v:ℂ)+rayMomentUnit θ).arg

theorem rayMomentUnit_re (θ : ℝ) : (rayMomentUnit θ).re=Real.cos θ := by
  simp [rayMomentUnit,Complex.exp_re]

theorem rayMomentUnit_im (θ : ℝ) : (rayMomentUnit θ).im=Real.sin θ := by
  simp [rayMomentUnit,Complex.exp_im]

theorem rayMomentUnit_arg {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) :
    (rayMomentUnit θ).arg=θ := by
  have he := Complex.log_exp
    (show -Real.pi<((θ:ℂ)*Complex.I).im by simpa using (by linarith [Real.pi_pos] : -Real.pi<θ))
    (show ((θ:ℂ)*Complex.I).im≤Real.pi by simpa using hθu.le)
  simpa only [rayMomentUnit,Complex.log_im,Complex.mul_im,Complex.ofReal_re,
    Complex.I_im,mul_one,Complex.ofReal_im,Complex.I_re,mul_zero,add_zero] using congrArg Complex.im he

theorem rayMoment_shift_im_pos {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) (v : ℝ) :
    0<((v:ℂ)+rayMomentUnit θ).im := by
  simpa only [Complex.add_im,Complex.ofReal_im,zero_add,rayMomentUnit_im] using
    Real.sin_pos_of_pos_of_lt_pi hθ hθu

theorem rayMoment_shift_ne_zero {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) (v : ℝ) :
    (v:ℂ)+rayMomentUnit θ≠0 := by
  intro he
  have hi := rayMoment_shift_im_pos hθ hθu v
  rw [he,Complex.zero_im] at hi
  exact hi.false

theorem rayMoment_shift_mem_slit {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) (v : ℝ) :
    (v:ℂ)+rayMomentUnit θ∈Complex.slitPlane :=
  Or.inr (rayMoment_shift_im_pos hθ hθu v).ne'

theorem hasDerivAt_rayMoment_arg {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) (v : ℝ) :
    HasDerivAt (fun x : ℝ => ((x:ℂ)+rayMomentUnit θ).arg)
      (-Real.sin θ/Complex.normSq ((v:ℂ)+rayMomentUnit θ)) v := by
  have hz : HasDerivAt (fun x : ℝ => (x:ℂ)+rayMomentUnit θ) 1 v :=
    Complex.ofRealCLM.hasDerivAt.add_const _
  have hl := hz.clog_real (rayMoment_shift_mem_slit hθ hθu v)
  have hi := Complex.imCLM.hasFDerivAt.comp_hasDerivAt v hl
  simpa only [Function.comp_def,Complex.imCLM_apply,Complex.log_im,one_div,Complex.inv_im,Complex.add_im,
    Complex.ofReal_im,zero_add,rayMomentUnit_im] using hi

theorem rayMoment_arg_strictAnti {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) :
    StrictAnti (fun v : ℝ => ((v:ℂ)+rayMomentUnit θ).arg) := by
  have hs : StrictAntiOn (fun v : ℝ => ((v:ℂ)+rayMomentUnit θ).arg) univ := by
    apply strictAntiOn_of_deriv_neg (convex_univ : Convex ℝ (univ : Set ℝ))
    · intro v hv
      exact (hasDerivAt_rayMoment_arg hθ hθu v).continuousAt.continuousWithinAt
    · intro v hv
      rw [(hasDerivAt_rayMoment_arg hθ hθu v).deriv]
      exact div_neg_of_neg_of_pos
        (neg_neg_of_pos (Real.sin_pos_of_pos_of_lt_pi hθ hθu))
        (Complex.normSq_pos.mpr (rayMoment_shift_ne_zero hθ hθu v))
  exact fun _ _ h => hs (mem_univ _) (mem_univ _) h

theorem rayMoment_arg_pos {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) (v : ℝ) :
    0<((v:ℂ)+rayMomentUnit θ).arg := by
  have hi := rayMoment_shift_im_pos hθ hθu v
  have ha : 0≤((v:ℂ)+rayMomentUnit θ).arg := Complex.arg_nonneg_iff.mpr hi.le
  apply lt_of_le_of_ne ha
  intro he
  have hz := (Complex.arg_eq_zero_iff.mp he.symm).2
  exact hi.ne' hz

theorem rayMoment_arg_lt_theta {θ v : ℝ}
    (hθ : 0<θ) (hθu : θ<Real.pi) (hv : 0<v) :
    ((v:ℂ)+rayMomentUnit θ).arg<θ := by
  have hs := rayMoment_arg_strictAnti hθ hθu hv
  simpa only [Complex.ofReal_zero,zero_add,rayMomentUnit_arg hθ hθu] using hs

theorem rayMoment_arg_tendsto_zero {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) :
    Tendsto (fun v : ℝ => ((v:ℂ)+rayMomentUnit θ).arg) atTop (𝓝 0) := by
  have hinv : Tendsto (fun v : ℝ => ((v⁻¹:ℝ):ℂ)) atTop (𝓝 (0:ℂ)) := by
    exact_mod_cast Complex.continuous_ofReal.continuousAt.tendsto.comp tendsto_inv_atTop_zero
  have hn : Tendsto (fun v : ℝ => 1+rayMomentUnit θ*(v⁻¹:ℝ)) atTop (𝓝 (1:ℂ)) := by
    simpa only [mul_zero,add_zero] using tendsto_const_nhds.add (tendsto_const_nhds.mul hinv)
  have ha := (Complex.continuousAt_arg (Or.inl (by norm_num : 0<(1:ℂ).re))).tendsto.comp hn
  simp only [Complex.arg_one] at ha
  apply ha.congr'
  filter_upwards [eventually_gt_atTop (0:ℝ)] with v hv
  have hvn : (v:ℂ)≠0 := Complex.ofReal_ne_zero.mpr hv.ne'
  have he : (v:ℂ)+rayMomentUnit θ=(v:ℂ)*(1+rayMomentUnit θ*(v⁻¹:ℝ)) := by
    push_cast
    field_simp [hvn]
    <;> ring
  rw [he,Complex.arg_real_mul _ hv]
  rfl

theorem rayMomentKernel_phase_identity (k : ℕ) (θ v : ℝ) :
    rayMomentKernel k θ v=
      Real.exp (-((k:ℝ)+1/2)*Real.log ‖(v:ℂ)+rayMomentUnit θ‖)*
        Real.cos (rayMomentPhase k θ v) := by
  dsimp only [rayMomentKernel,rayMomentUnit,principalSquareRoot]
  rw [←Complex.exp_nat_mul,←Complex.exp_nat_mul,←Complex.exp_sub,Complex.exp_re]
  congr 1
  · congr 1
    simp only [Complex.sub_re,Complex.mul_re,Complex.natCast_re,Complex.natCast_im,
      Complex.ofReal_re,Complex.ofReal_im,Complex.I_re,Complex.I_im,mul_zero,zero_mul,
      sub_zero,Complex.div_ofNat_re,Complex.log_re]
    push_cast
    ring
  · congr 1
    simp only [rayMomentPhase,rayMomentUnit,Complex.sub_im,Complex.mul_im,
      Complex.natCast_re,Complex.natCast_im,Complex.ofReal_re,Complex.ofReal_im,
      Complex.I_re,Complex.I_im,mul_zero,zero_mul,mul_one,add_zero,
      Complex.div_ofNat_im,Complex.log_im]
    push_cast
    ring

theorem rayMomentPhase_strictMono {k : ℕ} {θ : ℝ}
    (hθ : 0<θ) (hθu : θ<Real.pi) : StrictMono (rayMomentPhase k θ) := by
  intro u v huv
  have hs := rayMoment_arg_strictAnti hθ hθu huv
  have hk : 0<(k:ℝ)+1/2 := by positivity
  dsimp only [rayMomentPhase]
  exact sub_lt_sub_left (mul_lt_mul_of_pos_left hs hk) _

theorem continuous_rayMomentPhase {k : ℕ} {θ : ℝ}
    (hθ : 0<θ) (hθu : θ<Real.pi) : Continuous (rayMomentPhase k θ) := by
  apply continuous_iff_continuousAt.mpr
  intro v
  exact continuousAt_const.sub (continuousAt_const.mul
    (hasDerivAt_rayMoment_arg hθ hθu v).continuousAt)

theorem rayMomentPhase_zero {k : ℕ} {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) :
    rayMomentPhase k θ 0= -θ/2 := by
  simp only [rayMomentPhase,Complex.ofReal_zero,zero_add,rayMomentUnit_arg hθ hθu]
  ring

theorem rayMomentPhase_tendsto {k : ℕ} {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) :
    Tendsto (rayMomentPhase k θ) atTop (𝓝 ((k:ℝ)*θ)) := by
  simpa only [mul_zero,sub_zero] using
    tendsto_const_nhds.sub (tendsto_const_nhds.mul (rayMoment_arg_tendsto_zero hθ hθu))

theorem rayMomentPhase_bounds {k : ℕ} {θ v : ℝ}
    (hθ : 0<θ) (hθu : θ<Real.pi) (hv : 0<v) :
    -θ/2<rayMomentPhase k θ v ∧ rayMomentPhase k θ v<(k:ℝ)*θ := by
  constructor
  · have h := rayMomentPhase_strictMono (k:=k) hθ hθu hv
    rwa [rayMomentPhase_zero hθ hθu] at h
  · dsimp only [rayMomentPhase]
    exact sub_lt_self _ (mul_pos (by positivity) (rayMoment_arg_pos hθ hθu v))

/-- Complete positive-then-negative sign pattern of the actual principal
kernel, including the case where the limiting phase is exactly 3π/2. -/
theorem rayMomentKernel_single_crossing {k : ℕ} {θ : ℝ}
    (hθ : 0<θ) (hθu : θ<Real.pi)
    (hklo : Real.pi/2<(k:ℝ)*θ) (hkhi : (k:ℝ)*θ≤3*Real.pi/2) :
    ∃ v₀ : ℝ,0<v₀ ∧ rayMomentPhase k θ v₀=Real.pi/2 ∧
      rayMomentKernel k θ v₀=0 ∧
      (∀v,0<v → v<v₀ → 0<rayMomentKernel k θ v) ∧
      (∀v,v₀<v → rayMomentKernel k θ v<0) := by
  have he : ∀ᶠ v in atTop,Real.pi/2<rayMomentPhase k θ v :=
    (rayMomentPhase_tendsto hθ hθu).eventually (Ioi_mem_nhds hklo)
  obtain ⟨R,hR,hPR⟩ := (eventually_gt_atTop (0:ℝ) |>.and he).exists
  have hP0 : rayMomentPhase k θ 0<Real.pi/2 := by
    rw [rayMomentPhase_zero hθ hθu]
    linarith [Real.pi_pos]
  obtain ⟨v₀,hv₀,hphase⟩ := intermediate_value_Ioo hR.le
    (continuous_rayMomentPhase hθ hθu).continuousOn ⟨hP0,hPR⟩
  refine ⟨v₀,hv₀.1,hphase,?_,?_,?_⟩
  · rw [rayMomentKernel_phase_identity,hphase,Real.cos_pi_div_two,mul_zero]
  · intro v hv hvu
    rw [rayMomentKernel_phase_identity]
    apply mul_pos (Real.exp_pos _)
    apply Real.cos_pos_of_mem_Ioo
    constructor
    · have hb := (rayMomentPhase_bounds (k:=k) hθ hθu hv).1
      linarith
    · have hs := rayMomentPhase_strictMono (k:=k) hθ hθu hvu
      rwa [hphase] at hs
  · intro v hv
    rw [rayMomentKernel_phase_identity]
    apply mul_neg_of_pos_of_neg (Real.exp_pos _)
    apply Real.cos_neg_of_pi_div_two_lt_of_lt
    · have hs := rayMomentPhase_strictMono (k:=k) hθ hθu hv
      rwa [hphase] at hs
    · have hb := (rayMomentPhase_bounds (k:=k) hθ hθu (hv₀.1.trans hv)).2
      linarith only [hb,hkhi]

theorem continuous_rayMomentKernel {k : ℕ} {θ : ℝ}
    (hθ : 0<θ) (hθu : θ<Real.pi) : Continuous (rayMomentKernel k θ) := by
  apply continuous_iff_continuousAt.mpr
  intro v
  have hz : ContinuousAt (fun x : ℝ => (x:ℂ)+rayMomentUnit θ) v :=
    Complex.continuous_ofReal.continuousAt.add continuousAt_const
  have hl : ContinuousAt (fun x : ℝ => Complex.log ((x:ℂ)+rayMomentUnit θ)) v :=
    (Complex.hasDerivAt_log (rayMoment_shift_mem_slit hθ hθu v)).continuousAt.comp_of_eq hz rfl
  have hroot : ContinuousAt (fun x : ℝ => principalSquareRoot ((x:ℂ)+rayMomentUnit θ)) v :=
    Complex.continuous_exp.continuousAt.comp (hl.div_const 2)
  have hdiv : ContinuousAt (fun x : ℝ => (rayMomentUnit θ)^k/
      (principalSquareRoot ((x:ℂ)+rayMomentUnit θ))^(2*k+1)) v :=
    continuousAt_const.div (hroot.pow (2*k+1))
    (pow_ne_zero _ (Complex.exp_ne_zero _))
  exact Complex.continuous_re.continuousAt.comp hdiv

theorem rayMoment_sine_relation {θ : ℝ} (hθ : 0<θ) (hθu : θ<Real.pi) (v : ℝ) :
    v*Real.sin (((v:ℂ)+rayMomentUnit θ).arg)=
      Real.sin (θ-((v:ℂ)+rayMomentUnit θ).arg) := by
  let z := (v:ℂ)+rayMomentUnit θ
  have hc := Complex.norm_mul_cos_arg z
  have hs := Complex.norm_mul_sin_arg z
  have hzr : z.re=v+Real.cos θ := by simp only [z,Complex.add_re,Complex.ofReal_re,rayMomentUnit_re]
  have hzi : z.im=Real.sin θ := by simp only [z,Complex.add_im,Complex.ofReal_im,zero_add,rayMomentUnit_im]
  rw [hzr] at hc
  rw [hzi] at hs
  change v*Real.sin z.arg=Real.sin (θ-z.arg)
  rw [Real.sin_sub]
  have hc' := congrArg (fun t : ℝ => t*Real.sin z.arg) hc
  have hs' := congrArg (fun t : ℝ => t*Real.cos z.arg) hs
  dsimp only at hc' hs'
  nlinarith only [hc',hs']

theorem rayMomentPhase_one_crossing_eq {p v : ℝ}
    (hp : 0<p) (hpu : p<1/2)
    (hphase : rayMomentPhase 1 (Real.pi*(1-p)) v=Real.pi/2) :
    v=lowAngleCrossing p := by
  have hθ : 0<Real.pi*(1-p) := mul_pos Real.pi_pos (by linarith)
  have hθu : Real.pi*(1-p)<Real.pi := by nlinarith [mul_pos Real.pi_pos hp]
  have ha : ((v:ℂ)+rayMomentUnit (Real.pi*(1-p))).arg=2*lowAngleTheta p := by
    dsimp only [rayMomentPhase] at hphase
    norm_num at hphase
    dsimp only [lowAngleTheta]
    linarith only [hphase]
  have hrel := rayMoment_sine_relation hθ hθu v
  rw [ha] at hrel
  have hang : Real.pi*(1-p)-2*lowAngleTheta p=Real.pi/2+lowAngleTheta p := by
    dsimp only [lowAngleTheta]
    ring
  rw [hang,Real.sin_add,Real.sin_pi_div_two,Real.cos_pi_div_two,
    one_mul,zero_mul,add_zero,Real.sin_two_mul] at hrel
  have hsin := lowAngle_sin_pos hp.le hpu
  have hcos : 0<Real.cos (lowAngleTheta p) := by
    apply Real.cos_pos_of_mem_Ioo
    dsimp only [lowAngleTheta]
    constructor <;> nlinarith [Real.pi_pos,mul_pos Real.pi_pos hp,
      mul_pos Real.pi_pos (show 0<1/2-p by linarith)]
  change v=1/(2*Real.sin (lowAngleTheta p))
  apply (eq_div_iff (mul_pos (by norm_num : (0:ℝ)<2) hsin).ne').mpr
  apply mul_right_cancel₀ hcos.ne'
  nlinarith only [hrel]

/-- The first kernel changes sign at the explicit crossing used by the
finite low-angle preimage certificates. -/
theorem rayMomentKernel_one_crossing {p : ℝ} (hp : 0<p) (hpu : p<1/2) :
    rayMomentPhase 1 (Real.pi*(1-p)) (lowAngleCrossing p)=Real.pi/2 ∧
    rayMomentKernel 1 (Real.pi*(1-p)) (lowAngleCrossing p)=0 ∧
    (∀v,0<v → v<lowAngleCrossing p → 0<rayMomentKernel 1 (Real.pi*(1-p)) v) ∧
    (∀v,lowAngleCrossing p<v → rayMomentKernel 1 (Real.pi*(1-p)) v<0) := by
  have hθ : 0<Real.pi*(1-p) := mul_pos Real.pi_pos (by linarith)
  have hθu : Real.pi*(1-p)<Real.pi := by nlinarith [mul_pos Real.pi_pos hp]
  have hlo : Real.pi/2<(1:ℝ)*(Real.pi*(1-p)) := by
    nlinarith [mul_pos Real.pi_pos (show 0<1/2-p by linarith)]
  have hhi : (1:ℝ)*(Real.pi*(1-p))≤3*Real.pi/2 := by nlinarith [Real.pi_pos]
  obtain ⟨v₀,hv₀,hph,hz,hpos,hneg⟩ :=
    rayMomentKernel_single_crossing (k:=1) hθ hθu (by simpa using hlo) (by simpa using hhi)
  have hv : v₀=lowAngleCrossing p := rayMomentPhase_one_crossing_eq hp hpu hph
  exact hv ▸ ⟨hph,hz,hpos,hneg⟩

/-- The second kernel has one sign change throughout 1/4≤p<3/4, which
contains the complete range needed for the next derivative comparison. -/
theorem rayMomentKernel_two_crossing {p : ℝ} (hp : 1/4≤p) (hpu : p<3/4) :
    ∃ v₀ : ℝ,0<v₀ ∧ rayMomentPhase 2 (Real.pi*(1-p)) v₀=Real.pi/2 ∧
      rayMomentKernel 2 (Real.pi*(1-p)) v₀=0 ∧
      (∀v,0<v → v<v₀ → 0<rayMomentKernel 2 (Real.pi*(1-p)) v) ∧
      (∀v,v₀<v → rayMomentKernel 2 (Real.pi*(1-p)) v<0) := by
  have hθ : 0<Real.pi*(1-p) := mul_pos Real.pi_pos (by linarith)
  have hθu : Real.pi*(1-p)<Real.pi := by nlinarith [mul_pos Real.pi_pos (show 0<p by linarith)]
  apply rayMomentKernel_single_crossing hθ hθu
  · norm_num
    nlinarith [mul_pos Real.pi_pos (show 0<3/4-p by linarith)]
  · norm_num
    nlinarith [mul_nonneg Real.pi_pos.le (show 0≤p-1/4 by linarith)]

end LeanVerification.UpperLeftCompletion
