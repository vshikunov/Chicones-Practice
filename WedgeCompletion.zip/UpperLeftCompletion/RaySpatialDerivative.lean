import LeanVerification.UpperLeftCompletion.RayDensity

/-! Spatial differentiation of the actual negative-ray jets.  The Euler
primitive below is the integration-by-parts identity used in the regional
sign arguments; no identity for an abstract replacement density is assumed. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 2200000
set_option maxRecDepth 4000

def rayEulerPrimitiveFactor (p A B C r : ℝ) : ℝ :=
  r*rayPolynomial A B C r/rayEulerPolynomial p A B C r

theorem hasDerivAt_complex_pow_log {f : ℝ → ℂ} {x : ℝ} {a : ℂ}
    (hf : HasDerivAt f (a*f x) x) (n : ℕ) :
    HasDerivAt (fun r => f r^n) ((n:ℂ)*a*f x^n) x := by
  cases n with
  | zero => simpa using hasDerivAt_const x (1:ℂ)
  | succ n =>
    convert (hasDerivAt_pow (n+1) (f x)).comp x hf using 1
    simp only [Nat.add_sub_cancel, pow_succ]
    ring

theorem hasDerivAt_negativeRayPower_spatial (p : ℝ) {r : ℝ} (hr : 0<r) :
    HasDerivAt (negativeRayPower p)
      (((-(p/r):ℝ):ℂ)*negativeRayPower p r) r := by
  have h := ((Real.hasDerivAt_rpow_const (p := -p) (Or.inl hr.ne')).ofReal_comp).mul_const
    ((Real.cos (Real.pi*p):ℂ)-(Real.sin (Real.pi*p):ℂ)*Complex.I)
  have he : negativeRayPower p =ᶠ[𝓝 r]
      (fun x : ℝ => ((x^(-p):ℝ):ℂ)*
        ((Real.cos (Real.pi*p):ℂ)-(Real.sin (Real.pi*p):ℂ)*Complex.I)) := by
    filter_upwards [Ioi_mem_nhds hr] with x hx
    exact negativeRayPower_eq p hx
  convert h.congr_of_eventuallyEq he using 1
  rw [negativeRayPower_eq p hr, Real.rpow_sub_one hr.ne']
  push_cast
  ring

theorem hasDerivAt_negativeRayRadicand_spatial (p A B C δ : ℝ) {r : ℝ}
    (hr : 0<r) :
    HasDerivAt (negativeRayRadicand p A B C δ)
      (((2*A*r+B:ℝ):ℂ)+(δ:ℂ)*(p/r:ℝ)*negativeRayPower p r) r := by
  convert ((hasDerivAt_rayPolynomial A B C r).ofReal_comp).sub
    ((hasDerivAt_negativeRayPower_spatial p hr).const_mul (δ:ℂ)) using 1
  push_cast
  ring

theorem hasDerivAt_negativeRayKernel_spatial (A B C : ℝ) {p δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hδ : 0<δ) (hr : 0<r) :
    HasDerivAt (negativeRayKernel p A B C δ)
      (-(((2*A*r+B:ℝ):ℂ)+(δ:ℂ)*(p/r:ℝ)*negativeRayPower p r)/
        (2*negativeRayRadicand p A B C δ r)*negativeRayKernel p A B C δ r) r := by
  have hsl := negativeRayRadicand_mem_slit A B C hp hpu hδ hr
  have hz := negativeRayRadicand_ne_zero A B C hp hpu hδ hr
  have hs := (((hasDerivAt_negativeRayRadicand_spatial p A B C δ hr).clog_real hsl).div_const 2).cexp
  have hsn : principalSquareRoot (negativeRayRadicand p A B C δ r)≠0 := Complex.exp_ne_zero _
  convert (hasDerivAt_inv hsn).comp r hs using 1
  change -(((2*A*r+B:ℝ):ℂ)+(δ:ℂ)*(p/r:ℝ)*negativeRayPower p r)/
      (2*negativeRayRadicand p A B C δ r)*
        (principalSquareRoot (negativeRayRadicand p A B C δ r))⁻¹ = _
  simp only [div_eq_mul_inv] at *
  change _ = -((principalSquareRoot (negativeRayRadicand p A B C δ r))^2)⁻¹*
    (principalSquareRoot (negativeRayRadicand p A B C δ r)*
      ((((2*A*r+B:ℝ):ℂ)+(δ:ℂ)*(p/r:ℝ)*negativeRayPower p r)/
        negativeRayRadicand p A B C δ r/2))
  field_simp [hz,hsn]
  <;> ring

theorem negativeRayJet_succ_ratio (n : ℕ) (A B C : ℝ) {p δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hδ : 0<δ) (hr : 0<r) :
    negativeRayJet (n+1) p A B C δ r =
      ((n:ℂ)+1/2)*negativeRayPower p r/
        negativeRayRadicand p A B C δ r*negativeRayJet n p A B C δ r := by
  rw [negativeRayJet_eq_ratio (n+1) A B C hp hpu hδ hr,
    negativeRayJet_eq_ratio n A B C hp hpu hδ hr,negativeRayCoefficient,pow_succ]
  push_cast
  ring

theorem hasDerivAt_negativeRayJet_spatial (n : ℕ) (A B C : ℝ) {p δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hδ : 0<δ) (hr : 0<r) :
    HasDerivAt (negativeRayJet n p A B C δ)
      ((-(n:ℂ)*(p/r:ℝ)-((n:ℂ)+1/2)*
        (((2*A*r+B:ℝ):ℂ)+(δ:ℂ)*(p/r:ℝ)*negativeRayPower p r)/
          negativeRayRadicand p A B C δ r)*negativeRayJet n p A B C δ r) r := by
  have hq := hasDerivAt_complex_pow_log
    (hasDerivAt_negativeRayPower_spatial p hr) n
  have hk := hasDerivAt_complex_pow_log
    (hasDerivAt_negativeRayKernel_spatial A B C hp hpu hδ hr) (2*n+1)
  convert ((hq.const_mul (negativeRayCoefficient n:ℂ)).mul hk) using 1
  dsimp only [negativeRayJet]
  push_cast
  ring

theorem hasDerivAt_rayEulerPrimitiveFactor (p A B C r : ℝ)
    (hH : rayEulerPolynomial p A B C r≠0) :
    HasDerivAt (rayEulerPrimitiveFactor p A B C)
      (1+rayElasticity p A B C r-p*rayPolynomial A B C r/
        (2*rayEulerPolynomial p A B C r)) r := by
  convert (((hasDerivAt_id r).mul (hasDerivAt_rayPolynomial A B C r)).div
    (hasDerivAt_rayEulerPolynomial p A B C r) hH) using 1
  dsimp only [id_eq,rayElasticity]
  field_simp [hH]
  dsimp only [rayPolynomial,rayEulerPolynomial,rayEulerSlope]
  ring

theorem rayEulerPrimitive_algebra (P H S Q Z E p δ r k J : ℂ)
    (hH : H≠0) (hZ : Z≠0) (hr : r≠0) (hZe : Z=P-δ*Q)
    (hHe : H=p*P+r*S) :
    (E-k+1/2)*J-δ*((k+1/2)*Q/Z*J) =
      (1+E-p*P/(2*H))*J+
        (r*P/H)*((-k*(p/r)-(k+1/2)*(S+δ*(p/r)*Q)/Z)*J) := by
  field_simp (discharger := simp_all) [hH,hZ,hr]
  rw [hZe,hHe]
  ring

theorem hasDerivAt_rayEulerPrimitive (n : ℕ) (A B C : ℝ) {p δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hδ : 0<δ) (hr : 0<r)
    (hH : rayEulerPolynomial p A B C r≠0) :
    HasDerivAt (fun x => (rayEulerPrimitiveFactor p A B C x:ℂ)*
        negativeRayJet n p A B C δ x)
      (((rayElasticity p A B C r-(n:ℝ)+1/2:ℝ):ℂ)*
        negativeRayJet n p A B C δ r-(δ:ℂ)*negativeRayJet (n+1) p A B C δ r) r := by
  have hd := ((hasDerivAt_rayEulerPrimitiveFactor p A B C r hH).ofReal_comp).mul
    (hasDerivAt_negativeRayJet_spatial n A B C hp hpu hδ hr)
  convert hd using 1
  rw [negativeRayJet_succ_ratio n A B C hp hpu hδ hr]
  have hz := negativeRayRadicand_ne_zero A B C hp hpu hδ hr
  have hHC : (rayEulerPolynomial p A B C r:ℂ)≠0 := Complex.ofReal_ne_zero.mpr hH
  have hrC : (r:ℂ)≠0 := Complex.ofReal_ne_zero.mpr hr.ne'
  have hZe : negativeRayRadicand p A B C δ r=
      (rayPolynomial A B C r:ℂ)-(δ:ℂ)*negativeRayPower p r := rfl
  have hHe : (rayEulerPolynomial p A B C r:ℂ)=
      (p:ℂ)*(rayPolynomial A B C r:ℂ)+(r:ℂ)*((2*A*r+B:ℝ):ℂ) := by
    dsimp only [rayEulerPolynomial,rayPolynomial]
    push_cast
    ring
  simpa only [rayEulerPrimitiveFactor,Complex.ofReal_add,Complex.ofReal_sub,
    Complex.ofReal_mul,Complex.ofReal_div,Complex.ofReal_one,Complex.ofReal_ofNat,
    Complex.ofReal_natCast,Complex.ofReal_neg] using
    rayEulerPrimitive_algebra (rayPolynomial A B C r) (rayEulerPolynomial p A B C r)
      ((2*A*r+B:ℝ):ℂ) (negativeRayPower p r) (negativeRayRadicand p A B C δ r)
      (rayElasticity p A B C r) p δ r n (negativeRayJet n p A B C δ r)
      hHC hz hrC hZe hHe

end LeanVerification.UpperLeftCompletion
