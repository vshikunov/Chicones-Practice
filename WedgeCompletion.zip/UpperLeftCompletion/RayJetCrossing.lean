import LeanVerification.UpperLeftCompletion.RayMomentNormalization

/-! The one-crossing signs belong to the actual ray jets and to their
constructed positive inverse crossing radii. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 2400000

theorem negativeRayJet_signed_pos_iff (k : ℕ) (A B C : ℝ) {p δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hδ : 0<δ) (hr : 0<r) :
    0<(-1:ℝ)^k*(negativeRayJet k p A B C δ r).re ↔
      0<rayMomentKernel k (Real.pi*(1-p)) (rayEnergy p A B C r/δ) := by
  rw [negativeRayJet_signed_normalized k A B C hp hpu hδ hr]
  exact mul_pos_iff_of_pos_left (mul_pos
    (mul_pos (negativeRayCoefficient_pos k) (Real.rpow_pos_of_pos hr _))
    (Real.rpow_pos_of_pos hδ _))

theorem negativeRayJet_signed_neg_iff (k : ℕ) (A B C : ℝ) {p δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hδ : 0<δ) (hr : 0<r) :
    (-1:ℝ)^k*(negativeRayJet k p A B C δ r).re<0 ↔
      rayMomentKernel k (Real.pi*(1-p)) (rayEnergy p A B C r/δ)<0 := by
  rw [negativeRayJet_signed_normalized k A B C hp hpu hδ hr]
  have hc := mul_pos
    (mul_pos (negativeRayCoefficient_pos k) (Real.rpow_pos_of_pos hr (p/2)))
    (Real.rpow_pos_of_pos hδ (-(k:ℝ)-1/2))
  constructor
  · intro h
    by_contra hn
    exact (not_lt_of_ge (mul_nonneg hc.le (le_of_not_gt hn))) h
  · intro h
    exact mul_neg_of_pos_of_neg hc h

theorem negativeRayJet_crossing_of_kernel (k : ℕ) {p A B C δ v₀ : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hδ : 0<δ)
    (hv₀ : 0<v₀) (hz : rayMomentKernel k (Real.pi*(1-p)) v₀=0)
    (hpos : ∀v,0<v → v<v₀ → 0<rayMomentKernel k (Real.pi*(1-p)) v)
    (hneg : ∀v,v₀<v → rayMomentKernel k (Real.pi*(1-p)) v<0) :
    0<rayInverse p A B C (δ*v₀) ∧
      (negativeRayJet k p A B C δ (rayInverse p A B C (δ*v₀))).re=0 ∧
      (∀r,0<r → r<rayInverse p A B C (δ*v₀) →
        0<(-1:ℝ)^k*(negativeRayJet k p A B C δ r).re) ∧
      (∀r,rayInverse p A B C (δ*v₀)<r →
        (-1:ℝ)^k*(negativeRayJet k p A B C δ r).re<0) := by
  let r₀ := rayInverse p A B C (δ*v₀)
  have hr₀ : 0<r₀ := rayInverse_pos hp hA hB hC (mul_pos hδ hv₀)
  have he : rayEnergy p A B C r₀=δ*v₀ := rayEnergy_inverse hp hA hB hC (mul_pos hδ hv₀)
  have hv : rayEnergy p A B C r₀/δ=v₀ := by rw [he];exact mul_div_cancel_left₀ _ hδ.ne'
  refine ⟨hr₀,?_,?_,?_⟩
  · rw [negativeRayJet_real_normalized k A B C hp hpu hδ hr₀,hv,hz,mul_zero]
  · intro r hr hrr
    apply (negativeRayJet_signed_pos_iff k A B C hp hpu hδ hr).mpr
    apply hpos _ (div_pos (rayEnergy_pos hA hB.le hC hr) hδ)
    have hu := strictMonoOn_rayEnergy hp hA hB.le hC hr hr₀ hrr
    rw [he] at hu
    exact (div_lt_iff₀ hδ).mpr (by simpa only [mul_comm] using hu)
  · intro r hrr
    have hr : 0<r := hr₀.trans hrr
    apply (negativeRayJet_signed_neg_iff k A B C hp hpu hδ hr).mpr
    apply hneg
    have hu := strictMonoOn_rayEnergy hp hA hB.le hC hr₀ hr hrr
    rw [he] at hu
    exact (lt_div_iff₀ hδ).mpr (by simpa only [mul_comm] using hu)

/-- Explicit crossing radius for the actual first ray jet. -/
theorem negativeRayJet_one_crossing {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1/2) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hδ : 0<δ) :
    0<rayInverse p A B C (δ*lowAngleCrossing p) ∧
      (negativeRayJet 1 p A B C δ (rayInverse p A B C (δ*lowAngleCrossing p))).re=0 ∧
      (∀r,0<r → r<rayInverse p A B C (δ*lowAngleCrossing p) →
        0<(-1:ℝ)*(negativeRayJet 1 p A B C δ r).re) ∧
      (∀r,rayInverse p A B C (δ*lowAngleCrossing p)<r →
        (-1:ℝ)*(negativeRayJet 1 p A B C δ r).re<0) := by
  obtain ⟨hph,hz,hpos,hneg⟩ := rayMomentKernel_one_crossing hp hpu
  simpa only [pow_one] using negativeRayJet_crossing_of_kernel 1 hp (by linarith) hA hB hC hδ
    (lowAngleCrossing_pos hp.le hpu) hz hpos hneg

/-- The actual second jet has one crossing, with positive sign first. -/
theorem negativeRayJet_two_crossing {p A B C δ : ℝ}
    (hp : 1/4≤p) (hpu : p<3/4) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hδ : 0<δ) :
    ∃r₀ : ℝ,0<r₀ ∧ (negativeRayJet 2 p A B C δ r₀).re=0 ∧
      (∀r,0<r → r<r₀ → 0<(negativeRayJet 2 p A B C δ r).re) ∧
      (∀r,r₀<r → (negativeRayJet 2 p A B C δ r).re<0) := by
  obtain ⟨v₀,hv₀,hph,hz,hpos,hneg⟩ := rayMomentKernel_two_crossing hp hpu
  refine ⟨rayInverse p A B C (δ*v₀),?_⟩
  simpa only [neg_one_sq,one_mul] using negativeRayJet_crossing_of_kernel 2
    (by linarith) (by linarith) hA hB hC hδ hv₀ hz hpos hneg

end LeanVerification.UpperLeftCompletion
