import LeanVerification.UpperLeftCompletion.RayEulerIntegral
import LeanVerification.UpperLeftCompletion.RayJetCrossing
import LeanVerification.UpperLeftCompletion.PositiveOrientation

/-! The signs at every zero of the actual ray moments, followed by strict
propagation from a terminal energy.  All crossing and density-elasticity
hypotheses are discharged for the constructed negative-ray integral. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion ExteriorCompletion
set_option maxHeartbeats 1400000

theorem actual_first_ray_crossing_inequality {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1/2) (hA : 0<A) (hB : 0<B) (hC : 0<C)
    (hdisc : 4*A*C≤B^2) (hδ : 0<δ) :
    0<δ*(-negativeRayJetIntegral 1 p A B C δ)-
      (rayElasticity p A B C (rayInverse p A B C (δ*lowAngleCrossing p))-1/2)*
        (-negativeRayJetIntegral 0 p A B C δ) := by
  obtain ⟨hr,_,hl,hu⟩ := negativeRayJet_one_crossing hp hpu hA.le hB hC hδ
  have hi := actual_rayEuler_one_crossing 0 (-1) hp (by linarith) hA hB hC hdisc hδ hr hl hu
  norm_num only [Nat.cast_zero,sub_zero] at hi
  nlinarith

theorem actual_first_ray_deriv_pos_at_zero {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1/2) (hA : 0<A) (hB : 0<B) (hC : 0<C)
    (hdisc : 4*A*C≤B^2) (hδ : 0<δ)
    (hz : -negativeRayJetIntegral 0 p A B C δ=0) :
    0<deriv (fun d => -negativeRayJetIntegral 0 p A B C d) δ := by
  rw [((hasDerivAt_negativeRayJetIntegral 0 hp (by linarith) hA hB.le hC.le hδ).neg).deriv]
  have hi := actual_first_ray_crossing_inequality hp hpu hA hB hC hdisc hδ
  rw [hz,mul_zero,sub_zero] at hi
  exact (mul_pos_iff_of_pos_left hδ).mp hi

theorem actual_ray_zero_positive_of_center {p A B C δ H : ℝ}
    (hp : 0<p) (hpu : p<1/2) (hA : 0<A) (hB : 0<B) (hC : 0<C)
    (hdisc : 4*A*C≤B^2) (hδ : 0<δ) (hδH : δ≤H)
    (hcenter : 0<negativeRayJetIntegral 0 p A B C H) :
    0<negativeRayJetIntegral 0 p A B C δ := by
  have hi := neg_left_of_deriv_pos_at_zeros hδH
    (f := fun d => -negativeRayJetIntegral 0 p A B C d)
    (fun d hd => ((hasDerivAt_negativeRayJetIntegral 0 hp (by linarith)
      hA hB.le hC.le (hδ.trans_le hd.1)).neg).differentiableAt)
    (fun d hd hz => actual_first_ray_deriv_pos_at_zero hp hpu hA hB hC hdisc
      (hδ.trans_le hd.1) hz) (neg_neg_of_pos hcenter)
  exact neg_neg_iff_pos.mp hi

theorem actual_second_ray_deriv_pos_at_zero {p A B C δ : ℝ}
    (hp : 1/4≤p) (hpu : p<3/4) (hA : 0<A) (hB : 0<B) (hC : 0<C)
    (hdisc : 4*A*C≤B^2) (hδ : 0<δ)
    (hz : negativeRayJetIntegral 1 p A B C δ=0) :
    0<deriv (negativeRayJetIntegral 1 p A B C) δ := by
  have hp0 : 0<p := by linarith
  have hp1 : p<1 := by linarith
  obtain ⟨r,hr,_,hl,hu⟩ := negativeRayJet_two_crossing hp hpu hA.le hB hC hδ
  have hi := actual_rayEuler_one_crossing 1 1 hp0 hp1 hA hB hC hdisc hδ hr
    (fun x hx hxr => by simpa only [one_mul] using hl x hx hxr)
    (fun x hrx => by simpa only [one_mul] using hu x hrx)
  rw [hz,mul_zero,sub_zero,one_mul] at hi
  rw [(hasDerivAt_negativeRayJetIntegral 1 hp0 hp1 hA hB.le hC.le hδ).deriv]
  exact (mul_pos_iff_of_pos_left hδ).mp hi

theorem actual_ray_one_negative_of_center {p A B C δ H : ℝ}
    (hp : 1/4≤p) (hpu : p<3/4) (hA : 0<A) (hB : 0<B) (hC : 0<C)
    (hdisc : 4*A*C≤B^2) (hδ : 0<δ) (hδH : δ≤H)
    (hcenter : negativeRayJetIntegral 1 p A B C H<0) :
    negativeRayJetIntegral 1 p A B C δ<0 :=
  neg_left_of_deriv_pos_at_zeros hδH
    (fun d hd => (hasDerivAt_negativeRayJetIntegral 1 (by linarith) (by linarith)
      hA hB.le hC.le (hδ.trans_le hd.1)).differentiableAt)
    (fun d hd hz => actual_second_ray_deriv_pos_at_zero hp hpu hA hB hC hdisc
      (hδ.trans_le hd.1) hz) hcenter

end LeanVerification.UpperLeftCompletion
