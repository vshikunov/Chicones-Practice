import LeanVerification.ExteriorCompletion.PhysicalPeriodDerivatives
import LeanVerification.Sharpness.PeriodTaylorRemainder
import LeanVerification.Sharpness.TauPolynomials

/-! Matching the complete actual contour jets to the signed-energy
physical center germ.  The argument uses the proved interior contour
identity on positive energies and actual continuity at the center; it does
not infer any missing interior bound from a boundary theorem. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion ExteriorCompletion Sharpness
set_option maxHeartbeats 1600000

theorem physical_center_deficit_spec (D F : ℝ) (hD : D< -1) (hF : 1<F) :
    0<zeroEndpointHeight D F ∧ zeroEndpointHeight D F∈exteriorRange D F := by
  obtain ⟨h,hh⟩ := exists_admissibleEnergy D F
  have hp := loudTurn_actual_deficit_pos D F h hD hF hh
  have hm := physical_deficit_mem_exteriorRange D F h hD hF hh
  rw [exteriorRange_eq D F hD hF] at hm ⊢
  constructor
  · linarith [hh.1]
  · change exteriorEnergy D F (exteriorSaddle D)<zeroEndpointHeight D F
    exact hm.trans (sub_lt_self _ hh.1)

theorem hasDerivAt_physicalContourPeriodJet_extended {D F h : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2)
    (hδ : 0<zeroEndpointHeight D F-h)
    (hm : zeroEndpointHeight D F-h∈exteriorRange D F) (n : ℕ) :
    HasDerivAt (physicalContourPeriodJet D F hD hF n)
      (physicalContourPeriodJet D F hD hF (n+1) h) h := by
  have hc := loudTurn_coefficients_pos D F hD hF
  have hs := (hasDerivAt_exteriorAbelJet D F _ hD hF n hm).comp h
    ((hasDerivAt_id h).const_sub (zeroEndpointHeight D F))
  have hr := ((hasDerivAt_negativeRayJetIntegral n
    (by linarith : 0<2*F-2) (by linarith : 2*F-2<1) hc.1 hc.2.1.le hc.2.2.le hδ).comp h
      ((hasDerivAt_id h).const_sub (zeroEndpointHeight D F))).const_mul ((-1:ℝ)^n)
  convert (hs.add hr).const_mul (Real.sqrt 2) using 1
  dsimp only [physicalContourPeriodJet]
  rw [pow_succ]
  ring

theorem hasDerivAt_physicalContourPeriodJet_center {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2) (n : ℕ) :
    HasDerivAt (physicalContourPeriodJet D F hD hF n)
      (physicalContourPeriodJet D F hD hF (n+1) 0) 0 := by
  have hc := physical_center_deficit_spec D F hD hF
  exact hasDerivAt_physicalContourPeriodJet_extended hD hF hFu
    (by simpa using hc.1) (by simpa using hc.2) n

theorem physicalContourPeriodJet_center_eq {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2) (n : ℕ) :
    physicalContourPeriodJet D F hD hF n 0=
      iteratedDeriv (n+1) (centerPeriod D F) 0 := by
  have hf := (hasDerivAt_physicalContourPeriodJet_center hD hF hFu n).continuousAt
  have hg : ContinuousAt (iteratedDeriv (n+1) (centerPeriod D F)) 0 := by
    simpa only [iteratedDeriv_eq_iterate] using
      ((analyticAt_centerPeriod D F).iterated_deriv (n+1)).continuousAt
  have ht : Tendsto (fun h:ℝ => (((D,F),h):PeriodParameterSpace))
      (𝓝 0) (𝓝 ((D,F),0)) :=
    (continuousAt_const.prodMk continuousAt_id).tendsto
  have he : physicalContourPeriodJet D F hD hF n =ᶠ[𝓝[>] (0:ℝ)]
      iteratedDeriv (n+1) (centerPeriod D F) := by
    filter_upwards [self_mem_nhdsWithin,
      (ht.eventually (isOpen_jointCenterDomain.mem_nhds
        (jointCenterDomain_contains_center D F))).filter_mono nhdsWithin_le_nhds] with h hh hd
    have ha := (jointCenterPeriod_eq_periodQuadrature hd hh).1
    have hp : iteratedDeriv (n+1) (periodQuadrature D F) h=
        physicalContourPeriodJet D F hD hF n h :=
      actual_physical_period_all_contour_derivatives hD hF hFu ha n
    exact hp.symm.trans ((centerPeriod_germ_eq_physical hd hh).iteratedDeriv_eq (n+1)).symm
  exact tendsto_nhds_unique (hf.tendsto.mono_left nhdsWithin_le_nhds)
    ((hg.tendsto.mono_left nhdsWithin_le_nhds).congr' he.symm)

theorem actual_contour_first_center {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2) :
    Real.sqrt 2*(exteriorM D F hD hF (zeroEndpointHeight D F)+
      negativeRayJetIntegral 0 (2*F-2) (loudTurnA D F) (loudTurnB D F)
        (loudTurnC D F) (zeroEndpointHeight D F)) =
      2*Real.pi*tau1Polynomial D F := by
  have he := physicalContourPeriodJet_center_eq hD hF hFu 0
  have hc := actual_tau1_polynomial D F
  have hπ : 2*Real.pi≠0 := mul_ne_zero (by norm_num) Real.pi_ne_zero
  dsimp only [periodCoefficient] at hc
  norm_num [Nat.factorial] at hc
  have hc' : iteratedDeriv 1 (centerPeriod D F) 0=2*Real.pi*tau1Polynomial D F := by
    simpa only [iteratedDeriv_one] using ((div_eq_iff hπ).mp hc).trans (mul_comm _ _)
  simpa only [physicalContourPeriodJet,exteriorM,sub_zero,pow_zero,one_mul] using he.trans hc'

theorem actual_contour_second_center {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2) :
    Real.sqrt 2*(exteriorAbelJet D F hD hF 1 (zeroEndpointHeight D F)-
      negativeRayJetIntegral 1 (2*F-2) (loudTurnA D F) (loudTurnB D F)
        (loudTurnC D F) (zeroEndpointHeight D F)) =
      4*Real.pi*tau2Polynomial D F := by
  have he := physicalContourPeriodJet_center_eq hD hF hFu 1
  have hc := actual_tau2_polynomial D F
  have hπ : 4*Real.pi≠0 := mul_ne_zero (by norm_num) Real.pi_ne_zero
  dsimp only [periodCoefficient] at hc
  norm_num [Nat.factorial] at hc
  have hc' : iteratedDeriv 2 (centerPeriod D F) 0=4*Real.pi*tau2Polynomial D F := by
    have hden : (2:ℝ)*(2*Real.pi)=4*Real.pi := by ring
    rw [hden] at hc
    exact (div_eq_iff hπ).mp hc |>.trans (mul_comm _ _)
  simpa only [physicalContourPeriodJet,sub_zero,pow_one,neg_one_mul,←sub_eq_add_neg] using he.trans hc'

theorem actual_ray_zero_center {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2) :
    negativeRayJetIntegral 0 (2*F-2) (loudTurnA D F) (loudTurnB D F)
      (loudTurnC D F) (zeroEndpointHeight D F) =
        Real.sqrt 2*Real.pi*tau1Polynomial D F-
          exteriorM D F hD hF (zeroEndpointHeight D F) := by
  have he := actual_contour_first_center hD hF hFu
  have hs := Real.sq_sqrt (by norm_num : (0:ℝ)≤2)
  have hm := congrArg (fun x : ℝ => Real.sqrt 2*x) he
  dsimp only at hm
  rw [←mul_assoc,←pow_two,hs] at hm
  linarith

theorem actual_ray_one_center {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2) :
    negativeRayJetIntegral 1 (2*F-2) (loudTurnA D F) (loudTurnB D F)
      (loudTurnC D F) (zeroEndpointHeight D F) =
        exteriorAbelJet D F hD hF 1 (zeroEndpointHeight D F)-
          2*Real.sqrt 2*Real.pi*tau2Polynomial D F := by
  have he := actual_contour_second_center hD hF hFu
  have hs := Real.sq_sqrt (by norm_num : (0:ℝ)≤2)
  have hm := congrArg (fun x : ℝ => Real.sqrt 2*x) he
  dsimp only at hm
  rw [←mul_assoc,←pow_two,hs] at hm
  linarith

end LeanVerification.UpperLeftCompletion
