import LeanVerification.UpperLeftCompletion.LowAngleBoundsExterior

/-! The finite low-angle comparisons applied to the actual positive ray
inverse.  The inverse, its monotonicity, and the sign of its elasticity
are all constructed from the Loud coefficient functions. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
set_option maxHeartbeats 2400000

theorem lowAngle_discriminant_identity {p l : ℝ} (hp : 0<p) :
    (lowAngleB p l)^2-4*lowAngleA p l*lowAngleC p l=
      (1-l)*(l*p+p+2)/((p+1)^2*(p+2)) := by
  have hp0 : p≠0 := hp.ne'
  have hp1 : p+1≠0 := by positivity
  have hp2 : p+2≠0 := by positivity
  dsimp only [lowAngleA,lowAngleB,lowAngleC]
  field_simp
  <;> ring

theorem lowAngle_discriminant_nonneg {p l : ℝ}
    (hp : 0<p) (hl : 0≤l) (hlu : l≤1) :
    4*lowAngleA p l*lowAngleC p l≤(lowAngleB p l)^2 := by
  apply sub_nonneg.mp
  rw [lowAngle_discriminant_identity hp]
  have h1 : 0≤1-l := sub_nonneg.mpr hlu
  positivity

theorem lowAngleElasticity_strictAntiOn {p l : ℝ}
    (hp : 0<p) (hl : 0≤l) (hlu : l≤1) :
    StrictAntiOn (lowAngleElasticity p l) (Ioi (0:ℝ)) := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl
  exact rayElasticity_strictAntiOn hp hA hB hC (lowAngle_discriminant_nonneg hp hl hlu)

theorem lowAngleU_strictMonoOn {p l : ℝ} (hp : 0<p) (hl : 0≤l) :
    StrictMonoOn (lowAngleU p l) (Ioi (0:ℝ)) := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl
  exact strictMonoOn_rayEnergy hp hA hB.le hC

/-- The radius at the single kernel crossing is the previously constructed
positive inverse of the actual ray energy. -/
def lowAngleCrossingRadius (p l d : ℝ) : ℝ :=
  rayInverse p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l)
    (d*lowAngleCrossing p)

def lowAngleBracket (p l d : ℝ) : ℝ :=
  lowAngleElasticity p l (lowAngleCrossingRadius p l d)-1/2+
    d/(d+lowAngleExteriorDepth p l)

theorem lowAngleCrossingRadius_pos {p l d : ℝ}
    (hp : 0<p) (hpu : p<1/2) (hl : 0≤l) (hd : 0<d) :
    0<lowAngleCrossingRadius p l d := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl
  exact rayInverse_pos hp hA hB hC (mul_pos hd (lowAngleCrossing_pos hp.le hpu))

theorem lowAngleU_crossingRadius {p l d : ℝ}
    (hp : 0<p) (hpu : p<1/2) (hl : 0≤l) (hd : 0<d) :
    lowAngleU p l (lowAngleCrossingRadius p l d)=d*lowAngleCrossing p := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl
  exact rayEnergy_inverse hp hA hB hC (mul_pos hd (lowAngleCrossing_pos hp.le hpu))

theorem lowAngleCrossingRadius_lt {p l d R : ℝ}
    (hp : 0<p) (hpu : p<1/2) (hl : 0≤l) (hd : 0<d)
    (hdc : d≤lowAngleDeficit p l) (hR : 0<R)
    (hpre : lowAngleDeficit p l*lowAngleCrossing p<lowAngleU p l R) :
    lowAngleCrossingRadius p l d<R := by
  apply (lowAngleU_strictMonoOn hp hl).lt_iff_lt
    (lowAngleCrossingRadius_pos hp hpu hl hd) hR |>.mp
  rw [lowAngleU_crossingRadius hp hpu hl hd]
  exact (mul_le_mul_of_nonneg_right hdc (lowAngleCrossing_pos hp.le hpu).le).trans_lt hpre

theorem lowAngleBracket_pos_of_elasticity {p l d : ℝ}
    (hp : 0<p) (hl : 0<l) (hlu : l<1) (hd : 0<d)
    (he : 1/2<lowAngleElasticity p l (lowAngleCrossingRadius p l d)) :
    0<lowAngleBracket p l d := by
  have hW := lowAngleExteriorDepth_pos hp hl hlu
  have hf : 0<d/(d+lowAngleExteriorDepth p l) := div_pos hd (by positivity)
  dsimp only [lowAngleBracket]
  linarith

theorem lowAngleBracket_pos_of_radius_le_one {p l d : ℝ}
    (hp : 0<p) (hpu : p≤1/4) (hl : 0<l) (hlu : l<1) (hd : 0<d)
    (hr : lowAngleCrossingRadius p l d≤1) : 0<lowAngleBracket p l d := by
  apply lowAngleBracket_pos_of_elasticity hp hl hlu hd
  exact (lowAngleElasticity_one_gt_half hp hpu hl.le hlu.le).trans_le
    ((lowAngleElasticity_strictAntiOn hp hl.le hlu.le).antitoneOn
      (lowAngleCrossingRadius_pos hp (by linarith) hl.le hd) (by norm_num) hr)

theorem lowAngleBracket_pos_small_exponent {p l d : ℝ}
    (hp : 0<p) (hpu : p≤1/6) (hl : 0<l) (hlu : l<1)
    (hd : 0<d) (hdc : d≤lowAngleDeficit p l) : 0<lowAngleBracket p l d := by
  have hr := lowAngleCrossingRadius_lt hp (by linarith) hl.le hd hdc
    (by norm_num : (0:ℝ)<3/2) (lowAngle_preimage_three_halves hp hpu hl.le)
  have he := lowAngleElasticity_strictAntiOn hp hl.le hlu.le
    (lowAngleCrossingRadius_pos hp (by linarith) hl.le hd) (by norm_num) hr
  apply lowAngleBracket_pos_of_elasticity hp hl hlu hd
  exact (lowAngleElasticity_three_halves_gt_half hp hpu hl.le hlu.le).trans he

/-- The first full low-angle scalar region.  There are no assumptions on
the desired elasticity or exterior comparison. -/
theorem lowAngleBracket_pos_low {p l d : ℝ}
    (hp : 0<p) (hpu : p≤3/13) (hl : 0<l) (hlu : l<1)
    (hd : 0<d) (hdc : d≤lowAngleDeficit p l) : 0<lowAngleBracket p l d := by
  by_cases hp6 : p≤1/6
  · exact lowAngleBracket_pos_small_exponent hp hp6 hl hlu hd hdc
  by_cases hr1 : lowAngleCrossingRadius p l d≤1
  · exact lowAngleBracket_pos_of_radius_le_one hp (by linarith) hl hlu hd hr1
  have hr := lowAngleCrossingRadius_lt hp (by linarith) hl.le hd hdc
    (by norm_num : (0:ℝ)<5/3) (lowAngle_preimage_star_low hp hpu hl.le)
  have he := lowAngleElasticity_strictAntiOn hp hl.le hlu.le
    (lowAngleCrossingRadius_pos hp (by linarith) hl.le hd) (by norm_num) hr
  by_cases hl10 : l≤1/10
  · apply lowAngleBracket_pos_of_elasticity hp hl hlu hd
    exact (lowAngleElasticity_star_gt_half_small_mixture hp hpu hl.le hl10).trans he
  have hδ : lowAngleU p l 1/lowAngleCrossing p<d := by
    apply (div_lt_iff₀ (lowAngleCrossing_pos hp.le (by linarith))).mpr
    rw [←lowAngleU_crossingRadius hp (by linarith) hl.le hd]
    exact lowAngleU_strictMonoOn hp hl.le (by norm_num)
      (lowAngleCrossingRadius_pos hp (by linarith) hl.le hd) (lt_of_not_ge hr1)
  have hf := lowAngle_exterior_fraction_gt_third (le_of_not_ge hp6) hpu
    (le_of_not_ge hl10) hlu hδ
  have hs := lowAngleElasticity_star_gt_half_sub_third hp hpu hl.le hlu.le
  dsimp only [lowAngleBracket]
  linarith

/-- The second low-angle scalar region, including p=1/4. -/
theorem lowAngleBracket_pos_high_mixture {p l d : ℝ}
    (hp : 0<p) (hpu : p≤1/4) (hl : 1/2≤l) (hlu : l<1)
    (hd : 0<d) (hdc : d≤lowAngleDeficit p l) : 0<lowAngleBracket p l d := by
  have hl0 : 0<l := by linarith
  by_cases hp6 : p≤1/6
  · exact lowAngleBracket_pos_small_exponent hp hp6 hl0 hlu hd hdc
  by_cases hr1 : lowAngleCrossingRadius p l d≤1
  · exact lowAngleBracket_pos_of_radius_le_one hp hpu hl0 hlu hd hr1
  have hr := lowAngleCrossingRadius_lt hp (by linarith) hl0.le hd hdc
    (by norm_num : (0:ℝ)<5/3) (lowAngle_preimage_star_high_mixture hp hpu hl)
  have he := lowAngleElasticity_strictAntiOn hp hl0.le hlu.le
    (lowAngleCrossingRadius_pos hp (by linarith) hl0.le hd) (by norm_num) hr
  have hδ : lowAngleU p l 1/lowAngleCrossing p<d := by
    apply (div_lt_iff₀ (lowAngleCrossing_pos hp.le (by linarith))).mpr
    rw [←lowAngleU_crossingRadius hp (by linarith) hl0.le hd]
    exact lowAngleU_strictMonoOn hp hl0.le (by norm_num)
      (lowAngleCrossingRadius_pos hp (by linarith) hl0.le hd) (lt_of_not_ge hr1)
  have hf := lowAngle_exterior_fraction_gt_half (le_of_not_ge hp6) hpu hl hlu hδ
  have hs := lowAngleElasticity_star_gt_half_sub_half hp hpu hl0 hlu.le
  dsimp only [lowAngleBracket]
  linarith

end LeanVerification.UpperLeftCompletion
