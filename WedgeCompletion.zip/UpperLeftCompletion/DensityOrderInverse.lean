import LeanVerification.UpperLeftCompletion.LowAngleBounds
import LeanVerification.GeneralMechanical.ParametricInverse

/-! The actual globally selected positive ray inverse, with its dependence on
the Loud parameter.  The local inverse theorem supplies regularity; uniqueness
of the positive ray inverse identifies that germ with the global definition. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 4000

def densityOrderEnergy (p l r : ℝ) : ℝ := lowAngleU p l r/lowAngleDeficit p l

def densityOrderInverse (p l v : ℝ) : ℝ :=
  rayInverse p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l)
    (lowAngleDeficit p l*v)

def densityOrderDensity (p l v : ℝ) : ℝ :=
  rayDensity p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l)
    (lowAngleDeficit p l*v)

def densityOrderInverseVariation (p l r : ℝ) : ℝ :=
  -p*r*(r+1)/((l*p+p+2)*(l*p*(r+1)+2))

def densityOrderPolynomialVariation (p r : ℝ) : ℝ :=
  p/(2*(p+2))*r^2+p/(p+1)*r+1/2

theorem lowAngle_euler_factor {p : ℝ} (hp : 0<p) (l r : ℝ) :
    rayEulerPolynomial p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r=
      (r+1)*(l*p*(r+1)+2)/2 := by
  have hp0 : p≠0 := hp.ne'
  have hp1 : p+1≠0 := by positivity
  have hp2 : p+2≠0 := by positivity
  dsimp only [rayEulerPolynomial,lowAngleA,lowAngleB,lowAngleC]
  field_simp
  <;> ring

theorem densityOrderInverse_pos {p l v : ℝ} (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    0<densityOrderInverse p l v := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  exact rayInverse_pos hp hA hB hC (mul_pos (lowAngleDeficit_pos hp hl.le) hv)

theorem densityOrderDensity_pos {p l v : ℝ} (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    0<densityOrderDensity p l v := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  exact rayDensity_pos hp hA hB hC (mul_pos (lowAngleDeficit_pos hp hl.le) hv)

theorem densityOrderInverse_energy {p l v : ℝ} (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    lowAngleU p l (densityOrderInverse p l v)=lowAngleDeficit p l*v := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  exact rayEnergy_inverse hp hA hB hC (mul_pos (lowAngleDeficit_pos hp hl.le) hv)

theorem densityOrderEnergy_inverse {p l v : ℝ} (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    densityOrderEnergy p l (densityOrderInverse p l v)=v := by
  rw [densityOrderEnergy,densityOrderInverse_energy hp hl hv]
  exact mul_div_cancel_left₀ v (lowAngleDeficit_pos hp hl.le).ne'

theorem densityOrderInverse_eq_of_energy {p l v r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) (he : densityOrderEnergy p l r=v) :
    densityOrderInverse p l v=r := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hu : lowAngleDeficit p l*v=lowAngleU p l r := by
    rw [←he,densityOrderEnergy]
    exact mul_div_cancel₀ _ (lowAngleDeficit_pos hp hl.le).ne'
  dsimp only [densityOrderInverse]
  rw [hu]
  exact rayInverse_energy hp hA hB hC hr

theorem densityOrderInverse_strictMonoOn {p l : ℝ} (hp : 0<p) (hl : 0<l) :
    StrictMonoOn (densityOrderInverse p l) (Ioi (0:ℝ)) := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hd := lowAngleDeficit_pos hp hl.le
  intro u hu v hv huv
  exact strictMonoOn_rayInverse hp hA hB hC (mul_pos hd hu) (mul_pos hd hv)
    (mul_lt_mul_of_pos_left huv hd)

theorem analyticAt_lowAngleA (p l : ℝ) : AnalyticAt ℝ (lowAngleA p) l := by
  change AnalyticAt ℝ (fun t => p*t/(2*(p+2))) l
  simp only [div_eq_mul_inv]
  exact (analyticAt_const.mul analyticAt_id).mul analyticAt_const

theorem analyticAt_lowAngleB (p l : ℝ) : AnalyticAt ℝ (lowAngleB p) l := by
  change AnalyticAt ℝ (fun t => (1+p*t)/(p+1)) l
  simp only [div_eq_mul_inv]
  exact (analyticAt_const.add (analyticAt_const.mul analyticAt_id)).mul analyticAt_const

theorem analyticAt_lowAngleC (p l : ℝ) : AnalyticAt ℝ (lowAngleC p) l :=
  analyticAt_const.add (analyticAt_id.div analyticAt_const (by norm_num))

theorem analyticAt_lowAngleDeficit (p l : ℝ) : AnalyticAt ℝ (lowAngleDeficit p) l := by
  change AnalyticAt ℝ (fun t => (p+2+p*t)/(p*(p+1)*(p+2))) l
  simp only [div_eq_mul_inv]
  exact (analyticAt_const.add (analyticAt_const.mul analyticAt_id)).mul analyticAt_const

theorem analyticAt_densityOrderEnergy {p l r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) :
    AnalyticAt ℝ (fun q : ℝ×ℝ => densityOrderEnergy p q.1 q.2) (l,r) := by
  have hpow : AnalyticAt ℝ (fun q : ℝ×ℝ => q.2^p) (l,r) :=
    (analyticAt_rpow_const p r hr).comp_of_eq analyticAt_snd rfl
  have hA : AnalyticAt ℝ (fun q : ℝ×ℝ => lowAngleA p q.1) (l,r) :=
    (analyticAt_lowAngleA p l).comp_of_eq analyticAt_fst rfl
  have hB : AnalyticAt ℝ (fun q : ℝ×ℝ => lowAngleB p q.1) (l,r) :=
    (analyticAt_lowAngleB p l).comp_of_eq analyticAt_fst rfl
  have hC : AnalyticAt ℝ (fun q : ℝ×ℝ => lowAngleC p q.1) (l,r) :=
    (analyticAt_lowAngleC p l).comp_of_eq analyticAt_fst rfl
  have hδ : AnalyticAt ℝ (fun q : ℝ×ℝ => lowAngleDeficit p q.1) (l,r) :=
    (analyticAt_lowAngleDeficit p l).comp_of_eq analyticAt_fst rfl
  exact (hpow.mul (((hA.mul (analyticAt_snd.pow 2)).add
    (hB.mul analyticAt_snd)).add hC)).div hδ (lowAngleDeficit_pos hp hl.le).ne'

theorem hasDerivAt_densityOrderEnergy {p l r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) :
    HasDerivAt (densityOrderEnergy p l)
      (rayEnergySlope p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r/
        lowAngleDeficit p l) r :=
  (hasDerivAt_rayEnergy p _ _ _ hr).div_const _

/-- Joint analyticity of the actual global inverse, including the parameter
direction. No inverse-regularity hypothesis is supplied. -/
theorem analyticAt_densityOrderInverse {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    AnalyticAt ℝ (fun q : ℝ×ℝ => densityOrderInverse p q.1 q.2) (l,v) := by
  let r := densityOrderInverse p l v
  have hr : 0<r := densityOrderInverse_pos hp hl hv
  have he : densityOrderEnergy p l r=v := densityOrderEnergy_inverse hp hl hv
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
  have hd : deriv (densityOrderEnergy p l) r≠0 := by
    rw [(hasDerivAt_densityOrderEnergy hp hl hr).deriv]
    exact (div_pos (rayEnergySlope_pos hp hA hB.le hC hr)
      (lowAngleDeficit_pos hp hl.le)).ne'
  obtain ⟨I,hI,hI0,hIR,hIL⟩ := GeneralMechanical.exists_analytic_fiber_inverse_germ
    (analyticAt_densityOrderEnergy hp hl hr) hd
  change AnalyticAt ℝ I (l,densityOrderEnergy p l r) at hI
  rw [he] at hI hI0 hIR
  have hposI : ∀ᶠ q in 𝓝 (l,v),0<I q := by
    apply hI.continuousAt.eventually
    rw [hI0]
    exact Ioi_mem_nhds hr
  have hposl : ∀ᶠ q : ℝ×ℝ in 𝓝 (l,v),0<q.1 :=
    continuousAt_fst.eventually (Ioi_mem_nhds hl)
  apply hI.congr
  filter_upwards [hIR,hposI,hposl] with q hq hqr hql
  exact (densityOrderInverse_eq_of_energy hp hql hqr hq).symm

theorem hasDerivAt_lowAngleA (p l : ℝ) :
    HasDerivAt (lowAngleA p) (p/(2*(p+2))) l := by
  simpa only [lowAngleA,mul_one] using ((hasDerivAt_id l).const_mul p).div_const (2*(p+2))

theorem hasDerivAt_lowAngleB (p l : ℝ) :
    HasDerivAt (lowAngleB p) (p/(p+1)) l := by
  simpa only [lowAngleB,mul_one,zero_add] using
    (((hasDerivAt_id l).const_mul p).const_add 1).div_const (p+1)

theorem hasDerivAt_lowAngleC (p l : ℝ) :
    HasDerivAt (lowAngleC p) (1/2) l := by
  simpa only [lowAngleC,zero_add] using ((hasDerivAt_id l).div_const 2).const_add (1/p)

theorem hasDerivAt_lowAngleDeficit (p l : ℝ) :
    HasDerivAt (lowAngleDeficit p) (p/(p*(p+1)*(p+2))) l := by
  simpa only [lowAngleDeficit,mul_one,zero_add] using
    (((hasDerivAt_id l).const_mul p).const_add (p+2)).div_const (p*(p+1)*(p+2))

theorem hasDerivAt_lowAngleU_curve {p l d : ℝ} {r : ℝ→ℝ}
    (hr : 0<r l) (hd : HasDerivAt r d l) :
    HasDerivAt (fun t => lowAngleU p t (r t))
      (rayEnergySlope p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) (r l)*d+
        (r l)^p*densityOrderPolynomialVariation p (r l)) l := by
  have hpow := (Real.hasDerivAt_rpow_const (p:=p) (Or.inl hr.ne')).comp l hd
  have hpol := (((hasDerivAt_lowAngleA p l).mul (hd.pow 2)).add
    ((hasDerivAt_lowAngleB p l).mul hd)).add (hasDerivAt_lowAngleC p l)
  convert hpow.mul hpol using 1
  dsimp only [rayEnergySlope,rayEulerPolynomial,rayPolynomial,densityOrderPolynomialVariation]
  rw [Real.rpow_sub_one hr.ne']
  field_simp
  <;> ring

theorem densityOrderInverseVariation_identity {p l r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) :
    (p/(p*(p+1)*(p+2))*densityOrderEnergy p l r-
      r^p*densityOrderPolynomialVariation p r)/
      rayEnergySlope p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r=
      densityOrderInverseVariation p l r := by
  have hp0 : p≠0 := hp.ne'
  have hp1 : p+1≠0 := by positivity
  have hp2 : p+2≠0 := by positivity
  have hK : l*p+p+2≠0 := by positivity
  have hT : l*p*(r+1)+2≠0 := by positivity
  have hpow : r^p≠0 := (Real.rpow_pos_of_pos hr p).ne'
  have hr1 : r+1≠0 := by positivity
  have hδ : lowAngleDeficit p l≠0 := (lowAngleDeficit_pos hp hl.le).ne'
  dsimp only [rayEnergySlope]
  rw [lowAngle_euler_factor hp,Real.rpow_sub_one hr.ne']
  dsimp only [densityOrderEnergy,lowAngleU,rayEnergy,rayPolynomial,lowAngleA,lowAngleB,
    lowAngleC,lowAngleDeficit,densityOrderPolynomialVariation,densityOrderInverseVariation]
  field_simp
  <;> ring

/-- The exact implicit parameter derivative belongs to the constructed global
positive inverse, at every positive normalized energy. -/
theorem hasDerivAt_densityOrderInverse_parameter {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    HasDerivAt (fun t => densityOrderInverse p t v)
      (densityOrderInverseVariation p l (densityOrderInverse p l v)) l := by
  let r := densityOrderInverse p l v
  have hr : 0<r := densityOrderInverse_pos hp hl hv
  have hd := (analyticAt_densityOrderInverse hp hl hv).curry_left.differentiableAt.hasDerivAt
  have he : (fun t => lowAngleU p t (densityOrderInverse p t v))=ᶠ[𝓝 l]
      (fun t => lowAngleDeficit p t*v) := by
    filter_upwards [Ioi_mem_nhds hl] with t ht
    exact densityOrderInverse_energy hp ht hv
  have hdiff := ((hasDerivAt_lowAngleU_curve hr hd).congr_of_eventuallyEq he.symm).unique
    ((hasDerivAt_lowAngleDeficit p l).mul_const v)
  have hv' : densityOrderEnergy p l r=v := densityOrderEnergy_inverse hp hl hv
  have hs : rayEnergySlope p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r≠0 := by
    obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl.le
    exact (rayEnergySlope_pos hp hA hB.le hC hr).ne'
  have heq : deriv (fun t => densityOrderInverse p t v) l=
      (p/(p*(p+1)*(p+2))*densityOrderEnergy p l r-
        r^p*densityOrderPolynomialVariation p r)/
        rayEnergySlope p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r := by
    apply (eq_div_iff hs).mpr
    rw [hv']
    change rayEnergySlope p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r*
        deriv (fun t => densityOrderInverse p t v) l+
        r^p*densityOrderPolynomialVariation p r=p/(p*(p+1)*(p+2))*v at hdiff
    linarith only [hdiff]
  rw [densityOrderInverseVariation_identity hp hl hr] at heq
  exact heq ▸ hd

end LeanVerification.UpperLeftCompletion
