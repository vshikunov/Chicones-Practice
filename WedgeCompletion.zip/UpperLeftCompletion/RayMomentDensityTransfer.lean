import LeanVerification.UpperLeftCompletion.RayMomentIntegral

/-! Likelihood-ratio transfer of the actual normalized moments.  Absolute
integrability, the density order, and the single kernel crossing are all
proved for the functions used here. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 2400000

theorem integral_one_crossing_likelihood_neg {K f g : ℝ→ℝ} {v₀ : ℝ}
    (hv₀ : 0<v₀) (hzero : K v₀=0)
    (hleft : ∀v,0<v → v<v₀ → 0<K v)
    (hright : ∀v,v₀<v → K v<0)
    (hf : ∀v,0<v → 0<f v) (hg : ∀v,0<v → 0<g v)
    (horder : MonotoneOn (fun v => f v/g v) (Ioi (0:ℝ)))
    (hif : IntegrableOn (fun v => K v*f v) (Ioi (0:ℝ)))
    (hig : IntegrableOn (fun v => K v*g v) (Ioi (0:ℝ)))
    (hneg : (∫v in Ioi (0:ℝ),K v*g v)<0) :
    (∫v in Ioi (0:ℝ),K v*f v)<0 := by
  let q := f v₀/g v₀
  have hq : 0<q := div_pos (hf v₀ hv₀) (hg v₀ hv₀)
  have hbound : ∀v∈Ioi (0:ℝ),K v*f v≤q*(K v*g v) := by
    intro v hv
    rcases lt_trichotomy v v₀ with hlt|heq|hgt
    · have hr : f v/g v≤q := horder hv hv₀ hlt.le
      have hfg : f v≤q*g v := (div_le_iff₀ (hg v hv)).mp hr
      calc
        _ ≤ K v*(q*g v) := mul_le_mul_of_nonneg_left hfg (hleft v hv hlt).le
        _ = _ := by ring
    · rw [heq,hzero]
      simp
    · have hr : q≤f v/g v := horder hv₀ hv hgt.le
      have hfg : q*g v≤f v := (le_div_iff₀ (hg v hv)).mp hr
      calc
        _ ≤ K v*(q*g v) := mul_le_mul_of_nonpos_left hfg (hright v hgt).le
        _ = _ := by ring
  have hi := integral_mono_ae hif (hig.const_mul q)
    ((ae_restrict_mem measurableSet_Ioi).mono hbound)
  rw [integral_const_mul] at hi
  exact hi.trans_lt (mul_neg_of_pos_of_neg hq hneg)

/-- A negative reference moment at Λ remains negative for every smaller
positive λ in the same angular range. -/
theorem densityOrderMoment_neg_transfer (k : ℕ) (hk : 0<k) {p l L : ℝ}
    (hp : 0<p) (hpu : p<1) (hl : 0<l) (hlL : l<L)
    (hklo : Real.pi/2<(k:ℝ)*(Real.pi*(1-p)))
    (hkhi : (k:ℝ)*(Real.pi*(1-p))≤3*Real.pi/2)
    (hneg : densityOrderMoment k p L<0) : densityOrderMoment k p l<0 := by
  have hL : 0<L := hl.trans hlL
  have hθ : 0<Real.pi*(1-p) := mul_pos Real.pi_pos (by linarith)
  have hθu : Real.pi*(1-p)<Real.pi := by nlinarith [mul_pos Real.pi_pos hp]
  obtain ⟨v₀,hv₀,hphase,hzero,hleft,hright⟩ := rayMomentKernel_single_crossing hθ hθu hklo hkhi
  rw [densityOrderMoment_eq] at hneg ⊢
  exact integral_one_crossing_likelihood_neg hv₀ hzero hleft hright
    (fun v hv => densityOrderDensity_pos hp hl hv)
    (fun v hv => densityOrderDensity_pos hp hL hv)
    (densityOrder_ratio_strictMonoOn hp hl hlL).monotoneOn
    (integrable_densityOrderMoment k hk hp hpu hl)
    (integrable_densityOrderMoment k hk hp hpu hL) hneg

theorem densityOrder_signedJetIntegral_neg_iff (n : ℕ) {p l : ℝ}
    (hp : 0<p) (hpu : p<1) (hl : 0<l) :
    ((-1:ℝ)^(n+1)*negativeRayJetIntegral n p (lowAngleA p l) (lowAngleB p l)
      (lowAngleC p l) (lowAngleDeficit p l)<0) ↔ densityOrderMoment (n+1) p l<0 := by
  rw [densityOrderMoment_actual_normalization n hp hpu hl]
  have hc := mul_pos (negativeRayCoefficient_pos (n+1))
    (Real.rpow_pos_of_pos (lowAngleDeficit_pos hp hl.le) (-(n:ℝ)-1/2))
  constructor
  · intro h
    by_contra hn
    exact (not_lt_of_ge (mul_nonneg hc.le (le_of_not_gt hn))) h
  · intro h
    exact mul_neg_of_pos_of_neg hc h

theorem densityOrder_signedJetIntegral_neg_transfer (n : ℕ) {p l L : ℝ}
    (hp : 0<p) (hpu : p<1) (hl : 0<l) (hlL : l<L)
    (hklo : Real.pi/2<((n+1:ℕ):ℝ)*(Real.pi*(1-p)))
    (hkhi : ((n+1:ℕ):ℝ)*(Real.pi*(1-p))≤3*Real.pi/2)
    (hneg : (-1:ℝ)^(n+1)*negativeRayJetIntegral n p (lowAngleA p L) (lowAngleB p L)
      (lowAngleC p L) (lowAngleDeficit p L)<0) :
    (-1:ℝ)^(n+1)*negativeRayJetIntegral n p (lowAngleA p l) (lowAngleB p l)
      (lowAngleC p l) (lowAngleDeficit p l)<0 := by
  apply (densityOrder_signedJetIntegral_neg_iff n hp hpu hl).mpr
  apply densityOrderMoment_neg_transfer (n+1) (by omega) hp hpu hl hlL hklo hkhi
  exact (densityOrder_signedJetIntegral_neg_iff n hp hpu (hl.trans hlL)).mp hneg

/-- Actual first-ray-jet sign transfer, used to propagate N(center)<0. -/
theorem densityOrder_firstJet_center_pos_transfer {p l L : ℝ}
    (hp : 0<p) (hpu : p<1/2) (hl : 0<l) (hlL : l<L)
    (hpos : 0<negativeRayJetIntegral 0 p (lowAngleA p L) (lowAngleB p L)
      (lowAngleC p L) (lowAngleDeficit p L)) :
    0<negativeRayJetIntegral 0 p (lowAngleA p l) (lowAngleB p l)
      (lowAngleC p l) (lowAngleDeficit p l) := by
  have hlo : Real.pi/2<((0+1:ℕ):ℝ)*(Real.pi*(1-p)) := by
    norm_num
    nlinarith [mul_pos Real.pi_pos (show 0<1/2-p by linarith)]
  have hhi : ((0+1:ℕ):ℝ)*(Real.pi*(1-p))≤3*Real.pi/2 := by
    norm_num
    nlinarith [Real.pi_pos,mul_pos Real.pi_pos hp]
  have h := densityOrder_signedJetIntegral_neg_transfer 0 hp (by linarith) hl hlL hlo hhi
    (by simpa only [Nat.zero_add,pow_one,neg_one_mul,neg_neg_iff_pos] using hpos)
  simpa only [Nat.zero_add,pow_one,neg_one_mul,neg_neg_iff_pos] using h

/-- Actual second-ray-jet sign transfer, used to propagate N'(center)>0. -/
theorem densityOrder_secondJet_center_neg_transfer {p l L : ℝ}
    (hp : 1/4≤p) (hpu : p<3/4) (hl : 0<l) (hlL : l<L)
    (hneg : negativeRayJetIntegral 1 p (lowAngleA p L) (lowAngleB p L)
      (lowAngleC p L) (lowAngleDeficit p L)<0) :
    negativeRayJetIntegral 1 p (lowAngleA p l) (lowAngleB p l)
      (lowAngleC p l) (lowAngleDeficit p l)<0 := by
  have hlo : Real.pi/2<((1+1:ℕ):ℝ)*(Real.pi*(1-p)) := by
    norm_num
    nlinarith [mul_pos Real.pi_pos (show 0<3/4-p by linarith)]
  have hhi : ((1+1:ℕ):ℝ)*(Real.pi*(1-p))≤3*Real.pi/2 := by
    norm_num
    nlinarith [mul_nonneg Real.pi_pos.le (show 0≤p-1/4 by linarith)]
  have h := densityOrder_signedJetIntegral_neg_transfer 1 (by linarith) (by linarith)
    hl hlL hlo hhi (by simpa only [Nat.reduceAdd,neg_one_sq,one_mul] using hneg)
  simpa only [Nat.reduceAdd,neg_one_sq,one_mul] using h

end LeanVerification.UpperLeftCompletion
