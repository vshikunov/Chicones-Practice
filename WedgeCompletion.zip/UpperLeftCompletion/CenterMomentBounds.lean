import LeanVerification.UpperLeftCompletion.LowAngleBounds
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Data.Complex.ExponentialBounds
import Mathlib.Data.Real.Pi.Bounds

/-! Strict center-moment comparisons for the actual terminal coefficient data.
The proofs use explicit positive polynomial certificates and an exponential
partial sum; no numerical oracle or monotonicity claim is assumed. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
set_option maxHeartbeats 4000000
set_option maxRecDepth 6000

def centerMomentExpLower (p : ℝ) : ℝ :=
  1+14*p/5+(14*p/5)^2/2+(14*p/5)^3/6

def centerMomentZeroPolynomial (p : ℝ) : ℝ :=
  (157/50:ℝ)^2*(3*p^2-6*p+8)^2*
    (3*p+4+(p+4)*centerMomentExpLower p)^2-
      9216*p*(p+4)*(p+1)^2*(p+2)^2

def centerMomentOnePolynomial (p : ℝ) : ℝ :=
  (157/50:ℝ)^2*(p+1)^4*(13*p^2+26*p+1)^2-1296*p^3*(p+2)^5

theorem centerMomentZeroPolynomial_certificate (p : ℝ) :
    368640000000000*centerMomentZeroPolynomial p=
    14887497498624000000*(4*p)^0*(1-(4*p))^12+
    173620736085196800000*(4*p)^1*(1-(4*p))^11+
    919787082319134720000*(4*p)^2*(1-(4*p))^10+
    2921861020888596480000*(4*p)^3*(1-(4*p))^9+
    6184167390615148953600*(4*p)^4*(1-(4*p))^8+
    9156863197025936670720*(4*p)^5*(1-(4*p))^7+
    9679133439659394187264*(4*p)^6*(1-(4*p))^6+
    7304022017348017983488*(4*p)^7*(1-(4*p))^5+
    3856336484364793939520*(4*p)^8*(1-(4*p))^4+
    1356908655427419867680*(4*p)^9*(1-(4*p))^3+
    286509538322267188820*(4*p)^10*(1-(4*p))^2+
    27569853658961602748*(4*p)^11*(1-(4*p))^1+
    24047680865787241*(4*p)^12*(1-(4*p))^0 := by
  dsimp [centerMomentZeroPolynomial,centerMomentExpLower]
  ring

theorem centerMomentZeroPolynomial_pos {p : ℝ} (hp : 0<p) (hpu : p≤1/4) :
    0<centerMomentZeroPolynomial p := by
  have ht : 0≤1-(4*p) := by linarith
  have hh : 0<368640000000000*centerMomentZeroPolynomial p := by
    rw [centerMomentZeroPolynomial_certificate]
    positivity
  nlinarith

theorem centerMomentOnePolynomial_certificate (p : ℝ) :
    976562500*centerMomentOnePolynomial p=
    9628515625*(5*p/2)^0*(1-(5*p/2))^8+
    292706875000*(5*p/2)^1*(1-(5*p/2))^7+
    3190504937500*(5*p/2)^2*(1-(5*p/2))^6+
    13285037125000*(5*p/2)^3*(1-(5*p/2))^5+
    27344254153750*(5*p/2)^4*(1-(5*p/2))^4+
    30342941197000*(5*p/2)^5*(1-(5*p/2))^3+
    17800299521500*(5*p/2)^6*(1-(5*p/2))^2+
    4695308353720*(5*p/2)^7*(1-(5*p/2))^1+
    271543396681*(5*p/2)^8*(1-(5*p/2))^0 := by
  dsimp [centerMomentOnePolynomial,centerMomentExpLower]
  ring

theorem centerMomentOnePolynomial_pos {p : ℝ} (hp : 0<p) (hpu : p≤2/5) :
    0<centerMomentOnePolynomial p := by
  have ht : 0≤1-(5*p/2) := by linarith
  have hh : 0<976562500*centerMomentOnePolynomial p := by
    rw [centerMomentOnePolynomial_certificate]
    positivity
  nlinarith

theorem log_seventeen_gt : (14/5:ℝ)<Real.log 17 := by
  have h2 := Real.log_two_gt_d9
  have h17 := Real.le_log_one_add_of_nonneg (by norm_num : (0:ℝ)≤1/16)
  norm_num at h17
  have he : Real.log (17:ℝ)=4*Real.log 2+Real.log (17/16) := by
    calc
      Real.log (17:ℝ)=Real.log ((2:ℝ)^4*(17/16)) := by norm_num
      _ = Real.log ((2:ℝ)^4)+Real.log (17/16) := Real.log_mul (by norm_num) (by norm_num)
      _ = _ := by rw [Real.log_pow]; norm_num
  rw [he]
  linarith

theorem centerMoment_power_lower {p : ℝ} (hp : 0<p) (hpu : p≤1/4) :
    centerMomentExpLower p≤((p+4)/p)^p := by
  have hw : 0<(p+4)/p := by positivity
  have hw17 : (17:ℝ)≤(p+4)/p := (le_div_iff₀ hp).mpr (by linarith)
  have hl : (14/5:ℝ)≤Real.log ((p+4)/p) :=
    log_seventeen_gt.le.trans (Real.log_le_log (by norm_num) hw17)
  have hx : 0≤14*p/5 := by positivity
  have he := Real.sum_le_exp_of_nonneg hx 4
  norm_num [Finset.sum_range_succ,Nat.factorial] at he
  have hm : 14*p/5≤Real.log ((p+4)/p)*p := by
    nlinarith [mul_le_mul_of_nonneg_right hl hp.le]
  rw [Real.rpow_def_of_pos hw]
  exact he.trans (Real.exp_le_exp.mpr hm)

def centerMomentTauOne (p : ℝ) : ℝ := (3*p^2/4-3*p/2+2)/24
def centerMomentTauTwo (p : ℝ) : ℝ := (p+1)^2*(13*p^2+26*p+1)/576

def centerMomentR0 (p : ℝ) : ℝ :=
  2*Real.pi*centerMomentTauOne p*
    (lowAngleDeficit p (1/2)+((p+4)/p)^(p+1)/(2*(p+1)*(p+2)))/
      Real.sqrt ((p+4)/p)

def centerMomentR1 (p : ℝ) : ℝ :=
  16*Real.pi*centerMomentTauTwo p/(p^((3:ℝ)/2)*(p+2)^((5:ℝ)/2))

theorem centerMomentR0_eq {p : ℝ} (hp : 0<p) :
    centerMomentR0 p=
      Real.pi*(3*p^2-6*p+8)*(3*p+4+(p+4)*((p+4)/p)^p)/
        (96*p*(p+1)*(p+2)*Real.sqrt ((p+4)/p)) := by
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  have hw : 0<(p+4)/p := by positivity
  have hs : Real.sqrt ((p+4)/p)≠0 := (Real.sqrt_pos.mpr hw).ne'
  dsimp [centerMomentR0,centerMomentTauOne,lowAngleDeficit]
  rw [Real.rpow_add_one hw.ne']
  field_simp
  <;> ring

theorem centerMomentR0_gt_one {p : ℝ} (hp : 0<p) (hpu : p≤1/4) :
    1<centerMomentR0 p := by
  let Q := 3*p^2-6*p+8
  let Z := 3*p+4+(p+4)*centerMomentExpLower p
  let H := 96*p*(p+1)*(p+2)*Real.sqrt ((p+4)/p)
  have hQ : 0<Q := by dsimp [Q]; nlinarith [sq_nonneg (p-1)]
  have hExp : 0<centerMomentExpLower p := by dsimp [centerMomentExpLower]; positivity
  have hZ : 0<Z := by dsimp [Z]; positivity
  have hw : 0<(p+4)/p := by positivity
  have hs := Real.sqrt_pos.mpr hw
  have hH : 0<H := by dsimp [H]; positivity
  have hHsq : H^2=9216*p*(p+4)*(p+1)^2*(p+2)^2 := by
    dsimp [H]
    rw [mul_pow,Real.sq_sqrt hw.le]
    field_simp
    <;> ring
  have hcert := centerMomentZeroPolynomial_pos hp hpu
  have hLH : H<(157/50:ℝ)*Q*Z := by
    have hL : 0<(157/50:ℝ)*Q*Z := by positivity
    dsimp [centerMomentZeroPolynomial] at hcert
    change (157/50:ℝ)^2*Q^2*Z^2-9216*p*(p+4)*(p+1)^2*(p+2)^2>0 at hcert
    nlinarith [hHsq]
  have hpi : (157/50:ℝ)≤Real.pi := by linarith [Real.pi_gt_d2]
  have hpw := centerMoment_power_lower hp hpu
  have hnum : (157/50:ℝ)*Q*Z≤
      Real.pi*Q*(3*p+4+(p+4)*((p+4)/p)^p) := by
    dsimp only [Z]
    gcongr
  rw [centerMomentR0_eq hp]
  apply (one_lt_div hH).mpr
  exact hLH.trans_le hnum

theorem centerMomentR1_eq {p : ℝ} (hp : 0<p) :
    centerMomentR1 p=Real.pi*(p+1)^2*(13*p^2+26*p+1)/
      (36*p*(p+2)^2*Real.sqrt p*Real.sqrt (p+2)) := by
  have hp2 : 0<p+2 := by positivity
  have hr1 : p^((3:ℝ)/2)=p*Real.sqrt p := by
    calc
      _ = p^((1:ℝ)+1/2) := by norm_num
      _ = p^(1:ℝ)*p^((1:ℝ)/2) := Real.rpow_add hp _ _
      _ = _ := by rw [Real.rpow_one,Real.sqrt_eq_rpow]
  have hr2 : (p+2)^((5:ℝ)/2)=(p+2)^2*Real.sqrt (p+2) := by
    rw [Real.sqrt_eq_rpow,←Real.rpow_natCast,←Real.rpow_add hp2]
    norm_num
  dsimp [centerMomentR1,centerMomentTauTwo]
  rw [hr1,hr2]
  have hs1 := (Real.sqrt_pos.mpr hp).ne'
  have hs2 := (Real.sqrt_pos.mpr hp2).ne'
  field_simp [hp.ne',hp2.ne']
  <;> ring

theorem centerMomentR1_gt_one {p : ℝ} (hp : 0<p) (hpu : p≤2/5) :
    1<centerMomentR1 p := by
  let Q := (p+1)^2*(13*p^2+26*p+1)
  let H := 36*p*(p+2)^2*Real.sqrt p*Real.sqrt (p+2)
  have hQ : 0<Q := by dsimp [Q]; positivity
  have hH : 0<H := by dsimp [H]; positivity
  have hHsq : H^2=1296*p^3*(p+2)^5 := by
    dsimp [H]
    simp only [mul_pow,Real.sq_sqrt hp.le,Real.sq_sqrt (show 0≤p+2 by positivity)]
    ring
  have hcert := centerMomentOnePolynomial_pos hp hpu
  have hLH : H<(157/50:ℝ)*Q := by
    have hL : 0<(157/50:ℝ)*Q := by positivity
    dsimp [centerMomentOnePolynomial] at hcert
    have he : (p+1)^4*(13*p^2+26*p+1)^2=Q^2 := by dsimp [Q]; ring
    rw [mul_assoc,he] at hcert
    nlinarith [hHsq]
  have hpi : (157/50:ℝ)<Real.pi := by linarith [Real.pi_gt_d2]
  have hnum := mul_lt_mul_of_pos_right hpi hQ
  rw [centerMomentR1_eq hp]
  apply (one_lt_div hH).mpr
  simpa only [Q,mul_assoc] using hLH.trans hnum

end LeanVerification.UpperLeftCompletion
