import LeanVerification.ContourCompletion.NegativeRayDifferentiation

/-! A direct real certificate for the actual negative-ray density
elasticity.  This comparison uses no exterior spectral representation. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 2200000

def rayPolynomial (A B C r : ℝ) : ℝ := A*r^2+B*r+C

def rayEulerPolynomial (p A B C r : ℝ) : ℝ :=
  (p+2)*A*r^2+(p+1)*B*r+p*C

def rayEulerSlope (p A B r : ℝ) : ℝ := 2*(p+2)*A*r+(p+1)*B

def rayElasticity (p A B C r : ℝ) : ℝ :=
  rayPolynomial A B C r*((1-p/2)*rayEulerPolynomial p A B C r-
    r*rayEulerSlope p A B r)/(rayEulerPolynomial p A B C r)^2

def rayElasticityNumerator (p A B C r : ℝ) : ℝ :=
  A^2*B*p*(p+2)*r^4+
  A*(4*A*C*p^2+B^2*p*(p+5)+4*(B^2-4*A*C))*r^3+
  6*A*B*C*p*(p+3)*r^2+
  C*(4*A*C*p*(p+6)+B^2*p*(p+1))*r+
  B*C^2*p*(p+4)

theorem rayPolynomial_pos {A B C r : ℝ} (hA : 0≤A) (hB : 0≤B) (hC : 0<C)
    (hr : 0<r) : 0<rayPolynomial A B C r := by
  unfold rayPolynomial
  positivity

theorem rayEulerPolynomial_pos {p A B C r : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0≤B) (hC : 0<C) (hr : 0<r) :
    0<rayEulerPolynomial p A B C r := by
  unfold rayEulerPolynomial
  positivity

theorem hasDerivAt_rayPolynomial (A B C r : ℝ) :
    HasDerivAt (rayPolynomial A B C) (2*A*r+B) r := by
  convert ((((hasDerivAt_id r).pow 2).const_mul A).add
    ((hasDerivAt_id r).const_mul B)).add_const C using 1 <;>
    simp only [rayPolynomial,pow_one,mul_one,id_eq] <;> ring

theorem hasDerivAt_rayEulerPolynomial (p A B C r : ℝ) :
    HasDerivAt (rayEulerPolynomial p A B C) (rayEulerSlope p A B r) r := by
  convert (hasDerivAt_rayPolynomial ((p+2)*A) ((p+1)*B) (p*C) r) using 1 <;>
    simp only [rayEulerPolynomial,rayPolynomial,rayEulerSlope] <;> ring

theorem hasDerivAt_rayEulerSlope (p A B r : ℝ) :
    HasDerivAt (rayEulerSlope p A B) (2*(p+2)*A) r := by
  simpa only [rayEulerSlope,mul_one] using
    ((hasDerivAt_id r).const_mul (2*(p+2)*A)).add_const ((p+1)*B)

/-- The only potentially negative coefficient is the discriminant term;
all others are positive when the ray polynomial has two negative roots. -/
theorem rayElasticityNumerator_pos {p A B C r : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C)
    (hdisc : 4*A*C≤B^2) (hr : 0<r) :
    0<rayElasticityNumerator p A B C r := by
  have hd : 0≤B^2-4*A*C := sub_nonneg.mpr hdisc
  unfold rayElasticityNumerator
  positivity

theorem hasDerivAt_rayElasticity (p A B C r : ℝ)
    (hH : rayEulerPolynomial p A B C r≠0) :
    HasDerivAt (rayElasticity p A B C)
      (-rayElasticityNumerator p A B C r/(2*(rayEulerPolynomial p A B C r)^3)) r := by
  have hP := hasDerivAt_rayPolynomial A B C r
  have hE := hasDerivAt_rayEulerPolynomial p A B C r
  have hS := hasDerivAt_rayEulerSlope p A B r
  have hN := hP.mul ((hE.const_mul (1-p/2)).sub ((hasDerivAt_id r).mul hS))
  have hd := hN.div (hE.pow 2) (pow_ne_zero 2 hH)
  convert hd using 1
  simp only [id_eq] 
  field_simp [hH]
  dsimp only [rayElasticityNumerator,rayPolynomial,rayEulerPolynomial,rayEulerSlope]
  ring

theorem rayElasticity_deriv_neg {p A B C r : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C)
    (hdisc : 4*A*C≤B^2) (hr : 0<r) :
    deriv (rayElasticity p A B C) r<0 := by
  have hH := rayEulerPolynomial_pos hp hA hB.le hC hr
  rw [(hasDerivAt_rayElasticity p A B C r hH.ne').deriv]
  exact div_neg_of_neg_of_pos (neg_neg_of_pos (rayElasticityNumerator_pos hp hA hB hC hdisc hr))
    (by positivity)

theorem rayElasticity_strictAntiOn {p A B C : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hdisc : 4*A*C≤B^2) :
    StrictAntiOn (rayElasticity p A B C) (Ioi (0 : ℝ)) := by
  apply strictAntiOn_of_deriv_neg (convex_Ioi _)
  · intro r hr
    exact (hasDerivAt_rayElasticity p A B C r
      (rayEulerPolynomial_pos hp hA hB.le hC hr).ne').continuousAt.continuousWithinAt
  · intro r hr
    rw [interior_Ioi] at hr
    exact rayElasticity_deriv_neg hp hA hB hC hdisc hr

theorem loudTurn_discriminant_identity {D F : ℝ} (hF : 1<F) :
    (loudTurnB D F)^2-4*loudTurnA D F*loudTurnC D F=
      (D+F)*(F-D-1)/(F*(F-1)*(2*F-1)^2) := by
  have hF₀ : F≠0 := by linarith
  have hF₁ : F-1≠0 := by linarith
  have hF₂ : 2*F-1≠0 := by linarith
  have hF₃ : 2*F-2≠0 := by linarith
  dsimp only [loudTurnA,loudTurnB,loudTurnC]
  field_simp
  <;> ring

theorem loudTurn_discriminant_pos {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hDF : -F<D) :
    4*loudTurnA D F*loudTurnC D F<(loudTurnB D F)^2 := by
  apply sub_pos.mp
  rw [loudTurn_discriminant_identity hF]
  have h₁ : 0<D+F := by linarith
  have h₂ : 0<F-D-1 := by linarith
  have h₃ : 0<F*(F-1)*(2*F-1)^2 := by
    have hF₀ : 0<F := by linarith
    have hF₁ : 0<F-1 := by linarith
    have hF₂ : 0<2*F-1 := by linarith
    positivity
  exact div_pos (mul_pos h₁ h₂) h₃

def physicalRayElasticity (D F r : ℝ) : ℝ :=
  rayElasticity (2*F-2) (loudTurnA D F) (loudTurnB D F) (loudTurnC D F) r

theorem physicalRayElasticity_strictAntiOn {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hDF : -F<D) :
    StrictAntiOn (physicalRayElasticity D F) (Ioi (0 : ℝ)) := by
  have hc := loudTurn_coefficients_pos D F hD hF
  exact rayElasticity_strictAntiOn (by linarith) hc.1.le hc.2.1 hc.2.2
    (loudTurn_discriminant_pos hD hF hDF).le

end LeanVerification.UpperLeftCompletion
