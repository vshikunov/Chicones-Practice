import LeanVerification.UpperLeftCompletion.ActualRayOrientation
import LeanVerification.UpperLeftCompletion.PhysicalLowAngleData
import LeanVerification.ExteriorSpectralCompletion.WeightedAbel

/-! Interior curvature at every actual stationary period, obtained from
the strict ray inequality and the weighted actual exterior Abel bound. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion ExteriorCompletion ExteriorSpectralCompletion Sharpness RegionalComplex
set_option maxHeartbeats 1800000

theorem tau1_pos_low_upper_left {D F : ℝ} (hD : D≤ -1) (hF : F≤9/8) :
    0<tau1Polynomial D F := by
  have hd : 0≤ -D-1 := by linarith
  have hf : 0≤9/8-F := by linarith
  have he : tau1Polynomial D F=
      5*(-D-1)^2/6+5*(-D-1)*(9/8-F)/6+13*(-D-1)/16+
        (9/8-F)^2/3+(9/8-F)/2+1/64 := by
    dsimp only [tau1Polynomial]
    ring
  rw [he]
  positivity

theorem actual_critical_curvature_of_ray_bracket {D F h : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<5/4) (hDF : -F<D)
    (hh : AdmissibleEnergy D F h)
    (hb : 0<physicalRayElasticity D F
      (rayInverse (upperLeftRayP F) (loudTurnA D F) (loudTurnB D F) (loudTurnC D F)
        ((zeroEndpointHeight D F-h)*lowAngleCrossing (upperLeftRayP F)))-1/2+
      (zeroEndpointHeight D F-h)/
        ((zeroEndpointHeight D F-h)-exteriorEnergy D F (exteriorSaddle D)))
    (hz : physicalContourPeriodJet D F hD hF 0 h=0) :
    0<physicalContourPeriodJet D F hD hF 1 h := by
  let δ := zeroEndpointHeight D F-h
  let M := exteriorM D F hD hF δ
  let J := exteriorAbelJet D F hD hF 1 δ
  let R₀ := negativeRayJetIntegral 0 (2*F-2) (loudTurnA D F) (loudTurnB D F) (loudTurnC D F) δ
  let R₁ := negativeRayJetIntegral 1 (2*F-2) (loudTurnA D F) (loudTurnB D F) (loudTurnC D F) δ
  let E := physicalRayElasticity D F
    (rayInverse (upperLeftRayP F) (loudTurnA D F) (loudTurnB D F) (loudTurnC D F)
      (δ*lowAngleCrossing (upperLeftRayP F)))
  let z := δ-exteriorEnergy D F (exteriorSaddle D)
  have hδ : 0<δ := loudTurn_actual_deficit_pos D F h hD hF hh
  have hm := physical_deficit_mem_exteriorRange D F h hD hF hh
  have hzp : 0<z := by
    rw [exteriorRange_eq D F hD hF] at hm
    exact sub_pos.mpr hm
  have hMp : 0<M := exteriorAbelJet_pos D F δ hD hF 0 hm
  have hs : Real.sqrt (2:ℝ)≠0 := (Real.sqrt_pos.mpr (by norm_num)).ne'
  have hzero : M+R₀=0 := by
    have he : Real.sqrt 2*(M+R₀)=0 := by
      simpa only [physicalContourPeriodJet,exteriorM,pow_zero,one_mul,M,R₀,δ] using hz
    exact (mul_eq_zero.mp he).resolve_left hs
  have hR₀ : R₀= -M := by linarith
  obtain ⟨hA,hB,hC⟩ := loudTurn_coefficients_pos D F hD hF
  have hi := actual_first_ray_crossing_inequality (p:=2*F-2)
    (by linarith) (by linarith) hA hB hC (loudTurn_discriminant_pos hD hF hDF).le hδ
  change 0<δ*(-R₁)-(E-1/2)*(-R₀) at hi
  rw [hR₀,neg_neg] at hi
  have hext : M≤z*J := actual_exteriorM_weighted_derivative D F δ hD hF hm
  have hext' : M/z≤J := (div_le_iff₀ hzp).mpr (by simpa only [mul_comm] using hext)
  have hextδ := mul_le_mul_of_nonneg_left hext' hδ.le
  change 0<E-1/2+δ/z at hb
  have hMb := mul_pos hMp hb
  have hrewrite : M*(E-1/2+δ/z)=(E-1/2)*M+δ*(M/z) := by ring
  rw [hrewrite] at hMb
  have hp : 0<δ*(J-R₁) := by
    calc
      0 < (δ*(-R₁)-(E-1/2)*M)+((E-1/2)*M+δ*(M/z)) := add_pos hi hMb
      _ = δ*(-R₁)+δ*(M/z) := by ring
      _ ≤ δ*(-R₁)+δ*J := add_le_add_left hextδ _
      _ = δ*(J-R₁) := by ring
  have hJ : 0<J-R₁ := (mul_pos_iff_of_pos_left hδ).mp hp
  have hfinal := mul_pos (Real.sqrt_pos.mpr (by norm_num : (0:ℝ)<2)) hJ
  simpa only [physicalContourPeriodJet,pow_one,neg_one_mul,←sub_eq_add_neg,J,R₁,δ] using hfinal

theorem physical_period_deriv_pos_low_upper_left (D F h : ℝ)
    (hD : D< -1) (hF : 1<F) (hFu : F≤29/26) (hDF : -F<D)
    (hh : AdmissibleEnergy D F h) : 0<deriv (periodQuadrature D F) h := by
  apply physical_period_deriv_pos_of_critical_curvature hD hF (by linarith)
    (tau1_pos_low_upper_left hD.le (by linarith)) ?_ hh
  intro k hk hz
  have hd := loudTurn_actual_deficit_pos D F k hD hF hk
  have hdc : zeroEndpointHeight D F-k≤zeroEndpointHeight D F := sub_le_self _ hk.1.le
  exact actual_critical_curvature_of_ray_bracket hD hF (by linarith) hDF hk
    (physical_ray_bracket_pos_low D F _ hD hF hFu hDF hd hdc) hz

theorem physical_period_deriv_pos_high_mixture (D F h : ℝ)
    (hD : D< -1) (hF : 1<F) (hFu : F≤9/8) (hDF : -F<D)
    (hl : 1/2≤upperLeftRayLambda D F)
    (hh : AdmissibleEnergy D F h) : 0<deriv (periodQuadrature D F) h := by
  apply physical_period_deriv_pos_of_critical_curvature hD hF (by linarith)
    (tau1_pos_low_upper_left hD.le hFu) ?_ hh
  intro k hk hz
  have hd := loudTurn_actual_deficit_pos D F k hD hF hk
  have hdc : zeroEndpointHeight D F-k≤zeroEndpointHeight D F := sub_le_self _ hk.1.le
  exact actual_critical_curvature_of_ray_bracket hD hF (by linarith) hDF hk
    (physical_ray_bracket_pos_high_mixture D F _ hD hF hFu hDF hl hd hdc) hz

theorem criticalPeriodBound_zero_low_upper_left (D F : ℝ)
    (hD : D< -1) (hF : 1<F) (hFu : F≤29/26) (hDF : -F<D) :
    CriticalPeriodBound 0 D F :=
  RegionalReal.criticalPeriodBound_zero_of_deriv_ne_zero
    (fun h hh => (physical_period_deriv_pos_low_upper_left D F h hD hF hFu hDF hh).ne')

theorem full_regional_row15 (D F : ℝ) (h : parameterRegion 15 D F) :
    CriticalPeriodBound (parameterRegionBound 15) D F :=
  criticalPeriodBound_zero_low_upper_left D F h.2.2.2 h.1 h.2.1 h.2.2.1

end LeanVerification.UpperLeftCompletion
