import LeanVerification.UpperLeftCompletion.RayKernelCrossing
import LeanVerification.UpperLeftCompletion.DensityOrder

/-! Exact normalization of the actual negative-ray jets to the principal
moment kernels. Positive real scaling preserves the chosen square-root sheet. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 4000

theorem principalSquareRoot_posReal_mul {a : ℝ} {z : ℂ}
    (ha : 0<a) (hz : z≠0) :
    principalSquareRoot ((a:ℂ)*z)=(Real.sqrt a:ℂ)*principalSquareRoot z := by
  rw [principalSquareRoot,Complex.log_ofReal_mul ha hz,add_div,Complex.exp_add]
  congr 1
  rw [←Complex.ofReal_ofNat,←Complex.ofReal_div,←Complex.ofReal_exp,
    Real.sqrt_eq_rpow,Real.rpow_def_of_pos ha]
  congr 2
  ring

theorem negativeRayPower_rayMomentUnit (p : ℝ) {r : ℝ} (hr : 0<r) :
    negativeRayPower p r= -((r^(-p):ℝ):ℂ)*rayMomentUnit (Real.pi*(1-p)) := by
  have he : Real.pi*(1-p)=Real.pi-Real.pi*p := by ring
  apply Complex.ext
  · rw [negativeRayPower_re p hr]
    simp only [Complex.mul_re,Complex.neg_re,Complex.ofReal_re,Complex.neg_im,
      Complex.ofReal_im,neg_zero,zero_mul,sub_zero,rayMomentUnit_re,he,Real.cos_pi_sub]
    ring
  · rw [negativeRayPower_im p hr]
    simp only [Complex.mul_im,Complex.neg_re,Complex.ofReal_re,Complex.neg_im,
      Complex.ofReal_im,neg_zero,zero_mul,add_zero,rayMomentUnit_im,he,Real.sin_pi_sub]

theorem negativeRayRadicand_normalized (p A B C : ℝ) {δ r : ℝ}
    (hδ : 0<δ) (hr : 0<r) :
    negativeRayRadicand p A B C δ r=
      ((δ*r^(-p):ℝ):ℂ)*
        (((rayEnergy p A B C r/δ:ℝ):ℂ)+rayMomentUnit (Real.pi*(1-p))) := by
  have hδc : (δ:ℂ)≠0 := Complex.ofReal_ne_zero.mpr hδ.ne'
  have hpow : r^(-p)*r^p=1 := by rw [←Real.rpow_add hr];simp
  have hpowc : ((r^(-p):ℝ):ℂ)*((r^p:ℝ):ℂ)=1 := by exact_mod_cast hpow
  rw [negativeRayRadicand,negativeRayPower_rayMomentUnit p hr]
  dsimp only [rayEnergy,rayPolynomial]
  push_cast
  field_simp [hδc]
  linear_combination -((A:ℂ)*(r:ℂ)^2+(B:ℂ)*(r:ℂ)+(C:ℂ))*(δ:ℂ)*hpowc

theorem rayMoment_sqrt_scale {p δ r : ℝ} (hδ : 0<δ) (hr : 0<r) :
    Real.sqrt (δ*r^(-p))=δ^(1/2:ℝ)*r^(-p/2) := by
  rw [Real.sqrt_eq_rpow,Real.mul_rpow hδ.le (Real.rpow_nonneg hr.le _),
    ←Real.rpow_mul hr.le]
  congr 1
  ring

theorem rayMoment_inverse_scale {p δ r : ℝ} (hδ : 0<δ) (hr : 0<r) :
    (Real.sqrt (δ*r^(-p)))⁻¹=r^(p/2)*δ^(-1/2:ℝ) := by
  rw [rayMoment_sqrt_scale hδ hr,mul_inv_rev,←Real.rpow_neg hr.le,←Real.rpow_neg hδ.le]
  congr 1 <;> congr 1 <;> ring

theorem negativeRayKernel_normalized (A B C : ℝ) {p δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hδ : 0<δ) (hr : 0<r) :
    negativeRayKernel p A B C δ r=
      ((r^(p/2)*δ^(-1/2:ℝ):ℝ):ℂ)*
        (principalSquareRoot (((rayEnergy p A B C r/δ:ℝ):ℂ)+
          rayMomentUnit (Real.pi*(1-p))))⁻¹ := by
  have hθ : 0<Real.pi*(1-p) := mul_pos Real.pi_pos (by linarith)
  have hθu : Real.pi*(1-p)<Real.pi := by nlinarith [mul_pos Real.pi_pos hp]
  rw [negativeRayKernel,negativeRayRadicand_normalized p A B C hδ hr,
    principalSquareRoot_posReal_mul (mul_pos hδ (Real.rpow_pos_of_pos hr _))
      (rayMoment_shift_ne_zero hθ hθu _),mul_inv_rev]
  rw [←Complex.ofReal_inv,rayMoment_inverse_scale hδ hr]
  exact mul_comm _ _

theorem rayMoment_power_scale (k : ℕ) {p δ r : ℝ} (hδ : 0<δ) (hr : 0<r) :
    (r^(-p))^k*(r^(p/2)*δ^(-1/2:ℝ))^(2*k+1)=
      r^(p/2)*δ^(-(k:ℝ)-1/2) := by
  rw [mul_pow,←Real.rpow_mul_natCast hr.le,←Real.rpow_mul_natCast hr.le,
    ←Real.rpow_mul_natCast hδ.le,←mul_assoc,←Real.rpow_add hr]
  congr 1
  · congr 1
    push_cast
    ring
  · congr 1
    push_cast
    ring

/-- Complex identity before taking the real part. The signed factor is
precisely (-1)^k because the negative-ray power equals -r^(-p)ζ. -/
theorem negativeRayJet_normalized (k : ℕ) (A B C : ℝ) {p δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hδ : 0<δ) (hr : 0<r) :
    negativeRayJet k p A B C δ r=
      (((-1:ℝ)^k*negativeRayCoefficient k*r^(p/2)*δ^(-(k:ℝ)-1/2):ℝ):ℂ)*
        ((rayMomentUnit (Real.pi*(1-p)))^k/
          (principalSquareRoot (((rayEnergy p A B C r/δ:ℝ):ℂ)+
            rayMomentUnit (Real.pi*(1-p))))^(2*k+1)) := by
  rw [negativeRayJet,negativeRayPower_rayMomentUnit p hr,
    negativeRayKernel_normalized A B C hp hpu hδ hr]
  have hscale := congrArg (fun x : ℝ => (x:ℂ)) (rayMoment_power_scale k (p:=p) hδ hr)
  push_cast at hscale ⊢
  rw [neg_mul,neg_pow,mul_pow,mul_pow,inv_pow,div_eq_mul_inv]
  calc
    _ = (-1:ℂ)^k*(negativeRayCoefficient k:ℂ)*
        (((r^(-p):ℝ):ℂ)^k*((r^(p/2):ℝ)*((δ^(-1/2:ℝ):ℝ):ℂ))^(2*k+1))*
        ((rayMomentUnit (Real.pi*(1-p)))^k*
          ((principalSquareRoot (((rayEnergy p A B C r/δ:ℝ):ℂ)+
            rayMomentUnit (Real.pi*(1-p))))^(2*k+1))⁻¹) := by push_cast;ring
    _ = _ := by rw [hscale];push_cast;ring

theorem negativeRayJet_real_normalized (k : ℕ) (A B C : ℝ) {p δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hδ : 0<δ) (hr : 0<r) :
    (negativeRayJet k p A B C δ r).re=
      (-1:ℝ)^k*negativeRayCoefficient k*r^(p/2)*δ^(-(k:ℝ)-1/2)*
        rayMomentKernel k (Real.pi*(1-p)) (rayEnergy p A B C r/δ) := by
  rw [negativeRayJet_normalized k A B C hp hpu hδ hr,Complex.mul_re]
  simp only [Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero,rayMomentKernel]

theorem negativeRayJet_signed_normalized (k : ℕ) (A B C : ℝ) {p δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hδ : 0<δ) (hr : 0<r) :
    (-1:ℝ)^k*(negativeRayJet k p A B C δ r).re=
      negativeRayCoefficient k*r^(p/2)*δ^(-(k:ℝ)-1/2)*
        rayMomentKernel k (Real.pi*(1-p)) (rayEnergy p A B C r/δ) := by
  rw [negativeRayJet_real_normalized k A B C hp hpu hδ hr]
  have hs : (-1:ℝ)^k*(-1:ℝ)^k=1 := by rw [←mul_pow];simp
  linear_combination negativeRayCoefficient k*r^(p/2)*δ^(-(k:ℝ)-1/2)*
    rayMomentKernel k (Real.pi*(1-p)) (rayEnergy p A B C r/δ)*hs

end LeanVerification.UpperLeftCompletion
