import LeanVerification.UpperLeftCompletion.CriticalCurvature
import LeanVerification.UpperLeftCompletion.CenterMomentApplication
import LeanVerification.UpperLeftCompletion.RayMomentDensityTransfer

/-! Three complete regional table rows for the original-time physical
period.  The density comparison, actual center signs, interior ray bounds,
exterior bounds, contour identities, and zero propagation are all proved
in the imported modules.  These final statements have only the stated
regional parameter and admissible-energy hypotheses. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion ExteriorCompletion Sharpness RegionalComplex
set_option maxHeartbeats 1800000

theorem physical_ray_zero_center_pos_small_mixture (D F : ℝ)
    (hD : D< -1) (hF : 1<F) (hFu : F≤9/8) (hDF : -F<D)
    (hl : upperLeftRayLambda D F<1/2) :
    0<negativeRayJetIntegral 0 (2*F-2) (loudTurnA D F) (loudTurnB D F)
      (loudTurnC D F) (zeroEndpointHeight D F) := by
  obtain ⟨hp,hl0,_⟩ := physical_lowAngle_parameters hD hF hDF
  have hpu : upperLeftRayP F≤1/4 := by dsimp only [upperLeftRayP];linarith
  have hc := densityOrder_firstJet_center_pos_transfer hp (by linarith) hl0 hl
    (actual_ray_zero_center_half_pos hp hpu)
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  simpa only [hA,hB,hC,physical_lowAngle_center_height D F hF,upperLeftRayP] using hc

theorem physical_period_deriv_pos_small_mixture (D F h : ℝ)
    (hD : D< -1) (hF : 1<F) (hFu : F≤9/8) (hDF : -F<D)
    (hl : upperLeftRayLambda D F<1/2) (hh : AdmissibleEnergy D F h) :
    0<deriv (periodQuadrature D F) h := by
  obtain ⟨hA,hB,hC⟩ := loudTurn_coefficients_pos D F hD hF
  have hδ := loudTurn_actual_deficit_pos D F h hD hF hh
  have hδH : zeroEndpointHeight D F-h≤zeroEndpointHeight D F := sub_le_self _ hh.1.le
  have hraw := actual_ray_zero_positive_of_center (p:=2*F-2)
    (by linarith) (by linarith) hA hB hC (loudTurn_discriminant_pos hD hF hDF).le hδ hδH
      (physical_ray_zero_center_pos_small_mixture D F hD hF hFu hDF hl)
  have hm := exteriorAbelJet_pos D F (zeroEndpointHeight D F-h) hD hF 0
    (physical_deficit_mem_exteriorRange D F h hD hF hh)
  rw [actual_physical_period_first_derivative hD hF (by linarith) hh]
  simp only [physicalNegativeRayN,sub_neg_eq_add,exteriorM]
  exact mul_pos (Real.sqrt_pos.mpr (by norm_num)) (add_pos hm hraw)

/-- The physical period increases on the whole combined low-angle strip,
including the shared edge F=29/26. -/
theorem physical_period_deriv_pos_upper_left_quarter (D F h : ℝ)
    (hD : D< -1) (hF : 1<F) (hFu : F≤9/8) (hDF : -F<D)
    (hh : AdmissibleEnergy D F h) : 0<deriv (periodQuadrature D F) h := by
  by_cases hl : 1/2≤upperLeftRayLambda D F
  · exact physical_period_deriv_pos_high_mixture D F h hD hF hFu hDF hl hh
  · exact physical_period_deriv_pos_small_mixture D F h hD hF hFu hDF (lt_of_not_ge hl) hh

theorem criticalPeriodBound_zero_upper_left_quarter (D F : ℝ)
    (hD : D< -1) (hF : 1<F) (hFu : F≤9/8) (hDF : -F<D) :
    CriticalPeriodBound 0 D F :=
  RegionalReal.criticalPeriodBound_zero_of_deriv_ne_zero
    (fun h hh => (physical_period_deriv_pos_upper_left_quarter D F h hD hF hFu hDF hh).ne')

theorem full_regional_row16 (D F : ℝ) (h : parameterRegion 16 D F) :
    CriticalPeriodBound (parameterRegionBound 16) D F :=
  criticalPeriodBound_zero_upper_left_quarter D F h.2.2.2 (by linarith [h.1]) h.2.1 h.2.2.1

theorem physical_ray_one_center_neg_next_strip (D F : ℝ)
    (hD : D< -1) (hFl : 9/8≤F) (hFu : F≤6/5) (hDF : -F<D) :
    negativeRayJetIntegral 1 (2*F-2) (loudTurnA D F) (loudTurnB D F)
      (loudTurnC D F) (zeroEndpointHeight D F)<0 := by
  have hF : 1<F := by linarith
  obtain ⟨hp,hl0,hlu⟩ := physical_lowAngle_parameters hD hF hDF
  have hpl : 1/4≤upperLeftRayP F := by dsimp only [upperLeftRayP];linarith
  have hpu : upperLeftRayP F≤2/5 := by dsimp only [upperLeftRayP];linarith
  have hc := densityOrder_secondJet_center_neg_transfer hpl (by linarith) hl0 hlu
    (actual_ray_one_center_terminal_neg hp hpu)
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  simpa only [hA,hB,hC,physical_lowAngle_center_height D F hF,upperLeftRayP] using hc

/-- Strict positivity of the second physical period derivative on the
entire annulus; no endpoint-continuity estimate is substituted for it. -/
theorem physical_contour_curvature_pos_next_strip (D F h : ℝ)
    (hD : D< -1) (hFl : 9/8≤F) (hFu : F≤6/5) (hDF : -F<D)
    (hh : AdmissibleEnergy D F h) :
    0<physicalContourPeriodJet D F hD (show 1<F by linarith) 1 h := by
  have hF : 1<F := by linarith
  obtain ⟨hA,hB,hC⟩ := loudTurn_coefficients_pos D F hD hF
  have hδ := loudTurn_actual_deficit_pos D F h hD hF hh
  have hδH : zeroEndpointHeight D F-h≤zeroEndpointHeight D F := sub_le_self _ hh.1.le
  have hraw := actual_ray_one_negative_of_center (p:=2*F-2)
    (by linarith) (by linarith) hA hB hC (loudTurn_discriminant_pos hD hF hDF).le hδ hδH
      (physical_ray_one_center_neg_next_strip D F hD hFl hFu hDF)
  have hm := exteriorAbelJet_pos D F (zeroEndpointHeight D F-h) hD hF 1
    (physical_deficit_mem_exteriorRange D F h hD hF hh)
  have hsum : 0<exteriorAbelJet D F hD hF 1 (zeroEndpointHeight D F-h)-
      negativeRayJetIntegral 1 (2*F-2) (loudTurnA D F) (loudTurnB D F)
        (loudTurnC D F) (zeroEndpointHeight D F-h) := by linarith
  simpa only [physicalContourPeriodJet,pow_one,neg_one_mul,←sub_eq_add_neg] using
    mul_pos (Real.sqrt_pos.mpr (by norm_num : (0:ℝ)<2)) hsum

theorem physical_period_second_derivative_pos_next_strip (D F h : ℝ)
    (hD : D< -1) (hFl : 9/8≤F) (hFu : F≤6/5) (hDF : -F<D)
    (hh : AdmissibleEnergy D F h) : 0<deriv (deriv (periodQuadrature D F)) h := by
  rw [physical_period_second_derivative_eq hD (by linarith) (by linarith) hh]
  exact physical_contour_curvature_pos_next_strip D F h hD hFl hFu hDF hh

theorem criticalPeriodBound_one_upper_left_next_strip (D F : ℝ)
    (hD : D< -1) (hFl : 9/8≤F) (hFu : F≤6/5) (hDF : -F<D) :
    CriticalPeriodBound 1 D F :=
  criticalPeriodBound_one_of_contour_curvature hD (by linarith) (by linarith)
    (fun h hh => physical_contour_curvature_pos_next_strip D F h hD hFl hFu hDF hh)

theorem full_regional_row17 (D F : ℝ) (h : parameterRegion 17 D F) :
    CriticalPeriodBound (parameterRegionBound 17) D F :=
  criticalPeriodBound_one_upper_left_next_strip D F h.2.2.2 h.1 h.2.1 h.2.2.1

/-- The three newly completed whole table rows, with their original bounds. -/
theorem full_regional_rows15_16_17 (i : Fin 23) (hi : i=15 ∨ i=16 ∨ i=17)
    (D F : ℝ) (h : parameterRegion i D F) : CriticalPeriodBound (parameterRegionBound i) D F := by
  rcases hi with rfl|rfl|rfl
  · exact full_regional_row15 D F h
  · exact full_regional_row16 D F h
  · exact full_regional_row17 D F h

end LeanVerification.UpperLeftCompletion
