import LeanVerification.UpperLeftCompletion.RayEulerBounds

/-! The complete improper Euler identity for the actual negative-ray
moments, including the strict one-crossing comparison. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 1200000

theorem hasDerivAt_rayEulerJetPrimitive (n : ℕ) {p A B C δ r : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0≤A) (hB : 0≤B) (hC : 0<C)
    (hδ : 0<δ) (hr : 0<r) :
    HasDerivAt (rayEulerJetPrimitive n p A B C δ)
      ((rayElasticity p A B C r-(n:ℝ)-1/2)*(negativeRayJet (n+1) p A B C δ r).re-
        δ*(negativeRayJet (n+1+1) p A B C δ r).re) r := by
  have hd := Complex.reCLM.hasFDerivAt.comp_hasDerivAt r
    (hasDerivAt_rayEulerPrimitive (n+1) A B C hp hpu hδ hr
      (rayEulerPolynomial_pos hp hA hB hC hr).ne')
  convert hd using 1
  · funext x
    simp only [rayEulerJetPrimitive,Complex.mul_re,Complex.ofReal_re,
      Complex.ofReal_im,zero_mul,sub_zero,Complex.reCLM_apply,Function.comp_apply]
  · simp only [Complex.sub_re,Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,
      zero_mul,sub_zero,Complex.reCLM_apply,Nat.cast_add,Nat.cast_one]
    ring

theorem integrable_rayEuler_weight (n : ℕ) {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0<A) (hB : 0≤B) (hC : 0<C)
    (hδ : 0<δ) (c : ℝ) :
    IntegrableOn (fun r => (rayElasticity p A B C r-c)*
      (negativeRayJet (n+1) p A B C δ r).re) (Ioi 0) := by
  have he := integrable_rayElasticity_jet n hp hpu hA hB hC hδ
  have hj : IntegrableOn (fun r => (negativeRayJet (n+1) p A B C δ r).re)
      (Ioi (0:ℝ)) := (integrableOn_negativeRayJet n hp hpu hA hB hC.le hδ).re
  change Integrable _ (volume.restrict (Ioi (0:ℝ)))
  change Integrable _ (volume.restrict (Ioi (0:ℝ))) at he hj
  convert he.sub (hj.const_mul c) using 1
  funext r
  dsimp only [Pi.sub_apply]
  ring

theorem actual_rayEuler_identity (n : ℕ) {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0<A) (hB : 0≤B) (hC : 0<C) (hδ : 0<δ) :
    δ*negativeRayJetIntegral (n+1) p A B C δ =
      ∫r in Ioi (0:ℝ), (rayElasticity p A B C r-(n:ℝ)-1/2)*
        (negativeRayJet (n+1) p A B C δ r).re := by
  have hiw : IntegrableOn (fun r => (rayElasticity p A B C r-(n:ℝ)-1/2)*
      (negativeRayJet (n+1) p A B C δ r).re) (Ioi 0) := by
    convert integrable_rayEuler_weight n hp hpu hA hB hC hδ ((n:ℝ)+1/2) using 1
    funext r
    ring
  have hij : IntegrableOn (fun r => δ*(negativeRayJet (n+1+1) p A B C δ r).re)
      (Ioi (0:ℝ)) :=
    ((integrableOn_negativeRayJet (n+1) hp hpu hA hB hC.le hδ).re).const_mul δ
  have he := integral_Ioi_of_hasDerivAt_of_tendsto
    (rayEulerJetPrimitive_continuous_zero n hp hpu hA hB hC hδ)
    (fun r hr => hasDerivAt_rayEulerJetPrimitive n hp hpu hA.le hB hC hδ hr)
    (Integrable.sub hiw hij) (rayEulerJetPrimitive_tendsto_top n hp hpu hA hB hC hδ)
  rw [rayEulerJetPrimitive_zero,sub_self,integral_sub hiw hij,integral_const_mul] at he
  exact (sub_eq_zero.mp he).symm

theorem actual_rayEuler_shifted_identity (n : ℕ) {p A B C δ : ℝ}
    (hp : 0<p) (hpu : p<1) (hA : 0<A) (hB : 0≤B) (hC : 0<C)
    (hδ : 0<δ) (c : ℝ) :
    δ*negativeRayJetIntegral (n+1) p A B C δ-
        (c-(n:ℝ)-1/2)*negativeRayJetIntegral n p A B C δ =
      ∫r in Ioi (0:ℝ), (rayElasticity p A B C r-c)*
        (negativeRayJet (n+1) p A B C δ r).re := by
  rw [actual_rayEuler_identity n hp hpu hA hB hC hδ]
  have hiw : IntegrableOn (fun r => (rayElasticity p A B C r-(n:ℝ)-1/2)*
      (negativeRayJet (n+1) p A B C δ r).re) (Ioi 0) := by
    convert integrable_rayEuler_weight n hp hpu hA hB hC hδ ((n:ℝ)+1/2) using 1
    funext r
    ring
  have hij : IntegrableOn (fun r => (c-(n:ℝ)-1/2)*
      (negativeRayJet (n+1) p A B C δ r).re) (Ioi (0:ℝ)) :=
    ((integrableOn_negativeRayJet n hp hpu hA hB hC.le hδ).re).const_mul (c-(n:ℝ)-1/2)
  rw [negativeRayJetIntegral,←integral_const_mul,←integral_sub hiw hij]
  apply integral_congr_ae
  exact Filter.Eventually.of_forall (fun r => by ring)

theorem integral_decreasing_weight_one_crossing_pos {E K : ℝ → ℝ} {r₀ : ℝ}
    (hr₀ : 0<r₀) (hE : StrictAntiOn E (Ioi 0))
    (hleft : ∀r,0<r → r<r₀ → 0<K r) (hright : ∀r,r₀<r → K r<0)
    (hi : IntegrableOn (fun r => (E r-E r₀)*K r) (Ioi 0)) :
    0<∫r in Ioi (0:ℝ), (E r-E r₀)*K r := by
  have hn : ∀r∈Ioi (0:ℝ),0≤(E r-E r₀)*K r := by
    intro r hr
    rcases lt_trichotomy r r₀ with hl|he|hg
    · exact (mul_pos (sub_pos.mpr (hE hr hr₀ hl)) (hleft r hr hl)).le
    · simp [he]
    · exact (mul_pos_of_neg_of_neg (sub_neg.mpr (hE hr₀ hr hg)) (hright r hg)).le
  apply (setIntegral_pos_iff_support_of_nonneg_ae
    ((ae_restrict_mem measurableSet_Ioi).mono hn) hi).2
  have hm : 0<volume (Ioo (0:ℝ) r₀) := by
    rw [Real.volume_Ioo]
    exact ENNReal.ofReal_pos.mpr (by simpa using hr₀)
  refine hm.trans_le (measure_mono ?_)
  intro r hr
  exact ⟨(mul_pos (sub_pos.mpr (hE hr.1 hr₀ hr.2))
    (hleft r hr.1 hr.2)).ne',hr.1⟩

theorem actual_rayEuler_one_crossing (n : ℕ) {p A B C δ r₀ : ℝ} (σ : ℝ)
    (hp : 0<p) (hpu : p<1) (hA : 0<A) (hB : 0<B) (hC : 0<C)
    (hdisc : 4*A*C≤B^2) (hδ : 0<δ) (hr₀ : 0<r₀)
    (hleft : ∀r,0<r → r<r₀ → 0<σ*(negativeRayJet (n+1) p A B C δ r).re)
    (hright : ∀r,r₀<r → σ*(negativeRayJet (n+1) p A B C δ r).re<0) :
    0<σ*(δ*negativeRayJetIntegral (n+1) p A B C δ-
      (rayElasticity p A B C r₀-(n:ℝ)-1/2)*negativeRayJetIntegral n p A B C δ) := by
  rw [actual_rayEuler_shifted_identity n hp hpu hA hB.le hC hδ]
  rw [←integral_const_mul]
  have hi := (integrable_rayEuler_weight n hp hpu hA hB.le hC hδ
    (rayElasticity p A B C r₀)).const_mul σ
  have hf : (fun r => σ*((rayElasticity p A B C r-rayElasticity p A B C r₀)*
      (negativeRayJet (n+1) p A B C δ r).re)) =
      (fun r => (rayElasticity p A B C r-rayElasticity p A B C r₀)*
        (σ*(negativeRayJet (n+1) p A B C δ r).re)) := by
    funext r
    ring
  rw [hf] at hi ⊢
  exact integral_decreasing_weight_one_crossing_pos hr₀
    (rayElasticity_strictAntiOn hp hA.le hB hC hdisc) hleft hright hi

end LeanVerification.UpperLeftCompletion
