import LeanVerification.UpperLeftCompletion.LowAngleBoundsBracket
import LeanVerification.UpperLeftCompletion.CenterMomentBounds
import LeanVerification.ExteriorCompletion.RealInverse
import LeanVerification.Sharpness.TauPolynomials

/-! Exact physical normalization for the low-angle comparison.  The
deficit and exterior depth are the original Loud potential values, and
the center coefficients are those of the actual original-time period. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion ExteriorCompletion Sharpness RegionalComplex
set_option maxHeartbeats 2600000

def lowAngleParameterD (p l : ℝ) : ℝ := -1-p*l/2
def lowAngleParameterF (p : ℝ) : ℝ := 1+p/2

theorem lowAngleParameterF_gt_one {p : ℝ} (hp : 0<p) : 1<lowAngleParameterF p := by
  dsimp only [lowAngleParameterF]
  linarith

theorem lowAngleParameterD_lt_neg_one {p l : ℝ} (hp : 0<p) (hl : 0<l) :
    lowAngleParameterD p l< -1 := by
  dsimp only [lowAngleParameterD]
  nlinarith [mul_pos hp hl]

theorem lowAngleParameter_rayP (p : ℝ) : upperLeftRayP (lowAngleParameterF p)=p := by
  dsimp only [upperLeftRayP,lowAngleParameterF]
  ring

theorem lowAngleParameter_rayLambda {p l : ℝ} (hp : 0<p) :
    upperLeftRayLambda (lowAngleParameterD p l) (lowAngleParameterF p)=l := by
  dsimp only [upperLeftRayLambda]
  rw [lowAngleParameter_rayP]
  dsimp only [lowAngleParameterD]
  field_simp
  <;> ring

theorem physical_lowAngle_parameters {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hDF : -F<D) :
    0<upperLeftRayP F ∧ 0<upperLeftRayLambda D F ∧ upperLeftRayLambda D F<1 := by
  have hp : 0<upperLeftRayP F := by dsimp only [upperLeftRayP];linarith
  refine ⟨hp,div_pos (by linarith) hp,?_⟩
  apply (div_lt_iff₀ hp).mpr
  dsimp only [upperLeftRayP]
  linarith

theorem physical_lowAngle_parameterD (D F : ℝ) (hF : 1<F) :
    lowAngleParameterD (upperLeftRayP F) (upperLeftRayLambda D F)=D := by
  have hp : upperLeftRayP F≠0 := ne_of_gt (by dsimp only [upperLeftRayP];linarith)
  dsimp only [lowAngleParameterD,upperLeftRayLambda]
  field_simp
  <;> ring

theorem physical_lowAngle_parameterF (F : ℝ) : lowAngleParameterF (upperLeftRayP F)=F := by
  dsimp only [lowAngleParameterF,upperLeftRayP]
  ring

theorem lowAngleDeficit_coefficients {p : ℝ} (hp : 0<p) (l : ℝ) :
    lowAngleA p l-lowAngleB p l+lowAngleC p l=lowAngleDeficit p l := by
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  dsimp only [lowAngleDeficit,lowAngleA,lowAngleB,lowAngleC]
  field_simp
  <;> ring

theorem physical_lowAngle_center_height (D F : ℝ) (hF : 1<F) :
    zeroEndpointHeight D F=lowAngleDeficit (upperLeftRayP F) (upperLeftRayLambda D F) := by
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  rw [loudTurn_height_identity,hA,hB,hC]
  exact lowAngleDeficit_coefficients (by dsimp only [upperLeftRayP];linarith) _

theorem lowAngleParameter_center_height {p : ℝ} (hp : 0<p) (l : ℝ) :
    zeroEndpointHeight (lowAngleParameterD p l) (lowAngleParameterF p)=lowAngleDeficit p l := by
  simpa only [lowAngleParameter_rayP,lowAngleParameter_rayLambda hp] using
    physical_lowAngle_center_height (lowAngleParameterD p l) (lowAngleParameterF p)
      (lowAngleParameterF_gt_one hp)

theorem physical_lowAngle_saddle (D F : ℝ) (hD : D< -1) (hF : 1<F) :
    exteriorSaddle D=lowAngleSaddle (upperLeftRayP F) (upperLeftRayLambda D F) := by
  have h0 : D+1≠0 := ne_of_lt (by linarith)
  have hp : upperLeftRayP F≠0 := ne_of_gt (by dsimp only [upperLeftRayP];linarith)
  dsimp only [exteriorSaddle,lowAngleSaddle,upperLeftRayLambda]
  field_simp
  <;> ring

theorem lowAngleSaddle_quadratic {p l : ℝ} (hp : 0<p) (hl : 0<l) :
    -lowAngleA p l*(lowAngleSaddle p l)^2+lowAngleB p l*lowAngleSaddle p l-lowAngleC p l=
      2*(1-l)*(1+p*l/2)/(p*l*(p+1)*(p+2)) := by
  have h0 : p≠0 := hp.ne'
  have hl0 : l≠0 := hl.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  dsimp only [lowAngleSaddle,lowAngleA,lowAngleB,lowAngleC]
  field_simp
  <;> ring

theorem physical_lowAngle_exterior_depth (D F : ℝ) (hD : D< -1) (hF : 1<F) :
    potential D F (exteriorSaddle D)-zeroEndpointHeight D F=
      lowAngleExteriorDepth (upperLeftRayP F) (upperLeftRayLambda D F) := by
  have hp : 0<upperLeftRayP F := by dsimp only [upperLeftRayP];linarith
  have hl : 0<upperLeftRayLambda D F := div_pos (by linarith) hp
  have he := exteriorEnergy_factorization D F (exteriorSaddle D) hF (exteriorSaddle_pos D hD)
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  rw [physical_lowAngle_saddle D F hD hF,hA,hB,hC] at he
  have hq := lowAngleSaddle_quadratic hp hl
  dsimp only [exteriorEnergy] at he
  change potential D F (exteriorSaddle D)-zeroEndpointHeight D F=
    (lowAngleSaddle (upperLeftRayP F) (upperLeftRayLambda D F))^(upperLeftRayP F)*
      2*(1-upperLeftRayLambda D F)*(1+upperLeftRayP F*upperLeftRayLambda D F/2)/
        (upperLeftRayP F*upperLeftRayLambda D F*(upperLeftRayP F+1)*(upperLeftRayP F+2))
  rw [show 2*F-2=upperLeftRayP F from rfl] at he
  have hm := congrArg (fun x : ℝ =>
    (lowAngleSaddle (upperLeftRayP F) (upperLeftRayLambda D F))^(upperLeftRayP F)*x) hq
  dsimp only at hm
  rw [physical_lowAngle_saddle D F hD hF]
  linear_combination -he+hm

theorem lowAngleParameter_exterior_depth {p l : ℝ} (hp : 0<p) (hl : 0<l) :
    potential (lowAngleParameterD p l) (lowAngleParameterF p)
      (exteriorSaddle (lowAngleParameterD p l))-
        zeroEndpointHeight (lowAngleParameterD p l) (lowAngleParameterF p)=
      lowAngleExteriorDepth p l := by
  simpa only [lowAngleParameter_rayP,lowAngleParameter_rayLambda hp] using
    physical_lowAngle_exterior_depth (lowAngleParameterD p l) (lowAngleParameterF p)
      (lowAngleParameterD_lt_neg_one hp hl) (lowAngleParameterF_gt_one hp)

theorem physical_lowAngle_energy_gap (D F d : ℝ) (hD : D< -1) (hF : 1<F) :
    d-exteriorEnergy D F (exteriorSaddle D)=
      d+lowAngleExteriorDepth (upperLeftRayP F) (upperLeftRayLambda D F) := by
  have he := physical_lowAngle_exterior_depth D F hD hF
  dsimp only [exteriorEnergy]
  linarith

theorem lowAngleSaddle_half (p : ℝ) : lowAngleSaddle p (1/2)=(p+4)/p := by
  dsimp only [lowAngleSaddle]
  field_simp
  <;> ring

theorem lowAngleSaddle_terminal (p : ℝ) : lowAngleSaddle p 1=(p+2)/p := by
  dsimp only [lowAngleSaddle]
  ring

theorem lowAngleDeficit_half {p : ℝ} (hp : 0<p) :
    lowAngleDeficit p (1/2)=(3*p+4)/(2*p*(p+1)*(p+2)) := by
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  dsimp only [lowAngleDeficit]
  field_simp
  <;> ring

theorem lowAngleDeficit_terminal {p : ℝ} (hp : 0<p) :
    lowAngleDeficit p 1=2/(p*(p+2)) := by
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  dsimp only [lowAngleDeficit]
  field_simp
  <;> ring

theorem lowAngleExteriorDepth_half {p : ℝ} (hp : 0<p) :
    lowAngleExteriorDepth p (1/2)=((p+4)/p)^(p+1)/(2*(p+1)*(p+2)) := by
  have hw : 0<(p+4)/p := by positivity
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  dsimp only [lowAngleExteriorDepth]
  rw [lowAngleSaddle_half,Real.rpow_add hw,Real.rpow_one]
  field_simp
  <;> ring

theorem lowAngleExteriorDepth_terminal (p : ℝ) : lowAngleExteriorDepth p 1=0 := by
  simp only [lowAngleExteriorDepth,sub_self,mul_zero,zero_mul,zero_div]

theorem tau1_lowAngle_half (p : ℝ) :
    tau1Polynomial (lowAngleParameterD p (1/2)) (lowAngleParameterF p)=centerMomentTauOne p := by
  dsimp only [tau1Polynomial,lowAngleParameterD,lowAngleParameterF,centerMomentTauOne]
  ring

theorem tau2_lowAngle_terminal (p : ℝ) :
    tau2Polynomial (lowAngleParameterD p 1) (lowAngleParameterF p)=centerMomentTauTwo p := by
  dsimp only [tau2Polynomial,lowAngleParameterD,lowAngleParameterF,centerMomentTauTwo]
  ring

theorem actual_tau1_lowAngle_half (p : ℝ) :
    periodCoefficient (lowAngleParameterD p (1/2)) (lowAngleParameterF p) 1=centerMomentTauOne p := by
  rw [actual_tau1_polynomial,tau1_lowAngle_half]

theorem actual_tau2_lowAngle_terminal (p : ℝ) :
    periodCoefficient (lowAngleParameterD p 1) (lowAngleParameterF p) 2=centerMomentTauTwo p := by
  rw [actual_tau2_polynomial,tau2_lowAngle_terminal]

theorem physical_ray_bracket_pos_low (D F d : ℝ)
    (hD : D< -1) (hF : 1<F) (hFu : F≤29/26) (hDF : -F<D)
    (hd : 0<d) (hdc : d≤zeroEndpointHeight D F) :
    0<physicalRayElasticity D F
      (rayInverse (upperLeftRayP F) (loudTurnA D F) (loudTurnB D F)
        (loudTurnC D F) (d*lowAngleCrossing (upperLeftRayP F)))-1/2+
      d/(d-exteriorEnergy D F (exteriorSaddle D)) := by
  obtain ⟨hp,hl,hlu⟩ := physical_lowAngle_parameters hD hF hDF
  have hpu : upperLeftRayP F≤3/13 := by dsimp only [upperLeftRayP];linarith
  rw [physical_lowAngle_center_height D F hF] at hdc
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  rw [physicalRayElasticity_eq_lowAngle D F _ hF,hA,hB,hC,
    physical_lowAngle_energy_gap D F d hD hF]
  exact lowAngleBracket_pos_low hp hpu hl hlu hd hdc

theorem physical_ray_bracket_pos_high_mixture (D F d : ℝ)
    (hD : D< -1) (hF : 1<F) (hFu : F≤9/8) (hDF : -F<D)
    (hl : 1/2≤upperLeftRayLambda D F)
    (hd : 0<d) (hdc : d≤zeroEndpointHeight D F) :
    0<physicalRayElasticity D F
      (rayInverse (upperLeftRayP F) (loudTurnA D F) (loudTurnB D F)
        (loudTurnC D F) (d*lowAngleCrossing (upperLeftRayP F)))-1/2+
      d/(d-exteriorEnergy D F (exteriorSaddle D)) := by
  obtain ⟨hp,hl0,hlu⟩ := physical_lowAngle_parameters hD hF hDF
  have hpu : upperLeftRayP F≤1/4 := by dsimp only [upperLeftRayP];linarith
  rw [physical_lowAngle_center_height D F hF] at hdc
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  rw [physicalRayElasticity_eq_lowAngle D F _ hF,hA,hB,hC,
    physical_lowAngle_energy_gap D F d hD hF]
  exact lowAngleBracket_pos_high_mixture hp hpu hl hlu hd hdc

end LeanVerification.UpperLeftCompletion
