import LeanVerification.UpperLeftCompletion.RayDensity
import LeanVerification.ContourCompletion.PhysicalCoefficients

/-! Exact finite comparisons for the actual low-angle ray elasticity.
The coefficient functions are the original-time Loud coefficients in the
variables p=2F-2 and λ=-2(D+1)/p.  No elasticity inequality is assumed. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion RegionalComplex
set_option maxHeartbeats 2400000
set_option maxRecDepth 4000

def lowAngleA (p l : ℝ) : ℝ := p*l/(2*(p+2))
def lowAngleB (p l : ℝ) : ℝ := (1+p*l)/(p+1)
def lowAngleC (p l : ℝ) : ℝ := 1/p+l/2
def lowAngleDeficit (p l : ℝ) : ℝ := (p+2+p*l)/(p*(p+1)*(p+2))
def lowAngleElasticity (p l r : ℝ) : ℝ :=
  rayElasticity p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r
def lowAngleU (p l r : ℝ) : ℝ :=
  rayEnergy p (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r

theorem lowAngle_coefficients_pos {p l : ℝ} (hp : 0<p) (hl : 0≤l) :
    0≤lowAngleA p l ∧ 0<lowAngleB p l ∧ 0<lowAngleC p l := by
  refine ⟨?_,?_,?_⟩ <;> dsimp [lowAngleA,lowAngleB,lowAngleC] <;> positivity

theorem lowAngleDeficit_pos {p l : ℝ} (hp : 0<p) (hl : 0≤l) :
    0<lowAngleDeficit p l := by
  dsimp [lowAngleDeficit]
  positivity

theorem physical_lowAngle_coefficients (D F : ℝ) (hF : 1<F) :
    loudTurnA D F=lowAngleA (upperLeftRayP F) (upperLeftRayLambda D F) ∧
    loudTurnB D F=lowAngleB (upperLeftRayP F) (upperLeftRayLambda D F) ∧
    loudTurnC D F=lowAngleC (upperLeftRayP F) (upperLeftRayLambda D F) :=
  ⟨loudTurnA_eq_ray D F hF,loudTurnB_eq_ray D F hF,loudTurnC_eq_ray D F hF⟩

theorem physicalRayElasticity_eq_lowAngle (D F r : ℝ) (hF : 1<F) :
    physicalRayElasticity D F r=
      lowAngleElasticity (upperLeftRayP F) (upperLeftRayLambda D F) r := by
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  simp only [physicalRayElasticity,lowAngleElasticity,hA,hB,hC,upperLeftRayP]

def lowAngleOneNumerator (p l : ℝ) : ℝ :=
  2+l*p-(4*l^2*p^5+10*l^2*p^4+5*l^2*p^3+8*l*p^4+
    19*l*p^3+7*l*p^2+4*p^3+9*p^2+p)

theorem lowAngleElasticity_one_identity {p l : ℝ} (hp : 0<p) (hl : 0≤l) :
    lowAngleElasticity p l 1-1/2=
      lowAngleOneNumerator p l/(4*p*(p+1)*(p+2)*(l*p+1)^2) := by
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  have h3 : l*p+1≠0 := by positivity
  dsimp [lowAngleElasticity,rayElasticity,rayPolynomial,rayEulerPolynomial,
    rayEulerSlope,lowAngleA,lowAngleB,lowAngleC,lowAngleOneNumerator]
  field_simp
  <;> ring

theorem lowAngleOneNumerator_pos {p l : ℝ}
    (hp : 0<p) (hpu : p≤1/4) (hl : 0≤l) (hlu : l≤1) :
    0<lowAngleOneNumerator p l := by
  have hb : 4*l^2*p^5+10*l^2*p^4+5*l^2*p^3+8*l*p^4+
      19*l*p^3+7*l*p^2+4*p^3+9*p^2+p ≤ 451/256 := by
    calc
      _ ≤ 4*(1:ℝ)^2*(1/4)^5+10*1^2*(1/4)^4+5*1^2*(1/4)^3+8*1*(1/4)^4+
        19*1*(1/4)^3+7*1*(1/4)^2+4*(1/4)^3+9*(1/4)^2+1/4 := by gcongr
      _ = _ := by norm_num
  have hprod := mul_nonneg hl hp.le
  dsimp only [lowAngleOneNumerator]
  linarith

theorem lowAngleElasticity_one_gt_half {p l : ℝ}
    (hp : 0<p) (hpu : p≤1/4) (hl : 0≤l) (hlu : l≤1) :
    1/2<lowAngleElasticity p l 1 := by
  apply sub_pos.mp
  rw [lowAngleElasticity_one_identity hp hl]
  exact div_pos (lowAngleOneNumerator_pos hp hpu hl hlu) (by positivity)

def lowAngleStar (p l : ℝ) : ℝ :=
  -((16*l*p^2+(8*l+12)*p-9)*
    (32*l*p^3+(56*l+24)*p^2+(9*l+57)*p+18))/
      (64*p*(p+1)*(p+2)*(4*l*p+3)^2)

theorem lowAngleElasticity_star_eq {p l : ℝ} (hp : 0<p) (hl : 0≤l) :
    lowAngleElasticity p l (5/3)=lowAngleStar p l := by
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  have h3 : 4*l*p+3≠0 := by positivity
  dsimp [lowAngleElasticity,rayElasticity,rayPolynomial,rayEulerPolynomial,
    rayEulerSlope,lowAngleA,lowAngleB,lowAngleC,lowAngleStar]
  field_simp
  <;> ring

def lowAngleStarDerivativeCertificate (p l : ℝ) : ℝ :=
  (396*p^4+1746*p^3+2313*p^2+972*p+324)*(1-l)^3+
  (1584*p^5+7752*p^4+14460*p^3+11622*p^2+4212*p+972)*l*(1-l)^2+
  (1792*p^6+8880*p^5+19812*p^4+24366*p^3+16113*p^2+5508*p+972)*l^2*(1-l)+
  (512*p^7+2944*p^6+7712*p^5+11880*p^4+11460*p^3+6804*p^2+2268*p+324)*l^3

theorem lowAngleStarDerivativeCertificate_pos {p l : ℝ}
    (hp : 0<p) (hl : 0≤l) (hlu : l≤1) :
    0<lowAngleStarDerivativeCertificate p l := by
  by_cases he : l=1
  · subst l
    simp only [lowAngleStarDerivativeCertificate,sub_self,zero_pow,
      mul_zero,add_zero,zero_add,one_pow,mul_one]
    positivity
  · have hc : 0<1-l := sub_pos.mpr (lt_of_le_of_ne hlu he)
    dsimp only [lowAngleStarDerivativeCertificate]
    positivity

theorem hasDerivAt_lowAngleStar {p l : ℝ} (hp : 0<p) (hl : 0≤l) :
    HasDerivAt (fun q => lowAngleStar q l)
      (-3*lowAngleStarDerivativeCertificate p l/
        (64*p^2*(p+1)^2*(p+2)^2*(4*l*p+3)^3)) p := by
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  have h3 : 4*l*p+3≠0 := by positivity
  have hd : 64*p*(p+1)*(p+2)*(4*l*p+3)^2≠0 := by positivity
  have hi := hasDerivAt_id p
  have hN1 := (((hi.pow 2).const_mul (16*l)).add (hi.const_mul (8*l+12))).sub_const 9
  have hN2 := ((((hi.pow 3).const_mul (32*l)).add
    ((hi.pow 2).const_mul (56*l+24))).add (hi.const_mul (9*l+57))).add_const 18
  have hD := (((hi.mul (hi.add_const 1)).mul (hi.add_const 2)).mul
    (((hi.const_mul (4*l)).add_const 3).pow 2)).const_mul 64
  have hd' : 64*(p*(p+1)*(p+2)*(4*l*p+3)^2)≠0 := by positivity
  have hquot := (hN1.mul hN2).neg.div hD (by simpa only [id_eq] using hd')
  convert hquot using 1
  · funext q
    dsimp only [lowAngleStar,id_eq]
    ring
  · simp only [id_eq,pow_one,mul_one,one_mul]
    dsimp only [lowAngleStarDerivativeCertificate]
    field_simp
    <;> ring

theorem lowAngleStar_strictAntiOn {l : ℝ} (hl : 0≤l) (hlu : l≤1) :
    StrictAntiOn (fun p => lowAngleStar p l) (Ioi (0:ℝ)) := by
  apply strictAntiOn_of_deriv_neg (convex_Ioi _)
  · intro p hp
    exact (hasDerivAt_lowAngleStar hp hl).continuousAt.continuousWithinAt
  · intro p hp
    rw [interior_Ioi] at hp
    have hp0 : 0<p := hp
    rw [(hasDerivAt_lowAngleStar hp hl).deriv]
    exact div_neg_of_neg_of_pos
      (mul_neg_of_neg_of_pos (by norm_num) (lowAngleStarDerivativeCertificate_pos hp hl hlu))
      (by positivity)

theorem lowAngleStar_quarter (l : ℝ) (hl : 0≤l) :
    lowAngleStar (1/4) l= -((l-2)*(5*l+27))/(12*(l+3)^2) := by
  have h : l+3≠0 := by positivity
  dsimp [lowAngleStar]
  field_simp
  <;> ring

theorem lowAngleStar_quarter_half_identity {l : ℝ} (hl : 0≤l) :
    lowAngleStar (1/4) l-1/2+l/2=
      l*(6*l^2+25*l+1)/(12*(l+3)^2) := by
  have h : l+3≠0 := by positivity
  rw [lowAngleStar_quarter l hl]
  field_simp
  <;> ring

theorem lowAngleElasticity_star_gt_half_sub_half {p l : ℝ}
    (hp : 0<p) (hpu : p≤1/4) (hl : 0<l) (hlu : l≤1) :
    1/2-l/2<lowAngleElasticity p l (5/3) := by
  have hm := (lowAngleStar_strictAntiOn hl.le hlu).antitoneOn
    hp (by norm_num : (0:ℝ)<1/4) hpu
  have hs : 0<lowAngleStar (1/4) l-1/2+l/2 := by
    rw [lowAngleStar_quarter_half_identity hl.le]
    positivity
  rw [lowAngleElasticity_star_eq hp hl.le]
  linarith

theorem lowAngleStar_three_thirteenths (l : ℝ) (hl : 0≤l) :
    lowAngleStar (3/13) l=
      -((152*l-351)*(1331*l+7917))/(29696*(4*l+13)^2) := by
  have h : 4*l+13≠0 := by positivity
  have h' : 12*l+39≠0 := by positivity
  dsimp [lowAngleStar]
  field_simp
  <;> ring

theorem lowAngleStar_three_thirteenths_third_identity {l : ℝ} (hl : 0≤l) :
    lowAngleStar (3/13) l-1/2+l/3=
      (475136*l^3+1768744*l^2-1822561*l+808665)/(89088*(4*l+13)^2) := by
  have h : 4*l+13≠0 := by positivity
  rw [lowAngleStar_three_thirteenths l hl]
  field_simp
  <;> ring

theorem lowAngleElasticity_star_gt_half_sub_third {p l : ℝ}
    (hp : 0<p) (hpu : p≤3/13) (hl : 0≤l) (hlu : l≤1) :
    1/2-l/3<lowAngleElasticity p l (5/3) := by
  have hm := (lowAngleStar_strictAntiOn hl hlu).antitoneOn
    hp (by norm_num : (0:ℝ)<3/13) hpu
  have hq : 0<1768744*l^2-1822561*l+808665 := by
    nlinarith [sq_nonneg (3537488*l-1822561)]
  have hs : 0<lowAngleStar (3/13) l-1/2+l/3 := by
    rw [lowAngleStar_three_thirteenths_third_identity hl]
    apply div_pos ?_ (by positivity)
    have hc : 0≤475136*l^3 := by positivity
    linarith
  rw [lowAngleElasticity_star_eq hp hl]
  linarith

theorem lowAngleStar_three_thirteenths_half_identity {l : ℝ} (hl : 0≤l) :
    lowAngleStar (3/13) l-1/2=
      5*(53911-87976*l^2-456079*l)/(29696*(4*l+13)^2) := by
  have h : 4*l+13≠0 := by positivity
  rw [lowAngleStar_three_thirteenths l hl]
  field_simp
  <;> ring

theorem lowAngleElasticity_star_gt_half_small_mixture {p l : ℝ}
    (hp : 0<p) (hpu : p≤3/13) (hl : 0≤l) (hlu : l≤1/10) :
    1/2<lowAngleElasticity p l (5/3) := by
  have hm := (lowAngleStar_strictAntiOn hl (by linarith : l≤1)).antitoneOn
    hp (by norm_num : (0:ℝ)<3/13) hpu
  have hb : 87976*l^2+456079*l≤87976*(1/10:ℝ)^2+456079*(1/10) := by gcongr
  have hq : 0<53911-87976*l^2-456079*l := by norm_num at hb; linarith
  have hs : 0<lowAngleStar (3/13) l-1/2 := by
    rw [lowAngleStar_three_thirteenths_half_identity hl]
    exact div_pos (mul_pos (by norm_num) hq) (by positivity)
  rw [lowAngleElasticity_star_eq hp hl]
  linarith

def lowAngleThreeHalvesNumerator (p l : ℝ) : ℝ :=
  128-(625*l^2*p^5+1625*l^2*p^4+950*l^2*p^3+40*l^2*p^2+
    1000*l*p^4+2450*l*p^3+1160*l*p^2+16*l*p+400*p^3+920*p^2+176*p)

theorem lowAngleElasticity_three_halves_identity {p l : ℝ} (hp : 0<p) (hl : 0≤l) :
    lowAngleElasticity p l (3/2)-1/2=
      lowAngleThreeHalvesNumerator p l/(25*p*(p+1)*(p+2)*(5*l*p+4)^2) := by
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  have h3 : 5*l*p+4≠0 := by positivity
  dsimp [lowAngleElasticity,rayElasticity,rayPolynomial,rayEulerPolynomial,
    rayEulerSlope,lowAngleA,lowAngleB,lowAngleC,lowAngleThreeHalvesNumerator]
  field_simp
  <;> ring

theorem lowAngleElasticity_three_halves_gt_half {p l : ℝ}
    (hp : 0<p) (hpu : p≤1/6) (hl : 0≤l) (hlu : l≤1) :
    1/2<lowAngleElasticity p l (3/2) := by
  have hb : 625*l^2*p^5+1625*l^2*p^4+950*l^2*p^3+40*l^2*p^2+
      1000*l*p^4+2450*l*p^3+1160*l*p^2+16*l*p+400*p^3+920*p^2+176*p ≤
      859927/7776 := by
    calc
      _ ≤ 625*(1:ℝ)^2*(1/6)^5+1625*1^2*(1/6)^4+950*1^2*(1/6)^3+40*1^2*(1/6)^2+
        1000*1*(1/6)^4+2450*1*(1/6)^3+1160*1*(1/6)^2+16*1*(1/6)+
        400*(1/6)^3+920*(1/6)^2+176*(1/6) := by gcongr
      _ = _ := by norm_num
  apply sub_pos.mp
  rw [lowAngleElasticity_three_halves_identity hp hl]
  apply div_pos ?_ (by positivity)
  dsimp only [lowAngleThreeHalvesNumerator]
  linarith

end LeanVerification.UpperLeftCompletion
