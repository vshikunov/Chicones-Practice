import LeanVerification.UpperLeftCompletion.LowAngleBounds
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Data.Real.Pi.Bounds

/-! Uniform ray-preimage bounds.  Sine concavity and elementary logarithm
bounds reduce all three parameter strips to explicit polynomial inequalities. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
set_option maxHeartbeats 1800000

def lowAngleTheta (p : ℝ) : ℝ := Real.pi*(1-2*p)/6
def lowAngleCrossing (p : ℝ) : ℝ := 1/(2*Real.sin (lowAngleTheta p))
def lowAngleRatio (p l r : ℝ) : ℝ :=
  rayPolynomial (lowAngleA p l) (lowAngleB p l) (lowAngleC p l) r/lowAngleDeficit p l

theorem lowAngle_sin_pos {p : ℝ} (hp : 0≤p) (hpu : p<1/2) :
    0<Real.sin (lowAngleTheta p) := by
  apply Real.sin_pos_of_pos_of_lt_pi
  · dsimp [lowAngleTheta]
    exact div_pos (mul_pos Real.pi_pos (by linarith)) (by norm_num)
  · dsimp [lowAngleTheta]
    nlinarith [Real.pi_pos,mul_nonneg Real.pi_pos.le hp]

theorem lowAngleCrossing_pos {p : ℝ} (hp : 0≤p) (hpu : p<1/2) :
    0<lowAngleCrossing p := by
  exact one_div_pos.mpr (mul_pos (by norm_num) (lowAngle_sin_pos hp hpu))

theorem cubic_sine_lower {x : ℝ} (hx : 0≤x) : x-x^3/6≤Real.sin x := by
  let f : ℝ→ℝ := fun t => Real.sin t-t+t^3/6
  have hd (t : ℝ) : HasDerivAt f (Real.cos t-1+t^2/2) t := by
    convert ((Real.hasDerivAt_sin t).sub (hasDerivAt_id t)).add
      (((hasDerivAt_id t).pow 3).div_const 6) using 1 <;>
      simp only [f,id_eq,show (3:ℕ)-1=2 by omega] <;> ring
  have hm : MonotoneOn f (Ici (0:ℝ)) := by
    apply monotoneOn_of_deriv_nonneg (convex_Ici _)
    · exact fun t ht => (hd t).continuousAt.continuousWithinAt
    · exact fun t ht => (hd t).differentiableAt.differentiableWithinAt
    · intro t ht
      rw [(hd t).deriv]
      linarith [Real.one_sub_sq_div_two_le_cos (x:=t)]
  have hh := hm (show (0:ℝ)∈Ici 0 by simp) hx hx
  dsimp only [f] at hh
  simp only [Real.sin_zero,zero_sub,zero_pow,zero_div,add_zero] at hh
  linarith

theorem lowAngle_sin_sixth : 1/3<Real.sin (lowAngleTheta (1/6)) := by
  have hp0 := Real.pi_pos
  have hpl := Real.pi_gt_d2
  have hpu := Real.pi_lt_d2
  have hl : 157/450 < lowAngleTheta (1/6) := by dsimp [lowAngleTheta]; linarith
  have hu : lowAngleTheta (1/6)<7/20 := by dsimp [lowAngleTheta]; linarith
  have hx : 0≤lowAngleTheta (1/6) := by linarith
  have hc : (lowAngleTheta (1/6))^3≤(7/20:ℝ)^3 := by gcongr
  have hs := cubic_sine_lower hx
  nlinarith

theorem lowAngle_sin_three_thirteenths :
    5/18<Real.sin (lowAngleTheta (3/13)) := by
  have hpl := Real.pi_gt_d2
  have hpu := Real.pi_lt_d2
  have hl : 1099/3900 < lowAngleTheta (3/13) := by dsimp [lowAngleTheta]; linarith
  have hu : lowAngleTheta (3/13)<147/520 := by dsimp [lowAngleTheta]; linarith
  have hx : 0≤lowAngleTheta (3/13) := by linarith
  have hc : (lowAngleTheta (3/13))^3≤(147/520:ℝ)^3 := by gcongr
  have hs := cubic_sine_lower hx
  nlinarith

theorem lowAngle_sin_quarter : 15/58<Real.sin (lowAngleTheta (1/4)) := by
  have hpl := Real.pi_gt_d2
  have hpu := Real.pi_lt_d2
  have hl : 157/600 < lowAngleTheta (1/4) := by dsimp [lowAngleTheta]; linarith
  have hu : lowAngleTheta (1/4)<21/80 := by dsimp [lowAngleTheta]; linarith
  have hx : 0≤lowAngleTheta (1/4) := by linarith
  have hc : (lowAngleTheta (1/4))^3≤(21/80:ℝ)^3 := by gcongr
  have hs := cubic_sine_lower hx
  nlinarith

theorem lowAngle_sin_chord {p P s : ℝ}
    (hP : 0<P) (hPu : P≤1/2) (hp : 0≤p) (hpu : p≤P)
    (hs : s≤Real.sin (lowAngleTheta P)) :
    1-(1-2*s)/P*p≤2*Real.sin (lowAngleTheta p) := by
  have ht : 0≤p/P := div_nonneg hp hP.le
  have htu : p/P≤1 := (div_le_one hP).mpr hpu
  have ha : Real.pi/6∈Icc (0:ℝ) Real.pi := by constructor <;> linarith [Real.pi_pos]
  have hb : lowAngleTheta P∈Icc (0:ℝ) Real.pi := by
    dsimp [lowAngleTheta]
    constructor
    · have h0 : 0≤1-2*P := by linarith
      positivity
    · nlinarith [Real.pi_pos,mul_nonneg Real.pi_pos.le hP.le]
  have hh := strictConcaveOn_sin_Icc.concaveOn.2 ha hb
    (sub_nonneg.mpr htu) ht (by ring : (1-p/P)+p/P=1)
  simp only [smul_eq_mul,Real.sin_pi_div_six] at hh
  have he : (1-p/P)*(Real.pi/6)+(p/P)*lowAngleTheta P=lowAngleTheta p := by
    dsimp only [lowAngleTheta]
    field_simp
    <;> ring
  rw [he] at hh
  have hh' := mul_le_mul_of_nonneg_left hs ht
  have he' : 1-(1-2*s)/P*p=2*((1-p/P)*(1/2)+(p/P)*s) := by ring
  rw [he']
  linarith

theorem lowAngle_sin_chord_sixth {p : ℝ} (hp : 0≤p) (hpu : p≤1/6) :
    1-2*p≤2*Real.sin (lowAngleTheta p) := by
  convert lowAngle_sin_chord (s:=1/3) (by norm_num : (0:ℝ)<1/6)
    (by norm_num) hp hpu lowAngle_sin_sixth.le using 1 <;> ring

theorem lowAngle_sin_chord_three_thirteenths {p : ℝ} (hp : 0≤p) (hpu : p≤3/13) :
    1-52*p/27≤2*Real.sin (lowAngleTheta p) := by
  convert lowAngle_sin_chord (s:=5/18) (by norm_num : (0:ℝ)<3/13)
    (by norm_num) hp hpu lowAngle_sin_three_thirteenths.le using 1 <;> ring

theorem lowAngle_sin_chord_quarter {p : ℝ} (hp : 0≤p) (hpu : p≤1/4) :
    1-56*p/29≤2*Real.sin (lowAngleTheta p) := by
  convert lowAngle_sin_chord (s:=15/58) (by norm_num : (0:ℝ)<1/4)
    (by norm_num) hp hpu lowAngle_sin_quarter.le using 1 <;> ring

theorem rpow_linear_lower {R p a : ℝ} (hR : 0<R) (hp : 0≤p)
    (ha : a≤Real.log R) : 1+a*p≤R^p := by
  rw [Real.rpow_def_of_pos hR]
  have he := Real.add_one_le_exp (Real.log R*p)
  have hm := mul_le_mul_of_nonneg_right ha hp
  linarith

theorem three_halves_rpow_lower {p : ℝ} (hp : 0≤p) : 1+2*p/5≤(3/2:ℝ)^p := by
  have hh := Real.le_log_one_add_of_nonneg (by norm_num : (0:ℝ)≤1/2)
  norm_num at hh
  convert rpow_linear_lower (a:=2/5) (by norm_num : (0:ℝ)<3/2) hp hh using 1 <;> ring

theorem five_thirds_rpow_lower {p : ℝ} (hp : 0≤p) : 1+p/2≤(5/3:ℝ)^p := by
  have hh := Real.le_log_one_add_of_nonneg (by norm_num : (0:ℝ)≤2/3)
  norm_num at hh
  convert rpow_linear_lower (a:=1/2) (by norm_num : (0:ℝ)<5/3) hp hh using 1 <;> ring

theorem lowAngleRatio_identity {p l : ℝ} (r : ℝ) (hp : 0<p) (hl : 0≤l) :
    lowAngleRatio p l r=1+(r+1)*p+l*p^2*(p+1)*(r+1)^2/(2*(l*p+p+2)) := by
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  have h3 : p+2+p*l≠0 := by positivity
  have h4 : l*p+p+2≠0 := by positivity
  dsimp [lowAngleRatio,lowAngleDeficit,rayPolynomial,lowAngleA,lowAngleB,lowAngleC]
  field_simp
  <;> ring

theorem lowAngleRatio_lower {p l r : ℝ} (hp : 0<p) (hl : 0≤l) :
    1+(r+1)*p≤lowAngleRatio p l r := by
  rw [lowAngleRatio_identity r hp hl]
  have hh : 0≤l*p^2*(p+1)*(r+1)^2/(2*(l*p+p+2)) := by positivity
  linarith

theorem lowAngleRatio_star_half_identity {p l : ℝ} (hp : 0<p) (hl : 0≤l) :
    lowAngleRatio p l (5/3)=
      (32*p^3+104*p^2+123*p+36)/(9*(3*p+4))+
      32*p^2*(2*l-1)*(p+1)*(p+2)/(9*(3*p+4)*(l*p+p+2)) := by
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  have h3 : p+2+p*l≠0 := by positivity
  have h4 : l*p+p+2≠0 := by positivity
  have h5 : 3*p+4≠0 := by positivity
  dsimp [lowAngleRatio,lowAngleDeficit,rayPolynomial,lowAngleA,lowAngleB,lowAngleC]
  field_simp
  <;> ring

theorem lowAngleRatio_star_half_lower {p l : ℝ} (hp : 0<p) (hl : 1/2≤l) :
    (32*p^3+104*p^2+123*p+36)/(9*(3*p+4))≤lowAngleRatio p l (5/3) := by
  rw [lowAngleRatio_star_half_identity hp (by linarith)]
  have h0 : 0≤2*l-1 := by linarith
  have hh : 0≤32*p^2*(2*l-1)*(p+1)*(p+2)/(9*(3*p+4)*(l*p+p+2)) := by positivity
  linarith

theorem lowAngleU_div_deficit (p l r : ℝ) :
    lowAngleU p l r/lowAngleDeficit p l=r^p*lowAngleRatio p l r := by
  dsimp [lowAngleU,rayEnergy,lowAngleRatio]
  ring

theorem lowAngle_preimage_of_product {p l r x q s : ℝ}
    (hp : 0<p) (hl : 0≤l) (hr : 0<r) (hsin : 0<Real.sin (lowAngleTheta p))
    (hx : 0≤x) (hq : 0≤q) (hs : 0≤s)
    (hxp : x≤r^p) (hqr : q≤lowAngleRatio p l r)
    (hss : s≤2*Real.sin (lowAngleTheta p)) (hprod : 1<x*q*s) :
    lowAngleDeficit p l*lowAngleCrossing p<lowAngleU p l r := by
  have hrp : 0≤r^p := (Real.rpow_pos_of_pos hr _).le
  have hqr' : 0≤lowAngleRatio p l r := hq.trans hqr
  have hm : x*q*s≤(r^p*lowAngleRatio p l r)*(2*Real.sin (lowAngleTheta p)) :=
    mul_le_mul (mul_le_mul hxp hqr hq hrp) hss hs (mul_nonneg hrp hqr')
  have hcross : lowAngleCrossing p<r^p*lowAngleRatio p l r :=
    (div_lt_iff₀ (mul_pos (by norm_num) hsin)).mpr (hprod.trans_le hm)
  rw [←lowAngleU_div_deficit] at hcross
  have hh := (lt_div_iff₀ (lowAngleDeficit_pos hp hl)).mp hcross
  simpa only [mul_comm] using hh

theorem lowAngle_preimage_three_halves {p l : ℝ}
    (hp : 0<p) (hpu : p≤1/6) (hl : 0≤l) :
    lowAngleDeficit p l*lowAngleCrossing p<lowAngleU p l (3/2) := by
  have hb : 24*p/5+2*p^2≤24*(1/6:ℝ)/5+2*(1/6:ℝ)^2 := by gcongr
  have hc : 0<9/10-24*p/5-2*p^2 := by norm_num at hb; linarith
  have hprod : 1<(1+2*p/5)*(1+5*p/2)*(1-2*p) := by
    have hm := mul_pos hp hc
    nlinarith
  apply lowAngle_preimage_of_product hp hl (by norm_num)
    (lowAngle_sin_pos hp.le (by linarith)) (by positivity) (by positivity)
    (by linarith : 0≤1-2*p) (three_halves_rpow_lower hp.le) ?_
    (lowAngle_sin_chord_sixth hp.le hpu) hprod
  convert lowAngleRatio_lower (r:=3/2) hp hl using 1 <;> ring

theorem lowAngle_preimage_star_low {p l : ℝ}
    (hp : 0<p) (hpu : p≤3/13) (hl : 0≤l) :
    lowAngleDeficit p l*lowAngleCrossing p<lowAngleU p l (5/3) := by
  have hb : 386*p/81+208*p^2/81≤386*(3/13:ℝ)/81+208*(3/13:ℝ)^2/81 := by gcongr
  have hc : 0<67/54-386*p/81-208*p^2/81 := by norm_num at hb; linarith
  have hprod : 1<(1+p/2)*(1+8*p/3)*(1-52*p/27) := by
    have hm := mul_pos hp hc
    nlinarith
  apply lowAngle_preimage_of_product hp hl (by norm_num)
    (lowAngle_sin_pos hp.le (by linarith)) (by positivity) (by positivity)
    (by linarith : 0≤1-52*p/27) (five_thirds_rpow_lower hp.le) ?_
    (lowAngle_sin_chord_three_thirteenths hp.le hpu) hprod
  convert lowAngleRatio_lower (r:=5/3) hp hl using 1 <;> ring

theorem lowAngle_preimage_star_high_mixture {p l : ℝ}
    (hp : 0<p) (hpu : p≤1/4) (hl : 1/2≤l) :
    lowAngleDeficit p l*lowAngleCrossing p<lowAngleU p l (5/3) := by
  have hl0 : 0≤l := by linarith
  have hb : 1792*p^4+8480*p^3+13664*p^2+6193*p≤
      1792*(1/4:ℝ)^4+8480*(1/4:ℝ)^3+13664*(1/4:ℝ)^2+6193*(1/4:ℝ) := by gcongr
  have hc : 0<2580-1792*p^4-8480*p^3-13664*p^2-6193*p := by norm_num at hb; linarith
  have hd : 0<9*(3*p+4) := by positivity
  have hprod : 1<(1+p/2)*((32*p^3+104*p^2+123*p+36)/(9*(3*p+4)))*(1-56*p/29) := by
    have hm := mul_pos hp hc
    rw [←mul_div_assoc,div_mul_eq_mul_div,lt_div_iff₀ hd]
    nlinarith
  apply lowAngle_preimage_of_product hp hl0 (by norm_num)
    (lowAngle_sin_pos hp.le (by linarith)) (by positivity) (by positivity)
    (by linarith : 0≤1-56*p/29) (five_thirds_rpow_lower hp.le)
    (lowAngleRatio_star_half_lower hp hl) (lowAngle_sin_chord_quarter hp.le hpu) hprod

end LeanVerification.UpperLeftCompletion
