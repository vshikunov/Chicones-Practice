import LeanVerification.UpperLeftCompletion.RayElasticity

/-! The actual positive inverse of `u=r^p P(r)` and its density.  The
decreasing elasticity is attached to this constructed inverse. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 2200000

def rayEnergy (p A B C r : ℝ) : ℝ := r^p*rayPolynomial A B C r
def rayEnergySlope (p A B C r : ℝ) : ℝ := r^(p-1)*rayEulerPolynomial p A B C r
def rayDensityParam (p A B C r : ℝ) : ℝ := r^(1-p/2)/rayEulerPolynomial p A B C r
def rayDensityParamSlope (p A B C r : ℝ) : ℝ :=
  r^(1-p/2)*((1-p/2)*rayEulerPolynomial p A B C r-r*rayEulerSlope p A B r)/
    (r*(rayEulerPolynomial p A B C r)^2)
def rayInverse (p A B C u : ℝ) : ℝ := Function.invFunOn (rayEnergy p A B C) (Ioi 0) u
def rayDensity (p A B C u : ℝ) : ℝ := rayDensityParam p A B C (rayInverse p A B C u)

theorem analyticAt_rayEnergy (p A B C : ℝ) {r : ℝ} (hr : 0<r) :
    AnalyticAt ℝ (rayEnergy p A B C) r := by
  exact (analyticAt_rpow_const p r hr).mul
    (((analyticAt_const.mul (analyticAt_id.pow 2)).add
      (analyticAt_const.mul analyticAt_id)).add analyticAt_const)

theorem hasDerivAt_rayEnergy (p A B C : ℝ) {r : ℝ} (hr : 0<r) :
    HasDerivAt (rayEnergy p A B C) (rayEnergySlope p A B C r) r := by
  have hd := (Real.hasDerivAt_rpow_const (p:=p) (Or.inl hr.ne')).mul
    (hasDerivAt_rayPolynomial A B C r)
  convert hd using 1
  dsimp only [rayEnergySlope,rayEulerPolynomial,rayPolynomial]
  rw [Real.rpow_sub_one hr.ne']
  field_simp
  <;> ring

theorem rayEnergySlope_pos {p A B C r : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0≤B) (hC : 0<C) (hr : 0<r) :
    0<rayEnergySlope p A B C r :=
  mul_pos (Real.rpow_pos_of_pos hr _) (rayEulerPolynomial_pos hp hA hB hC hr)

theorem rayEnergy_pos {p A B C r : ℝ}
    (hA : 0≤A) (hB : 0≤B) (hC : 0<C) (hr : 0<r) :
    0<rayEnergy p A B C r :=
  mul_pos (Real.rpow_pos_of_pos hr _) (rayPolynomial_pos hA hB hC hr)

theorem strictMonoOn_rayEnergy {p A B C : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0≤B) (hC : 0<C) :
    StrictMonoOn (rayEnergy p A B C) (Ioi (0 : ℝ)) := by
  apply strictMonoOn_of_deriv_pos (convex_Ioi _)
  · intro r hr
    exact (hasDerivAt_rayEnergy p A B C hr).continuousAt.continuousWithinAt
  · intro r hr
    rw [interior_Ioi] at hr
    rw [(hasDerivAt_rayEnergy p A B C hr).deriv]
    exact rayEnergySlope_pos hp hA hB hC hr

theorem exists_large_rayEnergy {p A B C : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (u : ℝ) :
    ∃r,0<r ∧ u<rayEnergy p A B C r := by
  let r := 1+(|u|+1)/B
  have hr1 : 1<r := by
    dsimp only [r]
    exact lt_add_of_pos_right 1 (by positivity)
  have hr : 0<r := zero_lt_one.trans hr1
  have hBr : |u|<B*r := by
    have he : B*r=B+|u|+1 := by dsimp only [r];field_simp;ring
    rw [he]
    linarith
  have hP : |u|<rayPolynomial A B C r := by
    dsimp only [rayPolynomial]
    nlinarith [mul_nonneg hA (sq_nonneg r)]
  have hpow : 1≤r^p := Real.one_le_rpow hr1.le hp.le
  have hPpos := rayPolynomial_pos hA hB.le hC hr
  refine ⟨r,hr,?_⟩
  exact (le_abs_self u).trans_lt (hP.trans_le (by
    simpa only [rayEnergy,one_mul] using mul_le_mul_of_nonneg_right hpow hPpos.le))

theorem rayEnergy_range {p A B C : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) :
    rayEnergy p A B C '' Ioi (0 : ℝ)=Ioi 0 := by
  ext u
  constructor
  · rintro ⟨r,hr,rfl⟩
    exact rayEnergy_pos hA hB.le hC hr
  · intro hu
    obtain ⟨R,hR,huR⟩ := exists_large_rayEnergy hp hA hB hC u
    have hc : ContinuousOn (rayEnergy p A B C) (Icc 0 R) := by
      intro r hr
      have hw : ContinuousAt (fun r : ℝ => r^p) r := by
        apply Real.continuousAt_rpow_const
        exact Or.inr hp.le
      exact (hw.mul (hasDerivAt_rayPolynomial A B C r).continuousAt).continuousWithinAt
    have hz : rayEnergy p A B C 0=0 := by simp [rayEnergy,Real.zero_rpow hp.ne']
    have hu0 : rayEnergy p A B C 0<u := by simpa only [hz] using hu
    obtain ⟨r,hr,hru⟩ := intermediate_value_Ioo hR.le hc ⟨hu0,huR⟩
    exact ⟨r,hr.1,hru⟩

theorem rayInverse_pos {p A B C u : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hu : 0<u) :
    0<rayInverse p A B C u := by
  have hi : u∈rayEnergy p A B C '' Ioi (0 : ℝ) := by
    rw [rayEnergy_range hp hA hB hC]
    exact hu
  exact Function.invFunOn_mem hi

theorem rayEnergy_inverse {p A B C u : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hu : 0<u) :
    rayEnergy p A B C (rayInverse p A B C u)=u := by
  have hi : u∈rayEnergy p A B C '' Ioi (0 : ℝ) := by
    rw [rayEnergy_range hp hA hB hC]
    exact hu
  exact Function.invFunOn_eq hi

theorem rayInverse_energy {p A B C r : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hr : 0<r) :
    rayInverse p A B C (rayEnergy p A B C r)=r :=
  (strictMonoOn_rayEnergy hp hA hB.le hC).injOn.leftInvOn_invFunOn hr

theorem analyticAt_rayInverse {p A B C u : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hu : 0<u) :
    AnalyticAt ℝ (rayInverse p A B C) u := by
  let r := rayInverse p A B C u
  have hr : 0<r := rayInverse_pos hp hA hB hC hu
  have hl : ∀ᶠ x in 𝓝 r,rayInverse p A B C (rayEnergy p A B C x)=x := by
    filter_upwards [Ioi_mem_nhds hr] with x hx
    exact rayInverse_energy hp hA hB hC hx
  have hs : HasStrictDerivAt (rayEnergy p A B C) (deriv (rayEnergy p A B C) r) r :=
    (analyticAt_rayEnergy p A B C hr).hasStrictFDerivAt.hasStrictDerivAt
  have hd : deriv (rayEnergy p A B C) r≠0 := by
    rw [(hasDerivAt_rayEnergy p A B C hr).deriv]
    exact (rayEnergySlope_pos hp hA hB.le hC hr).ne'
  have ha := Loud.analyticAt_of_local_left_inverse (analyticAt_rayEnergy p A B C hr) hs hd hl
  simpa only [r,rayEnergy_inverse hp hA hB hC hu] using ha

theorem hasDerivAt_rayInverse {p A B C u : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hu : 0<u) :
    HasDerivAt (rayInverse p A B C)
      (rayEnergySlope p A B C (rayInverse p A B C u))⁻¹ u := by
  let r := rayInverse p A B C u
  have hr : 0<r := rayInverse_pos hp hA hB hC hu
  have hl : ∀ᶠ x in 𝓝 r,rayInverse p A B C (rayEnergy p A B C x)=x := by
    filter_upwards [Ioi_mem_nhds hr] with x hx
    exact rayInverse_energy hp hA hB hC hx
  have hs : HasStrictDerivAt (rayEnergy p A B C) (deriv (rayEnergy p A B C) r) r :=
    (analyticAt_rayEnergy p A B C hr).hasStrictFDerivAt.hasStrictDerivAt
  have hd : deriv (rayEnergy p A B C) r≠0 := by
    rw [(hasDerivAt_rayEnergy p A B C hr).deriv]
    exact (rayEnergySlope_pos hp hA hB.le hC hr).ne'
  have hi := (hs.to_local_left_inverse hd hl).hasDerivAt
  simpa only [r,rayEnergy_inverse hp hA hB hC hu,(hasDerivAt_rayEnergy p A B C hr).deriv] using hi

theorem strictMonoOn_rayInverse {p A B C : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) :
    StrictMonoOn (rayInverse p A B C) (Ioi (0 : ℝ)) := by
  intro u hu v hv huv
  have hru := rayInverse_pos hp hA hB hC hu
  have hrv := rayInverse_pos hp hA hB hC hv
  have hh := (strictMonoOn_rayEnergy hp hA hB.le hC).lt_iff_lt hru hrv
  apply hh.mp
  simpa only [rayEnergy_inverse hp hA hB hC hu,rayEnergy_inverse hp hA hB hC hv] using huv

theorem hasDerivAt_rayDensityParam (p A B C : ℝ) {r : ℝ}
    (hr : 0<r) (hH : rayEulerPolynomial p A B C r≠0) :
    HasDerivAt (rayDensityParam p A B C) (rayDensityParamSlope p A B C r) r := by
  have hd := (Real.hasDerivAt_rpow_const (p:=1-p/2) (Or.inl hr.ne')).div
    (hasDerivAt_rayEulerPolynomial p A B C r) hH
  convert hd using 1
  dsimp only [rayDensityParamSlope]
  rw [Real.rpow_sub_one hr.ne']
  field_simp
  <;> ring

theorem rayDensity_pos {p A B C u : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hu : 0<u) :
    0<rayDensity p A B C u := by
  have hr := rayInverse_pos hp hA hB hC hu
  exact div_pos (Real.rpow_pos_of_pos hr _) (rayEulerPolynomial_pos hp hA hB.le hC hr)

theorem hasDerivAt_rayDensity {p A B C u : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hu : 0<u) :
    HasDerivAt (rayDensity p A B C)
      (rayDensityParamSlope p A B C (rayInverse p A B C u)/
        rayEnergySlope p A B C (rayInverse p A B C u)) u := by
  have hr := rayInverse_pos hp hA hB hC hu
  simpa only [rayDensity,div_eq_mul_inv] using
    (hasDerivAt_rayDensityParam p A B C hr (rayEulerPolynomial_pos hp hA hB.le hC hr).ne').comp u
      (hasDerivAt_rayInverse hp hA hB hC hu)

theorem rayDensity_actual_elasticity {p A B C u : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hu : 0<u) :
    u*deriv (rayDensity p A B C) u/rayDensity p A B C u=
      rayElasticity p A B C (rayInverse p A B C u) := by
  let r := rayInverse p A B C u
  have hr : 0<r := rayInverse_pos hp hA hB hC hu
  have hH := (rayEulerPolynomial_pos hp hA hB.le hC hr).ne'
  have hpw := (Real.rpow_pos_of_pos hr (1-p/2)).ne'
  have hpr := (Real.rpow_pos_of_pos hr p).ne'
  rw [(hasDerivAt_rayDensity hp hA hB hC hu).deriv]
  change u*(rayDensityParamSlope p A B C r/rayEnergySlope p A B C r)/
    rayDensityParam p A B C r=rayElasticity p A B C r
  have hu' : u=rayEnergy p A B C r := (rayEnergy_inverse hp hA hB hC hu).symm
  rw [hu']
  dsimp only [rayEnergy,rayEnergySlope,rayDensityParam,rayDensityParamSlope,rayElasticity]
  rw [Real.rpow_sub_one hr.ne']
  field_simp [hH,hpw,hpr]
  <;> ring

theorem rayDensity_elasticity_strictAntiOn {p A B C : ℝ}
    (hp : 0<p) (hA : 0≤A) (hB : 0<B) (hC : 0<C) (hdisc : 4*A*C≤B^2) :
    StrictAntiOn (fun u => u*deriv (rayDensity p A B C) u/rayDensity p A B C u)
      (Ioi (0 : ℝ)) := by
  intro u hu v hv huv
  dsimp only
  rw [rayDensity_actual_elasticity hp hA hB hC hu,rayDensity_actual_elasticity hp hA hB hC hv]
  exact rayElasticity_strictAntiOn hp hA hB hC hdisc
    (rayInverse_pos hp hA hB hC hu) (rayInverse_pos hp hA hB hC hv)
    (strictMonoOn_rayInverse hp hA hB hC hu hv huv)

end LeanVerification.UpperLeftCompletion
