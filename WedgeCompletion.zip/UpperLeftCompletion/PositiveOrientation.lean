import LeanVerification.UpperLeftCompletion.PhysicalCenterJoin
import LeanVerification.ZeroOrientation
import LeanVerification.BoundaryAssembly.ZeroInput

/-! Strict propagation from a center value or a terminal moment value,
and its application to the actual physical contour jet. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion ExteriorCompletion Sharpness ZeroOrientation ZeroCounting
set_option maxHeartbeats 1200000

theorem neg_left_of_deriv_pos_at_zeros {f : ℝ→ℝ} {a b : ℝ} (hab : a≤b)
    (hf : ∀t∈Icc a b,DifferentiableAt ℝ f t)
    (hz : ∀t∈Icc a b,f t=0 → 0<deriv f t) (hb : f b<0) : f a<0 := by
  by_contra ha
  have hn := nonneg_on_Icc_of_deriv_pos_at_zeros hf hz (le_of_not_gt ha)
  exact (not_le_of_gt hb) (hn b ⟨hab,le_rfl⟩)

theorem pos_right_of_deriv_pos_at_zeros {f : ℝ→ℝ} {a b : ℝ} (hab : a≤b)
    (hf : ∀t∈Icc a b,DifferentiableAt ℝ f t)
    (hz : ∀t∈Icc a b,f t=0 → 0<deriv f t) (ha : 0<f a) : 0<f b := by
  rcases hab.eq_or_lt with rfl|hab
  · exact ha
  have hn := nonneg_on_Icc_of_deriv_pos_at_zeros hf hz ha.le
  have hnb := hn b ⟨hab.le,le_rfl⟩
  by_contra hb
  have hzero : f b=0 := le_antisymm (le_of_not_gt hb) hnb
  have hd := (hf b ⟨hab.le,le_rfl⟩).hasDerivAt
  have hlim : Tendsto (slope f b) (𝓝[<] b) (𝓝 (deriv f b)) :=
    (hasDerivAt_iff_tendsto_slope.mp hd).mono_left (nhdsLT_le_nhdsNE b)
  have hsl : ∀ᶠt in 𝓝[<] b,slope f b t≤0 := by
    filter_upwards [Ico_mem_nhdsLT hab] with t ht
    rw [slope_def_field,hzero,sub_zero]
    exact div_nonpos_of_nonneg_of_nonpos (hn t ⟨ht.1,ht.2.le⟩)
      (sub_nonpos.mpr ht.2.le)
  exact (not_le_of_gt (hz b ⟨hab.le,le_rfl⟩ hzero)) (le_of_tendsto hlim hsl)

theorem physical_period_deriv_pos_of_critical_curvature {D F h : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2)
    (hc : 0<tau1Polynomial D F)
    (hcurv : ∀k,AdmissibleEnergy D F k → physicalContourPeriodJet D F hD hF 0 k=0 →
      0<physicalContourPeriodJet D F hD hF 1 k)
    (hh : AdmissibleEnergy D F h) : 0<deriv (periodQuadrature D F) h := by
  have hzero : 0<physicalContourPeriodJet D F hD hF 0 0 := by
    have he := actual_contour_first_center hD hF hFu
    have hp : 0<2*Real.pi*tau1Polynomial D F := by positivity
    rw [←he] at hp
    simpa only [physicalContourPeriodJet,sub_zero,exteriorM,pow_zero,one_mul] using hp
  have hd : ∀k∈Icc 0 h,DifferentiableAt ℝ (physicalContourPeriodJet D F hD hF 0) k := by
    intro k hk
    rcases hk.1.eq_or_lt with rfl|hkp
    · exact (hasDerivAt_physicalContourPeriodJet_center hD hF hFu 0).differentiableAt
    · exact (hasDerivAt_physicalContourPeriodJet hD hF hFu
        (admissibleEnergy_downward D F h k hh hkp hk.2) 0).differentiableAt
  have hz : ∀k∈Icc 0 h,physicalContourPeriodJet D F hD hF 0 k=0 →
      0<deriv (physicalContourPeriodJet D F hD hF 0) k := by
    intro k hk he
    rcases hk.1.eq_or_lt with rfl|hkp
    · exact False.elim (hzero.ne' he)
    · have ha := admissibleEnergy_downward D F h k hh hkp hk.2
      rw [(hasDerivAt_physicalContourPeriodJet hD hF hFu ha 0).deriv]
      exact hcurv k ha he
  rw [physicalContourPeriodJet_zero hD hF hFu hh]
  exact pos_right_of_deriv_pos_at_zeros hh.1.le hd hz hzero

theorem physical_period_second_derivative_eq {D F h : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2) (hh : AdmissibleEnergy D F h) :
    deriv (deriv (periodQuadrature D F)) h=physicalContourPeriodJet D F hD hF 1 h := by
  have he : deriv (periodQuadrature D F) =ᶠ[𝓝 h] physicalContourPeriodJet D F hD hF 0 := by
    filter_upwards [(isOpen_admissibleEnergy D F).mem_nhds hh] with k hk
    exact physicalContourPeriodJet_zero hD hF hFu hk
  rw [he.deriv_eq,(hasDerivAt_physicalContourPeriodJet hD hF hFu hh 0).deriv]

theorem criticalPeriodBound_one_of_contour_curvature {D F : ℝ}
    (hD : D< -1) (hF : 1<F) (hFu : F<3/2)
    (hcurv : ∀h,AdmissibleEnergy D F h → 0<physicalContourPeriodJet D F hD hF 1 h) :
    CriticalPeriodBound 1 D F := by
  have hm : StrictMonoOn (deriv (periodQuadrature D F)) {h|AdmissibleEnergy D F h} := by
    apply strictMonoOn_of_deriv_pos (ordConnected_admissibleEnergy D F).convex
    · intro h hh
      exact (analyticAt_periodQuadrature_energy D F h hh).deriv.continuousAt.continuousWithinAt
    · intro h hh
      have ha := interior_subset hh
      rw [physical_period_second_derivative_eq hD hF hFu ha]
      exact hcurv h ha
  intro s hs
  apply Finset.card_le_one.mpr
  intro x hx y hy
  exact hm.injOn (hs x hx).1 (hs y hy).1 ((hs x hx).2.1.trans (hs y hy).2.1.symm)

end LeanVerification.UpperLeftCompletion
