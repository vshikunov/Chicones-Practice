import LeanVerification.UpperLeftCompletion.DensityOrderInverse

/-! Strict likelihood-ratio order for the actual normalized ray density.
The score is differentiated from the global positive inverse, rather than
postulated.  Its spatial derivative is an exact negative rational function. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 4000

def densityOrderScore (p l r : ℝ) : ℝ :=
  -p*(l*p*(2*l*p+p+2)*(r+1)^2+(8*l*p+2*p+8)*(r+1)+4)/
    (2*(l*p+p+2)*(l*p*(r+1)+2)^2)

theorem densityOrderDensity_formula {p : ℝ} (hp : 0<p) (l v : ℝ) :
    densityOrderDensity p l v=
      (densityOrderInverse p l v)^(1-p/2)/
        ((densityOrderInverse p l v+1)*(l*p*(densityOrderInverse p l v+1)+2)/2) := by
  dsimp only [densityOrderDensity,rayDensity,rayDensityParam]
  rw [lowAngle_euler_factor hp]
  rfl

theorem densityOrder_log_formula {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    Real.log (densityOrderDensity p l v)=
      (1-p/2)*Real.log (densityOrderInverse p l v)-
      Real.log (densityOrderInverse p l v+1)-
      Real.log (l*p*(densityOrderInverse p l v+1)+2)+Real.log 2 := by
  let r := densityOrderInverse p l v
  have hr : 0<r := densityOrderInverse_pos hp hl hv
  have hr1 : 0<r+1 := by positivity
  have hT : 0<l*p*(r+1)+2 := by positivity
  rw [densityOrderDensity_formula hp]
  change Real.log (r^(1-p/2)/((r+1)*(l*p*(r+1)+2)/2))=_
  rw [Real.log_div (Real.rpow_pos_of_pos hr _).ne' (by positivity),Real.log_rpow hr,
    Real.log_div (mul_pos hr1 hT).ne' (by norm_num),Real.log_mul hr1.ne' hT.ne']
  ring

theorem densityOrderScore_identity {p l r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) :
    (1-p/2)*(r⁻¹*densityOrderInverseVariation p l r)-
      (r+1)⁻¹*densityOrderInverseVariation p l r-
      (l*p*(r+1)+2)⁻¹*(p*(r+1)+l*p*densityOrderInverseVariation p l r)=
      densityOrderScore p l r := by
  have hr0 := hr.ne'
  have hr1 : r+1≠0 := by positivity
  have hK : l*p+p+2≠0 := by positivity
  have hT : l*p*(r+1)+2≠0 := by positivity
  dsimp only [densityOrderInverseVariation,densityOrderScore]
  field_simp
  <;> ring

/-- Actual parameter score of the normalized density. -/
theorem hasDerivAt_log_densityOrderDensity_parameter {p l v : ℝ}
    (hp : 0<p) (hl : 0<l) (hv : 0<v) :
    HasDerivAt (fun t => Real.log (densityOrderDensity p t v))
      (densityOrderScore p l (densityOrderInverse p l v)) l := by
  let r := densityOrderInverse p l v
  have hr : 0<r := densityOrderInverse_pos hp hl hv
  have hr1 : 0<r+1 := by positivity
  have hT : 0<l*p*(r+1)+2 := by positivity
  have hR := hasDerivAt_densityOrderInverse_parameter hp hl hv
  have hlogR := (Real.hasDerivAt_log hr.ne').comp l hR
  have hlogS := (Real.hasDerivAt_log hr1.ne').comp l (hR.add_const 1)
  have hTr := ((((hasDerivAt_id l).mul_const p).mul (hR.add_const 1)).add_const 2)
  have hlogT := (Real.hasDerivAt_log hT.ne').comp l hTr
  have hd := (((hlogR.const_mul (1-p/2)).sub hlogS).sub hlogT).add_const (Real.log 2)
  have he : (fun t => Real.log (densityOrderDensity p t v))=ᶠ[𝓝 l]
      (fun t => (1-p/2)*Real.log (densityOrderInverse p t v)-
        Real.log (densityOrderInverse p t v+1)-
        Real.log (t*p*(densityOrderInverse p t v+1)+2)+Real.log 2) := by
    filter_upwards [Ioi_mem_nhds hl] with t ht
    exact densityOrder_log_formula hp ht hv
  have hd' := hd.congr_of_eventuallyEq he
  convert hd' using 1
  simp only [id_eq,one_mul]
  exact (densityOrderScore_identity hp hl hr).symm

theorem hasDerivAt_densityOrderScore {p l r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) :
    HasDerivAt (densityOrderScore p l)
      (-p*(l*p^2*(r+1)+4*l*p+2*p+8)/
        ((l*p+p+2)*(l*p*(r+1)+2)^3)) r := by
  have hK : l*p+p+2≠0 := by positivity
  have hT : l*p*(r+1)+2≠0 := by positivity
  have hD : 2*(l*p+p+2)*(l*p*(r+1)+2)^2≠0 := by positivity
  have hS := (hasDerivAt_id r).add_const 1
  have hN := (((hS.pow 2).const_mul (l*p*(2*l*p+p+2))).add
    (hS.const_mul (8*l*p+2*p+8))).add_const 4
  have hT' := (hS.const_mul (l*p)).add_const 2
  have hd := (hN.const_mul (-p)).div ((hT'.pow 2).const_mul (2*(l*p+p+2))) hD
  convert hd using 1
  simp only [id_eq,pow_one,one_mul]
  field_simp
  <;> ring

theorem densityOrderScore_deriv_neg {p l r : ℝ}
    (hp : 0<p) (hl : 0<l) (hr : 0<r) :
    deriv (densityOrderScore p l) r<0 := by
  rw [(hasDerivAt_densityOrderScore hp hl hr).deriv]
  exact div_neg_of_neg_of_pos
    (mul_neg_of_neg_of_pos (neg_neg_of_pos hp) (by positivity)) (by positivity)

theorem densityOrderScore_strictAntiOn {p l : ℝ} (hp : 0<p) (hl : 0<l) :
    StrictAntiOn (densityOrderScore p l) (Ioi (0:ℝ)) := by
  apply strictAntiOn_of_deriv_neg (convex_Ioi _)
  · intro r hr
    exact (hasDerivAt_densityOrderScore hp hl hr).continuousAt.continuousWithinAt
  · intro r hr
    rw [interior_Ioi] at hr
    exact densityOrderScore_deriv_neg hp hl hr

theorem densityOrder_actual_score_strictAntiOn {p l : ℝ} (hp : 0<p) (hl : 0<l) :
    StrictAntiOn (fun v => deriv (fun t => Real.log (densityOrderDensity p t v)) l)
      (Ioi (0:ℝ)) := by
  intro u hu v hv huv
  dsimp only
  rw [(hasDerivAt_log_densityOrderDensity_parameter hp hl hv).deriv,
    (hasDerivAt_log_densityOrderDensity_parameter hp hl hu).deriv]
  exact densityOrderScore_strictAntiOn hp hl (densityOrderInverse_pos hp hl hu)
    (densityOrderInverse_pos hp hl hv) (densityOrderInverse_strictMonoOn hp hl hu hv huv)

theorem densityOrder_log_increment_strictAntiOn {p u v : ℝ}
    (hp : 0<p) (hu : 0<u) (huv : u<v) :
    StrictAntiOn (fun l => Real.log (densityOrderDensity p l v)-
      Real.log (densityOrderDensity p l u)) (Ioi (0:ℝ)) := by
  have hv : 0<v := hu.trans huv
  apply strictAntiOn_of_deriv_neg (convex_Ioi _)
  · intro l hl
    exact ((hasDerivAt_log_densityOrderDensity_parameter hp hl hv).sub
      (hasDerivAt_log_densityOrderDensity_parameter hp hl hu)).continuousAt.continuousWithinAt
  · intro l hl
    rw [interior_Ioi] at hl
    rw [((hasDerivAt_log_densityOrderDensity_parameter hp hl hv).sub
      (hasDerivAt_log_densityOrderDensity_parameter hp hl hu)).deriv]
    exact sub_neg.mpr (densityOrderScore_strictAntiOn hp hl
      (densityOrderInverse_pos hp hl hu) (densityOrderInverse_pos hp hl hv)
      (densityOrderInverse_strictMonoOn hp hl hu hv huv))

/-- The exact density in the center-normalized ray formula has strictly
increasing likelihood ratio whenever the Loud parameter increases.  The
result includes the endpoint Λ=1 directly, and in fact holds for all Λ>λ>0. -/
theorem densityOrder_ratio_strictMonoOn {p l L : ℝ}
    (hp : 0<p) (hl : 0<l) (hlL : l<L) :
    StrictMonoOn (fun v => densityOrderDensity p l v/densityOrderDensity p L v)
      (Ioi (0:ℝ)) := by
  have hL : 0<L := hl.trans hlL
  intro u hu v hv huv
  have hlu := densityOrderDensity_pos hp hl hu
  have hlv := densityOrderDensity_pos hp hl hv
  have hLu := densityOrderDensity_pos hp hL hu
  have hLv := densityOrderDensity_pos hp hL hv
  apply (Real.log_lt_log_iff (div_pos hlu hLu) (div_pos hlv hLv)).mp
  rw [Real.log_div hlu.ne' hLu.ne',Real.log_div hlv.ne' hLv.ne']
  have hi := densityOrder_log_increment_strictAntiOn hp hu huv hl hL hlL
  dsimp only at hi
  linarith only [hi]

end LeanVerification.UpperLeftCompletion
