import LeanVerification.UpperLeftCompletion.PhysicalLowAngleData
import LeanVerification.UpperLeftCompletion.PhysicalCenterJoin
import LeanVerification.ExteriorSpectralCompletion.SecondWeightedAbel

/-! The center-moment signs are proved for the actual negative-ray jet
integrals.  The comparison uses the checked scalar R0/R1 certificates,
the actual exterior Abel pole bounds, and the original-time center jet
identity.  No exterior spectral representation is assumed. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
open Loud ContourCompletion ExteriorCompletion ExteriorSpectralCompletion Sharpness RegionalComplex
set_option maxHeartbeats 3600000

theorem centerMomentR0_pole_ratio {p : ℝ} (hp : 0<p) :
    centerMomentR0 p=
      Real.sqrt 2*Real.pi*centerMomentTauOne p*
        (lowAngleDeficit p (1/2)+lowAngleExteriorDepth p (1/2))/
          Real.sqrt (lowAngleSaddle p (1/2)/2) := by
  have hw : 0<(p+4)/p := by positivity
  have hs := (Real.sqrt_pos.mpr hw).ne'
  have h2 := (Real.sqrt_pos.mpr (by norm_num : (0:ℝ)<2)).ne'
  rw [lowAngleExteriorDepth_half hp,lowAngleSaddle_half,Real.sqrt_div hw.le]
  dsimp only [centerMomentR0]
  field_simp
  ring_nf
  simp only [Real.sq_sqrt (show (0:ℝ)≤2 by norm_num)]
  <;> ring

theorem centerMomentR1_pole_ratio {p : ℝ} (hp : 0<p) :
    centerMomentR1 p=
      2*Real.sqrt 2*Real.pi*centerMomentTauTwo p*(lowAngleDeficit p 1)^2/
        Real.sqrt (lowAngleSaddle p 1/2) := by
  have hp2 : 0<p+2 := by positivity
  have hw : 0<(p+2)/p := by positivity
  have hs0 := (Real.sqrt_pos.mpr hp).ne'
  have hs2 := (Real.sqrt_pos.mpr hp2).ne'
  have h2 := (Real.sqrt_pos.mpr (by norm_num : (0:ℝ)<2)).ne'
  rw [centerMomentR1_eq hp,lowAngleDeficit_terminal hp,lowAngleSaddle_terminal,
    Real.sqrt_div hw.le,Real.sqrt_div hp2.le]
  dsimp only [centerMomentTauTwo]
  field_simp [hp.ne',hp2.ne']
  ring_nf
  simp only [Real.sq_sqrt hp.le,Real.sq_sqrt (show (0:ℝ)≤2 by norm_num)]
  <;> ring

theorem centerMoment_half_pole_lt {p : ℝ} (hp : 0<p) (hpu : p≤1/4) :
    Real.sqrt (lowAngleSaddle p (1/2)/2)/
      (lowAngleDeficit p (1/2)+lowAngleExteriorDepth p (1/2))<
        Real.sqrt 2*Real.pi*centerMomentTauOne p := by
  have hA : 0<Real.sqrt (lowAngleSaddle p (1/2)/2) :=
    Real.sqrt_pos.mpr (div_pos (lowAngleSaddle_pos hp (by norm_num)) (by norm_num))
  have hE : 0<lowAngleDeficit p (1/2)+lowAngleExteriorDepth p (1/2) :=
    add_pos (lowAngleDeficit_pos hp (by norm_num))
      (lowAngleExteriorDepth_pos hp (by norm_num) (by norm_num))
  have hR := centerMomentR0_gt_one hp hpu
  rw [centerMomentR0_pole_ratio hp] at hR
  exact (div_lt_iff₀ hE).mpr ((one_lt_div hA).mp hR)

theorem centerMoment_terminal_pole_lt {p : ℝ} (hp : 0<p) (hpu : p≤2/5) :
    Real.sqrt (lowAngleSaddle p 1/2)/(lowAngleDeficit p 1)^2<
      2*Real.sqrt 2*Real.pi*centerMomentTauTwo p := by
  have hA : 0<Real.sqrt (lowAngleSaddle p 1/2) :=
    Real.sqrt_pos.mpr (div_pos (lowAngleSaddle_pos hp (by norm_num)) (by norm_num))
  have hE : 0<(lowAngleDeficit p 1)^2 := sq_pos_of_pos (lowAngleDeficit_pos hp (by norm_num))
  have hR := centerMomentR1_gt_one hp hpu
  rw [centerMomentR1_pole_ratio hp] at hR
  exact (div_lt_iff₀ hE).mpr ((one_lt_div hA).mp hR)

/-- The actual zeroth negative-ray jet integral is positive at λ=1/2.
This is the manuscript's first negative N-center sign, with N=-J0. -/
theorem actual_ray_zero_center_half_pos {p : ℝ} (hp : 0<p) (hpu : p≤1/4) :
    0<negativeRayJetIntegral 0 p (lowAngleA p (1/2)) (lowAngleB p (1/2))
      (lowAngleC p (1/2)) (lowAngleDeficit p (1/2)) := by
  let D := lowAngleParameterD p (1/2)
  let F := lowAngleParameterF p
  have hD : D< -1 := lowAngleParameterD_lt_neg_one hp (by norm_num)
  have hF : 1<F := lowAngleParameterF_gt_one hp
  have hFu : F<3/2 := by dsimp only [F,lowAngleParameterF];linarith
  have he := (physical_center_deficit_spec D F hD hF).2
  have hb := actual_exteriorM_pole_upper_bound D F (zeroEndpointHeight D F) hD hF he
  have hnormP : upperLeftRayP F=p := lowAngleParameter_rayP p
  have hnormL : upperLeftRayLambda D F=1/2 := lowAngleParameter_rayLambda hp
  rw [physical_lowAngle_energy_gap D F _ hD hF,physical_lowAngle_saddle D F hD hF,
    physical_lowAngle_center_height D F hF,hnormP,hnormL] at hb
  have hm := hb.trans (centerMoment_half_pole_lt hp hpu)
  have hc := actual_ray_zero_center hD hF hFu
  have ht : tau1Polynomial D F=centerMomentTauOne p := tau1_lowAngle_half p
  rw [ht] at hc
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  rw [hA,hB,hC,physical_lowAngle_center_height D F hF,
    show 2*F-2=upperLeftRayP F from rfl,hnormP,hnormL] at hc
  linarith

/-- The actual first negative-ray jet integral is negative at λ=1.
This terminal comparison is valid up through p=2/5. -/
theorem actual_ray_one_center_terminal_neg {p : ℝ} (hp : 0<p) (hpu : p≤2/5) :
    negativeRayJetIntegral 1 p (lowAngleA p 1) (lowAngleB p 1)
      (lowAngleC p 1) (lowAngleDeficit p 1)<0 := by
  let D := lowAngleParameterD p 1
  let F := lowAngleParameterF p
  have hD : D< -1 := lowAngleParameterD_lt_neg_one hp (by norm_num)
  have hF : 1<F := lowAngleParameterF_gt_one hp
  have hFu : F<3/2 := by dsimp only [F,lowAngleParameterF];linarith
  have he := (physical_center_deficit_spec D F hD hF).2
  have hb := actual_exteriorAbelJet_one_pole_upper_bound D F (zeroEndpointHeight D F) hD hF he
  have hnormP : upperLeftRayP F=p := lowAngleParameter_rayP p
  have hnormL : upperLeftRayLambda D F=1 := lowAngleParameter_rayLambda hp
  rw [physical_lowAngle_energy_gap D F _ hD hF,physical_lowAngle_saddle D F hD hF,
    physical_lowAngle_center_height D F hF,hnormP,hnormL,lowAngleExteriorDepth_terminal,add_zero] at hb
  have hm := hb.trans (centerMoment_terminal_pole_lt hp hpu)
  have hc := actual_ray_one_center hD hF hFu
  have ht : tau2Polynomial D F=centerMomentTauTwo p := tau2_lowAngle_terminal p
  rw [ht] at hc
  obtain ⟨hA,hB,hC⟩ := physical_lowAngle_coefficients D F hF
  rw [hA,hB,hC,physical_lowAngle_center_height D F hF,
    show 2*F-2=upperLeftRayP F from rfl,hnormP,hnormL] at hc
  linarith

end LeanVerification.UpperLeftCompletion
