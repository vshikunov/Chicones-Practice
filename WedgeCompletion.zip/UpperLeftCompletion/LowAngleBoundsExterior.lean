import LeanVerification.UpperLeftCompletion.LowAngleBoundsPreimage

/-! The exterior fraction needed in the low-angle critical-point comparison.
Every constant is proved for the actual normalized ray and saddle depth. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.UpperLeftCompletion
set_option maxHeartbeats 2400000
set_option maxRecDepth 4000

def lowAngleSaddle (p l : ℝ) : ℝ := (2+p*l)/(p*l)
def lowAngleExteriorDepth (p l : ℝ) : ℝ :=
  (lowAngleSaddle p l)^p*2*(1-l)*(1+p*l/2)/(p*l*(p+1)*(p+2))
def lowAngleN (p l : ℝ) : ℝ := (p+2)*(2*p+1)+l*p*(2*p^2+4*p+1)
def lowAngleNSlope (p l : ℝ) : ℝ := 4*p+5+l*(6*p^2+8*p+1)
def lowAngleK (p l : ℝ) : ℝ :=
  lowAngleCrossing p*lowAngleExteriorDepth p l/lowAngleU p l 1

theorem lowAngleN_pos {p l : ℝ} (hp : 0<p) (hl : 0≤l) : 0<lowAngleN p l := by
  dsimp [lowAngleN]
  positivity

theorem lowAngleSaddle_pos {p l : ℝ} (hp : 0<p) (hl : 0<l) :
    0<lowAngleSaddle p l := by dsimp [lowAngleSaddle]; positivity

theorem lowAngleExteriorDepth_pos {p l : ℝ} (hp : 0<p) (hl : 0<l) (hlu : l<1) :
    0<lowAngleExteriorDepth p l := by
  have hs := lowAngleSaddle_pos hp hl
  have h1 : 0<1-l := by linarith
  dsimp [lowAngleExteriorDepth]
  positivity

theorem lowAngleU_pos {p l r : ℝ} (hp : 0<p) (hl : 0≤l) (hr : 0<r) :
    0<lowAngleU p l r := by
  obtain ⟨hA,hB,hC⟩ := lowAngle_coefficients_pos hp hl
  exact rayEnergy_pos hA hB.le hC hr

theorem lowAngleK_factorization {p l : ℝ} (hp : 0<p) (hl : 0<l) :
    lowAngleK p l=(lowAngleCrossing p/lowAngleN p l)*
      (lowAngleSaddle p l)^p*(1+p*l/2)*(2*(1-l)/l) := by
  have h0 : p≠0 := hp.ne'
  have h1 : p+1≠0 := by positivity
  have h2 : p+2≠0 := by positivity
  have h3 : l≠0 := hl.ne'
  have hN : lowAngleN p l≠0 := (lowAngleN_pos hp hl.le).ne'
  dsimp [lowAngleK,lowAngleExteriorDepth,lowAngleU,rayEnergy,rayPolynomial,
    lowAngleA,lowAngleB,lowAngleC,lowAngleN] at *
  rw [Real.one_rpow]
  field_simp
  <;> ring

theorem hasDerivAt_lowAngleN (p l : ℝ) :
    HasDerivAt (fun q => lowAngleN q l) (lowAngleNSlope p l) p := by
  have hi := hasDerivAt_id p
  have hd := ((hi.add_const 2).mul ((hi.const_mul 2).add_const 1)).add
    (((hi.const_mul l).mul ((((hi.pow 2).const_mul 2).add (hi.const_mul 4)).add_const 1)))
  convert hd using 1 <;> simp only [lowAngleN,lowAngleNSlope,id_eq,pow_one,mul_one,one_mul] <;> ring

theorem lowAngleN_slope_bound {p l : ℝ}
    (hp : 1/6≤p) (hl : 0≤l) (hlu : l≤1) :
    lowAngleNSlope p l≤(18/7)*lowAngleN p l := by
  have hp0 : 0<p := by linarith
  have hn : 0≤lowAngleNSlope p l := by dsimp [lowAngleNSlope]; positivity
  have hi : 3*lowAngleN p l-(1+p)*lowAngleNSlope p l=
      (1-l)*(2*p^2+6*p+1) := by dsimp [lowAngleN,lowAngleNSlope]; ring
  have hl1 : 0≤1-l := by linarith
  have hright : 0≤(1-l)*(2*p^2+6*p+1) := by positivity
  have hm := mul_le_mul_of_nonneg_right (show (7/6:ℝ)≤1+p by linarith) hn
  linarith

theorem lowAngle_crossing_score_bound {p : ℝ} (hp : 1/6≤p) (hpu : p≤1/4) :
    (18/7)*Real.sin (lowAngleTheta p)<(Real.pi/3)*Real.cos (lowAngleTheta p) := by
  have hx : 0≤lowAngleTheta p := by
    have h : 0≤1-2*p := by linarith
    dsimp [lowAngleTheta]
    positivity
  have hxu : lowAngleTheta p≤Real.pi/9 := by
    dsimp [lowAngleTheta]
    nlinarith [Real.pi_pos,mul_nonneg Real.pi_pos.le (sub_nonneg.mpr hp)]
  have hs := (Real.sin_le hx).trans hxu
  have hsquare : (lowAngleTheta p)^2≤(Real.pi/9)^2 := by gcongr
  have hpi := Real.pi_lt_d2
  have hpisq : Real.pi^2<10 := by nlinarith [Real.pi_pos]
  have hc := Real.one_sub_sq_div_two_le_cos (x:=lowAngleTheta p)
  have hcos : (76/81:ℝ)<Real.cos (lowAngleTheta p) := by nlinarith
  have hm := mul_lt_mul_of_pos_left hcos (show 0<Real.pi/3 by positivity)
  have hs' := mul_le_mul_of_nonneg_left hs (by norm_num : (0:ℝ)≤18/7)
  nlinarith [Real.pi_pos]

theorem hasDerivAt_lowAngleCrossing {p : ℝ} (hp : 0≤p) (hpu : p<1/2) :
    HasDerivAt lowAngleCrossing
      (Real.pi*Real.cos (lowAngleTheta p)/(6*(Real.sin (lowAngleTheta p))^2)) p := by
  have ht : HasDerivAt lowAngleTheta (-Real.pi/3) p := by
    convert (((hasDerivAt_id p).const_mul 2).const_sub 1).const_mul Real.pi |>.div_const 6
      using 1 <;> simp only [lowAngleTheta,mul_one] <;> ring
  have hs := lowAngle_sin_pos hp hpu
  have hs0 := hs.ne'
  have hd := (hasDerivAt_const p (1:ℝ)).div (ht.sin.const_mul 2) (by positivity : 2*Real.sin (lowAngleTheta p)≠0)
  convert hd using 1 <;> dsimp only [lowAngleCrossing] <;> field_simp <;> ring

theorem lowAngle_crossing_derivative_bound {p : ℝ} (hp : 1/6≤p) (hpu : p≤1/4) :
    (18/7)*lowAngleCrossing p<
      Real.pi*Real.cos (lowAngleTheta p)/(6*(Real.sin (lowAngleTheta p))^2) := by
  have hs := lowAngle_sin_pos (by linarith : 0≤p) (by linarith : p<1/2)
  have hc := lowAngle_crossing_score_bound hp hpu
  dsimp [lowAngleCrossing]
  apply (lt_div_iff₀ (by positivity : 0<6*(Real.sin (lowAngleTheta p))^2)).mpr
  have he : ((18/7:ℝ)*(1/(2*Real.sin (lowAngleTheta p))))*
      (6*(Real.sin (lowAngleTheta p))^2)=(54/7)*Real.sin (lowAngleTheta p) := by
    field_simp [hs.ne']
    <;> ring
  rw [he]
  nlinarith

theorem lowAngle_crossing_over_N_monotone {l : ℝ} (hl : 0≤l) (hlu : l≤1) :
    MonotoneOn (fun p => lowAngleCrossing p/lowAngleN p l) (Icc (1/6:ℝ) (1/4)) := by
  have hd (p : ℝ) (hp : p∈Icc (1/6:ℝ) (1/4)) :
      HasDerivAt (fun q => lowAngleCrossing q/lowAngleN q l)
        ((Real.pi*Real.cos (lowAngleTheta p)/(6*(Real.sin (lowAngleTheta p))^2)*lowAngleN p l-
          lowAngleCrossing p*lowAngleNSlope p l)/(lowAngleN p l)^2) p :=
    (hasDerivAt_lowAngleCrossing (by linarith [hp.1]) (by linarith [hp.2])).div
      (hasDerivAt_lowAngleN p l) (lowAngleN_pos (by linarith [hp.1]) hl).ne'
  apply monotoneOn_of_deriv_nonneg (convex_Icc _ _)
  · exact fun p hp => (hd p hp).continuousAt.continuousWithinAt
  · exact fun p hp => (hd p (interior_subset hp)).differentiableAt.differentiableWithinAt
  · intro p hp
    have hm := interior_subset hp
    rw [(hd p hm).deriv]
    apply div_nonneg ?_ (sq_nonneg _)
    have hN := lowAngleN_pos (p:=p) (by linarith [hm.1]) hl
    have hv := lowAngleCrossing_pos (p:=p) (by linarith [hm.1]) (by linarith [hm.2])
    have hC := lowAngle_crossing_derivative_bound hm.1 hm.2
    have hS := lowAngleN_slope_bound hm.1 hl hlu
    have h1 := mul_le_mul_of_nonneg_right hC.le hN.le
    have h2 := mul_le_mul_of_nonneg_left hS hv.le
    nlinarith

theorem lowAngleSaddle_power_monotone {l : ℝ} (hl : 0<l) :
    MonotoneOn (fun p => (lowAngleSaddle p l)^p) (Ioi (0:ℝ)) := by
  have hd (p : ℝ) (hp : 0<p) :
      HasDerivAt (fun q => (lowAngleSaddle q l)^q)
        ((lowAngleSaddle p l)^p*(Real.log (lowAngleSaddle p l)-2/(2+p*l))) p := by
    have h0 : p*l≠0 := by positivity
    have hs : HasDerivAt (fun q => lowAngleSaddle q l) (-2*l/(p*l)^2) p := by
      have hi := (hasDerivAt_id p).mul_const l
      convert (hi.const_add 2).div hi h0 using 1 <;> simp only [lowAngleSaddle,id_eq,one_mul] <;> ring
    have hw := lowAngleSaddle_pos hp hl
    have hr := hs.rpow (hasDerivAt_id p) hw
    convert hr using 1
    simp only [id_eq,one_mul]
    rw [Real.rpow_sub_one hw.ne']
    dsimp only [lowAngleSaddle]
    field_simp
    <;> ring
  apply monotoneOn_of_deriv_nonneg (convex_Ioi _)
  · exact fun p hp => (hd p hp).continuousAt.continuousWithinAt
  · exact fun p hp => (hd p (interior_subset hp)).differentiableAt.differentiableWithinAt
  · intro p hp
    rw [interior_Ioi] at hp
    have hp0 : 0<p := hp
    rw [(hd p hp0).deriv]
    apply mul_nonneg (Real.rpow_nonneg (lowAngleSaddle_pos hp0 hl).le _) (sub_nonneg.mpr ?_)
    have hh := Real.one_sub_inv_le_log_of_pos (lowAngleSaddle_pos hp0 hl)
    have he : 1-(lowAngleSaddle p l)⁻¹=2/(2+p*l) := by
      have h0 : p*l≠0 := by positivity
      have h1 : 2+p*l≠0 := by positivity
      dsimp [lowAngleSaddle]
      field_simp
      <;> ring
    rwa [he] at hh

theorem lowAngleK_monotone {l : ℝ} (hl : 0<l) (hlu : l<1) :
    MonotoneOn (fun p => lowAngleK p l) (Icc (1/6:ℝ) (1/4)) := by
  intro p hp q hq hpq
  have hp0 : 0<p := by linarith [hp.1]
  have hq0 : 0<q := by linarith [hq.1]
  change lowAngleK p l≤lowAngleK q l
  rw [lowAngleK_factorization hp0 hl,lowAngleK_factorization hq0 hl]
  have hR := lowAngle_crossing_over_N_monotone hl.le hlu.le hp hq hpq
  have hW := lowAngleSaddle_power_monotone hl hp0 hq0 hpq
  have hP : 0≤lowAngleCrossing p/lowAngleN p l :=
    div_nonneg (lowAngleCrossing_pos hp0.le (by linarith [hp.2])).le (lowAngleN_pos hp0 hl.le).le
  have hQ : 0≤lowAngleCrossing q/lowAngleN q l :=
    div_nonneg (lowAngleCrossing_pos hq0.le (by linarith [hq.2])).le (lowAngleN_pos hq0 hl.le).le
  have h1 : 0≤1-l := by linarith
  have hWp : 0≤(lowAngleSaddle p l)^p := (Real.rpow_pos_of_pos (lowAngleSaddle_pos hp0 hl) _).le
  have hWq : 0≤(lowAngleSaddle q l)^q := (Real.rpow_pos_of_pos (lowAngleSaddle_pos hq0 hl) _).le
  gcongr

theorem rational_rpow_lt {x y : ℝ} {m n : ℕ}
    (hx : 0<x) (hy : 0<y) (hn : n≠0) (hpow : x^m<y^n) :
    x^((m:ℝ)/n)<y := by
  have he : (x^((m:ℝ)/n))^n=x^m := by
    rw [←Real.rpow_natCast,←Real.rpow_mul hx.le]
    simp only [div_mul_cancel₀ _ (by exact_mod_cast hn : (n:ℝ)≠0),Real.rpow_natCast]
  by_contra hh
  have hle : y≤x^((m:ℝ)/n) := le_of_not_gt hh
  have hp : y^n≤(x^((m:ℝ)/n))^n := by gcongr
  rw [he] at hp
  linarith

theorem lowAngleSaddle_power_three_thirteenths {l : ℝ} (hl : 1/10≤l) :
    (lowAngleSaddle (3/13) l)^(3/13:ℝ)<17/6 := by
  have hl0 : 0<l := by linarith
  have hw : lowAngleSaddle (3/13) l≤263/3 := by
    dsimp [lowAngleSaddle]
    apply (div_le_iff₀ (by positivity)).mpr
    linarith
  have hm := Real.rpow_le_rpow (lowAngleSaddle_pos (by norm_num) hl0).le hw (by norm_num : (0:ℝ)≤3/13)
  exact hm.trans_lt (rational_rpow_lt (m:=3) (n:=13) (by norm_num : (0:ℝ)<263/3)
    (by norm_num : (0:ℝ)<17/6) (by norm_num) (by norm_num))

theorem lowAngleSaddle_power_quarter {l : ℝ} (hl : 1/2≤l) :
    (lowAngleSaddle (1/4) l)^(1/4:ℝ)<21/10 := by
  have hl0 : 0<l := by linarith
  have hw : lowAngleSaddle (1/4) l≤17 := by
    dsimp [lowAngleSaddle]
    apply (div_le_iff₀ (by positivity)).mpr
    linarith
  have hm := Real.rpow_le_rpow (lowAngleSaddle_pos (by norm_num) hl0).le hw (by norm_num : (0:ℝ)≤1/4)
  have hh := rational_rpow_lt (m:=1) (n:=4) (by norm_num : (0:ℝ)<17)
    (by norm_num : (0:ℝ)<21/10) (by norm_num) (by norm_num)
  norm_num at hh
  exact hm.trans_lt hh

theorem lowAngleCrossing_three_thirteenths : lowAngleCrossing (3/13)<9/5 := by
  dsimp only [lowAngleCrossing]
  apply (div_lt_iff₀ (by linarith [lowAngle_sin_three_thirteenths] :
    0<2*Real.sin (lowAngleTheta (3/13)))).mpr
  linarith [lowAngle_sin_three_thirteenths]

theorem lowAngleCrossing_quarter : lowAngleCrossing (1/4)<2 := by
  dsimp only [lowAngleCrossing]
  apply (div_lt_iff₀ (by linarith [lowAngle_sin_quarter] :
    0<2*Real.sin (lowAngleTheta (1/4)))).mpr
  linarith [lowAngle_sin_quarter]

theorem lowAngleK_three_thirteenths_bound {l : ℝ} (hl : 1/10≤l) (hlu : l<1) :
    lowAngleK (3/13) l<
      (8619/2755)*(1+3*l/26)*(1-l)/l := by
  have hl0 : 0<l := by linarith
  have hn : (551/169:ℝ)≤lowAngleN (3/13) l := by
    dsimp [lowAngleN]
    nlinarith
  have hN := lowAngleN_pos (by norm_num : (0:ℝ)<3/13) hl0.le
  have hc := lowAngleCrossing_pos (by norm_num : (0:ℝ)≤3/13) (by norm_num)
  have hw := Real.rpow_pos_of_pos (lowAngleSaddle_pos (by norm_num : (0:ℝ)<3/13) hl0) (3/13:ℝ)
  have h1 : 0<1-l := by linarith
  rw [lowAngleK_factorization (by norm_num) hl0]
  calc
    _ < ((9/5:ℝ)/(551/169))*(17/6)*(1+(3/13)*l/2)*(2*(1-l)/l) := by
      gcongr
      · exact lowAngleCrossing_three_thirteenths
      · exact lowAngleSaddle_power_three_thirteenths hl
    _ = _ := by ring

theorem lowAngleK_quarter_bound {l : ℝ} (hl : 1/2≤l) (hlu : l<1) :
    lowAngleK (1/4) l<(8/3)*(1-l)/l := by
  have hl0 : 0<l := by linarith
  have hn : (233/64:ℝ)≤lowAngleN (1/4) l := by dsimp [lowAngleN]; linarith
  have hN := lowAngleN_pos (by norm_num : (0:ℝ)<1/4) hl0.le
  have hc := lowAngleCrossing_pos (by norm_num : (0:ℝ)≤1/4) (by norm_num)
  have hw := Real.rpow_pos_of_pos (lowAngleSaddle_pos (by norm_num : (0:ℝ)<1/4) hl0) (1/4:ℝ)
  have h1 : 0<1-l := by linarith
  have hf : 1+(1/4:ℝ)*l/2≤9/8 := by linarith
  rw [lowAngleK_factorization (by norm_num) hl0]
  calc
    _ < ((2:ℝ)/(233/64))*(21/10)*(9/8)*(2*(1-l)/l) := by
      gcongr
      · exact lowAngleCrossing_quarter
      · exact lowAngleSaddle_power_quarter hl
      · linarith
    _ < _ := by
      have hh : 0<(1-l)/l := div_pos h1 hl0
      convert mul_lt_mul_of_pos_right
        (by norm_num : (2:ℝ)/(233/64)*(21/10)*(9/8)*2<8/3) hh using 1 <;> ring

theorem lowAngleK_low_scaled_bound {p l : ℝ}
    (hp : 1/6≤p) (hpu : p≤3/13) (hl : 1/10≤l) (hlu : l<1) :
    l*(1+lowAngleK p l)<3 := by
  have hl0 : 0<l := by linarith
  have hm := lowAngleK_monotone hl0 hlu ⟨hp,by linarith⟩
    (show (3/13:ℝ)∈Icc (1/6) (1/4) by norm_num) hpu
  have hb := hm.trans_lt (lowAngleK_three_thirteenths_bound hl hlu)
  have hb' := (lt_div_iff₀ hl0).mp hb
  have hs : (1/10:ℝ)^2≤l^2 := by nlinarith
  nlinarith

theorem lowAngleK_high_scaled_bound {p l : ℝ}
    (hp : 1/6≤p) (hpu : p≤1/4) (hl : 1/2≤l) (hlu : l<1) :
    l*(1+lowAngleK p l)<2 := by
  have hl0 : 0<l := by linarith
  have hm := lowAngleK_monotone hl0 hlu ⟨hp,hpu⟩
    (show (1/4:ℝ)∈Icc (1/6) (1/4) by norm_num) hpu
  have hb := hm.trans_lt (lowAngleK_quarter_bound hl hlu)
  have hb' := (lt_div_iff₀ hl0).mp hb
  nlinarith

theorem lowAngle_exterior_fraction_of_scaled_bound {p l d q : ℝ}
    (hp : 0<p) (hpu : p<1/2) (hl : 0<l) (hlu : l<1) (hq : l<q)
    (hd : lowAngleU p l 1/lowAngleCrossing p<d)
    (hK : l*(1+lowAngleK p l)<q) :
    l/q<d/(d+lowAngleExteriorDepth p l) := by
  have hv := lowAngleCrossing_pos hp.le hpu
  have hu := lowAngleU_pos hp hl.le (by norm_num : (0:ℝ)<1)
  have hW := lowAngleExteriorDepth_pos hp hl hlu
  have hdu := (div_lt_iff₀ hv).mp hd
  have hd0 : 0<d := (div_pos hu hv).trans hd
  have hq0 : 0<q := hl.trans hq
  have hk : l*(lowAngleCrossing p*lowAngleExteriorDepth p l)+l*lowAngleU p l 1<q*lowAngleU p l 1 := by
    have hh := mul_lt_mul_of_pos_right hK hu
    dsimp only [lowAngleK] at hh
    field_simp at hh
    nlinarith
  have hm := mul_lt_mul_of_pos_left hdu (sub_pos.mpr hq)
  apply (div_lt_div_iff₀ hq0 (by positivity : 0<d+lowAngleExteriorDepth p l)).mpr
  nlinarith

theorem lowAngle_exterior_fraction_gt_third {p l d : ℝ}
    (hp : 1/6≤p) (hpu : p≤3/13) (hl : 1/10≤l) (hlu : l<1)
    (hd : lowAngleU p l 1/lowAngleCrossing p<d) :
    l/3<d/(d+lowAngleExteriorDepth p l) :=
  lowAngle_exterior_fraction_of_scaled_bound (by linarith) (by linarith)
    (by linarith) hlu (by linarith) hd (lowAngleK_low_scaled_bound hp hpu hl hlu)

theorem lowAngle_exterior_fraction_gt_half {p l d : ℝ}
    (hp : 1/6≤p) (hpu : p≤1/4) (hl : 1/2≤l) (hlu : l<1)
    (hd : lowAngleU p l 1/lowAngleCrossing p<d) :
    l/2<d/(d+lowAngleExteriorDepth p l) :=
  lowAngle_exterior_fraction_of_scaled_bound (by linarith) (by linarith)
    (by linarith) hlu (by linarith) hd (lowAngleK_high_scaled_bound hp hpu hl hlu)

end LeanVerification.UpperLeftCompletion
