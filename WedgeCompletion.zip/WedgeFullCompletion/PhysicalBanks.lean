import LeanVerification.WedgeFullCompletion.PhysicalOrientation

/-! One pair of global sheets matches the physical left and right turns
throughout the complete admissible annulus.  The propagation uses compact
horizontal corridors and uniqueness of covering lifts. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion
set_option maxHeartbeats 1800000

theorem wedge_right_bank_corridor {D F a b : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (ha : 0 < a) (hb : b < wedgeSaddleLog D) :
    ∃ ε > 0, (Ioo a b ×ℂ Ioo 0 ε) ⊆ rightDomain D F := by
  obtain ⟨δ,hδ,htube⟩ := exists_positive_horizontal_tube (transverseFactor_continuous D F)
    (a := a) (b := b) (fun t ht => by
      rw [transverseFactor_real D F t hF]
      exact wedge_log_slope_pos hD (ha.trans_le ht.1) (ht.2.trans_lt hb))
  refine ⟨min δ (wedgeFirstAngle F),lt_min hδ (wedge_angles hF).1,?_⟩
  intro z hz
  have hp := htube z ⟨hz.1.1.le,hz.1.2.le⟩ (by
    rw [abs_of_pos hz.2.1]
    exact hz.2.2.trans_le (min_le_left _ _))
  have hi : z.im < wedgeFirstAngle F := hz.2.2.trans_le (min_le_right _ _)
  refine ⟨⟨hz.2.1.le,(hi.trans (wedge_angles hF).2.1).le,Or.inl hi.le⟩,?_⟩
  change 0 < (logPotential D F z).im
  rw [logPotential_im_factorization]
  exact mul_pos hz.2.1 hp

theorem wedge_left_bank_corridor {D F a b : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hb : b < 0) :
    ∃ ε > 0, (Ioo a b ×ℂ Ioo (-ε) 0) ⊆ leftDomain D F := by
  obtain ⟨δ,hδ,htube⟩ := exists_positive_horizontal_tube (transverseFactor_continuous D F).neg
    (a := a) (b := b) (fun t ht => by
      rw [transverseFactor_real D F t hF]
      exact neg_pos.mpr (wedge_log_slope_neg hD (ht.2.trans_lt hb)))
  refine ⟨min δ (wedgeFirstAngle F),lt_min hδ (wedge_angles hF).1,?_⟩
  intro z hz
  have hp := htube z ⟨hz.1.1.le,hz.1.2.le⟩ (by
    rw [abs_of_neg hz.2.2]
    linarith [hz.2.1,min_le_left δ (wedgeFirstAngle F)])
  have hi : -wedgeFirstAngle F < z.im := by
    linarith [hz.2.1,min_le_right δ (wedgeFirstAngle F)]
  refine ⟨?_,?_⟩
  · obtain ⟨ha,hab,hbc,hcd,hd⟩ := wedge_angles hF
    change 0 ≤ (star z : ℂ).im ∧ (star z : ℂ).im ≤ wedgeZeroAngle F ∧
      (wedgeFirstAngle F ≤ (star z : ℂ).im ∨ (star z : ℂ).re ≤ wedgeLogRadius D F) ∧
      ((star z : ℂ).im ≤ 2*wedgeFirstAngle F ∨ wedgeLogRadius D F ≤ (star z : ℂ).re)
    simp only [Complex.star_def,Complex.conj_im,Complex.conj_re]
    exact ⟨by linarith [hz.2.2],by linarith,
      Or.inr (hz.1.2.trans (hb.trans (wedgeLogRadius_pos hD hF))).le,Or.inl (by linarith)⟩
  · change 0 < (logPotential D F z).im
    rw [logPotential_im_factorization]
    exact mul_pos_of_neg_of_neg hz.2.2 (neg_pos.mp hp)

theorem wedge_right_bank_limit_propagates {D F t₀ t₁ : ℝ} {g : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (ht₀ : 0 < t₀) (ht₀u : t₀ < wedgeSaddleLog D)
    (ht₁ : 0 < t₁) (ht₁u : t₁ < wedgeSaddleLog D)
    (hg : AnalyticOnNhd ℂ g upperEnergy) (hm : MapsTo g upperEnergy (rightDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    (hl : Tendsto g (𝓝[upperEnergy] (logPotential D F (t₀ : ℂ))) (𝓝 (t₀ : ℂ))) :
    Tendsto g (𝓝[upperEnergy] (logPotential D F (t₁ : ℂ))) (𝓝 (t₁ : ℂ)) := by
  let a := min t₀ t₁/2
  let b := (max t₀ t₁+wedgeSaddleLog D)/2
  have ha : 0 < a := half_pos (lt_min ht₀ ht₁)
  have hb : b < wedgeSaddleLog D := by dsimp [b]; linarith [max_lt ht₀u ht₁u]
  have ht₀ab : t₀ ∈ Ioo a b := by
    constructor
    · exact (half_lt_self (lt_min ht₀ ht₁)).trans_le (min_le_left _ _)
    · dsimp [b]; linarith [le_max_left t₀ t₁,max_lt ht₀u ht₁u]
  have ht₁ab : t₁ ∈ Ioo a b := by
    constructor
    · exact (half_lt_self (lt_min ht₀ ht₁)).trans_le (min_le_right _ _)
    · dsimp [b]; linarith [le_max_right t₀ t₁,max_lt ht₀u ht₁u]
  obtain ⟨ε,hε,hUS⟩ := wedge_right_bank_corridor hD hF ha hb
  have hn (t : ℝ) (ht : 0 < t) (htu : t < wedgeSaddleLog D) :
      logPotentialSlope D F (t : ℂ) ≠ 0 := by
    intro heq
    have hp := wedge_log_slope_pos (F := F) hD ht htu
    rw [heq] at hp
    exact (lt_irrefl 0) hp
  let hmF : MapsTo (logPotential D F) (rightDomain D F) upperEnergy := fun _ hz => hz.2
  letI : Nonempty (rightDomain D F) := ⟨⟨g Complex.I,hm (by simp [upperEnergy])⟩⟩
  have hc := covering_of_proper_localHomeomorph_connected
    (localHomeomorph_complexRestriction (rightDomain_open hD hF hDF) upperEnergy_open hmF
      ((analyticOnNhd_logPotential D F hF).mono (subset_univ _))
      (fun _ hz => rightDomain_deriv_ne_zero hD hF hDF hz))
    (proper_rightDomain hD hF)
  apply propagate_inverse_bank_limit hmF hc
    ((analyticOnNhd_logPotential D F hF).continuousOn.mono (subset_univ _))
    hg.continuousOn hm he (complex_band_preconnected a b 0 ε) hUS
    (real_mem_closure_upper_band ht₀ab hε)
    (hasStrictDerivAt_logPotential D F hF (t₀ : ℂ)) (hn t₀ ht₀ ht₀u)
    (hasStrictDerivAt_logPotential D F hF (t₁ : ℂ)) (hn t₁ ht₁ ht₁u) hl
  have hr : (t₁ : ℂ).re ∈ Ioo a b := ht₁ab
  have hi : (t₁ : ℂ).im < ε := hε
  filter_upwards [wedge_right_local_orientation hD hF ht₁ ht₁u,
    Complex.continuous_re.continuousAt.eventually (isOpen_Ioo.mem_nhds hr),
    Complex.continuous_im.continuousAt.eventually (Iio_mem_nhds hi)] with z hz hre him
  intro hu
  exact ⟨hre,⟨hz.1.mp hu,him⟩⟩

theorem wedge_left_bank_limit_propagates {D F t₀ t₁ : ℝ} {g : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) (ht₀ : t₀ < 0) (ht₁ : t₁ < 0)
    (hg : AnalyticOnNhd ℂ g upperEnergy) (hm : MapsTo g upperEnergy (leftDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    (hl : Tendsto g (𝓝[upperEnergy] (logPotential D F (t₀ : ℂ))) (𝓝 (t₀ : ℂ))) :
    Tendsto g (𝓝[upperEnergy] (logPotential D F (t₁ : ℂ))) (𝓝 (t₁ : ℂ)) := by
  let a := min t₀ t₁-1
  let b := max t₀ t₁/2
  have hb : b < 0 := div_neg_of_neg_of_pos (max_lt ht₀ ht₁) (by norm_num)
  have ht₀ab : t₀ ∈ Ioo a b := by
    constructor
    · dsimp [a];linarith [min_le_left t₀ t₁]
    · dsimp [b];linarith [le_max_left t₀ t₁,max_lt ht₀ ht₁]
  have ht₁ab : t₁ ∈ Ioo a b := by
    constructor
    · dsimp [a];linarith [min_le_right t₀ t₁]
    · dsimp [b];linarith [le_max_right t₀ t₁,max_lt ht₀ ht₁]
  obtain ⟨ε,hε,hUS⟩ := wedge_left_bank_corridor (a := a) hD hF hb
  have hn (t : ℝ) (ht : t < 0) : logPotentialSlope D F (t : ℂ) ≠ 0 := by
    intro heq
    have hp := wedge_log_slope_neg (F := F) hD ht
    rw [heq] at hp
    exact (lt_irrefl 0) hp
  let hmF : MapsTo (logPotential D F) (leftDomain D F) upperEnergy := fun _ hz => hz.2
  letI : Nonempty (leftDomain D F) := ⟨⟨g Complex.I,hm (by simp [upperEnergy])⟩⟩
  have hc := covering_of_proper_localHomeomorph_connected
    (localHomeomorph_complexRestriction (leftDomain_open hD hF hDF) upperEnergy_open hmF
      ((analyticOnNhd_logPotential D F hF).mono (subset_univ _))
      (fun _ hz => leftDomain_deriv_ne_zero hD hF hDF hz))
    (proper_leftDomain hD hF)
  apply propagate_inverse_bank_limit hmF hc
    ((analyticOnNhd_logPotential D F hF).continuousOn.mono (subset_univ _))
    hg.continuousOn hm he (complex_band_preconnected a b (-ε) 0) hUS
    (real_mem_closure_lower_band ht₀ab hε)
    (hasStrictDerivAt_logPotential D F hF (t₀ : ℂ)) (hn t₀ ht₀)
    (hasStrictDerivAt_logPotential D F hF (t₁ : ℂ)) (hn t₁ ht₁) hl
  have hr : (t₁ : ℂ).re ∈ Ioo a b := ht₁ab
  have hi : -ε < (t₁ : ℂ).im := by simpa using neg_lt_zero.mpr hε
  filter_upwards [wedge_left_local_orientation hD hF ht₁,
    Complex.continuous_re.continuousAt.eventually (isOpen_Ioo.mem_nhds hr),
    Complex.continuous_im.continuousAt.eventually (Ioi_mem_nhds hi)] with z hz hre him
  intro hu
  exact ⟨hre,⟨him,hz.1.mp hu⟩⟩

theorem actual_right_inverse_all_banks {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    ∃ g : ℂ → ℂ, AnalyticOnNhd ℂ g upperEnergy ∧ MapsTo g upperEnergy (rightDomain D F) ∧
      (∀ z ∈ upperEnergy,logPotential D F (g z)=z) ∧
      ∀ t : ℝ, 0 < t → t < wedgeSaddleLog D →
        Tendsto g (𝓝[upperEnergy] (logPotential D F (t : ℂ))) (𝓝 (t : ℂ)) := by
  have hs := wedgeSaddleLog_pos hD
  obtain ⟨g,hg,hm,he,hl⟩ := actual_right_inverse_at_bank hD hF hDF
    (half_pos hs) (half_lt_self hs)
  exact ⟨g,hg,hm,he,fun t ht htu => wedge_right_bank_limit_propagates hD hF hDF
    (half_pos hs) (half_lt_self hs) ht htu hg hm he hl⟩

theorem actual_left_inverse_all_banks {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    ∃ g : ℂ → ℂ, AnalyticOnNhd ℂ g upperEnergy ∧ MapsTo g upperEnergy (leftDomain D F) ∧
      (∀ z ∈ upperEnergy,logPotential D F (g z)=z) ∧
      ∀ t : ℝ, t < 0 →
        Tendsto g (𝓝[upperEnergy] (logPotential D F (t : ℂ))) (𝓝 (t : ℂ)) := by
  obtain ⟨g,hg,hm,he,hl⟩ := actual_left_inverse_at_bank hD hF hDF (by norm_num : (-1 : ℝ) < 0)
  exact ⟨g,hg,hm,he,fun t ht => wedge_left_bank_limit_propagates hD hF hDF
    (by norm_num) ht hg hm he hl⟩

theorem actual_right_inverse_complete_annulus {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    ∃ g : ℂ → ℂ, AnalyticOnNhd ℂ g upperEnergy ∧ MapsTo g upperEnergy (rightDomain D F) ∧
      (∀ z ∈ upperEnergy,logPotential D F (g z)=z) ∧
      ∀ h : ℝ, AdmissibleEnergy D F h →
        Tendsto g (𝓝[upperEnergy] (h : ℂ)) (𝓝 (Real.log (rightTurn D F h) : ℂ)) := by
  obtain ⟨g,hg,hm,he,hl⟩ := actual_right_inverse_all_banks hD hF hDF
  refine ⟨g,hg,hm,he,fun h hh => ?_⟩
  have hw := rightTurn_spec D F h hh
  have ht : 0 < Real.log (rightTurn D F h) := Real.log_pos hw.2.1
  have hr := ((inCentralInterval_iff_of_lt_neg_one D _ hD).1 hw.1).2
  have htu : Real.log (rightTurn D F h) < wedgeSaddleLog D := Real.log_lt_log hw.1.1 hr
  have hb := hl _ ht htu
  rw [logPotential_real D F _ hF,Real.exp_log hw.1.1,hw.2.2] at hb
  exact hb

theorem actual_left_inverse_complete_annulus {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    ∃ g : ℂ → ℂ, AnalyticOnNhd ℂ g upperEnergy ∧ MapsTo g upperEnergy (leftDomain D F) ∧
      (∀ z ∈ upperEnergy,logPotential D F (g z)=z) ∧
      ∀ h : ℝ, AdmissibleEnergy D F h →
        Tendsto g (𝓝[upperEnergy] (h : ℂ)) (𝓝 (Real.log (leftTurn D F h) : ℂ)) := by
  obtain ⟨g,hg,hm,he,hl⟩ := actual_left_inverse_all_banks hD hF hDF
  refine ⟨g,hg,hm,he,fun h hh => ?_⟩
  have hw := leftTurn_spec D F h hh
  have ht : Real.log (leftTurn D F h) < 0 := Real.log_neg hw.1.1 hw.2.1
  have hb := hl _ ht
  rw [logPotential_real D F _ hF,Real.exp_log hw.1.1,hw.2.2] at hb
  exact hb

end LeanVerification.WedgeFullCompletion
