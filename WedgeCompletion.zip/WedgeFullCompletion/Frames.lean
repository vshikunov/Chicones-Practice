import LeanVerification.WedgeFullCompletion.BoundarySigns

/-! Closed logarithmic frames for the physical right inverse and the
reflected physical left inverse. Their intersection with the correct
nonreal energy half-plane is open because all frame boundaries have the
opposite imaginary-energy sign. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open MiddleStripCompletion
set_option maxHeartbeats 1200000

def rightFrame (D F : ℝ) : Set ℂ :=
  {z | 0 ≤ z.im ∧ z.im ≤ wedgeRightAngle F ∧
    (z.im ≤ wedgeFirstAngle F ∨ wedgeLogRadius D F ≤ z.re)}

def zeroFrame (D F : ℝ) : Set ℂ :=
  {z | 0 ≤ z.im ∧ z.im ≤ wedgeZeroAngle F ∧
    (wedgeFirstAngle F ≤ z.im ∨ z.re ≤ wedgeLogRadius D F) ∧
    (z.im ≤ 2*wedgeFirstAngle F ∨ wedgeLogRadius D F ≤ z.re)}

def rightFrameInterior (D F : ℝ) : Set ℂ :=
  {z | 0 < z.im ∧ z.im < wedgeRightAngle F ∧
    (z.im < wedgeFirstAngle F ∨ wedgeLogRadius D F < z.re)}

def zeroFrameInterior (D F : ℝ) : Set ℂ :=
  {z | 0 < z.im ∧ z.im < wedgeZeroAngle F ∧
    (wedgeFirstAngle F < z.im ∨ z.re < wedgeLogRadius D F) ∧
    (z.im < 2*wedgeFirstAngle F ∨ wedgeLogRadius D F < z.re)}

def rightDomain (D F : ℝ) : Set ℂ :=
  rightFrame D F ∩ logPotential D F ⁻¹' upperEnergy

def zeroDomain (D F : ℝ) : Set ℂ :=
  zeroFrame D F ∩ (fun z => -logPotential D F z) ⁻¹' upperEnergy

theorem rightFrame_closed (D F : ℝ) : IsClosed (rightFrame D F) :=
  (isClosed_le continuous_const Complex.continuous_im).inter
    ((isClosed_le Complex.continuous_im continuous_const).inter
      ((isClosed_le Complex.continuous_im continuous_const).union
        (isClosed_le continuous_const Complex.continuous_re)))

theorem zeroFrame_closed (D F : ℝ) : IsClosed (zeroFrame D F) :=
  (isClosed_le continuous_const Complex.continuous_im).inter
    ((isClosed_le Complex.continuous_im continuous_const).inter
      (((isClosed_le continuous_const Complex.continuous_im).union
        (isClosed_le Complex.continuous_re continuous_const)).inter
        ((isClosed_le Complex.continuous_im continuous_const).union
          (isClosed_le continuous_const Complex.continuous_re))))

theorem rightFrameInterior_open (D F : ℝ) : IsOpen (rightFrameInterior D F) :=
  (isOpen_lt continuous_const Complex.continuous_im).inter
    ((isOpen_lt Complex.continuous_im continuous_const).inter
      ((isOpen_lt Complex.continuous_im continuous_const).union
        (isOpen_lt continuous_const Complex.continuous_re)))

theorem zeroFrameInterior_open (D F : ℝ) : IsOpen (zeroFrameInterior D F) :=
  (isOpen_lt continuous_const Complex.continuous_im).inter
    ((isOpen_lt Complex.continuous_im continuous_const).inter
      (((isOpen_lt continuous_const Complex.continuous_im).union
        (isOpen_lt Complex.continuous_re continuous_const)).inter
        ((isOpen_lt Complex.continuous_im continuous_const).union
          (isOpen_lt continuous_const Complex.continuous_re))))

theorem rightFrame_strict_of_positive_energy {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hz : z ∈ rightFrame D F) (hE : 0 < (logPotential D F z).im) :
    z ∈ rightFrameInterior D F := by
  obtain ⟨ha,hab,hbc,hcd,hd⟩ := wedge_angles hF
  have hθ : 0 < z.im := by
    rcases eq_or_lt_of_le hz.1 with h | h
    · have he := logPotential_real_bank D F h.symm
      linarith
    · exact h
  have hθu : z.im < wedgeRightAngle F := by
    rcases lt_or_eq_of_le hz.2.1 with h | h
    · exact h
    · have hx : wedgeLogRadius D F ≤ z.re := hz.2.2.resolve_left (by rw [h]; linarith)
      have he := wedge_right_top_neg hD hF hDF h hx
      linarith
  refine ⟨hθ,hθu,?_⟩
  by_contra hn
  push_neg at hn
  rcases hz.2.2 with h | h
  · have he := wedge_first_boundary_le hD hF (le_antisymm h hn.1) hn.2
    linarith
  · have he := wedge_radius_right_nonpos hD hF hDF (le_antisymm hn.2 h) hn.1 hz.2.1
    linarith

theorem zeroFrame_strict_of_negative_energy {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hz : z ∈ zeroFrame D F) (hE : (logPotential D F z).im < 0) :
    z ∈ zeroFrameInterior D F := by
  obtain ⟨ha,hab,hbc,hcd,hd⟩ := wedge_angles hF
  have hθ : 0 < z.im := by
    rcases eq_or_lt_of_le hz.1 with h | h
    · have he := logPotential_real_bank D F h.symm
      linarith
    · exact h
  have hθu : z.im < wedgeZeroAngle F := by
    rcases lt_or_eq_of_le hz.2.1 with h | h
    · exact h
    · have hx : wedgeLogRadius D F ≤ z.re := hz.2.2.2.resolve_left (by rw [h]; linarith)
      have he := wedge_zero_top_pos hD hF hDF h hx
      linarith
  refine ⟨hθ,hθu,?_,?_⟩
  · by_contra hn
    push_neg at hn
    rcases hz.2.2.1 with h | h
    · have he := wedge_first_boundary_ge hD hF (le_antisymm hn.1 h) hn.2
      linarith
    · have he := wedge_radius_lower_nonneg hD hF hDF (le_antisymm h hn.2) hz.1 hn.1
      linarith
  · by_contra hn
    push_neg at hn
    rcases hz.2.2.2 with h | h
    · have he := wedge_second_boundary_ge hD hF (le_antisymm h hn.1) hn.2
      linarith
    · have he := wedge_radius_upper_nonneg hD hF hDF (le_antisymm hn.2 h) hn.1 hz.2.1
      linarith

theorem rightDomain_eq_strict {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    rightDomain D F=rightFrameInterior D F ∩ logPotential D F ⁻¹' upperEnergy := by
  ext z
  constructor
  · intro hz
    exact ⟨rightFrame_strict_of_positive_energy hD hF hDF hz.1 hz.2,hz.2⟩
  · rintro ⟨hz,hE⟩
    exact ⟨⟨hz.1.le,hz.2.1.le,hz.2.2.imp le_of_lt le_of_lt⟩,hE⟩

theorem zeroDomain_eq_strict {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    zeroDomain D F=zeroFrameInterior D F ∩ (fun z => -logPotential D F z) ⁻¹' upperEnergy := by
  ext z
  constructor
  · intro hz
    have hE : (logPotential D F z).im < 0 := by
      have h := hz.2
      change 0 < (-logPotential D F z).im at h
      simpa using h
    exact ⟨zeroFrame_strict_of_negative_energy hD hF hDF hz.1 hE,hz.2⟩
  · rintro ⟨hz,hE⟩
    exact ⟨⟨hz.1.le,hz.2.1.le,hz.2.2.1.imp le_of_lt le_of_lt,
      hz.2.2.2.imp le_of_lt le_of_lt⟩,hE⟩

theorem rightDomain_open {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) : IsOpen (rightDomain D F) := by
  rw [rightDomain_eq_strict hD hF hDF]
  exact (rightFrameInterior_open D F).inter (upperEnergy_open.preimage
    (continuous_iff_continuousOn_univ.mpr (analyticOnNhd_logPotential D F hF).continuousOn))

theorem zeroDomain_open {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) : IsOpen (zeroDomain D F) := by
  rw [zeroDomain_eq_strict hD hF hDF]
  exact (zeroFrameInterior_open D F).inter (upperEnergy_open.preimage
    (continuous_iff_continuousOn_univ.mpr (analyticOnNhd_logPotential D F hF).continuousOn).neg)

end LeanVerification.WedgeFullCompletion
