import LeanVerification.WedgeFullCompletion.QuadraticRoots
import LeanVerification.WedgeIntegralCompletion.ComplexResolventComparison

/-! Positive rescaling of the actual quadratic-power rays to the fully
proved normalized improper resolvent comparison. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open MiddleStripCompletion WedgeIntegralCompletion
set_option maxHeartbeats 2200000

def residueRayDenominator (E A B C F : ℝ) (ζ : ℂ) (r : ℝ) : ℂ :=
  (E : ℂ)+(r^(2*F-2) : ℝ)*((A : ℂ)*(r : ℂ)^2+(B : ℂ)*ζ*(r : ℂ)+(C : ℂ)*ζ^2)

def residueRayWeight (E A B C F : ℝ) (ζ : ℂ) (r : ℝ) : ℂ :=
  (r^(F-1) : ℝ)/residueRayDenominator E A B C F ζ r

theorem residueRayDenominator_scaled {A B C R E F x : ℝ} (ζ : ℂ)
    (hR : 0 < R) (hC : 0 < C) (hAR : A*R^2=C) (hx : 0 < x) :
    residueRayDenominator E A B C F ζ (R*x)=
      ((C*R^(2*F-2) : ℝ) : ℂ)*
        complexResolventDenominator (E/(C*R^(2*F-2))) (B*R/C) F ζ x := by
  have hAeq : A=C/R^2 := (eq_div_iff (pow_ne_zero 2 hR.ne')).2 hAR
  have hRn : (R : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hR.ne'
  have hCn : (C : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hC.ne'
  have hPn : ((R^(2*F-2) : ℝ) : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (Real.rpow_pos_of_pos hR _).ne'
  rw [residueRayDenominator,Real.mul_rpow hR.le hx.le,
    complexResolventDenominator,powerQuadraticDenominator,hAeq]
  push_cast
  field_simp
  <;> ring

theorem residueRayWeight_scaling_jacobian {A B C R E F x : ℝ} (ζ : ℂ)
    (hR : 0 < R) (hC : 0 < C) (hAR : A*R^2=C) (hx : 0 < x) :
    (R : ℂ)*residueRayWeight E A B C F ζ (R*x)=
      ((R^F/(C*R^(2*F-2)) : ℝ) : ℂ)*
        complexResolventWeight (E/(C*R^(2*F-2))) (B*R/C) F ζ x := by
  have hp : R*R^(F-1)=R^F := by
    calc
      _ = R^(1 : ℝ)*R^(F-1) := by rw [Real.rpow_one]
      _ = R^(1+(F-1)) := (Real.rpow_add hR _ _).symm
      _ = _ := by congr 1;ring
  have hpc := congrArg (fun r : ℝ => (r : ℂ)) hp
  rw [residueRayWeight,residueRayDenominator_scaled ζ hR hC hAR hx,
    Real.mul_rpow hR.le hx.le,complexResolventWeight]
  generalize complexResolventDenominator (E/(C*R^(2*F-2))) (B*R/C) F ζ x=Z
  push_cast at hpc ⊢
  simp only [div_eq_mul_inv,mul_inv_rev]
  linear_combination ((x^(F-1) : ℝ) : ℂ)*
    ((R^(2*F-2) : ℝ) : ℂ)⁻¹*(C : ℂ)⁻¹*
    Z⁻¹*hpc

theorem integral_positive_ray_scale (f : ℝ → ℂ) {R : ℝ} (hR : 0 < R) :
    (∫ r in Ioi (0:ℝ),f r)=(∫ x in Ioi (0:ℝ),(R : ℂ)*f (R*x)) := by
  rw [integral_const_mul,integral_comp_mul_left_Ioi f 0 hR]
  simp only [mul_zero,Complex.real_smul,←Complex.ofReal_inv]
  rw [←mul_assoc,←Complex.ofReal_mul,mul_inv_cancel₀ hR.ne',Complex.ofReal_one,one_mul]

theorem residueRayWeight_integral_scaling {A B C R E F : ℝ} (ζ : ℂ)
    (hR : 0 < R) (hC : 0 < C) (hAR : A*R^2=C) :
    (∫ r in Ioi (0:ℝ),residueRayWeight E A B C F ζ r)=
      ((R^F/(C*R^(2*F-2)) : ℝ) : ℂ)*
        ∫ x in Ioi (0:ℝ),complexResolventWeight (E/(C*R^(2*F-2))) (B*R/C) F ζ x := by
  rw [integral_positive_ray_scale _ hR,←integral_const_mul]
  exact setIntegral_congr_fun measurableSet_Ioi
    (fun x hx => residueRayWeight_scaling_jacobian ζ hR hC hAR hx)

theorem complexResolventDenominator_negative_one (e b F x : ℝ) :
    complexResolventDenominator e b F (-1) x=(realResolventDenominator e b F x : ℂ) := by
  dsimp only [complexResolventDenominator,powerQuadraticDenominator,realResolventDenominator]
  push_cast
  ring

theorem complexResolventWeight_negative_one (e b F x : ℝ) :
    complexResolventWeight e b F (-1) x=(realResolventWeight e b F x : ℂ) := by
  rw [complexResolventWeight,complexResolventDenominator_negative_one,realResolventWeight,Complex.ofReal_div]

def wedgeNormalizedMiddle (D F : ℝ) : ℝ :=
  middle D F*wedgeRadius D F/trailing D F

def wedgeEnergyScale (D F : ℝ) : ℝ :=
  trailing D F*(wedgeRadius D F)^(2*F-2)

def wedgeResolventScale (D F : ℝ) : ℝ :=
  (wedgeRadius D F)^F/wedgeEnergyScale D F

theorem wedgeEnergyScale_pos {D F : ℝ} (hD : D < -1) (hF : 3/2 < F) :
    0 < wedgeEnergyScale D F :=
  mul_pos (wedge_coefficients_pos hD hF).2.2 (Real.rpow_pos_of_pos (wedgeRadius_pos hD hF) _)

theorem wedgeResolventScale_pos {D F : ℝ} (hD : D < -1) (hF : 3/2 < F) :
    0 < wedgeResolventScale D F :=
  div_pos (Real.rpow_pos_of_pos (wedgeRadius_pos hD hF) _) (wedgeEnergyScale_pos hD hF)

theorem wedgeNormalizedMiddle_gt_two {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) : 2 < wedgeNormalizedMiddle D F :=
  (lt_div_iff₀ (wedge_coefficients_pos hD hF).2.2).2 (wedgeRadius_middle_gap hD hF hDF)

end LeanVerification.WedgeFullCompletion
