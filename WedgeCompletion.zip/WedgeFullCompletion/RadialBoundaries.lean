import LeanVerification.WedgeFullCompletion.Basic

/-! The fixed-radius and fixed-angle barriers which isolate the two actual
physical logarithmic sheets.  These identities remain valid when the curved
real-energy banks cross one of the usual straight-sector boundaries. -/

noncomputable section
open Set Filter
open scoped Topology

namespace LeanVerification.WedgeFullCompletion
open MiddleStripCompletion
set_option maxHeartbeats 1600000

def radialImag (D F r θ : ℝ) : ℝ :=
  -wedgeLeading D F*r^2*Real.sin (2*F*θ)+
    middle D F*r*Real.sin ((2*F-1)*θ)-trailing D F*Real.sin ((2*F-2)*θ)

theorem logPotential_im_radial (D F : ℝ) (z : ℂ) :
    (logPotential D F z).im=
      Real.exp ((2*F-2)*z.re)*radialImag D F (Real.exp z.re) z.im := by
  have h1 : Real.exp ((2*F-1)*z.re)=Real.exp ((2*F-2)*z.re)*Real.exp z.re := by
    rw [←Real.exp_add]
    congr 1
    ring
  have h2 : Real.exp ((2*F)*z.re)=Real.exp ((2*F-2)*z.re)*(Real.exp z.re)^2 := by
    rw [pow_two, ←mul_assoc, ←Real.exp_add, ←Real.exp_add]
    congr 1
    ring
  rw [logPotential_im, h1, h2]
  dsimp [radialImag, wedgeLeading]
  ring

theorem radialImag_at_radius {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (θ : ℝ) :
    radialImag D F (wedgeRadius D F) θ =
      Real.sin ((2*F-1)*θ)*(middle D F*wedgeRadius D F-2*trailing D F*Real.cos θ) := by
  have hs := wedgeRadius_square hD hF
  have ha : 2*F*θ=(2*F-1)*θ+θ := by ring
  have hb : (2*F-2)*θ=(2*F-1)*θ-θ := by ring
  dsimp only [radialImag]
  rw [ha, hb, Real.sin_add, Real.sin_sub]
  nlinarith only [congrArg (fun x : ℝ =>
    x*(Real.sin ((2*F-1)*θ)*Real.cos θ+Real.cos ((2*F-1)*θ)*Real.sin θ)) hs]

theorem radial_radius_factor_pos {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) (θ : ℝ) :
    0 < middle D F*wedgeRadius D F-2*trailing D F*Real.cos θ := by
  have hg := wedgeRadius_middle_gap hD hF hDF
  have hK := (wedge_coefficients_pos hD hF).2.2
  have hc := Real.cos_le_one θ
  nlinarith only [hg, hK, hc]

theorem radialImag_first_angle (D F r : ℝ) (hF : 3/2 < F) :
    radialImag D F r (wedgeFirstAngle F)=
      Real.sin (wedgeFirstAngle F)*(wedgeLeading D F*r^2-trailing D F) := by
  have hfn : 2*F-1 ≠ 0 := by linarith
  have hm : (2*F-1)*wedgeFirstAngle F=Real.pi := by
    dsimp [wedgeFirstAngle]
    field_simp
  have hp : 2*F*wedgeFirstAngle F=wedgeFirstAngle F+Real.pi := by nlinarith only [hm]
  have hk : (2*F-2)*wedgeFirstAngle F=Real.pi-wedgeFirstAngle F := by nlinarith only [hm]
  dsimp only [radialImag]
  rw [hp, hm, hk, Real.sin_add_pi, Real.sin_pi, Real.sin_pi_sub]
  ring

theorem radialImag_second_angle (D F r : ℝ) (hF : 3/2 < F) :
    radialImag D F r (2*wedgeFirstAngle F)=
      Real.sin (2*wedgeFirstAngle F)*(trailing D F-wedgeLeading D F*r^2) := by
  have hfn : 2*F-1 ≠ 0 := by linarith
  have hm : (2*F-1)*wedgeFirstAngle F=Real.pi := by
    dsimp [wedgeFirstAngle]
    field_simp
  have hp : 2*F*(2*wedgeFirstAngle F)=2*wedgeFirstAngle F+2*Real.pi := by nlinarith only [hm]
  have hb : (2*F-1)*(2*wedgeFirstAngle F)=2*Real.pi := by nlinarith only [hm]
  have hk : (2*F-2)*(2*wedgeFirstAngle F)=2*Real.pi-2*wedgeFirstAngle F := by nlinarith only [hm]
  dsimp only [radialImag]
  rw [hp, hb, hk, Real.sin_add_two_pi, Real.sin_two_pi, Real.sin_two_pi_sub]
  ring

theorem radialImag_right_angle (D F r : ℝ) (hF : 3/2 < F) :
    radialImag D F r (wedgeRightAngle F)=
      Real.sin (wedgeRightAngle F)*(2*trailing D F*Real.cos (wedgeRightAngle F)-middle D F*r) := by
  have hfn : 2*F ≠ 0 := by linarith
  have hp : 2*F*wedgeRightAngle F=2*Real.pi := by
    dsimp [wedgeRightAngle]
    field_simp
  have hb : (2*F-1)*wedgeRightAngle F=2*Real.pi-wedgeRightAngle F := by nlinarith only [hp]
  have hk : (2*F-2)*wedgeRightAngle F=2*Real.pi-2*wedgeRightAngle F := by nlinarith only [hp]
  dsimp only [radialImag]
  rw [hp, hb, hk, Real.sin_two_pi, Real.sin_two_pi_sub, Real.sin_two_pi_sub, Real.sin_two_mul]
  ring

theorem radialImag_zero_angle (D F r : ℝ) (hF : 3/2 < F) :
    radialImag D F r (wedgeZeroAngle F)=
      Real.sin (wedgeZeroAngle F)*(middle D F*r-2*trailing D F*Real.cos (wedgeZeroAngle F)) := by
  have hfn : 2*F ≠ 0 := by linarith
  have hp : 2*F*wedgeZeroAngle F=3*Real.pi := by
    dsimp [wedgeZeroAngle]
    field_simp
  have hb : (2*F-1)*wedgeZeroAngle F=(Real.pi-wedgeZeroAngle F)+2*Real.pi := by nlinarith only [hp]
  have hk : (2*F-2)*wedgeZeroAngle F=(Real.pi-2*wedgeZeroAngle F)+2*Real.pi := by nlinarith only [hp]
  have hs : Real.sin (3*Real.pi)=0 := by
    rw [show 3*Real.pi=Real.pi+2*Real.pi by ring, Real.sin_add_two_pi, Real.sin_pi]
  dsimp only [radialImag]
  rw [hp, hb, hk, hs, Real.sin_add_two_pi, Real.sin_pi_sub,
    Real.sin_add_two_pi, Real.sin_pi_sub, Real.sin_two_mul]
  ring

theorem sine_between_pi_two_pi_nonpos {θ : ℝ}
    (hlo : Real.pi ≤ θ) (hhi : θ ≤ 2*Real.pi) : Real.sin θ ≤ 0 := by
  have h := Real.sin_nonneg_of_mem_Icc (show θ-Real.pi ∈ Icc 0 Real.pi by constructor <;> linarith)
  have he : θ=(θ-Real.pi)+Real.pi := by ring
  rw [he, Real.sin_add_pi]
  exact neg_nonpos.mpr h

theorem sine_between_two_pi_three_pi_nonneg {θ : ℝ}
    (hlo : 2*Real.pi ≤ θ) (hhi : θ ≤ 3*Real.pi) : 0 ≤ Real.sin θ := by
  have h := Real.sin_nonneg_of_mem_Icc (show θ-2*Real.pi ∈ Icc 0 Real.pi by constructor <;> linarith)
  simpa only [Real.sin_sub_two_pi] using h

theorem wedge_first_angle_sin_pos {F : ℝ} (hF : 3/2 < F) :
    0 < Real.sin (wedgeFirstAngle F) := by
  obtain ⟨ha,hab,hbc,hcd,hd⟩ := wedge_angles hF
  exact Real.sin_pos_of_pos_of_lt_pi ha (by linarith)

theorem wedge_second_angle_sin_pos {F : ℝ} (hF : 3/2 < F) :
    0 < Real.sin (2*wedgeFirstAngle F) := by
  obtain ⟨ha,hab,hbc,hcd,hd⟩ := wedge_angles hF
  exact Real.sin_pos_of_pos_of_lt_pi (by linarith) (hcd.trans hd)

theorem wedge_right_angle_sin_pos {F : ℝ} (hF : 3/2 < F) :
    0 < Real.sin (wedgeRightAngle F) := by
  obtain ⟨ha,hab,hbc,hcd,hd⟩ := wedge_angles hF
  exact Real.sin_pos_of_pos_of_lt_pi (ha.trans hab) (by linarith)

theorem wedge_zero_angle_sin_pos {F : ℝ} (hF : 3/2 < F) :
    0 < Real.sin (wedgeZeroAngle F) := by
  obtain ⟨ha,hab,hbc,hcd,hd⟩ := wedge_angles hF
  exact Real.sin_pos_of_pos_of_lt_pi (by linarith) hd

end LeanVerification.WedgeFullCompletion
