import LeanVerification.WedgeFullCompletion.RegularBanks
import LeanVerification.HigherUpperLeftCompletion.NegativeOrientation

/-! The zero-end height is the actual boundary energy in the open wedge.
The second real critical value lies strictly above it. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion

theorem wedge_height_lt_saddle {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    height D F < wedgeSaddleHeight D F := by
  have h := HigherUpperLeftCompletion.physical_exterior_depth_pos hD (by linarith : 1 < F) hDF
  dsimp only [ExteriorCompletion.exteriorEnergy,ContourCompletion.exteriorSaddle] at h
  rw [height_eq_zeroEndpointHeight]
  dsimp [wedgeSaddleHeight]
  linarith

theorem wedge_saddleHeight_pos {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    0 < wedgeSaddleHeight D F :=
  (height_pos (by linarith) hF).trans (wedge_height_lt_saddle hD hF hDF)

theorem wedge_admissibleEnergy_iff {D F h : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    AdmissibleEnergy D F h ↔ 0 < h ∧ h < height D F := by
  have hl : Tendsto (potential D F) (𝓝[>] (centralLeftEndpoint D))
      (𝓝 (height D F)) := by
    rw [height_eq_zeroEndpointHeight]
    simpa only [centralLeftEndpoint,if_neg (by linarith : ¬0 < D)] using
      tendsto_potential_zero_above_one D F (by linarith : 1 < F)
  have hr : Tendsto (potential D F) (centralRightEndpointFilter D)
      (𝓝 (wedgeSaddleHeight D F)) :=
    tendsto_potential_right_endpoint_of_lt_neg_one D F hD
  rw [admissibleEnergy_iff_below_finite_endpoint_limits D F h _ _ hl hr,
    min_eq_left (wedge_height_lt_saddle hD hF hDF).le]

theorem wedge_admissibleEnergy_set {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    {h : ℝ | AdmissibleEnergy D F h}=Ioo 0 (height D F) := by
  ext h
  exact wedge_admissibleEnergy_iff hD hF hDF

end LeanVerification.WedgeFullCompletion
