import LeanVerification.WedgeFullCompletion.PhysicalBanks
import LeanVerification.MiddleStripSpectral.UpperGermCompatibility

/-! A regular cluster value of a holomorphic inverse determines its entire
local upper-bank germ.  The proof uses the analytic identity theorem on a
connected upper half-ball, so it does not assume an unproved boundary
orientation at the corners of a curved-sheet frame. -/

noncomputable section
open Set Filter Metric
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open MiddleStripCompletion MiddleStripSpectral
set_option maxHeartbeats 1600000

theorem inverse_germ_of_regular_cluster
    {f g : ℂ → ℂ} {x w a : ℂ} {u : ℕ → ℂ}
    (hg : AnalyticOnNhd ℂ g upperEnergy)
    (he : ∀ z ∈ upperEnergy, f (g z)=z)
    (ha : AnalyticAt ℂ f w) (hd : HasStrictDerivAt f a w) (han : a ≠ 0)
    (hw : f w=x)
    (hu : ∀ n, u n ∈ upperEnergy) (hul : Tendsto u atTop (𝓝 x))
    (hgl : Tendsto (fun n => g (u n)) atTop (𝓝 w)) :
    ∃ j : ℂ → ℂ, AnalyticAt ℂ j x ∧ j x=w ∧
      g =ᶠ[𝓝[upperEnergy] x] j ∧ Tendsto g (𝓝[upperEnergy] x) (𝓝 w) := by
  let hd' := hd.hasStrictFDerivAt_equiv han
  let e := hd'.toPartialHomeomorph f
  have hwS : w ∈ e.source := hd'.mem_toPartialHomeomorph_source
  have hxT : x ∈ e.target := by rw [←hw]; exact hd'.image_mem_toPartialHomeomorph_target
  have hjx : AnalyticAt ℂ e.symm x := by
    rw [←hw]
    exact e.analyticAt_symm' hwS ha hd'.hasFDerivAt.fderiv
  obtain ⟨r,hr,hball⟩ := Metric.eventually_nhds_iff.mp
    (hjx.eventually_analyticAt.and (e.open_target.mem_nhds hxT))
  let U : Set ℂ := ball x r ∩ upperEnergy
  have hjU : AnalyticOnNhd ℂ e.symm U := fun z hz => (hball hz.1).1
  have hselect : ∀ᶠ n : ℕ in atTop, u n ∈ U ∧ g (u n) ∈ e.source := by
    filter_upwards [hul.eventually (ball_mem_nhds x hr),
      hgl.eventually (e.open_source.mem_nhds hwS)] with n hn hgS
    exact ⟨⟨hn,hu n⟩,hgS⟩
  obtain ⟨n,hnU,hng⟩ := hselect.exists
  have hgcont : ContinuousAt g (u n) := (hg _ (hu n)).continuousAt
  have hez : g =ᶠ[𝓝 (u n)] e.symm := by
    filter_upwards [hgcont.eventually (e.open_source.mem_nhds hng),
      upperEnergy_open.mem_nhds (hu n)] with z hz hzU
    have hi := e.left_inv hz
    change e.symm (f (g z))=g z at hi
    rw [he z hzU] at hi
    exact hi.symm
  have heU : EqOn g e.symm U :=
    (hg.mono inter_subset_right).eqOn_of_preconnected_of_eventuallyEq hjU
      ((convex_ball x r).inter upperEnergy_convex).isPreconnected hnU hez
  have hev : g =ᶠ[𝓝[upperEnergy] x] e.symm := by
    filter_upwards [self_mem_nhdsWithin,
      mem_nhdsWithin_of_mem_nhds (ball_mem_nhds x hr)] with z hz hb
    exact heU ⟨hb,hz⟩
  have hval : e.symm x=w := by rw [←hw]; exact e.left_inv hwS
  have hlim : Tendsto e.symm (𝓝[upperEnergy] x) (𝓝 w) := by
    rw [←hval]
    exact hjx.continuousAt.tendsto.mono_left nhdsWithin_le_nhds
  exact ⟨e.symm,hjx,hval,hev,hlim.congr' hev.symm⟩

end LeanVerification.WedgeFullCompletion
