import LeanVerification.WedgeFullCompletion.ActualPair
import Mathlib.Tactic.LinearCombination

/-! Derivatives of the actual bank values and the strict increase of the
reflected-left logarithmic angle. These are derivatives of the constructed
physical inverses, not additional spectral data. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral RegionalComplex
set_option maxHeartbeats 2000000

theorem logPotentialSlope_factorLog {D F : ℝ} {w : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) (hw : w ∈ logRayStrip) :
    logPotentialSlope D F w=(logPotential D F w-(height D F : ℂ))*
      factorLogDeriv (2*F) (wedgeRootLower D F) (wedgeRootUpper D F) w := by
  have hL := (hasDerivAt_factorLogMap (2*F) (wedgeRootLower D F) (wedgeRootUpper D F) hw).cexp
  have hR := ((hasDerivAt_const w (height D F : ℂ)).sub
    (hasDerivAt_logPotential D F hF w)).div_const (wedgeLeading D F : ℂ)
  have he : (fun z => Complex.exp (actualFactorLog D F z)) =ᶠ[𝓝 w]
      (fun z => ((height D F : ℂ)-logPotential D F z)/(wedgeLeading D F : ℂ)) := by
    filter_upwards [logRayStrip_open.mem_nhds hw] with z hz
    exact actualFactorLog_exp hD hF hDF hz
  have hd := (hL.congr_of_eventuallyEq he.symm).unique hR
  change Complex.exp (actualFactorLog D F w)*
    factorLogDeriv (2*F) (wedgeRootLower D F) (wedgeRootUpper D F) w=
      (0-logPotentialSlope D F w)/(wedgeLeading D F : ℂ) at hd
  rw [actualFactorLog_exp hD hF hDF hw] at hd
  have hχ : (wedgeLeading D F : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (wedge_coefficients_pos hD hF).1.ne'
  field_simp at hd
  linear_combination hd

theorem logPotentialSlope_inverse_im_pos {D F t : ℝ} {w : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) (hw : w ∈ logRayStrip)
    (ht : height D F < t) (he : logPotential D F w=(t : ℂ)) :
    0 < (logPotentialSlope D F w)⁻¹.im := by
  obtain ⟨hu,huv⟩ := wedge_roots_pos_order hD hF hDF
  have hp := factorLogDeriv_inverse_im_pos (2*F) hu (hu.trans huv) hw
  rw [logPotentialSlope_factorLog hD hF hDF hw,he,←Complex.ofReal_sub,mul_inv_rev,
    ←div_eq_mul_inv,Complex.div_ofReal_im]
  exact div_pos hp (sub_pos.mpr ht)

theorem inverse_real_bank_hasDerivAt {D F t : ℝ} {k : ℝ → ℂ} {S : Set ℝ}
    (hF : 3/2 < F) (hS : IsOpen S) (ht : t ∈ S) (hk : DifferentiableAt ℝ k t)
    (he : ∀ s ∈ S,logPotential D F (k s)=(s : ℂ))
    (hn : logPotentialSlope D F (k t) ≠ 0) :
    HasDerivAt k (logPotentialSlope D F (k t))⁻¹ t := by
  have hd := (hasDerivAt_logPotential D F hF (k t)).comp t hk.hasDerivAt
  have hev : (fun s : ℝ => logPotential D F (k s)) =ᶠ[𝓝 t] (fun s => (s : ℂ)) := by
    filter_upwards [hS.mem_nhds ht] with s hs
    exact he s hs
  have hp := (hd.congr_of_eventuallyEq hev.symm).unique (Complex.ofRealCLM.hasDerivAt (x := t))
  have heq : deriv k t=(logPotentialSlope D F (k t))⁻¹ := by
    apply (mul_left_cancel₀ hn)
    rw [mul_inv_cancel₀ hn]
    exact hp
  exact hk.hasDerivAt.congr_deriv heq

namespace ActualWedgePair
variable {D F : ℝ} (b : ActualWedgePair D F)

theorem rightCutLog_analytic (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    AnalyticOnNhd ℝ b.rightCutLog (Ioi (wedgeSaddleHeight D F)) :=
  analyticOnNhd_upperBank_of_germs isOpen_Ioi
    (fun _ ht => (b.rightCutLog_spec hD hF hDF ht).2.2.2.1)

theorem leftCutLog_analytic (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    AnalyticOnNhd ℝ b.leftCutLog (Ioi (height D F)) := by
  have ha : AnalyticOnNhd ℝ (upperBank b.left) (Ioi (height D F)) :=
    analyticOnNhd_upperBank_of_germs isOpen_Ioi
      (fun _ ht => (b.leftCutLog_spec hD hF hDF ht).2.2.2.1)
  intro t ht
  simpa only [leftCutLog,Complex.conjCLE_apply,Complex.star_def] using
    (Complex.conjCLE.toContinuousLinearMap.analyticAt (upperBank b.left t)).comp (ha t ht)

theorem rightCutLog_hasDerivAt (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) :
    HasDerivAt b.rightCutLog (logPotentialSlope D F (b.rightCutLog t))⁻¹ t := by
  have hs := b.rightCutLog_strip hD hF hDF ht
  exact inverse_real_bank_hasDerivAt hF isOpen_Ioi ht
    ((b.rightCutLog_analytic hD hF hDF) t ht).differentiableAt
    (fun _ hx => (b.rightCutLog_spec hD hF hDF hx).2.2.1)
    (wedge_logPotentialSlope_ne_zero hD (by linarith [hs.1,Real.pi_pos]) hs.2 hs.1.ne')

theorem leftCutLog_hasDerivAt (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F < t) :
    HasDerivAt b.leftCutLog (logPotentialSlope D F (b.leftCutLog t))⁻¹ t := by
  have hs := b.leftCutLog_strip hD hF hDF ht
  exact inverse_real_bank_hasDerivAt hF isOpen_Ioi ht
    ((b.leftCutLog_analytic hD hF hDF) t ht).differentiableAt
    (fun _ hx => (b.leftCutLog_spec hD hF hDF hx).2.2.1)
    (wedge_logPotentialSlope_ne_zero hD (by linarith [hs.1,Real.pi_pos]) hs.2 hs.1.ne')

theorem leftCutLog_angle_deriv_pos (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F < t) : 0 < deriv (fun s => (b.leftCutLog s).im) t := by
  have hd := Complex.imCLM.hasFDerivAt.comp_hasDerivAt t (b.leftCutLog_hasDerivAt hD hF hDF ht)
  change HasDerivAt (fun s => (b.leftCutLog s).im) (logPotentialSlope D F (b.leftCutLog t))⁻¹.im t at hd
  rw [hd.deriv]
  exact logPotentialSlope_inverse_im_pos hD hF hDF (b.leftCutLog_strip hD hF hDF ht) ht
    (b.leftCutLog_spec hD hF hDF ht).2.2.1

theorem leftCutLog_angle_strictMonoOn (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    StrictMonoOn (fun t => (b.leftCutLog t).im) (Ioi (height D F)) := by
  apply strictMonoOn_of_deriv_pos (convex_Ioi _)
  · exact Complex.continuous_im.continuousOn.comp
      (b.leftCutLog_analytic hD hF hDF).continuousOn (mapsTo_univ _ _)
  · intro t ht
    exact b.leftCutLog_angle_deriv_pos hD hF hDF (interior_subset ht)

end ActualWedgePair
end LeanVerification.WedgeFullCompletion
