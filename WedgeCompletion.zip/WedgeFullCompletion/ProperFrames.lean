import LeanVerification.WedgeFullCompletion.Frames
import LeanVerification.MiddleStripCompletion.StripProper

/-! Properness of the actual framed potential maps.  Both horizontal
escape directions are controlled uniformly in angle, and compact target
sets cannot meet any finite frame boundary. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open MiddleStripCompletion
set_option maxHeartbeats 1200000

theorem compact_real_bounds_of_uniform_ends {f : ℂ → ℂ} (c : ℝ)
    (hbot : ∀ ε : ℝ, 0 < ε → ∃ a : ℝ, ∀ z : ℂ, z.re ≤ a → ‖f z-(c : ℂ)‖ < ε)
    (htop : ∀ M : ℝ, ∃ b : ℝ, ∀ z : ℂ, b ≤ z.re → M < ‖f z‖)
    (K : Set ℂ) (hK : IsCompact K) (hKU : K ⊆ upperEnergy) :
    ∃ l r : ℝ, ∀ z : ℂ, f z ∈ K → l ≤ z.re ∧ z.re ≤ r := by
  rcases K.eq_empty_or_nonempty with hKe | hKn
  · exact ⟨0,0,fun z hz => False.elim (by simpa [hKe] using hz)⟩
  obtain ⟨u,hu,humin⟩ := hK.exists_isMinOn hKn Complex.continuous_im.continuousOn
  obtain ⟨v,hv,hvmax⟩ := hK.exists_isMaxOn hKn continuous_norm.continuousOn
  have hu0 : 0 < u.im := hKU hu
  obtain ⟨l,hl⟩ := hbot u.im hu0
  obtain ⟨r,hr⟩ := htop ‖v‖
  refine ⟨l,r,fun z hz => ⟨?_,?_⟩⟩
  · by_contra hn
    have he := hl z (le_of_not_ge hn)
    have hlo : u.im ≤ (f z).im := humin hz
    have hnorm := Complex.im_le_norm (f z-(c : ℂ))
    simp only [Complex.sub_im,Complex.ofReal_im,sub_zero] at hnorm
    linarith
  · by_contra hn
    have he := hr z (le_of_not_ge hn)
    have hhi : ‖f z‖ ≤ ‖v‖ := hvmax hz
    linarith

theorem proper_closed_frame {f : ℂ → ℂ} {S : Set ℂ} {a b : ℝ}
    (hf : Continuous f) (hS : IsClosed S)
    (him : ∀ z ∈ S, a ≤ z.im ∧ z.im ≤ b)
    (hbound : ∀ K : Set ℂ, IsCompact K → K ⊆ upperEnergy →
      ∃ l r : ℝ, ∀ z : ℂ, f z ∈ K → l ≤ z.re ∧ z.re ≤ r) :
    IsProperMap (complexRestriction f (S ∩ f ⁻¹' upperEnergy) upperEnergy
      (fun _ hz => hz.2)) := by
  apply isProperMap_iff_isCompact_preimage.mpr
  constructor
  · exact (hf.comp continuous_subtype_val).subtype_mk (fun z => z.property.2)
  · intro K hK
    let L : Set ℂ := Subtype.val '' K
    have hL : IsCompact L := hK.image continuous_subtype_val
    have hLU : L ⊆ upperEnergy := by
      rintro z ⟨u,hu,rfl⟩
      exact u.property
    obtain ⟨l,r,hlr⟩ := hbound L hL hLU
    let Q : Set ℂ := (Icc l r) ×ℂ (Icc a b)
    have hQ : IsCompact Q := isCompact_Icc.reProdIm isCompact_Icc
    apply Topology.IsEmbedding.subtypeVal.isCompact_iff.mpr
    have he : Subtype.val ''
        ((complexRestriction f (S ∩ f ⁻¹' upperEnergy) upperEnergy
          (fun _ hz => hz.2)) ⁻¹' K)=(Q ∩ S) ∩ f ⁻¹' L := by
      apply Set.Subset.antisymm
      · rintro z ⟨u,hu,rfl⟩
        have hfu : f u ∈ L := ⟨complexRestriction f (S ∩ f ⁻¹' upperEnergy)
          upperEnergy (fun _ hz => hz.2) u,hu,rfl⟩
        exact ⟨⟨⟨hlr u hfu,him u u.property.1⟩,u.property.1⟩,hfu⟩
      · intro z hz
        let u : {z : ℂ // z ∈ S ∩ f ⁻¹' upperEnergy} := ⟨z,⟨hz.1.2,hLU hz.2⟩⟩
        refine ⟨u,?_,rfl⟩
        obtain ⟨v,hv,hev⟩ := hz.2
        have hev' : complexRestriction f (S ∩ f ⁻¹' upperEnergy) upperEnergy
            (fun _ hz => hz.2) u=v := Subtype.ext hev.symm
        change complexRestriction f (S ∩ f ⁻¹' upperEnergy) upperEnergy
          (fun _ hz => hz.2) u ∈ K
        rw [hev']
        exact hv
    rw [he]
    exact (hQ.inter_right hS).inter_right (hL.isClosed.preimage hf)

theorem wedge_compact_real_bounds {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F)
    (K : Set ℂ) (hK : IsCompact K) (hKU : K ⊆ upperEnergy) :
    ∃ l r : ℝ, ∀ z : ℂ, logPotential D F z ∈ K → l ≤ z.re ∧ z.re ≤ r :=
  compact_real_bounds_of_uniform_ends (height D F)
    (fun ε hε => uniform_logPotential_atBot D F hF hε)
    (wedge_uniform_logPotential_atTop hD hF) K hK hKU

theorem wedge_negative_compact_real_bounds {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F)
    (K : Set ℂ) (hK : IsCompact K) (hKU : K ⊆ upperEnergy) :
    ∃ l r : ℝ, ∀ z : ℂ, -logPotential D F z ∈ K → l ≤ z.re ∧ z.re ≤ r := by
  apply compact_real_bounds_of_uniform_ends (-height D F) ?_ ?_ K hK hKU
  · intro ε hε
    obtain ⟨a,ha⟩ := uniform_logPotential_atBot D F hF hε
    refine ⟨a,fun z hz => ?_⟩
    have he : -logPotential D F z-((-height D F : ℝ) : ℂ)=
        -(logPotential D F z-(height D F : ℂ)) := by push_cast; ring
    rw [he, norm_neg]
    exact ha z hz
  · intro M
    obtain ⟨b,hb⟩ := wedge_uniform_logPotential_atTop hD hF M
    exact ⟨b,fun z hz => by simpa only [norm_neg] using hb z hz⟩

theorem proper_rightDomain {D F : ℝ} (hD : D < -1) (hF : 3/2 < F) :
    IsProperMap (complexRestriction (logPotential D F) (rightDomain D F) upperEnergy
      (fun _ hz => hz.2)) :=
  proper_closed_frame
    (continuous_iff_continuousOn_univ.mpr (analyticOnNhd_logPotential D F hF).continuousOn)
    (rightFrame_closed D F) (fun _ hz => ⟨hz.1,hz.2.1⟩)
    (wedge_compact_real_bounds hD hF)

theorem proper_zeroDomain {D F : ℝ} (hD : D < -1) (hF : 3/2 < F) :
    IsProperMap (complexRestriction (fun z => -logPotential D F z) (zeroDomain D F) upperEnergy
      (fun _ hz => hz.2)) :=
  proper_closed_frame
    (continuous_iff_continuousOn_univ.mpr (analyticOnNhd_logPotential D F hF).continuousOn).neg
    (zeroFrame_closed D F) (fun _ hz => ⟨hz.1,hz.2.1⟩)
    (wedge_negative_compact_real_bounds hD hF)

end LeanVerification.WedgeFullCompletion
