import LeanVerification.WedgeFullCompletion.ResidueIdentity
import LeanVerification.WedgeFullCompletion.ResolventScaling

/-! Exact logarithmic substitution on both complete horizontal banks. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion WedgeIntegralCompletion
set_option maxHeartbeats 2200000

theorem scaled_exp_log_add_imag (a y : ℝ) {r : ℝ} (hr : 0 < r) :
    Complex.exp ((a : ℂ)*((Real.log r : ℂ)+(y : ℂ)*Complex.I))=
      ((r^a : ℝ) : ℂ)*Complex.exp ((a : ℂ)*(y : ℂ)*Complex.I) := by
  rw [mul_add,Complex.exp_add]
  congr 1
  · rw [←Complex.ofReal_mul,←Complex.ofReal_exp,Real.rpow_def_of_pos hr]
    congr 2
    ring
  · congr 1
    ring

theorem residue_ray_denominator_identity {D F t r y : ℝ} (hr : 0 < r)
    (hy : Complex.exp ((F : ℂ)*(y : ℂ)*Complex.I)=1) :
    residueRayDenominator (t-height D F) (wedgeLeading D F) (middle D F)
        (trailing D F) F (-Complex.exp (-(y : ℂ)*Complex.I)) r=
      (t : ℂ)-logPotential D F ((Real.log r : ℂ)+(y : ℂ)*Complex.I) := by
  have hm : Complex.exp (((2*F-2 : ℝ) : ℂ)*(y : ℂ)*Complex.I)=
      (Complex.exp (-(y : ℂ)*Complex.I))^2 := by
    calc
      _ = Complex.exp ((F : ℂ)*(y : ℂ)*Complex.I)*
          Complex.exp ((F : ℂ)*(y : ℂ)*Complex.I)*
          Complex.exp (-(y : ℂ)*Complex.I)*Complex.exp (-(y : ℂ)*Complex.I) := by
            rw [←Complex.exp_add,←Complex.exp_add,←Complex.exp_add]
            congr 1
            push_cast
            ring
      _ = _ := by rw [hy];ring
  have he : Complex.exp ((Real.log r : ℂ)+(y : ℂ)*Complex.I)=
      (r : ℂ)*Complex.exp ((y : ℂ)*Complex.I) := by
    rw [Complex.exp_add,←Complex.ofReal_exp,Real.exp_log hr]
  have hn : Complex.exp (-(y : ℂ)*Complex.I)*Complex.exp ((y : ℂ)*Complex.I)=1 := by
    rw [←Complex.exp_add]
    convert Complex.exp_zero using 1 <;> congr 1 <;> ring
  have hq := logPotential_quadratic_factor D F ((Real.log r : ℂ)+(y : ℂ)*Complex.I)
  rw [scaled_exp_log_add_imag _ _ hr,hm,he] at hq
  dsimp only [residueRayDenominator]
  push_cast
  linear_combination -hq -
    ((r^(2*F-2) : ℝ) : ℂ)*
      ((wedgeLeading D F : ℂ)*(r : ℂ)^2*
        (Complex.exp (-(y : ℂ)*Complex.I)*Complex.exp ((y : ℂ)*Complex.I)+1)-
        (middle D F : ℂ)*(r : ℂ)*Complex.exp (-(y : ℂ)*Complex.I))*hn

theorem residue_horizontal_log_jacobian {D F t r y : ℝ} (hr : 0 < r)
    (hy : Complex.exp ((F : ℂ)*(y : ℂ)*Complex.I)=1) :
    ((r⁻¹ : ℝ) : ℂ)*wedgeResidueKernel D F t
        ((Real.log r : ℂ)+(y : ℂ)*Complex.I)=
      -residueRayWeight (t-height D F) (wedgeLeading D F) (middle D F)
        (trailing D F) F (-Complex.exp (-(y : ℂ)*Complex.I)) r := by
  have hp : r⁻¹*r^F=r^(F-1) := by
    rw [Real.rpow_sub hr,Real.rpow_one]
    ring
  have hpc := congrArg (fun s : ℝ => (s : ℂ)) hp
  rw [wedgeResidueKernel,scaled_exp_log_add_imag _ _ hr,hy,mul_one,
    residueRayWeight,residue_ray_denominator_identity hr hy]
  rw [←neg_sub,div_neg]
  push_cast at hpc ⊢
  rw [mul_neg,←mul_div_assoc,hpc]

theorem integral_log_positive_ray (f : ℝ → ℂ) :
    (∫ x : ℝ,f x)=(∫ r in Ioi (0:ℝ),((r⁻¹ : ℝ) : ℂ)*f (Real.log r)) := by
  have him : Real.log '' Ioi (0:ℝ)=univ := by
    apply eq_univ_of_forall
    intro x
    exact ⟨Real.exp x,Real.exp_pos x,Real.log_exp x⟩
  have hc := integral_image_eq_integral_abs_deriv_smul measurableSet_Ioi
    (fun x hx => (Real.hasDerivAt_log (ne_of_gt hx)).hasDerivWithinAt)
    Real.strictMonoOn_log.injOn f
  rw [him,setIntegral_univ] at hc
  rw [hc]
  apply setIntegral_congr_fun measurableSet_Ioi
  intro r hr
  dsimp only
  rw [abs_of_pos (inv_pos.mpr hr),Complex.real_smul]

theorem residue_horizontal_integral_ray_identity {D F t y : ℝ}
    (hy : Complex.exp ((F : ℂ)*(y : ℂ)*Complex.I)=1) :
    (∫ x : ℝ,wedgeResidueKernel D F t ((x : ℂ)+(y : ℂ)*Complex.I))=
      -(∫ r in Ioi (0:ℝ),residueRayWeight (t-height D F) (wedgeLeading D F) (middle D F)
        (trailing D F) F (-Complex.exp (-(y : ℂ)*Complex.I)) r) := by
  rw [integral_log_positive_ray,←integral_neg]
  exact setIntegral_congr_fun measurableSet_Ioi
    (fun r hr => residue_horizontal_log_jacobian hr hy)

theorem residue_contour_phase {F : ℝ} (hF : F ≠ 0) :
    Complex.exp ((F : ℂ)*(wedgeContourAngle F : ℂ)*Complex.I)=1 := by
  have he : (F : ℂ)*(wedgeContourAngle F : ℂ)=2*(Real.pi : ℂ) := by
    have hFc : (F : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hF
    dsimp only [wedgeContourAngle]
    push_cast
    field_simp
  rw [he,Complex.exp_two_pi_mul_I]

theorem residueRayDenominator_negative_one_actual {D F t r : ℝ}
    (hF : 3/2 < F) (hr : 0 < r) :
    residueRayDenominator (t-height D F) (wedgeLeading D F) (middle D F)
      (trailing D F) F (-1) r=(t-potential D F r : ℝ) := by
  have h := residue_ray_denominator_identity (D:=D) (F:=F) (t:=t) (y:=0) hr (by simp)
  simpa only [Complex.ofReal_zero,zero_mul,neg_zero,Complex.exp_zero,add_zero,
    logPotential_real D F _ hF,Real.exp_log hr,Complex.ofReal_sub] using h

theorem actual_normalized_real_resolvent_pos {D F t x : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (ht : wedgeSaddleHeight D F < t) (hx : 0 < x) :
    0 < realResolventDenominator ((t-height D F)/wedgeEnergyScale D F)
      (wedgeNormalizedMiddle D F) F x := by
  have h := residueRayDenominator_scaled (A:=wedgeLeading D F) (B:=middle D F)
    (C:=trailing D F) (R:=wedgeRadius D F) (E:=t-height D F) (F:=F)
    (-1) (wedgeRadius_pos hD hF) (wedge_coefficients_pos hD hF).2.2
    (wedgeRadius_square hD hF) hx
  rw [residueRayDenominator_negative_one_actual hF (mul_pos (wedgeRadius_pos hD hF) hx),
    complexResolventDenominator_negative_one] at h
  have hh := congrArg Complex.re h
  simp only [Complex.ofReal_re,Complex.mul_re,Complex.ofReal_im,mul_zero,sub_zero] at hh
  have hp := real_resolvent_positive hD hF hDF ht (mul_pos (wedgeRadius_pos hD hF) hx)
  have hk := wedgeEnergyScale_pos hD hF
  rw [hh] at hp
  change 0 < wedgeEnergyScale D F *
    realResolventDenominator ((t-height D F)/wedgeEnergyScale D F)
      (wedgeNormalizedMiddle D F) F x at hp
  exact (mul_pos_iff_of_pos_left hk).mp hp

end LeanVerification.WedgeFullCompletion
