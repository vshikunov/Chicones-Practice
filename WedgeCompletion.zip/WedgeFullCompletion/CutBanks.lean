import LeanVerification.WedgeFullCompletion.PhysicalPhases
import LeanVerification.WedgeFullCompletion.RealMaximum

/-! Actual regular banks on the spectral cut.  The left physical bank
remains regular through the saddle energy, and its reflected logarithm
stays strictly in the upper strip. Above the saddle the same is true of
the right bank. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral RegionalComplex
set_option maxHeartbeats 1800000

theorem leftFrame_im_bounds {D F : ℝ} {z : ℂ} (hz : z ∈ leftFrame D F) :
    -wedgeZeroAngle F ≤ z.im ∧ z.im ≤ 0 := by
  have h : 0 ≤ (star z : ℂ).im ∧ (star z : ℂ).im ≤ wedgeZeroAngle F := ⟨hz.1,hz.2.1⟩
  simpa only [Complex.star_def,Complex.conj_im,neg_nonneg,neg_le] using
    And.intro h.2 h.1

theorem leftFrame_real_below_radius {D F : ℝ} {z : ℂ}
    (hF : 3/2 < F) (hz : z ∈ leftFrame D F) (hi : z.im=0) :
    z.re ≤ wedgeLogRadius D F := by
  have h := hz.2.2.1
  simp only [Complex.star_def,Complex.conj_im,Complex.conj_re,hi,neg_zero] at h
  exact h.resolve_left (not_le.mpr (wedge_angles hF).1)

theorem leftFrame_regular_above_height {D F t : ℝ} {w : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hw : w ∈ leftFrame D F) (ht : height D F < t)
    (he : logPotential D F w=(t : ℂ)) : logPotentialSlope D F w ≠ 0 := by
  have hb := leftFrame_im_bounds hw
  by_cases hi : w.im=0
  · have hr := real_bank_between_roots hD hF hDF ht hi he
    have hp : 0 < w.re := Real.one_lt_exp_iff.mp ((wedgeRootLower_gt_one hD hF hDF).trans hr.1)
    have hu : w.re < wedgeSaddleLog D :=
      (leftFrame_real_below_radius hF hw hi).trans_lt (wedgeLogRadius_lt_saddleLog hD hF hDF)
    have hs := wedge_log_slope_pos (F := F) hD hp hu
    rw [show w=(w.re : ℂ) from Complex.ext rfl hi]
    intro hz
    rw [hz] at hs
    exact (lt_irrefl 0) hs
  · exact wedge_logPotentialSlope_ne_zero hD
      (by linarith [(wedge_angles hF).2.2.2.2]) (by linarith [Real.pi_pos]) hi

theorem actual_left_cut_regular_bank {D F t : ℝ} {g : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hg : AnalyticOnNhd ℂ g upperEnergy) (hm : MapsTo g upperEnergy (leftDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    (ht : height D F < t) :
    ∃ w : ℂ,w ∈ leftFrame D F ∧ logPotential D F w=(t : ℂ) ∧
      ∃ j : ℂ → ℂ,AnalyticAt ℂ j (t : ℂ) ∧ j (t : ℂ)=w ∧
        g =ᶠ[𝓝[upperEnergy] (t : ℂ)] j ∧
        Tendsto g (𝓝[upperEnergy] (t : ℂ)) (𝓝 w) := by
  obtain ⟨w,hw,heq,φ,hφ,hlim⟩ := wedge_inverse_vertical_cluster hD hF ht.ne'
    (leftFrame_closed D F) (fun _ hz => leftFrame_im_bounds hz) (fun _ hz => (hm hz).1) he
  refine ⟨w,hw,heq,?_⟩
  exact inverse_germ_of_regular_cluster hg he
    ((analyticOnNhd_logPotential D F hF) w (mem_univ w))
    (hasStrictDerivAt_logPotential D F hF w) (leftFrame_regular_above_height hD hF hDF hw ht heq) heq
    (fun n => upperSequence_mem t (φ n)) ((upperSequence_tendsto t).comp hφ.tendsto_atTop) hlim

theorem actual_left_cut_bank_im_neg {D F t : ℝ} {g : ℂ → ℂ} {w : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hm : MapsTo g upperEnergy (leftDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    (ht : height D F < t) (hw : w ∈ leftFrame D F)
    (hew : logPotential D F w=(t : ℂ))
    (hl : Tendsto g (𝓝[upperEnergy] (t : ℂ)) (𝓝 w)) : w.im < 0 := by
  have hb := leftFrame_im_bounds hw
  by_contra hn
  have hi : w.im=0 := le_antisymm hb.2 (le_of_not_gt hn)
  have hr := real_bank_between_roots hD hF hDF ht hi hew
  have hp : 0 < w.re := Real.one_lt_exp_iff.mp ((wedgeRootLower_gt_one hD hF hDF).trans hr.1)
  have hu : w.re < wedgeSaddleLog D :=
    (leftFrame_real_below_radius hF hw hi).trans_lt (wedgeLogRadius_lt_saddleLog hD hF hDF)
  have hwreal : w=(w.re : ℂ) := Complex.ext rfl hi
  rw [hwreal] at hl
  have hor := hl.eventually (wedge_right_local_orientation hD hF hp hu)
  letI := nhdsWithin_upperEnergy_neBot t
  have hmem : ∀ᶠ z in 𝓝[upperEnergy] (t : ℂ),z ∈ upperEnergy := self_mem_nhdsWithin
  obtain ⟨z,hz,hzo⟩ := (hmem.and hor).exists
  have hpos := hzo.1.mp (show 0 < (logPotential D F (g z)).im by rw [he z hz];exact hz)
  exact (not_lt.mpr (leftFrame_im_bounds (hm hz).1).2) hpos

theorem actual_right_cut_bank_im_pos {D F t : ℝ} {w : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (ht : wedgeSaddleHeight D F < t) (hw : w ∈ rightFrame D F)
    (he : logPotential D F w=(t : ℂ)) : 0 < w.im := by
  rcases eq_or_lt_of_le hw.1 with hi | hi
  · have hwreal : w=(w.re : ℂ) := Complex.ext rfl hi.symm
    have hmax := logPotential_real_le_wedgeSaddleHeight hD hF hDF w.re
    rw [←hwreal,he,Complex.ofReal_re] at hmax
    linarith
  · exact hi

theorem actual_right_cut_bank {D F t : ℝ} {g : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hg : AnalyticOnNhd ℂ g upperEnergy) (hm : MapsTo g upperEnergy (rightDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    (ht : wedgeSaddleHeight D F < t) :
    ∃ w : ℂ,w ∈ rightFrame D F ∧ 0 < w.im ∧ logPotential D F w=(t : ℂ) ∧
      ∃ j : ℂ → ℂ,AnalyticAt ℂ j (t : ℂ) ∧ j (t : ℂ)=w ∧
        g =ᶠ[𝓝[upperEnergy] (t : ℂ)] j ∧
        Tendsto g (𝓝[upperEnergy] (t : ℂ)) (𝓝 w) := by
  obtain ⟨w,hw,hew,j,hj,hj0,hej,hl⟩ := actual_right_regular_bank hD hF hg hm he
    ((wedge_saddleHeight_pos hD hF hDF).trans ht).ne'
    ((wedge_height_lt_saddle hD hF hDF).trans ht).ne' ht.ne'
  exact ⟨w,hw,actual_right_cut_bank_im_pos hD hF hDF ht hw hew,hew,j,hj,hj0,hej,hl⟩

theorem actual_left_cut_bank {D F t : ℝ} {g : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hg : AnalyticOnNhd ℂ g upperEnergy) (hm : MapsTo g upperEnergy (leftDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    (ht : height D F < t) :
    ∃ w : ℂ,w ∈ leftFrame D F ∧ w.im < 0 ∧ logPotential D F w=(t : ℂ) ∧
      ∃ j : ℂ → ℂ,AnalyticAt ℂ j (t : ℂ) ∧ j (t : ℂ)=w ∧
        g =ᶠ[𝓝[upperEnergy] (t : ℂ)] j ∧
        Tendsto g (𝓝[upperEnergy] (t : ℂ)) (𝓝 w) := by
  obtain ⟨w,hw,hew,j,hj,hj0,hej,hl⟩ := actual_left_cut_regular_bank hD hF hDF hg hm he ht
  exact ⟨w,hw,actual_left_cut_bank_im_neg hD hF hDF hm he ht hw hew hl,hew,j,hj,hj0,hej,hl⟩

theorem factorLog_bank_phase_of_limit {D F t a b : ℝ} {g : ℂ → ℂ} {w : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hw : w ∈ logRayStrip) (hl : Tendsto g (𝓝[upperEnergy] (t : ℂ)) (𝓝 w))
    (hb : ∀ z ∈ upperEnergy,a < (actualFactorLog D F (g z)).im ∧
      (actualFactorLog D F (g z)).im < b) :
    a ≤ (actualFactorLog D F w).im ∧ (actualFactorLog D F w).im ≤ b := by
  letI := nhdsWithin_upperEnergy_neBot t
  have hc : ContinuousAt (fun z => (actualFactorLog D F z).im) w :=
    Complex.continuous_im.continuousAt.comp ((factorLogMap_analytic _ _ _) w hw).continuousAt
  have htend := hc.tendsto.comp hl
  constructor
  · apply ge_of_tendsto htend
    filter_upwards [self_mem_nhdsWithin] with z hz
    exact (hb z hz).1.le
  · apply le_of_tendsto htend
    filter_upwards [self_mem_nhdsWithin] with z hz
    exact (hb z hz).2.le

theorem factorLog_real_energy_phases {D F t : ℝ} {w : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hw : w ∈ logRayStrip) (ht : height D F < t)
    (he : logPotential D F w=(t : ℂ))
    (hlo : 0 < (actualFactorLog D F w).im) (hhi : (actualFactorLog D F w).im < 5*Real.pi) :
    actualFactorLog D F w=(Real.log ((t-height D F)/wedgeLeading D F) : ℂ)+(Real.pi : ℂ)*Complex.I ∨
      actualFactorLog D F w=(Real.log ((t-height D F)/wedgeLeading D F) : ℂ)+(3*Real.pi : ℝ)*Complex.I := by
  have hexp := actualFactorLog_exp hD hF hDF hw
  rw [he] at hexp
  have hx : Complex.exp (actualFactorLog D F w)= -(((t-height D F)/wedgeLeading D F : ℝ) : ℂ) := by
    rw [hexp]
    push_cast
    ring
  exact negative_exponential_two_phases
    (div_pos (sub_pos.mpr ht) (wedge_coefficients_pos hD hF).1) hx hlo hhi

end LeanVerification.WedgeFullCompletion
