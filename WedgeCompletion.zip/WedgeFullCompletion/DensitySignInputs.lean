import LeanVerification.WedgeFullCompletion.CutDensityPhysical

/-! Actual continuity, nonvanishing, and the forbidden negative-positive-
negative pattern needed for the continuum moment sign partition. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral
set_option maxHeartbeats 1800000

namespace ActualWedgePair
variable {D F : ℝ} (b : ActualWedgePair D F)

theorem cutDensity_continuous_away_saddle (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    ContinuousOn b.cutDensity {t : ℝ | height D F < t ∧ t ≠ wedgeSaddleHeight D F} := by
  have hS : IsOpen {t : ℝ | height D F < t ∧ t ≠ wedgeSaddleHeight D F} :=
    isOpen_Ioi.inter isOpen_ne
  have hr : AnalyticOnNhd ℝ b.rightCutLog
      {t : ℝ | height D F < t ∧ t ≠ wedgeSaddleHeight D F} := by
    apply analyticOnNhd_upperBank_of_germs hS
    intro t ht
    obtain ⟨w,hw,he,j,hj,hj0,hej,hl⟩ := actual_right_regular_bank hD hF
      b.right_analytic b.right_maps b.right_inverse
      ((height_pos (by linarith) hF).trans ht.1).ne' ht.1.ne' ht.2
    exact ⟨j,hj,hej⟩
  have hl := (b.leftCutLog_analytic hD hF hDF).continuousOn.mono
    (show {t : ℝ | height D F < t ∧ t ≠ wedgeSaddleHeight D F} ⊆ Ioi (height D F)
      from fun _ ht => ht.1)
  exact (Complex.continuous_im.comp_continuousOn
    ((Complex.continuous_exp.comp_continuousOn (continuousOn_const.mul hr.continuousOn)).add
      (Complex.continuous_exp.comp_continuousOn (continuousOn_const.mul hl)))).div_const F

theorem cutDensity_exists_nonzero (hD : D < -1) (hF : 3/2 < F) (hFu : F < 4) (hDF : -F < D) :
    ∃ t : ℝ,(height D F < t ∧ t ≠ wedgeSaddleHeight D F) ∧ b.cutDensity t ≠ 0 := by
  have hs := wedge_height_lt_saddle hD hF hDF
  have hm := b.cutDensity_strictMonoOn_above_saddle hD hF hFu hDF
    (show wedgeSaddleHeight D F+1 ∈ Ioi (wedgeSaddleHeight D F) by simp)
    (show wedgeSaddleHeight D F+2 ∈ Ioi (wedgeSaddleHeight D F) by simp) (by linarith)
  by_cases h0 : b.cutDensity (wedgeSaddleHeight D F+1)=0
  · refine ⟨wedgeSaddleHeight D F+2,⟨by linarith,by linarith⟩,?_⟩
    rw [h0] at hm
    exact hm.ne'
  · exact ⟨wedgeSaddleHeight D F+1,⟨by linarith,by linarith⟩,h0⟩

theorem leftDensity_negative_angle (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F < t) (hn : b.leftDensity t < 0) :
    Real.pi < F*(b.leftCutLog t).im := by
  have ha := b.left_scaled_angle_bounds hD hF hDF ht
  by_contra he
  have hs := Real.sin_nonneg_of_mem_Icc ⟨ha.1.le,le_of_not_gt he⟩
  rw [b.leftDensity_eq_exp_sin] at hn
  have hp : 0 ≤ Real.exp (F*(b.leftCutLog t).re)/F := by positivity
  exact (not_lt_of_ge (mul_nonneg hp hs)) hn

theorem leftDensity_positive_angle (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F < t) (hp : 0 < b.leftDensity t) :
    F*(b.leftCutLog t).im < Real.pi := by
  have ha := b.left_scaled_angle_bounds hD hF hDF ht
  by_contra he
  have hs := Real.sin_nonneg_of_mem_Icc
    (show F*(b.leftCutLog t).im-Real.pi ∈ Icc 0 Real.pi by
      constructor <;> linarith [Real.pi_pos])
  rw [Real.sin_sub_pi] at hs
  rw [b.leftDensity_eq_exp_sin] at hp
  have hc : 0 ≤ Real.exp (F*(b.leftCutLog t).re)/F := by positivity
  exact (not_lt_of_ge (mul_nonpos_of_nonneg_of_nonpos hc (by linarith))) hp

theorem cutDensity_no_negative_positive_negative (hD : D < -1) (hF : 3/2 < F)
    (hFu : F < 4) (hDF : -F < D)
    {x y z : ℝ}
    (hx : height D F < x ∧ x ≠ wedgeSaddleHeight D F)
    (hy : height D F < y ∧ y ≠ wedgeSaddleHeight D F)
    (hz : height D F < z ∧ z ≠ wedgeSaddleHeight D F)
    (hxy : x < y) (hyz : y < z)
    (hxn : b.cutDensity x < 0) (hyp : 0 < b.cutDensity y) (hzn : b.cutDensity z < 0) : False := by
  rcases lt_or_gt_of_ne hy.2 with hys | hsy
  · have hxs := hxy.trans hys
    rw [b.cutDensity_eq_left_below_saddle hD hF
      ((height_pos (by linarith) hF).trans hx.1) hxs] at hxn
    rw [b.cutDensity_eq_left_below_saddle hD hF
      ((height_pos (by linarith) hF).trans hy.1) hys] at hyp
    have hθx := b.leftDensity_negative_angle hD hF hDF hx.1 hxn
    have hθy := b.leftDensity_positive_angle hD hF hDF hy.1 hyp
    have hm := b.left_scaled_angle_strictMonoOn hD hF hDF hx.1 hy.1 hxy
    dsimp only at hm
    linarith
  · have hm := b.cutDensity_strictMonoOn_above_saddle hD hF hFu hDF hsy (hsy.trans hyz) hyz
    linarith

end ActualWedgePair
end LeanVerification.WedgeFullCompletion
