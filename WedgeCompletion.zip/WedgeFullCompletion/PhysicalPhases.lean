import LeanVerification.WedgeFullCompletion.QuadraticRoots
import LeanVerification.MiddleStripSpectral.UpperGermCompatibility

/-! The actual physical inverse sheets select the lifted phases π and 3π.
The phase sector in the energy half-plane is obtained from the physical
real bank and connectedness, rather than imposed as a sheet assumption. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral RegionalComplex
set_option maxHeartbeats 1800000

theorem continuousOn_lt_level_of_one {S : Set ℂ} {f : ℂ → ℝ} {c : ℝ}
    (hS : IsPreconnected S) (hf : ContinuousOn f S)
    (hne : ∀ z ∈ S,f z ≠ c) {a : ℂ} (ha : a ∈ S) (hac : f a < c) :
    ∀ z ∈ S,f z < c := by
  intro z hz
  by_contra hn
  obtain ⟨w,hw,he⟩ := hS.intermediate_value₂ ha hz hf continuousOn_const hac.le (le_of_not_gt hn)
  exact hne w hw he

theorem continuousOn_gt_level_of_one {S : Set ℂ} {f : ℂ → ℝ} {c : ℝ}
    (hS : IsPreconnected S) (hf : ContinuousOn f S)
    (hne : ∀ z ∈ S,f z ≠ c) {a : ℂ} (ha : a ∈ S) (hac : c < f a) :
    ∀ z ∈ S,c < f z := by
  intro z hz
  by_contra hn
  obtain ⟨w,hw,he⟩ := hS.intermediate_value₂ ha hz continuousOn_const hf hac.le (le_of_not_gt hn)
  exact hne w hw he.symm

theorem negative_sine_first_sector {x : ℝ}
    (h0 : 0 < x) (h3 : x < 3*Real.pi) (hs : Real.sin x < 0) :
    Real.pi < x ∧ x < 2*Real.pi := by
  constructor
  · by_contra hn
    exact (not_lt.mpr (Real.sin_nonneg_of_nonneg_of_le_pi h0.le (le_of_not_gt hn))) hs
  · by_contra hn
    have h := Real.sin_nonneg_of_nonneg_of_le_pi (show 0 ≤ x-2*Real.pi by linarith)
      (show x-2*Real.pi ≤ Real.pi by linarith)
    rw [Real.sin_sub_two_pi] at h
    linarith

theorem positive_sine_second_sector {x : ℝ}
    (h1 : Real.pi < x) (h3 : x < 3*Real.pi) (hs : 0 < Real.sin x) :
    2*Real.pi < x ∧ x < 3*Real.pi := by
  refine ⟨?_,h3⟩
  by_contra hn
  have h := Real.sin_nonpos_of_nonnpos_of_neg_pi_le (show x-2*Real.pi ≤ 0 by linarith)
    (show -Real.pi ≤ x-2*Real.pi by linarith)
  rw [Real.sin_sub_two_pi] at h
  linarith

theorem rightDomain_mem_logRayStrip {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) (hz : z ∈ rightDomain D F) :
    z ∈ logRayStrip := by
  have h := rightFrame_strict_of_positive_energy hD hF hDF hz.1 hz.2
  have ha := wedge_angles hF
  exact ⟨h.1,lt_trans h.2.1 (ha.2.2.1.trans (ha.2.2.2.1.trans ha.2.2.2.2))⟩

theorem leftDomain_star_mem_logRayStrip {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) (hz : z ∈ leftDomain D F) :
    star z ∈ logRayStrip := by
  rw [leftDomain_eq_strict hD hF hDF] at hz
  exact ⟨hz.1.1,hz.1.2.1.trans (wedge_angles hF).2.2.2.2⟩

theorem actualFactorLog_phase_bounds {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {z : ℂ} (hz : z ∈ logRayStrip) :
    (2*F)*z.im < (actualFactorLog D F z).im ∧
      (actualFactorLog D F z).im < (2*F-2)*z.im+2*Real.pi := by
  obtain ⟨hu,huv⟩ := wedge_roots_pos_order hD hF hDF
  exact factorLogMap_phase_bounds _ hu (hu.trans huv) hz

theorem actualFactorLog_phase_lt_three_pi {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {z : ℂ} (hz : z ∈ logRayStrip) (ha : z.im < wedgeFirstAngle F) :
    (actualFactorLog D F z).im < 3*Real.pi := by
  have hmul : (2*F-1)*z.im < Real.pi := by
    simpa only [mul_comm] using (lt_div_iff₀ (by linarith : 0<2*F-1)).mp ha
  have hb := (actualFactorLog_phase_bounds hD hF hDF hz).2
  nlinarith [hz.1]

theorem actualFactorLog_sin_neg {D F : ℝ} {g : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hm : MapsTo g upperEnergy (rightDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    {z : ℂ} (hz : z ∈ upperEnergy) : Real.sin (actualFactorLog D F (g z)).im < 0 := by
  have hx := actualFactorLog_exp hD hF hDF (rightDomain_mem_logRayStrip hD hF hDF (hm hz))
  rw [he z hz] at hx
  have hi := congrArg Complex.im hx
  simp only [Complex.exp_im,Complex.div_ofReal_im,Complex.sub_im,Complex.ofReal_im,zero_sub] at hi
  have hn : Real.exp (actualFactorLog D F (g z)).re*
      Real.sin (actualFactorLog D F (g z)).im < 0 := by
    rw [hi]
    exact div_neg_of_neg_of_pos (neg_neg_of_pos hz) (wedge_coefficients_pos hD hF).1
  exact (mul_lt_mul_left (Real.exp_pos _)).mp (by simpa only [mul_zero] using hn)

theorem actualFactorLog_star_sin_pos {D F : ℝ} {g : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hm : MapsTo g upperEnergy (leftDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    {z : ℂ} (hz : z ∈ upperEnergy) : 0 < Real.sin (actualFactorLog D F (star (g z))).im := by
  have hx := actualFactorLog_exp hD hF hDF (leftDomain_star_mem_logRayStrip hD hF hDF (hm hz))
  rw [logPotential_star,he z hz] at hx
  have hi : Real.exp (actualFactorLog D F (star (g z))).re*
      Real.sin (actualFactorLog D F (star (g z))).im=z.im/wedgeLeading D F := by
    simpa only [Complex.exp_im,Complex.div_ofReal_im,Complex.sub_im,Complex.ofReal_im,
      Complex.star_def,Complex.conj_im,zero_sub,neg_neg] using congrArg Complex.im hx
  have hn : 0 < Real.exp (actualFactorLog D F (star (g z))).re*
      Real.sin (actualFactorLog D F (star (g z))).im := by
    rw [hi]
    exact div_pos hz (wedge_coefficients_pos hD hF).1
  exact (mul_pos_iff_of_pos_left (Real.exp_pos _)).mp hn

theorem actual_right_factor_phase {D F : ℝ} {g : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hg : AnalyticOnNhd ℂ g upperEnergy) (hm : MapsTo g upperEnergy (rightDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    (hl : ∀ t : ℝ,0 < t → t < wedgeSaddleLog D →
      Tendsto g (𝓝[upperEnergy] (logPotential D F (t : ℂ))) (𝓝 (t : ℂ))) :
    ∀ z ∈ upperEnergy,Real.pi < (actualFactorLog D F (g z)).im ∧
      (actualFactorLog D F (g z)).im < 2*Real.pi := by
  have hmap : MapsTo g upperEnergy logRayStrip :=
    fun _ hz => rightDomain_mem_logRayStrip hD hF hDF (hm hz)
  have hc : ContinuousOn (fun z => (actualFactorLog D F (g z)).im) upperEnergy :=
    Complex.continuous_im.continuousOn.comp
      ((factorLogMap_analytic _ _ _).continuousOn.comp hg.continuousOn hmap) (mapsTo_univ _ _)
  have hsin (z : ℂ) (hz : z ∈ upperEnergy) : Real.sin (actualFactorLog D F (g z)).im < 0 :=
    actualFactorLog_sin_neg hD hF hDF hm he hz
  have hne : ∀ z ∈ upperEnergy,(actualFactorLog D F (g z)).im ≠ 2*Real.pi := by
    intro z hz heq
    have h := hsin z hz
    rw [heq,Real.sin_two_pi] at h
    exact (lt_irrefl 0) h
  let t : ℝ := wedgeSaddleLog D/2
  have ht : 0 < t := half_pos (wedgeSaddleLog_pos hD)
  have htu : t < wedgeSaddleLog D := half_lt_self (wedgeSaddleLog_pos hD)
  have hb := hl t ht htu
  rw [logPotential_real D F t hF] at hb
  letI := nhdsWithin_upperEnergy_neBot (potential D F (Real.exp t))
  have hei : ∀ᶠ z in 𝓝[upperEnergy] ((potential D F (Real.exp t) : ℝ) : ℂ),
      (g z).im < wedgeFirstAngle F :=
    (Complex.continuous_im.tendsto _ |>.comp hb).eventually
      (Iio_mem_nhds (show (t : ℂ).im < wedgeFirstAngle F by simpa using (wedge_angles hF).1))
  have hemem : ∀ᶠ z in 𝓝[upperEnergy] ((potential D F (Real.exp t) : ℝ) : ℂ),
      z ∈ upperEnergy := self_mem_nhdsWithin
  obtain ⟨a,ha,hai⟩ := (hemem.and hei).exists
  have has := hmap ha
  have hapos : 0 < (actualFactorLog D F (g a)).im :=
    (mul_pos (by linarith : 0<2*F) has.1).trans (actualFactorLog_phase_bounds hD hF hDF has).1
  have hac := (negative_sine_first_sector hapos
    (actualFactorLog_phase_lt_three_pi hD hF hDF has hai) (hsin a ha)).2
  have hall := continuousOn_lt_level_of_one upperEnergy_convex.isPreconnected hc hne ha hac
  intro z hz
  have hzpos : 0 < (actualFactorLog D F (g z)).im :=
    (mul_pos (by linarith : 0<2*F) (hmap hz).1).trans
      (actualFactorLog_phase_bounds hD hF hDF (hmap hz)).1
  exact negative_sine_first_sector hzpos (by linarith [hall z hz,Real.pi_pos]) (hsin z hz)

theorem negative_real_upper_arg_gt_half_pi {w : ℂ}
    (hr : w.re < 0) (hi : 0 < w.im) : Real.pi/2 < w.arg := by
  by_contra hn
  rcases Complex.arg_le_pi_div_two_iff.mp (le_of_not_gt hn) with h | h <;> linarith

theorem actual_left_factor_phase {D F : ℝ} {g : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hg : AnalyticOnNhd ℂ g upperEnergy) (hm : MapsTo g upperEnergy (leftDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    (hl : ∀ t : ℝ,t < 0 →
      Tendsto g (𝓝[upperEnergy] (logPotential D F (t : ℂ))) (𝓝 (t : ℂ))) :
    ∀ z ∈ upperEnergy,2*Real.pi < (actualFactorLog D F (star (g z))).im ∧
      (actualFactorLog D F (star (g z))).im < 3*Real.pi := by
  have hmap : MapsTo (fun z => star (g z)) upperEnergy logRayStrip :=
    fun _ hz => leftDomain_star_mem_logRayStrip hD hF hDF (hm hz)
  have hc : ContinuousOn (fun z => (actualFactorLog D F (star (g z))).im) upperEnergy :=
    Complex.continuous_im.continuousOn.comp
      ((factorLogMap_analytic _ _ _).continuousOn.comp (continuous_star.comp_continuousOn hg.continuousOn)
        hmap) (mapsTo_univ _ _)
  have hsin (z : ℂ) (hz : z ∈ upperEnergy) : 0 < Real.sin (actualFactorLog D F (star (g z))).im :=
    actualFactorLog_star_sin_pos hD hF hDF hm he hz
  have hne2 : ∀ z ∈ upperEnergy,(actualFactorLog D F (star (g z))).im ≠ 2*Real.pi := by
    intro z hz heq
    have h := hsin z hz
    rw [heq,Real.sin_two_pi] at h
    exact (lt_irrefl 0) h
  have hne3 : ∀ z ∈ upperEnergy,(actualFactorLog D F (star (g z))).im ≠ 3*Real.pi := by
    intro z hz heq
    have h := hsin z hz
    have hs3 : Real.sin (3*Real.pi)=0 := by
      rw [show 3*Real.pi=Real.pi+2*Real.pi by ring,Real.sin_add_two_pi,Real.sin_pi]
    rw [heq,hs3] at h
    exact (lt_irrefl 0) h
  have hb := hl (-1) (by norm_num)
  rw [logPotential_real D F (-1) hF] at hb
  letI := nhdsWithin_upperEnergy_neBot (potential D F (Real.exp (-1)))
  have hbst : Tendsto (fun z => star (g z))
      (𝓝[upperEnergy] ((potential D F (Real.exp (-1)) : ℝ) : ℂ)) (𝓝 (-1 : ℂ)) := by
    simpa using continuous_star.continuousAt.tendsto.comp hb
  have hei : ∀ᶠ z in 𝓝[upperEnergy] ((potential D F (Real.exp (-1)) : ℝ) : ℂ),
      (star (g z) : ℂ).im < wedgeFirstAngle F :=
    (Complex.continuous_im.tendsto _ |>.comp hbst).eventually
      (Iio_mem_nhds (show (-1 : ℂ).im < wedgeFirstAngle F by simpa using (wedge_angles hF).1))
  have her : ∀ᶠ z in 𝓝[upperEnergy] ((potential D F (Real.exp (-1)) : ℝ) : ℂ),
      (Complex.exp (star (g z))).re < wedgeRootLower D F := by
    have ht := Complex.continuous_re.tendsto _ |>.comp (Complex.continuous_exp.tendsto _ |>.comp hbst)
    apply ht.eventually (Iio_mem_nhds ?_)
    have hx : Real.exp (-1) < 1 := Real.exp_lt_one_iff.mpr (by norm_num)
    simp only [Complex.exp_re,Complex.neg_re,Complex.one_re,Complex.neg_im,
      Complex.one_im,neg_zero,Real.cos_zero,mul_one]
    exact hx.trans (wedgeRootLower_gt_one hD hF hDF)
  have hemem : ∀ᶠ z in 𝓝[upperEnergy] ((potential D F (Real.exp (-1)) : ℝ) : ℂ),
      z ∈ upperEnergy := self_mem_nhdsWithin
  obtain ⟨a,ha,hai,har⟩ := (hemem.and (hei.and her)).exists
  have has := hmap ha
  have hie := exp_im_pos_of_logRayStrip has
  have hlu : Real.pi/2 < (Complex.exp (star (g a))+((-wedgeRootLower D F : ℝ) : ℂ)).arg :=
    negative_real_upper_arg_gt_half_pi (by simpa using sub_neg.mpr har) (by simpa using hie)
  have hlv : Real.pi/2 < (Complex.exp (star (g a))+((-wedgeRootUpper D F : ℝ) : ℂ)).arg :=
    negative_real_upper_arg_gt_half_pi
      (by simpa using sub_neg.mpr (har.trans (wedge_roots_pos_order hD hF hDF).2)) (by simpa using hie)
  have hap : Real.pi < (actualFactorLog D F (star (g a))).im := by
    dsimp only [actualFactorLog,factorLogMap,logRayMap]
    simp only [Complex.add_im,Complex.mul_im,Complex.ofReal_im,Complex.ofReal_re,
      zero_mul,add_zero,Complex.log_im]
    have hmpos := mul_pos (by linarith : 0<2*F-2) has.1
    linarith
  have hac := positive_sine_second_sector hap
    (actualFactorLog_phase_lt_three_pi hD hF hDF has hai) (hsin a ha)
  have hlower := continuousOn_gt_level_of_one upperEnergy_convex.isPreconnected hc hne2 ha hac.1
  have hupper := continuousOn_lt_level_of_one upperEnergy_convex.isPreconnected hc hne3 ha hac.2
  exact fun z hz => ⟨hlower z hz,hupper z hz⟩

end LeanVerification.WedgeFullCompletion
