import LeanVerification.WedgeFullCompletion.QuadraticRoots

/-! The actual nonzero saddle is the global maximum on the positive
reciprocal axis. This proves positivity of the real resolvent denominator
above that saddle, with no assumed absence of real poles. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion RegionalReal
set_option maxHeartbeats 1500000

theorem antitoneOn_potential_after_negative_saddle (D F : ℝ) (hD : D < -1) :
    AntitoneOn (potential D F) (Ici (D/(D+1))) := by
  have hs := extra_root_gt_one_of_lt_neg_one D hD
  have hD1 : D+1 ≠ 0 := by linarith
  apply antitoneOn_of_deriv_nonpos (convex_Ici _)
  · intro w hw
    have hws : D/(D+1) ≤ w := hw
    exact (hasDerivAt_potential D F w (by linarith)).continuousAt.continuousWithinAt
  · intro w hw
    have hws : D/(D+1) ≤ w := interior_subset hw
    exact (hasDerivAt_potential D F w (by linarith)).differentiableAt.differentiableWithinAt
  · intro w hw
    have hws : D/(D+1) ≤ w := interior_subset hw
    have hw0 : 0 < w := by linarith
    have hmul := mul_le_mul_of_nonpos_left hws (show D+1 ≤ 0 by linarith)
    rw [mul_div_cancel₀ D hD1] at hmul
    rw [deriv_potential D F w hw0,potentialSlope]
    exact mul_nonpos_of_nonneg_of_nonpos
      (mul_nonneg (Real.rpow_pos_of_pos hw0 _).le (by linarith)) (by linarith)

theorem potential_le_wedgeSaddleHeight {D F w : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) (hw : 0 < w) :
    potential D F w ≤ wedgeSaddleHeight D F := by
  by_cases hH : potential D F w ≤ height D F
  · exact hH.trans (wedge_height_lt_saddle hD hF hDF).le
  have hHt : height D F < potential D F w := lt_of_not_ge hH
  have hbetween := real_bank_between_roots (z := (Real.log w : ℂ)) hD hF hDF hHt rfl
    (by rw [logPotential_real D F _ hF,Real.exp_log hw])
  simp only [Complex.ofReal_re,Real.exp_log hw] at hbetween
  have hw1 : 1 < w := (wedgeRootLower_gt_one hD hF hDF).trans hbetween.1
  have hs := extra_root_gt_one_of_lt_neg_one D hD
  rcases le_total w (D/(D+1)) with hle | hge
  · exact (strictMonoOn_potential_center_to_negative_saddle D F hD).monotoneOn
      ⟨hw1.le,hle⟩ ⟨hs.le,le_rfl⟩ hle
  · exact antitoneOn_potential_after_negative_saddle D F hD
      (mem_Ici.mpr (le_refl (D/(D+1)))) (mem_Ici.mpr hge) hge

theorem logPotential_real_le_wedgeSaddleHeight {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) (x : ℝ) :
    (logPotential D F (x : ℂ)).re ≤ wedgeSaddleHeight D F := by
  rw [logPotential_real D F x hF,Complex.ofReal_re]
  exact potential_le_wedgeSaddleHeight hD hF hDF (Real.exp_pos _)

theorem real_resolvent_positive {D F t r : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (ht : wedgeSaddleHeight D F < t) (hr : 0 < r) :
    0 < t-potential D F r :=
  sub_pos.mpr ((potential_le_wedgeSaddleHeight hD hF hDF hr).trans_lt ht)

end LeanVerification.WedgeFullCompletion
