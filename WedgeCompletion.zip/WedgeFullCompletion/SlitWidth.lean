import LeanVerification.WedgeFullCompletion.WidthGerms
import LeanVerification.MiddleStripSpectral.ReflectedEstimates

/-! The actual normalized physical width on the complete slit energy
plane.  Both its holomorphy and its physical values come from the same
two constructed inverse sheets. -/

noncomputable section
open Set Filter Metric
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral
set_option maxHeartbeats 1500000

def wedgeSlitWidth (F : ℝ) (gp gm : ℂ → ℂ) : ℂ → ℂ :=
  reflectedUpper (upperNormalizedWidth F gp gm)

theorem wedgeSlitWidth_physical_value {D F h : ℝ} {gp gm : ℂ → ℂ}
    (hF : F ≠ 0) (hh : AdmissibleEnergy D F h)
    (hlp : Tendsto gp (𝓝[upperEnergy] (h : ℂ))
      (𝓝 (Real.log (rightTurn D F h) : ℂ)))
    (hlm : Tendsto gm (𝓝[upperEnergy] (h : ℂ))
      (𝓝 (Real.log (leftTurn D F h) : ℂ))) :
    wedgeSlitWidth F gp gm (h : ℂ)=(physicalEnergyWidth D F h/Real.sqrt h : ℝ) := by
  rw [wedgeSlitWidth,reflectedUpper_eq_real]
  exact upperBank_eq_of_tendsto (upperNormalizedWidth_physical_bank hF hh hlp hlm)

section ActualPair
variable {D F : ℝ} {gp gm : ℂ → ℂ}
variable (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
variable (hp : AnalyticOnNhd ℂ gp upperEnergy) (hm : AnalyticOnNhd ℂ gm upperEnergy)
variable (hmp : MapsTo gp upperEnergy (rightDomain D F))
variable (hmm : MapsTo gm upperEnergy (leftDomain D F))
variable (hep : ∀ z ∈ upperEnergy,logPotential D F (gp z)=z)
variable (hem : ∀ z ∈ upperEnergy,logPotential D F (gm z)=z)
variable (hlp : ∀ h,AdmissibleEnergy D F h → Tendsto gp (𝓝[upperEnergy] (h : ℂ))
  (𝓝 (Real.log (rightTurn D F h) : ℂ)))
variable (hlm : ∀ h,AdmissibleEnergy D F h → Tendsto gm (𝓝[upperEnergy] (h : ℂ))
  (𝓝 (Real.log (leftTurn D F h) : ℂ)))
include hD hF hDF hp hm hmp hmm hep hem hlp hlm

theorem wedgeSlitWidth_analytic :
    AnalyticOnNhd ℂ (wedgeSlitWidth F gp gm) (SlitContour.domain (height D F)) :=
  analyticOnNhd_reflectedUpper (analyticOnNhd_upperNormalizedWidth (by linarith) hp hm)
    (wedge_upperWidth_germs_below_height hD hF hDF hp hm hmp hmm hep hem hlp hlm)
    (wedge_upperWidth_bank_real_below hD hF hDF hp hm hmp hmm hep hem hlp hlm)

theorem wedgeSlitWidth_real_below :
    ∀ x : ℝ,x < height D F → (wedgeSlitWidth F gp gm (x : ℂ)).im=0 :=
  reflectedUpper_real_below
    (wedge_upperWidth_bank_real_below hD hF hDF hp hm hmp hmm hep hem hlp hlm)

theorem wedgeSlitWidth_center : wedgeSlitWidth F gp gm 0=(2*Real.sqrt 2 : ℝ) := by
  obtain ⟨J,r,hr,hJ,hJ0,he⟩ := wedge_upperWidth_center_continuation
    hD hF hDF hp hm hmp hmm hep hem hlp hlm
  have heU : upperNormalizedWidth F gp gm =ᶠ[𝓝[upperEnergy] (0 : ℂ)] J := by
    filter_upwards [self_mem_nhdsWithin,
      mem_nhdsWithin_of_mem_nhds (ball_mem_nhds (0 : ℂ) hr)] with z hz hb
    exact he ⟨hb,hz⟩
  have hjl : Tendsto J (𝓝[upperEnergy] (0 : ℂ)) (𝓝 (J 0)) :=
    (hJ 0 (mem_ball_self hr)).continuousAt.tendsto.mono_left nhdsWithin_le_nhds
  have hl : Tendsto (upperNormalizedWidth F gp gm) (𝓝[upperEnergy] (0 : ℂ))
      (𝓝 (J 0)) := hjl.congr' heU.symm
  change reflectedUpper (upperNormalizedWidth F gp gm) (0 : ℂ)=_
  rw [show (0 : ℂ)=((0 : ℝ) : ℂ) by rfl,reflectedUpper_eq_real,
    upperBank_eq_of_tendsto hl,hJ0]

end ActualPair

theorem exists_actual_wedge_slit_width {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    ∃ gp gm : ℂ → ℂ,
      AnalyticOnNhd ℂ gp upperEnergy ∧ AnalyticOnNhd ℂ gm upperEnergy ∧
      MapsTo gp upperEnergy (rightDomain D F) ∧ MapsTo gm upperEnergy (leftDomain D F) ∧
      (∀ z ∈ upperEnergy,logPotential D F (gp z)=z) ∧
      (∀ z ∈ upperEnergy,logPotential D F (gm z)=z) ∧
      AnalyticOnNhd ℂ (wedgeSlitWidth F gp gm) (SlitContour.domain (height D F)) ∧
      (∀ x : ℝ,x < height D F → (wedgeSlitWidth F gp gm (x : ℂ)).im=0) ∧
      wedgeSlitWidth F gp gm 0=(2*Real.sqrt 2 : ℝ) ∧
      ∀ h,AdmissibleEnergy D F h →
        wedgeSlitWidth F gp gm (h : ℂ)=(physicalEnergyWidth D F h/Real.sqrt h : ℝ) := by
  obtain ⟨gp,hp,hmp,hep,hlp⟩ := actual_right_inverse_complete_annulus hD hF hDF
  obtain ⟨gm,hm,hmm,hem,hlm⟩ := actual_left_inverse_complete_annulus hD hF hDF
  exact ⟨gp,gm,hp,hm,hmp,hmm,hep,hem,
    wedgeSlitWidth_analytic hD hF hDF hp hm hmp hmm hep hem hlp hlm,
    wedgeSlitWidth_real_below hD hF hDF hp hm hmp hmm hep hem hlp hlm,
    wedgeSlitWidth_center hD hF hDF hp hm hmp hmm hep hem hlp hlm,
    fun h hh => wedgeSlitWidth_physical_value (by linarith) hh (hlp h hh) (hlm h hh)⟩

end LeanVerification.WedgeFullCompletion
