import LeanVerification.WedgeFullCompletion.SlitWidth

/-! Uniform boundedness at both finite exceptional energies. The estimate
is proved first on the entire upper half-plane from the actual potential
growth. Reflection and established bank limits then transport that bound;
no omitted interior estimate is supplied merely by continuity. -/

noncomputable section
open Set Filter Metric
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open MiddleStripCompletion MiddleStripSpectral ContourCompletion
set_option maxHeartbeats 1500000

theorem wedge_inverse_real_upper_bound {D F M : ℝ}
    (hD : D < -1) (hF : 3/2 < F) :
    ∃ b : ℝ,∀ z : ℂ,‖logPotential D F z‖ ≤ M → z.re < b := by
  obtain ⟨b,hb⟩ := wedge_uniform_logPotential_atTop hD hF M
  refine ⟨b,fun z hz => ?_⟩
  by_contra hn
  exact (not_lt.mpr hz) (hb z (le_of_not_gt hn))

theorem wedge_upperWidth_bounded_near_positive {D F a : ℝ} {gp gm : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F) (ha : 0 < a)
    (hep : ∀ z ∈ upperEnergy,logPotential D F (gp z)=z)
    (hem : ∀ z ∈ upperEnergy,logPotential D F (gm z)=z) :
    ∃ r > 0,∃ M ≥ 0,∀ z ∈ upperEnergy,dist z (a : ℂ) < r →
      ‖upperNormalizedWidth F gp gm z‖ ≤ M := by
  have hFp : 0 < F := by linarith
  obtain ⟨b,hb⟩ := wedge_inverse_real_upper_bound hD hF (M := a+1)
  refine ⟨min 1 (a/2),lt_min zero_lt_one (half_pos ha),
    2*Real.exp (F*b)/(F*Real.sqrt (a/2)),by positivity,?_⟩
  intro z hz hd
  have hdist1 : dist z (a : ℂ) < 1 := hd.trans_le (min_le_left _ _)
  have hdistA : dist z (a : ℂ) < a/2 := hd.trans_le (min_le_right _ _)
  have hznorm : ‖z‖ ≤ a+1 := by
    have hh := norm_le_insert' z (a : ℂ)
    rw [Complex.norm_real,Real.norm_of_nonneg ha.le,←dist_eq_norm] at hh
    linarith
  have hp : (gp z).re < b := hb _ (by rw [hep z hz];exact hznorm)
  have hm : (gm z).re < b := hb _ (by rw [hem z hz];exact hznorm)
  have hnum : ‖Complex.exp ((F : ℂ)*gp z)-Complex.exp ((F : ℂ)*gm z)‖ ≤
      2*Real.exp (F*b) := by
    have hp' := Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left hp.le hFp.le)
    have hm' := Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left hm.le hFp.le)
    have hh := norm_sub_le (Complex.exp ((F : ℂ)*gp z)) (Complex.exp ((F : ℂ)*gm z))
    rw [norm_scaled_exp,norm_scaled_exp] at hh
    linarith
  have hlow : a/2 ≤ ‖z‖ := by
    have hh := norm_le_insert' (a : ℂ) z
    rw [Complex.norm_real,Real.norm_of_nonneg ha.le,←dist_eq_norm,dist_comm] at hh
    linarith
  have hzn : z ≠ 0 := by intro he;rw [he,norm_zero] at hlow;linarith
  have hden : F*Real.sqrt (a/2) ≤ F*‖principalSquareRoot z‖ := by
    rw [norm_principalSquareRoot hzn]
    exact mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt hlow) hFp.le
  rw [upperNormalizedWidth,norm_div,norm_mul,Complex.norm_real,Real.norm_of_nonneg hFp.le]
  exact div_le_div₀ (by positivity) hnum (by positivity) hden

theorem reflectedUpper_local_bound_at_real {f : ℂ → ℂ} {H a r M : ℝ}
    (hg : ∀ x ∈ Iio H,HasUpperGerm f x)
    (hb : ∀ z ∈ upperEnergy,dist z (a : ℂ) < r → ‖f z‖ ≤ M) :
    ∀ z ∈ SlitContour.domain H,dist z (a : ℂ) < r → ‖reflectedUpper f z‖ ≤ M := by
  intro z hz hd
  rcases lt_trichotomy z.im 0 with hn | he | hp
  · have hs : star z ∈ upperEnergy := by
      simpa only [upperEnergy,mem_setOf_eq,Complex.star_def,Complex.conj_im,neg_pos] using hn
    simp only [reflectedUpper,if_neg (not_lt.mpr hn.le),if_pos hn,norm_star]
    exact hb (star z) hs (by rwa [dist_star_real])
  · have hx : z.re < H := hz.resolve_right (fun hn => hn he)
    have hez : z=(z.re : ℂ) := by apply Complex.ext <;> simp [he]
    rw [hez,reflectedUpper_eq_real]
    letI := nhdsWithin_upperEnergy_neBot z.re
    have hl := (continuous_norm.tendsto (upperBank f z.re)).comp
      (tendsto_upperBank_of_germ (hg z.re hx))
    have hm : ∀ᶠ w in 𝓝[upperEnergy] (z.re : ℂ),‖f w‖ ≤ M := by
      have hdz : (z.re : ℂ) ∈ ball (a : ℂ) r := by rwa [←hez]
      filter_upwards [self_mem_nhdsWithin,
        mem_nhdsWithin_of_mem_nhds (isOpen_ball.mem_nhds hdz)] with w hw hdw
      exact hb w hw hdw
    exact le_of_tendsto hl hm
  · rw [reflectedUpper_eq_upper hp]
    exact hb z hp hd

theorem wedgeSlitWidth_finite_bound {D F a : ℝ} {gp gm : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F) (ha : 0 < a)
    (hep : ∀ z ∈ upperEnergy,logPotential D F (gp z)=z)
    (hem : ∀ z ∈ upperEnergy,logPotential D F (gm z)=z)
    (hg : ∀ x ∈ Iio (height D F),HasUpperGerm (upperNormalizedWidth F gp gm) x) :
    ∃ r > 0,∃ M ≥ 0,∀ z ∈ SlitContour.domain (height D F),dist z (a : ℂ) < r →
      ‖wedgeSlitWidth F gp gm z‖ ≤ M := by
  obtain ⟨r,hr,M,hM,hb⟩ := wedge_upperWidth_bounded_near_positive hD hF ha hep hem
  exact ⟨r,hr,M,hM,reflectedUpper_local_bound_at_real hg hb⟩

end LeanVerification.WedgeFullCompletion
