import LeanVerification.WedgeFullCompletion.ProperFrames
import LeanVerification.MiddleStripCompletion.PhysicalBranchContinuation

/-! Both physical inverse sheets are treated over the same upper energy
half-plane.  The second source is the reflection of the zero-end frame. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open MiddleStripCompletion
set_option maxHeartbeats 1200000

theorem logPotential_star (D F : ℝ) (z : ℂ) :
    logPotential D F (star z)=star (logPotential D F z) := by
  simp only [logPotential, Complex.star_def, map_add, map_sub, map_mul, Complex.conj_ofReal,
    ←Complex.exp_conj]

def leftFrame (D F : ℝ) : Set ℂ := star ⁻¹' zeroFrame D F
def leftFrameInterior (D F : ℝ) : Set ℂ := star ⁻¹' zeroFrameInterior D F
def leftDomain (D F : ℝ) : Set ℂ :=
  leftFrame D F ∩ logPotential D F ⁻¹' upperEnergy

theorem leftFrame_closed (D F : ℝ) : IsClosed (leftFrame D F) :=
  (zeroFrame_closed D F).preimage continuous_star

theorem leftFrameInterior_open (D F : ℝ) : IsOpen (leftFrameInterior D F) :=
  (zeroFrameInterior_open D F).preimage continuous_star

theorem leftDomain_eq_strict {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    leftDomain D F=leftFrameInterior D F ∩ logPotential D F ⁻¹' upperEnergy := by
  ext z
  constructor
  · intro hz
    have hE : (logPotential D F (star z)).im < 0 := by
      rw [logPotential_star]
      simpa using hz.2
    exact ⟨zeroFrame_strict_of_negative_energy hD hF hDF hz.1 hE,hz.2⟩
  · rintro ⟨hz,hE⟩
    exact ⟨⟨hz.1.le,hz.2.1.le,hz.2.2.1.imp le_of_lt le_of_lt,
      hz.2.2.2.imp le_of_lt le_of_lt⟩,hE⟩

theorem leftDomain_open {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) : IsOpen (leftDomain D F) := by
  rw [leftDomain_eq_strict hD hF hDF]
  exact (leftFrameInterior_open D F).inter (upperEnergy_open.preimage
    (continuous_iff_continuousOn_univ.mpr (analyticOnNhd_logPotential D F hF).continuousOn))

theorem proper_leftDomain {D F : ℝ} (hD : D < -1) (hF : 3/2 < F) :
    IsProperMap (complexRestriction (logPotential D F) (leftDomain D F) upperEnergy
      (fun _ hz => hz.2)) := by
  apply proper_closed_frame
    (continuous_iff_continuousOn_univ.mpr (analyticOnNhd_logPotential D F hF).continuousOn)
    (leftFrame_closed D F) (a := -wedgeZeroAngle F) (b := 0) ?_
    (wedge_compact_real_bounds hD hF)
  intro z hz
  change 0 ≤ (star z : ℂ).im ∧ (star z : ℂ).im ≤ wedgeZeroAngle F ∧ _ at hz
  simp only [Complex.star_def, Complex.conj_im] at hz
  exact ⟨by linarith [hz.2.1], by linarith [hz.1]⟩

theorem rightDomain_deriv_ne_zero {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {z : ℂ} (hz : z ∈ rightDomain D F) : deriv (logPotential D F) z ≠ 0 := by
  rw [(hasDerivAt_logPotential D F hF z).deriv]
  have h := rightFrame_strict_of_positive_energy hD hF hDF hz.1 hz.2
  obtain ⟨ha,hab,hbc,hcd,hd⟩ := wedge_angles hF
  exact wedge_logPotentialSlope_ne_zero hD (by linarith [h.1, Real.pi_pos])
    (by linarith [h.2.1]) h.1.ne'

theorem leftDomain_deriv_ne_zero {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {z : ℂ} (hz : z ∈ leftDomain D F) : deriv (logPotential D F) z ≠ 0 := by
  rw [(hasDerivAt_logPotential D F hF z).deriv]
  rw [leftDomain_eq_strict hD hF hDF] at hz
  have h : 0 < -z.im ∧ -z.im < wedgeZeroAngle F := by
    simpa only [leftFrameInterior, mem_preimage, Complex.star_def, Complex.conj_im]
      using And.intro hz.1.1 hz.1.2.1
  have hd := (wedge_angles hF).2.2.2.2
  exact wedge_logPotentialSlope_ne_zero hD (by linarith)
    (by linarith [Real.pi_pos]) (by linarith)

theorem right_global_inverse_through_point {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {w₀ : ℂ} (hw₀ : w₀ ∈ rightDomain D F) :
    ∃ g : ℂ → ℂ, AnalyticOnNhd ℂ g upperEnergy ∧ MapsTo g upperEnergy (rightDomain D F) ∧
      (∀ z ∈ upperEnergy, logPotential D F (g z)=z) ∧ g (logPotential D F w₀)=w₀ :=
  global_analytic_inverse_of_proper (rightDomain_open hD hF hDF) upperEnergy_open
    (fun _ hz => hz.2) ((analyticOnNhd_logPotential D F hF).mono (subset_univ _))
    (fun _ hz => rightDomain_deriv_ne_zero hD hF hDF hz)
    (proper_rightDomain hD hF) hw₀

theorem left_global_inverse_through_point {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {w₀ : ℂ} (hw₀ : w₀ ∈ leftDomain D F) :
    ∃ g : ℂ → ℂ, AnalyticOnNhd ℂ g upperEnergy ∧ MapsTo g upperEnergy (leftDomain D F) ∧
      (∀ z ∈ upperEnergy, logPotential D F (g z)=z) ∧ g (logPotential D F w₀)=w₀ :=
  global_analytic_inverse_of_proper (leftDomain_open hD hF hDF) upperEnergy_open
    (fun _ hz => hz.2) ((analyticOnNhd_logPotential D F hF).mono (subset_univ _))
    (fun _ hz => leftDomain_deriv_ne_zero hD hF hDF hz)
    (proper_leftDomain hD hF) hw₀

end LeanVerification.WedgeFullCompletion
