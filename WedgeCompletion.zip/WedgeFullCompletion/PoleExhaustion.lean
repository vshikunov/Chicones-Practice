import LeanVerification.WedgeFullCompletion.ActualPair

/-! Every pole in the actual logarithmic residue rectangle is one of the
two physical bank values.  The lifted factor map is injective, and its
permitted phases in this rectangle are precisely π and 3π. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral RegionalComplex
set_option maxHeartbeats 2000000

def wedgeContourAngle (F : ℝ) : ℝ := 2*Real.pi/F

theorem wedgeContourAngle_pos {F : ℝ} (hF : 3/2 < F) : 0 < wedgeContourAngle F :=
  div_pos (mul_pos (by norm_num) Real.pi_pos) (by linarith)

theorem logPotential_im_pos_above_pi_low {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hF2 : F < 2)
    (hz : Real.pi ≤ z.im) (hzu : z.im ≤ wedgeContourAngle F) :
    0 < (logPotential D F z).im := by
  have hFp : 0 < F := by linarith
  have hθ : 0 < z.im := Real.pi_pos.trans_le hz
  have hmul : F*z.im ≤ 2*Real.pi := by
    simpa only [mul_comm] using (le_div_iff₀ hFp).mp hzu
  have hFπ : (3:ℝ)*Real.pi < 2*F*Real.pi := by
    have h := mul_pos (show 0<2*F-3 by linarith) Real.pi_pos
    nlinarith only [h]
  have h3 : 3*Real.pi < (2*F)*z.im :=
    hFπ.trans_le (mul_le_mul_of_nonneg_left hz (by linarith))
  have h4 : (2*F)*z.im ≤ 4*Real.pi := by nlinarith only [hmul]
  have hslead : Real.sin ((2*F)*z.im) ≤ 0 := by
    have hs := sine_between_pi_two_pi_nonpos
      (show Real.pi ≤ (2*F)*z.im-2*Real.pi by linarith)
      (show (2*F)*z.im-2*Real.pi ≤ 2*Real.pi by linarith)
    simpa only [Real.sin_sub_two_pi] using hs
  have hmidlo : 2*Real.pi < (2*F-1)*z.im := by
    have h := mul_pos (show 0<2*F-3 by linarith) Real.pi_pos
    have hh := mul_le_mul_of_nonneg_left hz (show 0≤2*F-1 by linarith)
    nlinarith only [h,hh]
  have hmidhi : (2*F-1)*z.im < 3*Real.pi := by
    have hbound := mul_le_mul_of_nonneg_left hzu (show 0≤2*F-1 by linarith)
    have htop : (2*F-1)*(2*Real.pi/F) < 3*Real.pi := by
      rw [←mul_div_assoc]
      apply (div_lt_iff₀ hFp).2
      have h := mul_pos (sub_pos.mpr hF2) Real.pi_pos
      nlinarith only [h]
    exact hbound.trans_lt htop
  have hsmid : 0 < Real.sin ((2*F-1)*z.im) := by
    have hs := Real.sin_pos_of_pos_of_lt_pi
      (show 0 < (2*F-1)*z.im-2*Real.pi by linarith)
      (show (2*F-1)*z.im-2*Real.pi < Real.pi by linarith)
    simpa only [Real.sin_sub_two_pi] using hs
  have htaillo : Real.pi ≤ (2*F-2)*z.im := by
    have h := mul_nonneg (show 0≤2*F-3 by linarith) Real.pi_pos.le
    have hh := mul_le_mul_of_nonneg_left hz (show 0≤2*F-2 by linarith)
    nlinarith only [h,hh]
  have htailhi : (2*F-2)*z.im ≤ 2*Real.pi := by nlinarith only [hmul,hz]
  have hstail := sine_between_pi_two_pi_nonpos htaillo htailhi
  obtain ⟨hχ,hB,hK⟩ := wedge_coefficients_pos hD hF
  rw [logPotential_im_radial]
  apply mul_pos (Real.exp_pos _)
  dsimp only [radialImag]
  have hlead : 0 ≤ -wedgeLeading D F*(Real.exp z.re)^2*Real.sin (2*F*z.im) :=
    mul_nonneg_of_nonpos_of_nonpos
      (mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr hχ.le) (sq_nonneg _)) hslead
  have hmid := mul_pos (mul_pos hB (Real.exp_pos z.re)) hsmid
  have htail := mul_nonpos_of_nonneg_of_nonpos hK.le hstail
  linarith

theorem logPotential_re_at_pi_two_lt_height {D : ℝ} {z : ℂ}
    (hD : D < -1) (hz : z.im=Real.pi) :
    (logPotential D 2 z).re < height D 2 := by
  have hF : (3:ℝ)/2 < 2 := by norm_num
  have hχ := (wedge_coefficients_pos hD hF).1
  have hB := (wedge_coefficients_pos hD hF).2.1
  have hK := (wedge_coefficients_pos hD hF).2.2
  have he : Complex.exp z=-(Real.exp z.re : ℂ) := by
    apply Complex.ext <;> simp [Complex.exp_re,Complex.exp_im,hz]
  have he2 : Complex.exp (((2*(2:ℝ)-2 : ℝ) : ℂ)*z)=(Real.exp (2*z.re) : ℂ) := by
    apply Complex.ext <;> norm_num [Complex.exp_re,Complex.exp_im,Complex.mul_re,Complex.mul_im,hz]
  have hr := congrArg Complex.re (logPotential_quadratic_factor D 2 z)
  rw [he,he2] at hr
  simp only [Complex.sub_re,Complex.ofReal_re,←Complex.ofReal_neg,←Complex.ofReal_mul,
    ←Complex.ofReal_pow,←Complex.ofReal_add,←Complex.ofReal_sub] at hr
  have hp : 0 < Real.exp (2*z.re)*(wedgeLeading D 2*(-Real.exp z.re)^2-
      middle D 2*(-Real.exp z.re)+trailing D 2) := by
    rw [show wedgeLeading D 2*(-Real.exp z.re)^2-middle D 2*(-Real.exp z.re)+trailing D 2=
      wedgeLeading D 2*(Real.exp z.re)^2+middle D 2*Real.exp z.re+trailing D 2 by ring]
    positivity
  linarith

theorem real_energy_in_contour_strip {D F t : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (ht : wedgeSaddleHeight D F < t) (hz : 0 ≤ z.im) (hzu : z.im ≤ wedgeContourAngle F)
    (he : logPotential D F z=(t : ℂ)) : z ∈ logRayStrip := by
  have hzpos : 0 < z.im := by
    rcases eq_or_lt_of_le hz with h | h
    · have hwreal : z=(z.re : ℂ) := Complex.ext rfl h.symm
      have hmax := logPotential_real_le_wedgeSaddleHeight hD hF hDF z.re
      rw [←hwreal,he,Complex.ofReal_re] at hmax
      linarith
    · exact h
  refine ⟨hzpos,?_⟩
  by_contra hn
  have hzpi : Real.pi ≤ z.im := le_of_not_gt hn
  have hF2 : F ≤ 2 := by
    have hm : F*z.im ≤ 2*Real.pi := by
      simpa only [mul_comm] using (le_div_iff₀ (by linarith : 0<F)).mp hzu
    have hmul := mul_le_mul_of_nonneg_left hzpi (show 0≤F by linarith)
    exact (mul_le_mul_right Real.pi_pos).mp (by nlinarith only [hm,hmul])
  rcases lt_or_eq_of_le hF2 with hF2 | rfl
  · have hi := logPotential_im_pos_above_pi_low hD hF hF2 hzpi hzu
    rw [he,Complex.ofReal_im] at hi
    exact (lt_irrefl 0) hi
  · have him : z.im=Real.pi := by
      have hu : z.im ≤ Real.pi := by simpa [wedgeContourAngle] using hzu
      exact le_antisymm hu hzpi
    have hmax := logPotential_re_at_pi_two_lt_height hD him
    rw [he,Complex.ofReal_re] at hmax
    linarith [wedge_height_lt_saddle hD hF hDF]

theorem actualFactorLog_phase_lt_five_pi {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hFu : F < 4) (hDF : -F < D)
    (hz : z ∈ logRayStrip) (hzu : z.im ≤ wedgeContourAngle F) :
    (actualFactorLog D F z).im < 5*Real.pi := by
  have hp := (actualFactorLog_phase_bounds hD hF hDF hz).2
  have hb := mul_le_mul_of_nonneg_left hzu (show 0≤2*F-2 by linarith)
  have ht : (2*F-2)*(2*Real.pi/F) < 3*Real.pi := by
    rw [←mul_div_assoc]
    apply (div_lt_iff₀ (by linarith : 0<F)).2
    have h := mul_pos (sub_pos.mpr hFu) Real.pi_pos
    nlinarith only [h]
  have hbound := hb.trans_lt ht
  linarith

namespace ActualWedgePair
variable {D F : ℝ} (b : ActualWedgePair D F)

theorem poles_exhausted (hD : D < -1) (hF : 3/2 < F) (hFu : F < 4) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) {z : ℂ}
    (hz : 0 ≤ z.im) (hzu : z.im ≤ wedgeContourAngle F)
    (he : logPotential D F z=(t : ℂ)) : z=b.rightCutLog t ∨ z=b.leftCutLog t := by
  have hs := real_energy_in_contour_strip hD hF hDF ht hz hzu he
  have hp := (actualFactorLog_phase_bounds hD hF hDF hs).1
  have hpos : 0 < (actualFactorLog D F z).im :=
    (mul_pos (by linarith : 0<2*F) hs.1).trans hp
  rcases factorLog_real_energy_phases hD hF hDF hs
    ((wedge_height_lt_saddle hD hF hDF).trans ht) he hpos
    (actualFactorLog_phase_lt_five_pi hD hF hFu hDF hs hzu) with h | h
  · left
    apply actualFactorLog_injective hD hF hDF hs (b.rightCutLog_strip hD hF hDF ht)
    rw [h,b.rightCutLog_phase hD hF hDF ht]
  · right
    apply actualFactorLog_injective hD hF hDF hs
      (b.leftCutLog_strip hD hF hDF ((wedge_height_lt_saddle hD hF hDF).trans ht))
    rw [h,b.leftCutLog_phase hD hF hDF ((wedge_height_lt_saddle hD hF hDF).trans ht)]

theorem cutLogs_inside_contour (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) :
    0 < (b.rightCutLog t).im ∧ (b.rightCutLog t).im < wedgeContourAngle F ∧
      0 < (b.leftCutLog t).im ∧ (b.leftCutLog t).im < wedgeContourAngle F := by
  have hp := b.rightCutLog_angle_bound hD hF hDF ht
  have hm := b.leftCutLog_angle_bounds hD hF hDF ((wedge_height_lt_saddle hD hF hDF).trans ht)
  have hFpos : 0 < F := by linarith
  have h2Fpos : 0 < 2*F := by linarith
  have hangle : 3*Real.pi/(2*F) < wedgeContourAngle F := by
    apply (div_lt_div_iff₀ h2Fpos hFpos).2
    nlinarith [mul_pos hFpos Real.pi_pos]
  have ha : Real.pi/(2*F) < 3*Real.pi/(2*F) :=
    (div_lt_div_iff_of_pos_right h2Fpos).2 (by linarith [Real.pi_pos])
  exact ⟨hp.1,hp.2.trans (ha.trans hangle),
    (b.leftCutLog_strip hD hF hDF ((wedge_height_lt_saddle hD hF hDF).trans ht)).1,hm.2.trans hangle⟩

include b in
theorem contour_edges_no_poles (hD : D < -1) (hF : 3/2 < F) (hFu : F < 4) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) {z : ℂ}
    (hz : z.im=0 ∨ z.im=wedgeContourAngle F) : logPotential D F z ≠ (t : ℂ) := by
  intro he
  have hθ := wedgeContourAngle_pos hF
  have hlo : 0 ≤ z.im := by rcases hz with h | h <;> rw [h] <;> linarith
  have hhi : z.im ≤ wedgeContourAngle F := by rcases hz with h | h <;> rw [h] <;> linarith
  have hb := b.cutLogs_inside_contour hD hF hDF ht
  rcases b.poles_exhausted hD hF hFu hDF ht hlo hhi he with h | h
  · rw [h] at hz
    rcases hz with hz | hz <;> linarith [hb.1,hb.2.1]
  · rw [h] at hz
    rcases hz with hz | hz <;> linarith [hb.2.2.1,hb.2.2.2]

end ActualWedgePair
end LeanVerification.WedgeFullCompletion
