import LeanVerification.WedgeFullCompletion.PoleExhaustion
import LeanVerification.HigherUpperLeftCompletion.StripRotation
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.MeasureTheory.Integral.Asymptotics

/-! Absolute horizontal integrability and vanishing vertical banks for
the actual logarithmic residue kernel. Both end estimates are uniform in
the entire angular coordinate. -/

noncomputable section
open Set Filter MeasureTheory Asymptotics
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open MiddleStripCompletion MiddleStripSpectral RegionalComplex
set_option maxHeartbeats 1800000

def wedgeResidueKernel (D F t : ℝ) (z : ℂ) : ℂ :=
  Complex.exp ((F : ℂ)*z)/(logPotential D F z-(t : ℂ))

def residueInfinityError (D F t : ℝ) (z : ℂ) : ℂ :=
  infinityResidual D F z-(t : ℂ)*Complex.exp (((-(2*F) : ℝ) : ℂ)*z)

def residueInfinityBound (D F t x : ℝ) : ℝ :=
  infinityEndBound D F x + |t| * Real.exp (-(2*F)*x)

theorem residueInfinityBound_tendsto_zero (D F t : ℝ) (hF : 3/2 < F) :
    Tendsto (residueInfinityBound D F t) atTop (𝓝 0) := by
  simpa only [residueInfinityBound,mul_zero,add_zero] using
    (infinityEndBound_tendsto_zero D F hF).add
      ((exp_negative_scaled_tendsto_zero_atTop (show 0<2*F by linarith)).const_mul |t|)

theorem norm_residueInfinityError_le (D F t : ℝ) (z : ℂ) :
    ‖residueInfinityError D F t z‖ ≤ residueInfinityBound D F t z.re := by
  exact (norm_sub_le _ _).trans (by
    simpa only [residueInfinityBound,norm_mul,Complex.norm_real,Real.norm_eq_abs,norm_scaled_exp]
      using add_le_add_right (norm_infinityResidual_le D F z)
        ‖(t : ℂ)*Complex.exp (((-(2*F) : ℝ) : ℂ)*z)‖)

theorem residue_denominator_factor (D F t : ℝ) (z : ℂ) :
    logPotential D F z-(t : ℂ)=Complex.exp (((2*F : ℝ) : ℂ)*z)*
      ((leading D F : ℂ)+residueInfinityError D F t z) := by
  have he : Complex.exp (((2*F : ℝ) : ℂ)*z)*
      Complex.exp (((-(2*F) : ℝ) : ℂ)*z)=1 := by
    rw [←Complex.exp_add]
    convert Complex.exp_zero using 1
    push_cast
    ring
  rw [logPotential_infinity_factorization]
  dsimp only [residueInfinityError]
  linear_combination (t : ℂ)*he

theorem wedgeResidueKernel_bound_atBot {D F t : ℝ}
    (hF : 3/2 < F) (ht : height D F < t) :
    ∃ a : ℝ,∀ z : ℂ,z.re ≤ a →
      ‖wedgeResidueKernel D F t z‖ ≤ (2/(t-height D F))*Real.exp (F*z.re) := by
  obtain ⟨a,ha⟩ := uniform_logPotential_atBot D F hF (half_pos (sub_pos.mpr ht))
  refine ⟨a,fun z hz => ?_⟩
  have herr := ha z hz
  have htriangle : t-height D F ≤ ‖logPotential D F z-(height D F : ℂ)‖+
      ‖logPotential D F z-(t : ℂ)‖ := by
    calc
      _ = ‖(logPotential D F z-(height D F : ℂ))-(logPotential D F z-(t : ℂ))‖ := by
        rw [show (logPotential D F z-(height D F : ℂ))-(logPotential D F z-(t : ℂ))=
          ((t-height D F : ℝ) : ℂ) by push_cast;ring,Complex.norm_real,Real.norm_eq_abs,
          abs_of_pos (sub_pos.mpr ht)]
      _ ≤ _ := norm_sub_le _ _
  have hden : (t-height D F)/2 ≤ ‖logPotential D F z-(t : ℂ)‖ := by linarith
  rw [wedgeResidueKernel,norm_div,norm_scaled_exp]
  calc
    _ ≤ Real.exp (F*z.re)/((t-height D F)/2) :=
      div_le_div_of_nonneg_left (Real.exp_pos _).le (half_pos (sub_pos.mpr ht)) hden
    _ = _ := by field_simp;ring

theorem wedgeResidueKernel_bound_atTop {D F t : ℝ}
    (hD : D < -1) (hF : 3/2 < F) :
    ∃ a : ℝ,∀ z : ℂ,a ≤ z.re →
      ‖wedgeResidueKernel D F t z‖ ≤ (2/wedgeLeading D F)*Real.exp (-F*z.re) := by
  have hχ := (wedge_coefficients_pos hD hF).1
  obtain ⟨a,ha⟩ := eventually_atTop.mp
    ((residueInfinityBound_tendsto_zero D F t hF).eventually (Iio_mem_nhds (half_pos hχ)))
  refine ⟨a,fun z hz => ?_⟩
  have herr : ‖residueInfinityError D F t z‖ < wedgeLeading D F/2 :=
    (norm_residueInfinityError_le D F t z).trans_lt (ha z.re hz)
  have htriangle : wedgeLeading D F ≤
      ‖(leading D F : ℂ)+residueInfinityError D F t z‖+‖residueInfinityError D F t z‖ := by
    calc
      _ = ‖((leading D F : ℂ)+residueInfinityError D F t z)-residueInfinityError D F t z‖ := by
        simp only [add_sub_cancel_right,Complex.norm_real,Real.norm_eq_abs]
        rw [abs_of_neg (show leading D F<0 by simpa [wedgeLeading] using hχ)]
        rfl
      _ ≤ _ := norm_sub_le _ _
  have hhalf : wedgeLeading D F/2 ≤ ‖(leading D F : ℂ)+residueInfinityError D F t z‖ := by linarith
  have hden : Real.exp ((2*F)*z.re)*(wedgeLeading D F/2) ≤ ‖logPotential D F z-(t : ℂ)‖ := by
    rw [residue_denominator_factor,norm_mul,norm_scaled_exp]
    exact mul_le_mul_of_nonneg_left hhalf (Real.exp_pos _).le
  rw [wedgeResidueKernel,norm_div,norm_scaled_exp]
  calc
    _ ≤ Real.exp (F*z.re)/(Real.exp ((2*F)*z.re)*(wedgeLeading D F/2)) :=
      div_le_div_of_nonneg_left (Real.exp_pos _).le (mul_pos (Real.exp_pos _) (half_pos hχ)) hden
    _ = (2/wedgeLeading D F)*Real.exp (-F*z.re) := by
      rw [div_mul_eq_div_div,←Real.exp_sub]
      rw [show F*z.re-(2*F)*z.re= -F*z.re by ring]
      field_simp
      <;> ring

theorem integrable_of_exponential_end_bounds {f : ℝ → ℂ} {a C₀ Ctop : ℝ}
    (ha : 0 < a) (hf : Continuous f)
    (hbot : ∀ᶠ x in atBot,‖f x‖ ≤ C₀*Real.exp (a*x))
    (htop : ∀ᶠ x in atTop,‖f x‖ ≤ Ctop*Real.exp (-a*x)) : Integrable f := by
  have ho₀ : f =O[atBot] (fun x : ℝ => Real.exp (a*x)) := by
    apply isBigO_iff.mpr
    exact ⟨C₀,by simpa only [Real.norm_of_nonneg (Real.exp_pos _).le] using hbot⟩
  have hotop : f =O[atTop] (fun x : ℝ => Real.exp (-a*x)) := by
    apply isBigO_iff.mpr
    exact ⟨Ctop,by simpa only [Real.norm_of_nonneg (Real.exp_pos _).le] using htop⟩
  exact hf.locallyIntegrable.integrable_of_isBigO_atBot_atTop ho₀
    ⟨Iic 0,Iic_mem_atBot 0,integrableOn_exp_mul_Iic ha 0⟩ hotop
    ⟨Ioi 0,Ioi_mem_atTop 0,integrableOn_exp_mul_Ioi (neg_neg_of_pos ha) 0⟩

theorem vertical_integral_tendsto_zero_of_eventual_bound
    {f : ℂ → ℂ} {a b : ℝ} (hab : a ≤ b) {l : Filter ℝ} {g : ℝ → ℝ}
    (hg : Tendsto g l (𝓝 0))
    (hbound : ∀ᶠ x : ℝ in l,∀ y ∈ Icc a b,‖f ((x : ℂ)+(y : ℂ)*Complex.I)‖ ≤ g x) :
    Tendsto (fun x : ℝ => ∫ y in a..b,f ((x : ℂ)+(y : ℂ)*Complex.I)) l (𝓝 0) := by
  have hlim : Tendsto (fun x : ℝ => |b-a| * g x) l (𝓝 0) := by
    simpa only [mul_zero] using hg.const_mul |b-a|
  apply squeeze_zero_norm' _ hlim
  filter_upwards [hbound] with x hx
  rw [mul_comm |b-a| (g x)]
  apply intervalIntegral.norm_integral_le_of_norm_le_const
  intro y hy
  exact hx y (Ioc_subset_Icc_self (uIoc_of_le hab ▸ hy))

namespace ActualWedgePair
variable {D F : ℝ} (b : ActualWedgePair D F)

include b in
theorem residue_horizontal_integrable (hD : D < -1) (hF : 3/2 < F) (hFu : F < 4) (hDF : -F < D)
    {t y : ℝ} (ht : wedgeSaddleHeight D F < t) (hy : y=0 ∨ y=wedgeContourAngle F) :
    Integrable (fun x : ℝ => wedgeResidueKernel D F t ((x : ℂ)+(y : ℂ)*Complex.I)) := by
  have hc : Continuous (fun x : ℝ => wedgeResidueKernel D F t ((x : ℂ)+(y : ℂ)*Complex.I)) := by
    apply continuous_iff_continuousAt.mpr
    intro x
    have hn : logPotential D F ((x : ℂ)+(y : ℂ)*Complex.I)-(t : ℂ) ≠ 0 :=
      sub_ne_zero.mpr (b.contour_edges_no_poles hD hF hFu hDF ht (by simpa using hy))
    have ho : ContinuousAt (wedgeResidueKernel D F t) ((x : ℂ)+(y : ℂ)*Complex.I) := by
      unfold wedgeResidueKernel
      exact ((Complex.continuous_exp.comp (continuous_const.mul continuous_id)).continuousAt).div
        (((analyticOnNhd_logPotential D F hF) _ (mem_univ _)).continuousAt.sub continuousAt_const) hn
    exact ho.comp (f := fun x : ℝ => (x : ℂ)+(y : ℂ)*Complex.I) (by fun_prop)
  obtain ⟨a,ha⟩ := wedgeResidueKernel_bound_atBot hF ((wedge_height_lt_saddle hD hF hDF).trans ht)
  obtain ⟨c,hc'⟩ := wedgeResidueKernel_bound_atTop (t := t) hD hF
  apply integrable_of_exponential_end_bounds (a := F) (by linarith) hc
  · filter_upwards [Iic_mem_atBot a] with x hx
    simpa using ha ((x : ℂ)+(y : ℂ)*Complex.I) (by simpa using hx)
  · filter_upwards [Ici_mem_atTop c] with x hx
    simpa using hc' ((x : ℂ)+(y : ℂ)*Complex.I) (by simpa using hx)

end ActualWedgePair

theorem residue_vertical_banks_tendsto_zero {D F t : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (ht : height D F < t) :
    Tendsto (fun x : ℝ => ∫ y in (0:ℝ)..wedgeContourAngle F,
      wedgeResidueKernel D F t ((x : ℂ)+(y : ℂ)*Complex.I)) atBot (𝓝 0) ∧
    Tendsto (fun x : ℝ => ∫ y in (0:ℝ)..wedgeContourAngle F,
      wedgeResidueKernel D F t ((x : ℂ)+(y : ℂ)*Complex.I)) atTop (𝓝 0) := by
  obtain ⟨a,ha⟩ := wedgeResidueKernel_bound_atBot hF ht
  obtain ⟨c,hc⟩ := wedgeResidueKernel_bound_atTop (t := t) hD hF
  have hbot : Tendsto (fun x : ℝ => (2/(t-height D F))*Real.exp (F*x)) atBot (𝓝 0) := by
    simpa only [mul_zero] using (exp_scaled_tendsto_zero_atBot (show 0<F by linarith)).const_mul (2/(t-height D F))
  have htop : Tendsto (fun x : ℝ => (2/wedgeLeading D F)*Real.exp (-F*x)) atTop (𝓝 0) := by
    simpa only [mul_zero] using (exp_negative_scaled_tendsto_zero_atTop (show 0<F by linarith)).const_mul (2/wedgeLeading D F)
  constructor
  · apply vertical_integral_tendsto_zero_of_eventual_bound (wedgeContourAngle_pos hF).le hbot
    filter_upwards [Iic_mem_atBot a] with x hx
    intro y hy
    simpa using ha ((x : ℂ)+(y : ℂ)*Complex.I) (by simpa using hx)
  · apply vertical_integral_tendsto_zero_of_eventual_bound (wedgeContourAngle_pos hF).le htop
    filter_upwards [Ici_mem_atTop c] with x hx
    intro y hy
    simpa using hc ((x : ℂ)+(y : ℂ)*Complex.I) (by simpa using hx)

end LeanVerification.WedgeFullCompletion
