import LeanVerification.WedgeFullCompletion.ResidueBounds
import LeanVerification.WedgeIntegralCompletion.TwoPoleRectangle

/-! The complete contour identity for the actual two physical spectral
poles. The finite residue formula and every closing-bank limit are proved. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open MiddleStripCompletion MiddleStripSpectral RegionalComplex WedgeIntegralCompletion
set_option maxHeartbeats 2000000

def wedgeResidueAt (D F : ℝ) (w : ℂ) : ℂ :=
  Complex.exp ((F : ℂ)*w)/logPotentialSlope D F w

namespace ActualWedgePair
variable {D F : ℝ} (b : ActualWedgePair D F)

theorem residue_finite_rectangle (hD : D < -1) (hF : 3/2 < F) (hFu : F < 4) (hDF : -F < D)
    {t L R : ℝ} (ht : wedgeSaddleHeight D F < t)
    (hp : (b.rightCutLog t).re ∈ Ioo L R) (hm : (b.leftCutLog t).re ∈ Ioo L R) :
    RectangularCauchy.boundary (wedgeResidueKernel D F t) L R 0 (wedgeContourAngle F)=
      2*(Real.pi : ℂ)*Complex.I*
        (wedgeResidueAt D F (b.rightCutLog t)+wedgeResidueAt D F (b.leftCutLog t)) := by
  have hb := b.cutLogs_inside_contour hD hF hDF ht
  have hps := b.rightCutLog_strip hD hF hDF ht
  have hms := b.leftCutLog_strip hD hF hDF ((wedge_height_lt_saddle hD hF hDF).trans ht)
  have hd (w : ℂ) : deriv (fun z => logPotential D F z-(t : ℂ)) w=logPotentialSlope D F w :=
    ((hasDerivAt_logPotential D F hF w).sub_const (t : ℂ)).deriv
  have hform := rectangle_two_simple_poles
    (b.cutLogs_ne hD hF hDF ht) ⟨hp,hb.1,hb.2.1⟩ ⟨hm,hb.2.2.1,hb.2.2.2⟩
    (f := fun z : ℂ => Complex.exp ((F : ℂ)*z)) (q := fun z => logPotential D F z-(t : ℂ))
    (fun z _ => (analyticAt_const.mul analyticAt_id).cexp')
    (fun z _ => ((analyticOnNhd_logPotential D F hF) z (mem_univ z)).sub analyticAt_const)
    (sub_eq_zero.mpr (b.rightCutLog_spec hD hF hDF ht).2.2.1)
    (sub_eq_zero.mpr (b.leftCutLog_spec hD hF hDF ((wedge_height_lt_saddle hD hF hDF).trans ht)).2.2.1)
    (by
      rw [hd]
      exact wedge_logPotentialSlope_ne_zero hD (by linarith [hps.1,Real.pi_pos]) hps.2 hps.1.ne')
    (by
      rw [hd]
      exact wedge_logPotentialSlope_ne_zero hD (by linarith [hms.1,Real.pi_pos]) hms.2 hms.1.ne')
    (fun z hz he => b.poles_exhausted hD hF hFu hDF ht hz.2.1 hz.2.2 (sub_eq_zero.mp he))
  simpa only [wedgeResidueKernel,wedgeResidueAt,hd] using hform

theorem actual_residue_integral_identity (hD : D < -1) (hF : 3/2 < F) (hFu : F < 4) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) :
    (∫ x : ℝ,wedgeResidueKernel D F t (x : ℂ))-
        (∫ x : ℝ,wedgeResidueKernel D F t ((x : ℂ)+(wedgeContourAngle F : ℂ)*Complex.I))=
      2*(Real.pi : ℂ)*Complex.I*
        (wedgeResidueAt D F (b.rightCutLog t)+wedgeResidueAt D F (b.leftCutLog t)) := by
  have hi₀ : Integrable (fun x : ℝ => wedgeResidueKernel D F t (x : ℂ)) := by
    simpa only [Complex.ofReal_zero,zero_mul,add_zero] using
      b.residue_horizontal_integrable hD hF hFu hDF ht (Or.inl rfl : (0:ℝ)=0 ∨ 0=wedgeContourAngle F)
  have hi₁ := b.residue_horizontal_integrable hD hF hFu hDF ht
    (Or.inr rfl : wedgeContourAngle F=0 ∨ wedgeContourAngle F=wedgeContourAngle F)
  obtain ⟨hbot,htop⟩ := residue_vertical_banks_tendsto_zero hD hF
    ((wedge_height_lt_saddle hD hF hDF).trans ht)
  have hva := hbot.comp tendsto_neg_atTop_atBot
  have hha := intervalIntegral_tendsto_integral hi₀ tendsto_neg_atTop_atBot tendsto_id
  have hhb := intervalIntegral_tendsto_integral hi₁ tendsto_neg_atTop_atBot tendsto_id
  have hlim := ((hha.sub hhb).add (htop.const_mul Complex.I)).sub (hva.const_mul Complex.I)
  have hlim' : Tendsto
      (fun R : ℝ => RectangularCauchy.boundary (wedgeResidueKernel D F t) (-R) R 0 (wedgeContourAngle F))
      atTop (𝓝 ((∫ x : ℝ,wedgeResidueKernel D F t (x : ℂ))-
        ∫ x : ℝ,wedgeResidueKernel D F t ((x : ℂ)+(wedgeContourAngle F : ℂ)*Complex.I))) := by
    simpa only [RectangularCauchy.boundary,Complex.ofReal_zero,zero_mul,add_zero,
      mul_zero,sub_zero] using hlim
  let R₀ := max |(b.rightCutLog t).re| |(b.leftCutLog t).re|+1
  have he : ∀ᶠ R : ℝ in atTop,
      RectangularCauchy.boundary (wedgeResidueKernel D F t) (-R) R 0 (wedgeContourAngle F)=
        2*(Real.pi : ℂ)*Complex.I*
          (wedgeResidueAt D F (b.rightCutLog t)+wedgeResidueAt D F (b.leftCutLog t)) := by
    filter_upwards [Ici_mem_atTop R₀] with R hR
    change R₀ ≤ R at hR
    have hpabs : |(b.rightCutLog t).re| < R := by
      have hp := le_max_left |(b.rightCutLog t).re| |(b.leftCutLog t).re|
      dsimp only [R₀] at hR
      linarith
    have hmabs : |(b.leftCutLog t).re| < R := by
      have hm := le_max_right |(b.rightCutLog t).re| |(b.leftCutLog t).re|
      dsimp only [R₀] at hR
      linarith
    exact b.residue_finite_rectangle hD hF hFu hDF ht (abs_lt.mp hpabs) (abs_lt.mp hmabs)
  exact tendsto_nhds_unique hlim' (tendsto_const_nhds.congr' (he.mono fun _ h => h.symm))

end ActualWedgePair
end LeanVerification.WedgeFullCompletion
