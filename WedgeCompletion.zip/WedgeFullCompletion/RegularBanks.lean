import LeanVerification.WedgeFullCompletion.RegularInverseGerm

/-! Complete regular bank continuations of the two actual inverse sheets.
Only the actual center, zero-end energy, and saddle energy are excluded.
The compactness argument supplies the bank values and the local inverse
identity supplies the analytic germ. -/

noncomputable section
open Set Filter Metric
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral
set_option maxHeartbeats 1800000

def wedgeSaddleHeight (D F : ℝ) : ℝ := potential D F (D/(D+1))

theorem wedge_critical_value {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F)
    (hlo : -Real.pi < z.im) (hhi : z.im < Real.pi)
    (hd : logPotentialSlope D F z=0) :
    logPotential D F z=0 ∨ logPotential D F z=(wedgeSaddleHeight D F : ℂ) := by
  have hi : z.im=0 := by
    by_contra hn
    exact wedge_logPotentialSlope_ne_zero hD hlo hhi hn hd
  have hz : z=(z.re : ℂ) := Complex.ext rfl hi
  rw [hz,logPotentialSlope_real] at hd
  have hr : Real.exp ((2*F-2)*z.re)*(Real.exp z.re-1)*((D+1)*Real.exp z.re-D)=0 :=
    Complex.ofReal_eq_zero.mp hd
  have hcases : Real.exp z.re-1=0 ∨ (D+1)*Real.exp z.re-D=0 := by
    rcases mul_eq_zero.mp hr with h | h
    · exact Or.inl ((mul_eq_zero.mp h).resolve_left (Real.exp_pos _).ne')
    · exact Or.inr h
  rw [hz,logPotential_real D F z.re hF]
  rcases hcases with h | h
  · left
    rw [sub_eq_zero.mp h,potential_one,Complex.ofReal_zero]
  · right
    have he : Real.exp z.re=D/(D+1) := (eq_div_iff (by linarith : D+1 ≠ 0)).2 (by linarith)
    rw [he]
    rfl

theorem wedge_log_deriv_ne_zero_of_regular_energy {D F t : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F)
    (hlo : -Real.pi < z.im) (hhi : z.im < Real.pi)
    (ht0 : t ≠ 0) (hts : t ≠ wedgeSaddleHeight D F)
    (he : logPotential D F z=(t : ℂ)) : logPotentialSlope D F z ≠ 0 := by
  intro hd
  rcases wedge_critical_value hD hF hlo hhi hd with h | h
  · rw [he] at h
    exact ht0 (Complex.ofReal_eq_zero.mp h)
  · rw [he] at h
    exact hts (Complex.ofReal_injective h)

theorem wedge_vertical_target_real_bounds {D F t : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (ht : t ≠ height D F) :
    ∃ l r : ℝ, ∀ z : ℂ, (logPotential D F z).re=t →
      0 < (logPotential D F z).im → (logPotential D F z).im ≤ 1 →
      l ≤ z.re ∧ z.re ≤ r := by
  have hdist : 0 < |t-height D F| := abs_pos.mpr (sub_ne_zero.mpr ht)
  obtain ⟨l,hl⟩ := uniform_logPotential_atBot D F hF hdist
  obtain ⟨r,hr⟩ := wedge_uniform_logPotential_atTop hD hF (|t|+1)
  refine ⟨l,r,?_⟩
  intro z hzt hzim hzimh
  constructor
  · by_contra hn
    have hsmall := hl z (le_of_not_ge hn)
    have hlow := Complex.abs_re_le_norm (logPotential D F z-(height D F : ℂ))
    simp only [Complex.sub_re,Complex.ofReal_re,hzt] at hlow
    linarith
  · by_contra hn
    have hbig := hr z (le_of_not_ge hn)
    have hnorm := Complex.norm_le_abs_re_add_abs_im (logPotential D F z)
    rw [hzt,abs_of_pos hzim] at hnorm
    linarith

theorem wedge_inverse_vertical_cluster {D F t lo hi : ℝ} {g : ℂ → ℂ} {S : Set ℂ}
    (hD : D < -1) (hF : 3/2 < F) (ht : t ≠ height D F)
    (hS : IsClosed S) (hbound : ∀ z ∈ S,lo ≤ z.im ∧ z.im ≤ hi)
    (hm : MapsTo g upperEnergy S)
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z) :
    ∃ w : ℂ,w ∈ S ∧ logPotential D F w=(t : ℂ) ∧
      ∃ φ : ℕ → ℕ,StrictMono φ ∧ Tendsto (fun n => g (upperSequence t (φ n))) atTop (𝓝 w) := by
  obtain ⟨l,r,hlr⟩ := wedge_vertical_target_real_bounds hD hF ht
  let Q : Set ℂ := (Icc l r ×ℂ Icc lo hi) ∩ S
  have hQ : IsCompact Q := (isCompact_Icc.reProdIm isCompact_Icc).inter_right hS
  have hmem : ∀ n : ℕ,g (upperSequence t n) ∈ Q := by
    intro n
    have hu := upperSequence_mem t n
    have hr := hlr (g (upperSequence t n))
      (by rw [he _ hu];simp [upperSequence])
      (by rw [he _ hu];exact hu)
      (by rw [he _ hu];exact upperSequence_im_le_one t n)
    exact ⟨⟨hr,hbound _ (hm hu)⟩,hm hu⟩
  obtain ⟨w,hw,φ,hφ,hlim⟩ := hQ.tendsto_subseq hmem
  have hf : Continuous (logPotential D F) :=
    continuous_iff_continuousOn_univ.mpr (analyticOnNhd_logPotential D F hF).continuousOn
  have heq : logPotential D F w=(t : ℂ) := by
    apply tendsto_nhds_unique (hf.continuousAt.tendsto.comp hlim)
    apply ((upperSequence_tendsto t).comp hφ.tendsto_atTop).congr'
    filter_upwards [] with n
    exact (he _ (upperSequence_mem t (φ n))).symm
  exact ⟨w,hw.2,heq,φ,hφ,hlim⟩

theorem actual_right_regular_bank {D F t : ℝ} {g : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F)
    (hg : AnalyticOnNhd ℂ g upperEnergy) (hm : MapsTo g upperEnergy (rightDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    (ht0 : t ≠ 0) (htH : t ≠ height D F) (hts : t ≠ wedgeSaddleHeight D F) :
    ∃ w : ℂ,w ∈ rightFrame D F ∧ logPotential D F w=(t : ℂ) ∧
      ∃ j : ℂ → ℂ, AnalyticAt ℂ j (t : ℂ) ∧ j (t : ℂ)=w ∧
        g =ᶠ[𝓝[upperEnergy] (t : ℂ)] j ∧
        Tendsto g (𝓝[upperEnergy] (t : ℂ)) (𝓝 w) := by
  obtain ⟨w,hw,heq,φ,hφ,hlim⟩ := wedge_inverse_vertical_cluster hD hF htH
    (rightFrame_closed D F) (fun _ hz => ⟨hz.1,hz.2.1⟩)
    (fun _ hz => (hm hz).1) he
  obtain ⟨ha,hab,hbc,hcd,hd⟩ := wedge_angles hF
  have hn := wedge_log_deriv_ne_zero_of_regular_energy hD hF
    (by linarith [hw.1,Real.pi_pos]) (by linarith [hw.2.1]) ht0 hts heq
  refine ⟨w,hw,heq,?_⟩
  exact inverse_germ_of_regular_cluster hg he
    ((analyticOnNhd_logPotential D F hF) w (mem_univ w))
    (hasStrictDerivAt_logPotential D F hF w) hn heq
    (fun n => upperSequence_mem t (φ n)) ((upperSequence_tendsto t).comp hφ.tendsto_atTop) hlim

theorem actual_left_regular_bank {D F t : ℝ} {g : ℂ → ℂ}
    (hD : D < -1) (hF : 3/2 < F)
    (hg : AnalyticOnNhd ℂ g upperEnergy) (hm : MapsTo g upperEnergy (leftDomain D F))
    (he : ∀ z ∈ upperEnergy,logPotential D F (g z)=z)
    (ht0 : t ≠ 0) (htH : t ≠ height D F) (hts : t ≠ wedgeSaddleHeight D F) :
    ∃ w : ℂ,w ∈ leftFrame D F ∧ logPotential D F w=(t : ℂ) ∧
      ∃ j : ℂ → ℂ, AnalyticAt ℂ j (t : ℂ) ∧ j (t : ℂ)=w ∧
        g =ᶠ[𝓝[upperEnergy] (t : ℂ)] j ∧
        Tendsto g (𝓝[upperEnergy] (t : ℂ)) (𝓝 w) := by
  have hbound : ∀ z ∈ leftFrame D F,-wedgeZeroAngle F ≤ z.im ∧ z.im ≤ 0 := by
    intro z hz
    change 0 ≤ (star z : ℂ).im ∧ (star z : ℂ).im ≤ wedgeZeroAngle F ∧ _ at hz
    simp only [Complex.star_def,Complex.conj_im] at hz
    exact ⟨by linarith [hz.2.1],by linarith [hz.1]⟩
  obtain ⟨w,hw,heq,φ,hφ,hlim⟩ := wedge_inverse_vertical_cluster hD hF htH
    (leftFrame_closed D F) hbound (fun _ hz => (hm hz).1) he
  have hb := hbound w hw
  have hd := (wedge_angles hF).2.2.2.2
  have hn := wedge_log_deriv_ne_zero_of_regular_energy hD hF
    (by linarith [hb.1]) (by linarith [hb.2,Real.pi_pos]) ht0 hts heq
  refine ⟨w,hw,heq,?_⟩
  exact inverse_germ_of_regular_cluster hg he
    ((analyticOnNhd_logPotential D F hF) w (mem_univ w))
    (hasStrictDerivAt_logPotential D F hF w) hn heq
    (fun n => upperSequence_mem t (φ n)) ((upperSequence_tendsto t).comp hφ.tendsto_atTop) hlim

end LeanVerification.WedgeFullCompletion
