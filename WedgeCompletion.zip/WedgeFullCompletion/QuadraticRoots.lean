import LeanVerification.WedgeFullCompletion.FactorLogMap
import LeanVerification.WedgeFullCompletion.EnergyRange

/-! The two positive roots of the actual quadratic factor and its exact
logarithmic factorization.  The fixed frame radius lies strictly between
the center and the nonzero saddle. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion RegionalComplex
set_option maxHeartbeats 1800000

def wedgeDiscriminant (D F : ℝ) : ℝ :=
  (middle D F)^2-4*wedgeLeading D F*trailing D F

def wedgeRootLower (D F : ℝ) : ℝ :=
  (middle D F-Real.sqrt (wedgeDiscriminant D F))/(2*wedgeLeading D F)

def wedgeRootUpper (D F : ℝ) : ℝ :=
  (middle D F+Real.sqrt (wedgeDiscriminant D F))/(2*wedgeLeading D F)

theorem wedge_roots_pos_order {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    0 < wedgeRootLower D F ∧ wedgeRootLower D F < wedgeRootUpper D F := by
  have hp := wedge_coefficients_pos hD hF
  have hd : 0 < wedgeDiscriminant D F := wedge_discriminant_pos hD hF hDF
  have hs := Real.sq_sqrt hd.le
  have hs0 := Real.sqrt_pos.mpr hd
  have hsb : Real.sqrt (wedgeDiscriminant D F) < middle D F := by
    have hck := mul_pos hp.1 hp.2.2
    change (Real.sqrt (wedgeDiscriminant D F))^2=
      (middle D F)^2-4*wedgeLeading D F*trailing D F at hs
    nlinarith
  constructor
  · exact div_pos (sub_pos.mpr hsb) (mul_pos (by norm_num) hp.1)
  · apply (div_lt_div_iff_of_pos_right (mul_pos (by norm_num : (0:ℝ)<2) hp.1)).2
    linarith

theorem wedge_roots_coefficients {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    wedgeLeading D F*(wedgeRootLower D F+wedgeRootUpper D F)=middle D F ∧
      wedgeLeading D F*wedgeRootLower D F*wedgeRootUpper D F=trailing D F := by
  have hn := (wedge_coefficients_pos hD hF).1.ne'
  have hs := Real.sq_sqrt (wedge_discriminant_pos hD hF hDF).le
  change (Real.sqrt (wedgeDiscriminant D F))^2=wedgeDiscriminant D F at hs
  change (Real.sqrt (wedgeDiscriminant D F))^2=
    (middle D F)^2-4*wedgeLeading D F*trailing D F at hs
  dsimp only [wedgeRootLower,wedgeRootUpper]
  constructor
  · field_simp
    <;> ring
  · field_simp
    nlinarith only [congrArg (fun x : ℝ => wedgeLeading D F*x) hs]

theorem logPotential_quadratic_factor (D F : ℝ) (z : ℂ) :
    (height D F : ℂ)-logPotential D F z=
      Complex.exp (((2*F-2 : ℝ) : ℂ)*z)*
        ((wedgeLeading D F : ℂ)*(Complex.exp z)^2-
          (middle D F : ℂ)*Complex.exp z+(trailing D F : ℂ)) := by
  have h1 : Complex.exp (((2*F-1 : ℝ) : ℂ)*z)=
      Complex.exp (((2*F-2 : ℝ) : ℂ)*z)*Complex.exp z := by
    convert exp_scaled_add_one (2*F-2) z using 1 <;> congr 2 <;> ring
  have h2 : Complex.exp (((2*F : ℝ) : ℂ)*z)=
      Complex.exp (((2*F-2 : ℝ) : ℂ)*z)*(Complex.exp z)^2 := by
    calc
      _ = Complex.exp (((2*F-1 : ℝ) : ℂ)*z)*Complex.exp z := by
        convert exp_scaled_add_one (2*F-1) z using 1 <;> congr 2 <;> ring
      _ = _ := by rw [h1];ring
  simp only [logPotential,h1,h2,wedgeLeading,Complex.ofReal_neg]
  ring

theorem logPotential_root_factor {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) (z : ℂ) :
    (height D F : ℂ)-logPotential D F z=
      (wedgeLeading D F : ℂ)*Complex.exp (((2*F-2 : ℝ) : ℂ)*z)*
        (Complex.exp z-(wedgeRootLower D F : ℂ))*
        (Complex.exp z-(wedgeRootUpper D F : ℂ)) := by
  obtain ⟨hs,hp⟩ := wedge_roots_coefficients hD hF hDF
  have hsc : (wedgeLeading D F : ℂ)*
      ((wedgeRootLower D F : ℂ)+(wedgeRootUpper D F : ℂ))=(middle D F : ℂ) := by
    exact_mod_cast hs
  have hpc : (wedgeLeading D F : ℂ)*(wedgeRootLower D F : ℂ)*
      (wedgeRootUpper D F : ℂ)=(trailing D F : ℂ) := by exact_mod_cast hp
  rw [logPotential_quadratic_factor,←hsc,←hpc]
  ring

def actualFactorLog (D F : ℝ) : ℂ → ℂ :=
  factorLogMap (2*F) (wedgeRootLower D F) (wedgeRootUpper D F)

theorem actualFactorLog_exp {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {z : ℂ} (hz : z ∈ logRayStrip) :
    Complex.exp (actualFactorLog D F z)=
      ((height D F : ℂ)-logPotential D F z)/(wedgeLeading D F : ℂ) := by
  rw [actualFactorLog,factorLogMap_exp _ _ _ hz,logPotential_root_factor hD hF hDF]
  have hn : (wedgeLeading D F : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (wedge_coefficients_pos hD hF).1.ne'
  field_simp
  <;> ring

theorem actualFactorLog_injective {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    Set.InjOn (actualFactorLog D F) logRayStrip := by
  obtain ⟨hu,huv⟩ := wedge_roots_pos_order hD hF hDF
  exact factorLogMap_injective _ hu (hu.trans huv)

theorem wedge_radius_saddle_gap {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) :
    wedgeLeading D F*(D/(D+1))^2-trailing D F=
      D*(D+F)/(2*F*(D+1)*(F-1)) := by
  have hD1 : D+1 ≠ 0 := by linarith
  have hF0 : F ≠ 0 := by linarith
  have hF1 : F-1 ≠ 0 := by linarith
  have hF2 : 2*F-2 ≠ 0 := by linarith
  dsimp only [wedgeLeading,leading,trailing]
  field_simp
  <;> ring

theorem wedgeRadius_lt_saddle {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    wedgeRadius D F < D/(D+1) := by
  have hp := wedge_coefficients_pos hD hF
  have hr := wedgeRadius_pos hD hF
  have hs : 0 < D/(D+1) := lt_trans zero_lt_one (extra_root_gt_one_of_lt_neg_one D hD)
  have hgap : 0 < wedgeLeading D F*(D/(D+1))^2-trailing D F := by
    rw [wedge_radius_saddle_gap hD hF]
    exact div_pos_of_neg_of_neg (mul_neg_of_neg_of_pos (by linarith) (by linarith))
      (mul_neg_of_neg_of_pos
        (mul_neg_of_pos_of_neg (mul_pos (by norm_num) (by linarith)) (by linarith))
        (by linarith))
  rw [←wedgeRadius_square hD hF] at hgap
  have hsq : (wedgeRadius D F)^2 < (D/(D+1))^2 :=
    (mul_lt_mul_left hp.1).mp (by linarith only [hgap])
  nlinarith

theorem wedgeLogRadius_lt_saddleLog {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    wedgeLogRadius D F < wedgeSaddleLog D :=
  Real.log_lt_log (wedgeRadius_pos hD hF) (wedgeRadius_lt_saddle hD hF hDF)

theorem wedgeRootLower_gt_one {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    1 < wedgeRootLower D F := by
  have hχ := (wedge_coefficients_pos hD hF).1
  obtain ⟨hu,huv⟩ := wedge_roots_pos_order hD hF hDF
  obtain ⟨hs,hp⟩ := wedge_roots_coefficients hD hF hDF
  have hprod : wedgeRootLower D F*wedgeRootUpper D F=(wedgeRadius D F)^2 := by
    apply (mul_left_cancel₀ hχ.ne')
    simpa only [mul_assoc,wedgeRadius_square hD hF] using hp
  have hv1 : 1 < wedgeRootUpper D F := by
    by_contra hn
    have hv : wedgeRootUpper D F ≤ 1 := le_of_not_gt hn
    have hp1 := mul_le_mul (huv.le.trans hv) hv (hu.trans huv).le (by norm_num : (0:ℝ)≤1)
    rw [hprod] at hp1
    have hr := wedgeRadius_gt_one hD hF
    nlinarith
  have hcenter : wedgeLeading D F*(1-wedgeRootLower D F)*(1-wedgeRootUpper D F)=height D F := by
    calc
      _ = wedgeLeading D F-wedgeLeading D F*(wedgeRootLower D F+wedgeRootUpper D F)+
          wedgeLeading D F*wedgeRootLower D F*wedgeRootUpper D F := by ring
      _ = _ := by rw [hs,hp];dsimp only [height,wedgeLeading];ring
  have hh := height_pos (show D<0 by linarith) hF
  have hprodpos : 0 < (1-wedgeRootLower D F)*(1-wedgeRootUpper D F) := by
    apply (mul_pos_iff_of_pos_left hχ).mp
    simpa only [←mul_assoc,hcenter] using hh
  have hlo : 1-wedgeRootLower D F < 0 :=
    ((mul_pos_iff.mp hprodpos).resolve_left (fun h => by linarith [h.2])).1
  linarith

theorem real_bank_between_roots {D F t : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (ht : height D F < t) (hz : z.im=0)
    (he : logPotential D F z=(t : ℂ)) :
    wedgeRootLower D F < Real.exp z.re ∧ Real.exp z.re < wedgeRootUpper D F := by
  have hf := logPotential_root_factor hD hF hDF z
  rw [he,show z=(z.re : ℂ) from Complex.ext rfl hz] at hf
  have hfr := congrArg Complex.re hf
  simp only [Complex.sub_re,Complex.ofReal_re,←Complex.ofReal_mul,←Complex.ofReal_exp,
    ←Complex.ofReal_sub] at hfr
  have hpos : 0 < wedgeLeading D F*Real.exp ((2*F-2)*z.re) :=
    mul_pos (wedge_coefficients_pos hD hF).1 (Real.exp_pos _)
  have hn : (Real.exp z.re-wedgeRootLower D F)*(Real.exp z.re-wedgeRootUpper D F)<0 := by
    apply (mul_lt_mul_left hpos).mp
    rw [mul_zero]
    have : (wedgeLeading D F*Real.exp ((2*F-2)*z.re))*
        ((Real.exp z.re-wedgeRootLower D F)*(Real.exp z.re-wedgeRootUpper D F))=height D F-t := by
      simpa only [mul_assoc] using hfr.symm
    rw [this]
    linarith
  have huv := (wedge_roots_pos_order hD hF hDF).2
  rcases mul_neg_iff.mp hn with h | h
  · exact ⟨by linarith [h.1],by linarith [h.2]⟩
  · exfalso
    linarith [h.1,h.2]

end LeanVerification.WedgeFullCompletion
