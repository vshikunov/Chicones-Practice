import LeanVerification.WedgeFullCompletion.PhysicalDomains
import LeanVerification.MiddleStripCompletion.PhysicalBankGlobal

/-! The actual turning branches select the two global inverse sheets.
The logarithmic intervals and the source-side bank orientation are proved
from the original Loud force. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion
set_option maxHeartbeats 1500000

def wedgeSaddleLog (D : ℝ) : ℝ := Real.log (D/(D+1))

theorem wedgeSaddleLog_pos {D : ℝ} (hD : D < -1) : 0 < wedgeSaddleLog D :=
  Real.log_pos (extra_root_gt_one_of_lt_neg_one D hD)

theorem central_exp_of_lt_saddle {D t : ℝ} (hD : D < -1) (ht : t < wedgeSaddleLog D) :
    inCentralInterval D (Real.exp t) := by
  apply (inCentralInterval_iff_of_lt_neg_one D _ hD).2
  refine ⟨Real.exp_pos _, ?_⟩
  have h := Real.exp_lt_exp.mpr ht
  rwa [wedgeSaddleLog, Real.exp_log (lt_trans zero_lt_one
    (extra_root_gt_one_of_lt_neg_one D hD))] at h

theorem wedge_log_slope_pos {D F t : ℝ} (hD : D < -1)
    (ht : 0 < t) (htu : t < wedgeSaddleLog D) :
    0 < (logPotentialSlope D F (t : ℂ)).re := by
  rw [logPotentialSlope_real]
  simp only [Complex.ofReal_re]
  exact mul_pos (mul_pos (Real.exp_pos _) (sub_pos.mpr (Real.one_lt_exp_iff.mpr ht)))
    (central_exp_of_lt_saddle hD htu).2

theorem wedge_log_slope_neg {D F t : ℝ} (hD : D < -1) (ht : t < 0) :
    (logPotentialSlope D F (t : ℂ)).re < 0 := by
  rw [logPotentialSlope_real]
  simp only [Complex.ofReal_re]
  exact mul_neg_of_neg_of_pos
    (mul_neg_of_pos_of_neg (Real.exp_pos _) (sub_neg.mpr (Real.exp_lt_one_iff.mpr ht)))
    (central_exp_of_lt_saddle hD (ht.trans (wedgeSaddleLog_pos hD))).2

theorem wedgeRadius_gt_one {D F : ℝ} (hD : D < -1) (hF : 3/2 < F) :
    1 < wedgeRadius D F := by
  have hp := wedge_coefficients_pos hD hF
  have h0 : F ≠ 0 := by linarith
  have h1 : F-1 ≠ 0 := by linarith
  have h2 : 2*F-2 ≠ 0 := by linarith
  have he : trailing D F-wedgeLeading D F=(F-D-1)/(2*F*(F-1)) := by
    dsimp [trailing,wedgeLeading,leading]
    field_simp
    <;> ring
  have hg : 0 < trailing D F-wedgeLeading D F := by
    rw [he]
    exact div_pos (by linarith) (mul_pos (by linarith) (by linarith))
  have hs := wedgeRadius_square hD hF
  have hr := wedgeRadius_pos hD hF
  by_contra hn
  have hr1 : wedgeRadius D F ≤ 1 := le_of_not_gt hn
  have hsq : (wedgeRadius D F)^2 ≤ 1 := by nlinarith
  have hc := mul_le_mul_of_nonneg_left hsq hp.1.le
  rw [hs, mul_one] at hc
  linarith

theorem wedgeLogRadius_pos {D F : ℝ} (hD : D < -1) (hF : 3/2 < F) :
    0 < wedgeLogRadius D F := Real.log_pos (wedgeRadius_gt_one hD hF)

theorem wedge_right_local_orientation {D F t : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (ht : 0 < t) (htu : t < wedgeSaddleLog D) :
    ∀ᶠ z : ℂ in 𝓝 (t : ℂ),
      (0 < (logPotential D F z).im ↔ 0 < z.im) ∧ z.im < wedgeFirstAngle F := by
  have hp : 0 < transverseFactor D F (t : ℂ) := by
    rw [transverseFactor_real D F t hF]
    exact wedge_log_slope_pos hD ht htu
  have hlim := (transverseFactor_continuous D F).continuousAt.eventually (Ioi_mem_nhds hp)
  have hlt : (t : ℂ).im < wedgeFirstAngle F := (wedge_angles hF).1
  filter_upwards [hlim,Complex.continuous_im.continuousAt.eventually (Iio_mem_nhds hlt)] with z hz hi
  rw [logPotential_im_factorization]
  exact ⟨mul_pos_iff_of_pos_right hz,hi⟩

theorem wedge_left_local_orientation {D F t : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (ht : t < 0) :
    ∀ᶠ z : ℂ in 𝓝 (t : ℂ),
      (0 < (logPotential D F z).im ↔ z.im < 0) ∧
        -wedgeFirstAngle F < z.im ∧ z.re < wedgeLogRadius D F := by
  have hp : transverseFactor D F (t : ℂ) < 0 := by
    rw [transverseFactor_real D F t hF]
    exact wedge_log_slope_neg hD ht
  have hlim := (transverseFactor_continuous D F).continuousAt.eventually (Iio_mem_nhds hp)
  have hlt : -wedgeFirstAngle F < (t : ℂ).im := by
    simpa only [Complex.ofReal_im] using neg_lt_zero.mpr (wedge_angles hF).1
  have hrt : (t : ℂ).re < wedgeLogRadius D F := ht.trans (wedgeLogRadius_pos hD hF)
  filter_upwards [hlim,Complex.continuous_im.continuousAt.eventually (Ioi_mem_nhds hlt),
    Complex.continuous_re.continuousAt.eventually (Iio_mem_nhds hrt)] with z hz hi hr
  rw [logPotential_im_factorization]
  refine ⟨?_,hi,hr⟩
  constructor
  · intro hh
    exact ((mul_pos_iff.mp hh).resolve_left (fun h => (not_lt.mpr hz.le) h.2)).1
  · intro hh
    exact mul_pos_of_neg_of_neg hh hz

theorem actual_right_inverse_at_bank {D F t : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (ht : 0 < t) (htu : t < wedgeSaddleLog D) :
    ∃ g : ℂ → ℂ, AnalyticOnNhd ℂ g upperEnergy ∧ MapsTo g upperEnergy (rightDomain D F) ∧
      (∀ z ∈ upperEnergy,logPotential D F (g z)=z) ∧
      Tendsto g (𝓝[upperEnergy] (logPotential D F (t : ℂ))) (𝓝 (t : ℂ)) := by
  have hn : logPotentialSlope D F (t : ℂ) ≠ 0 := by
    intro he
    have hp := wedge_log_slope_pos (F := F) hD ht htu
    rw [he] at hp
    exact (lt_irrefl 0) hp
  apply global_inverse_anchored_at_real_bank (rightDomain_open hD hF hDF)
    (fun _ hz => hz.2) ((analyticOnNhd_logPotential D F hF).mono (subset_univ _))
    (fun _ hz => rightDomain_deriv_ne_zero hD hF hDF hz)
    (proper_rightDomain hD hF) (hasStrictDerivAt_logPotential D F hF _) hn
    (logPotential_real_bank D F rfl)
  filter_upwards [wedge_right_local_orientation hD hF ht htu] with z hz
  intro hu
  exact ⟨⟨(hz.1.mp hu).le,(hz.2.trans (wedge_angles hF).2.1).le,Or.inl hz.2.le⟩,hu⟩

theorem actual_left_inverse_at_bank {D F t : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) (ht : t < 0) :
    ∃ g : ℂ → ℂ, AnalyticOnNhd ℂ g upperEnergy ∧ MapsTo g upperEnergy (leftDomain D F) ∧
      (∀ z ∈ upperEnergy,logPotential D F (g z)=z) ∧
      Tendsto g (𝓝[upperEnergy] (logPotential D F (t : ℂ))) (𝓝 (t : ℂ)) := by
  have hn : logPotentialSlope D F (t : ℂ) ≠ 0 := by
    intro he
    have hp := wedge_log_slope_neg (F := F) hD ht
    rw [he] at hp
    exact (lt_irrefl 0) hp
  apply global_inverse_anchored_at_real_bank (leftDomain_open hD hF hDF)
    (fun _ hz => hz.2) ((analyticOnNhd_logPotential D F hF).mono (subset_univ _))
    (fun _ hz => leftDomain_deriv_ne_zero hD hF hDF hz)
    (proper_leftDomain hD hF) (hasStrictDerivAt_logPotential D F hF _) hn
    (logPotential_real_bank D F rfl)
  filter_upwards [wedge_left_local_orientation hD hF ht] with z hz
  intro hu
  have hz0 := hz.1.mp hu
  obtain ⟨ha,hab,hbc,hcd,hd⟩ := wedge_angles hF
  refine ⟨?_,hu⟩
  change 0 ≤ (star z : ℂ).im ∧ (star z : ℂ).im ≤ wedgeZeroAngle F ∧
    (wedgeFirstAngle F ≤ (star z : ℂ).im ∨ (star z : ℂ).re ≤ wedgeLogRadius D F) ∧
    ((star z : ℂ).im ≤ 2*wedgeFirstAngle F ∨ wedgeLogRadius D F ≤ (star z : ℂ).re)
  simp only [Complex.star_def,Complex.conj_im,Complex.conj_re]
  exact ⟨by linarith,by linarith [hz.2.1],Or.inr hz.2.2.le,Or.inl (by linarith [hz.2.1])⟩

end LeanVerification.WedgeFullCompletion
