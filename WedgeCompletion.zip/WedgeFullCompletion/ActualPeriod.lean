import LeanVerification.WedgeFullCompletion.CutData
import LeanVerification.MiddleStripSpectral.ActualPeriod
import LeanVerification.SlitPrincipalParts

/-! Complete Cauchy identities and all spectral energy derivatives of
the actual original-time physical period in the open resolvent wedge. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral
set_option maxHeartbeats 1800000

namespace ActualWedgePair
variable {D F : ℝ} (b : ActualWedgePair D F)

theorem actual_width_cauchy_identity (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {z : ℂ} (hz : z ∈ SlitContour.domain (height D F)) :
    wedgeSlitWidth F b.right b.left z=(1/(Real.pi : ℂ))*
      ∫ t in Ioi (height D F),(b.cutDensity t : ℂ)/
        ((Real.sqrt t : ℂ)*((t : ℂ)-z)) := by
  obtain ⟨d,hK,hW,he⟩ := b.exists_physical_cut_data hD hF hDF
  rw [d.complex_width_density_representation hz,hK]
  simp only [Complex.ofReal_zero,zero_add]
  congr 1
  apply integral_congr_ae
  filter_upwards [he] with t ht
  rw [ht]

theorem actual_period_kernel_integrable (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {h β : ℝ} (hh : h < height D F) (hβ : 3/2 ≤ β) :
    IntegrableOn (fun t => b.cutDensity t*(t-h)^(-β)) (Ioi (height D F)) := by
  obtain ⟨d,hK,hW,he⟩ := b.exists_physical_cut_data hD hF hDF
  apply (physical_cut_kernel_integrable d hh hβ).congr
  filter_upwards [he] with t ht
  rw [ht]

theorem actual_physical_period_identity (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {h : ℝ} (hh : AdmissibleEnergy D F h) :
    periodQuadrature D F h=(1/Real.sqrt 2)*
      ∫ t in Ioi (height D F),b.cutDensity t*(t-h)^(-(3 : ℝ)/2) := by
  obtain ⟨d,hK,hW,he⟩ := b.exists_physical_cut_data hD hF hDF
  rw [physical_cauchy_period d hh ((wedge_admissibleEnergy_iff hD hF hDF).mp hh).2 hW,hK]
  simp only [mul_zero,zero_div,zero_add]
  congr 1
  apply integral_congr_ae
  filter_upwards [he] with t ht
  rw [ht]

theorem actual_physical_period_derivatives (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {h : ℝ} (hh : AdmissibleEnergy D F h) {k : ℕ} (hk : 0 < k) :
    iteratedDeriv k (periodQuadrature D F) h=Cauchy.risingFactor ((3 : ℝ)/2) k/Real.sqrt 2*
      ∫ t in Ioi (height D F),b.cutDensity t*(t-h)^(-((3 : ℝ)/2+k)) := by
  obtain ⟨d,hK,hW,he⟩ := b.exists_physical_cut_data hD hF hDF
  rw [physical_period_spectral_derivatives d hh ((wedge_admissibleEnergy_iff hD hF hDF).mp hh).2 hW hk]
  congr 1
  apply integral_congr_ae
  filter_upwards [he] with t ht
  rw [ht]

theorem actual_cut_residue_zero (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F ≤ t) :
    Tendsto (fun z : ℂ => (z-(t : ℂ))*wedgeSlitWidth F b.right b.left z)
      (𝓝[SlitContour.domain (height D F)] (t : ℂ)) (𝓝 0) := by
  have hH := height_pos (show D < 0 by linarith) hF
  have hg := wedge_upperWidth_germs_below_height hD hF hDF
    b.right_analytic b.left_analytic b.right_maps b.left_maps b.right_inverse b.left_inverse
    (fun _ hh => b.right_annulus hD hF hh) (fun _ hh => b.left_annulus hF hh)
  obtain ⟨r,hr,M,hM,hb⟩ := wedgeSlitWidth_finite_bound hD hF (hH.trans_le ht)
    b.right_inverse b.left_inverse hg
  refine SlitContour.boundary_growth_residue_zero (β:=0) (M:=M) ?_ hr zero_lt_one ?_
  · simpa only [SlitContour.domain,mem_setOf_eq,Complex.ofReal_re,Complex.ofReal_im,
      ne_eq,not_true_eq_false,or_false,not_lt] using ht
  · intro z hz hd
    simpa only [neg_zero,Real.rpow_zero,mul_one] using hb z hz hd

end ActualWedgePair

theorem exists_actual_wedge_physical_spectral_formula {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    ∃ ν : ℝ → ℝ,
      AEStronglyMeasurable ν (volume.restrict (Ioi (height D F))) ∧
      (∀ h β : ℝ,h < height D F → 3/2 ≤ β →
        IntegrableOn (fun t => ν t*(t-h)^(-β)) (Ioi (height D F))) ∧
      (∀ h,AdmissibleEnergy D F h →
        periodQuadrature D F h=(1/Real.sqrt 2)*
          ∫ t in Ioi (height D F),ν t*(t-h)^(-(3 : ℝ)/2)) ∧
      (∀ h,AdmissibleEnergy D F h → ∀ k : ℕ,0 < k →
        iteratedDeriv k (periodQuadrature D F) h=Cauchy.risingFactor ((3 : ℝ)/2) k/Real.sqrt 2*
          ∫ t in Ioi (height D F),ν t*(t-h)^(-((3 : ℝ)/2+k))) := by
  obtain ⟨b⟩ := actualWedgePair_nonempty hD hF hDF
  obtain ⟨d,hK,hW,he⟩ := b.exists_physical_cut_data hD hF hDF
  exact ⟨b.cutDensity,d.aestronglyMeasurable_density.congr he,
    fun h β hh hβ => b.actual_period_kernel_integrable hD hF hDF hh hβ,
    fun h hh => b.actual_physical_period_identity hD hF hDF hh,
    fun h hh k hk => b.actual_physical_period_derivatives hD hF hDF hh hk⟩

end LeanVerification.WedgeFullCompletion
