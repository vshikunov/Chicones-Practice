import LeanVerification.MiddleStripCompletion.Growth
import LeanVerification.MiddleStripCompletion.PhysicalSeeds

/-!
# Actual coefficients and logarithmic growth in the open resolvent wedge

The entire logarithmic potential is the same original-time potential used
in the existing physical-width construction.  Here its leading coefficient
is negative.  All coefficient and growth bounds are proved from the actual
parameters; none is an additional regional hypothesis.
-/

noncomputable section
open Set Filter
open scoped Topology

namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion

set_option maxHeartbeats 1200000

def wedgeLeading (D F : ℝ) : ℝ := -leading D F
def wedgeRadius (D F : ℝ) : ℝ := Real.sqrt (trailing D F / wedgeLeading D F)
def wedgeLogRadius (D F : ℝ) : ℝ := Real.log (wedgeRadius D F)
def wedgeFirstAngle (F : ℝ) : ℝ := Real.pi/(2*F-1)
def wedgeRightAngle (F : ℝ) : ℝ := 2*Real.pi/(2*F)
def wedgeZeroAngle (F : ℝ) : ℝ := 3*Real.pi/(2*F)

theorem wedge_coefficients_pos {D F : ℝ} (hD : D < -1) (hF : 3/2 < F) :
    0 < wedgeLeading D F ∧ 0 < middle D F ∧ 0 < trailing D F := by
  dsimp [wedgeLeading, leading, middle, trailing]
  exact ⟨neg_pos.mpr (div_neg_of_neg_of_pos (by linarith) (by linarith)),
    div_pos (by linarith) (by linarith), div_pos (by linarith) (by linarith)⟩

theorem wedge_discriminant_identity {D F : ℝ} (hF : 3/2 < F) :
    (middle D F)^2-4*wedgeLeading D F*trailing D F =
      (D+F)*(F-D-1)/(F*(F-1)*(2*F-1)^2) := by
  have h0 : F ≠ 0 := by linarith
  have h1 : F-1 ≠ 0 := by linarith
  have h2 : 2*F-1 ≠ 0 := by linarith
  have h3 : 2*F-2 ≠ 0 := by linarith
  dsimp [wedgeLeading, leading, middle, trailing]
  field_simp
  <;> ring

theorem wedge_discriminant_pos {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    0 < (middle D F)^2-4*wedgeLeading D F*trailing D F := by
  rw [wedge_discriminant_identity hF]
  exact div_pos (mul_pos (by linarith) (by linarith))
    (mul_pos (mul_pos (by linarith) (by linarith)) (sq_pos_of_pos (by linarith)))

theorem wedgeRadius_pos {D F : ℝ} (hD : D < -1) (hF : 3/2 < F) :
    0 < wedgeRadius D F :=
  Real.sqrt_pos.mpr (div_pos (wedge_coefficients_pos hD hF).2.2
    (wedge_coefficients_pos hD hF).1)

theorem wedgeRadius_square {D F : ℝ} (hD : D < -1) (hF : 3/2 < F) :
    wedgeLeading D F*(wedgeRadius D F)^2=trailing D F := by
  have hp := wedge_coefficients_pos hD hF
  rw [wedgeRadius, Real.sq_sqrt (div_pos hp.2.2 hp.1).le]
  exact mul_div_cancel₀ _ hp.1.ne'

theorem wedgeRadius_middle_gap {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    2*trailing D F < middle D F*wedgeRadius D F := by
  have hp := wedge_coefficients_pos hD hF
  have hr := wedgeRadius_pos hD hF
  have hs := wedgeRadius_square hD hF
  have hd := wedge_discriminant_pos hD hF hDF
  have hh := mul_pos hd (sq_pos_of_pos hr)
  have he : (middle D F*wedgeRadius D F)^2-(2*trailing D F)^2 =
      ((middle D F)^2-4*wedgeLeading D F*trailing D F)*(wedgeRadius D F)^2 := by
    calc
      _ = (middle D F)^2*(wedgeRadius D F)^2-
          4*trailing D F*(wedgeLeading D F*(wedgeRadius D F)^2) := by rw [hs]; ring
      _ = _ := by ring
  have hsq : (2*trailing D F)^2 < (middle D F*wedgeRadius D F)^2 := by
    rw [←he] at hh
    linarith only [hh]
  have hm := mul_pos hp.2.1 hr
  nlinarith only [hsq, hp.2.2, hm]

theorem exp_wedgeLogRadius {D F : ℝ} (hD : D < -1) (hF : 3/2 < F) :
    Real.exp (wedgeLogRadius D F)=wedgeRadius D F :=
  Real.exp_log (wedgeRadius_pos hD hF)

theorem wedge_angles {F : ℝ} (hF : 3/2 < F) :
    0 < wedgeFirstAngle F ∧ wedgeFirstAngle F < wedgeRightAngle F ∧
      wedgeRightAngle F < 2*wedgeFirstAngle F ∧
      2*wedgeFirstAngle F < wedgeZeroAngle F ∧ wedgeZeroAngle F < Real.pi := by
  have h0 : 0 < 2*F := by linarith
  have h1 : 0 < 2*F-1 := by linarith
  have hpi := Real.pi_pos
  dsimp [wedgeFirstAngle, wedgeRightAngle, wedgeZeroAngle]
  constructor
  · exact div_pos hpi h1
  constructor
  · apply (div_lt_div_iff₀ h1 h0).2
    nlinarith
  constructor
  · rw [←mul_div_assoc]
    apply (div_lt_div_iff₀ h0 h1).2
    nlinarith
  constructor
  · rw [←mul_div_assoc]
    apply (div_lt_div_iff₀ h1 h0).2
    nlinarith
  · apply (div_lt_iff₀ h0).2
    nlinarith

theorem wedge_logPotentialSlope_ne_zero {D F : ℝ} (hD : D < -1) {z : ℂ}
    (hlo : -Real.pi < z.im) (hhi : z.im < Real.pi) (hn : z.im ≠ 0) :
    logPotentialSlope D F z ≠ 0 := by
  have hi := exp_im_ne_zero hlo hhi hn
  apply mul_ne_zero (mul_ne_zero (Complex.exp_ne_zero _) ?_) ?_
  · intro he
    have hh := congrArg Complex.im he
    apply hi
    simpa using hh
  · intro he
    have hh := congrArg Complex.im he
    simp only [Complex.sub_im, Complex.mul_im, Complex.ofReal_im, Complex.ofReal_re,
      zero_mul, add_zero, sub_zero, Complex.zero_im] at hh
    exact mul_ne_zero (show D+1 ≠ 0 by linarith) hi hh

/-- Uniform growth uses the absolute value of the actual negative leading
coefficient and is uniform in the imaginary logarithmic coordinate. -/
theorem wedge_uniform_logPotential_atTop {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (M : ℝ) :
    ∃ b : ℝ, ∀ z : ℂ, b ≤ z.re → M < ‖logPotential D F z‖ := by
  have hA := (wedge_coefficients_pos hD hF).1
  obtain ⟨b₀,hb₀⟩ := eventually_atTop.mp
    ((infinityEndBound_tendsto_zero D F hF).eventually (Iio_mem_nhds (half_pos hA)))
  have hexp : Tendsto (fun t : ℝ => (wedgeLeading D F/2)*Real.exp ((2*F)*t))
      atTop atTop :=
    (Real.tendsto_exp_atTop.comp
      ((tendsto_const_mul_atTop_of_pos (show 0 < 2*F by linarith)).mpr tendsto_id)).const_mul_atTop
        (half_pos hA)
  obtain ⟨b₁,hb₁⟩ := eventually_atTop.mp (hexp.eventually (eventually_gt_atTop M))
  refine ⟨max b₀ b₁,fun z hz => ?_⟩
  have herr : ‖infinityResidual D F z‖ < wedgeLeading D F/2 :=
    (norm_infinityResidual_le D F z).trans_lt (hb₀ z.re ((le_max_left _ _).trans hz))
  have hnorm : wedgeLeading D F ≤ ‖(leading D F : ℂ)+infinityResidual D F z‖+
      ‖infinityResidual D F z‖ := by
    calc
      _ = ‖((leading D F : ℂ)+infinityResidual D F z)-infinityResidual D F z‖ := by
        simp only [add_sub_cancel_right, Complex.norm_real, Real.norm_eq_abs]
        rw [abs_of_neg (show leading D F < 0 by simpa [wedgeLeading] using hA)]
        rfl
      _ ≤ _ := norm_sub_le _ _
  have hhalf : wedgeLeading D F/2 ≤ ‖(leading D F : ℂ)+infinityResidual D F z‖ := by linarith
  have hbound := mul_le_mul_of_nonneg_left hhalf (Real.exp_pos ((2*F)*z.re)).le
  rw [logPotential_infinity_factorization, norm_mul, norm_scaled_exp]
  exact (hb₁ z.re ((le_max_right _ _).trans hz)).trans_le (by simpa only [mul_comm] using hbound)

end LeanVerification.WedgeFullCompletion
