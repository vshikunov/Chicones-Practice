import LeanVerification.WedgeFullCompletion.PoleExhaustion
import LeanVerification.WedgeIntegralCompletion.ComplexResolventComparison

/-! The actual upper horizontal ray lies in the proved resolvent cone,
including the internal seam F = 2. -/

noncomputable section
open Set
namespace LeanVerification.WedgeFullCompletion
open WedgeIntegralCompletion
set_option maxHeartbeats 1400000

def wedgeResolventPhase (F : ℝ) : ℂ :=
  -Complex.exp (-(wedgeContourAngle F : ℂ)*Complex.I)

theorem wedgeResolventPhase_eq_exp (F : ℝ) :
    wedgeResolventPhase F=Complex.exp (((Real.pi-wedgeContourAngle F : ℝ) : ℂ)*Complex.I) := by
  dsimp only [wedgeResolventPhase]
  calc
    _ = Complex.exp (-(wedgeContourAngle F : ℂ)*Complex.I+(Real.pi : ℂ)*Complex.I) :=
      (Complex.exp_add_pi_mul_I _).symm
    _ = _ := by congr 1;push_cast;ring

theorem wedgeResolventPhase_ne_zero (F : ℝ) : wedgeResolventPhase F ≠ 0 :=
  neg_ne_zero.mpr (Complex.exp_ne_zero _)

theorem wedgeResolventPhase_re (F : ℝ) :
    (wedgeResolventPhase F).re=Real.cos (Real.pi-wedgeContourAngle F) := by
  rw [wedgeResolventPhase_eq_exp,Complex.exp_re]
  simp only [Complex.mul_re,Complex.mul_im,Complex.ofReal_re,Complex.ofReal_im,
    Complex.I_re,Complex.I_im,mul_zero,zero_mul,sub_self,Real.exp_zero,one_mul,
    mul_one,add_zero]

theorem wedgeResolventPhase_im (F : ℝ) :
    (wedgeResolventPhase F).im=Real.sin (Real.pi-wedgeContourAngle F) := by
  rw [wedgeResolventPhase_eq_exp,Complex.exp_im]
  simp only [Complex.mul_re,Complex.mul_im,Complex.ofReal_re,Complex.ofReal_im,
    Complex.I_re,Complex.I_im,mul_zero,zero_mul,sub_self,Real.exp_zero,one_mul,
    mul_one,add_zero]

theorem wedgeResolventPhase_allowed {F : ℝ} (hF : 3/2 < F) (hFu : F < 4) :
    AllowedQuadraticAngle F (wedgeResolventPhase F) := by
  have hF0 : 0 < F := by linarith
  have hπ := Real.pi_pos
  have hθ0 := wedgeContourAngle_pos hF
  by_cases h2 : 2 ≤ F
  · left
    refine ⟨h2,?_⟩
    rw [wedgeResolventPhase_re]
    apply Real.cos_nonneg_of_mem_Icc
    have hθπ : wedgeContourAngle F ≤ Real.pi := by
      apply (div_le_iff₀ hF0).2
      nlinarith
    have hθhalf : Real.pi/2 < wedgeContourAngle F := by
      apply (lt_div_iff₀ hF0).2
      nlinarith
    constructor <;> linarith
  · have hF2 : F ≤ 2 := le_of_not_ge h2
    have hθπ : Real.pi ≤ wedgeContourAngle F := by
      apply (le_div_iff₀ hF0).2
      nlinarith
    right
    refine ⟨hF.le,hF2,?_,?_⟩
    · rw [wedgeResolventPhase_re]
      apply Real.cos_pos_of_mem_Ioo
      have hθmax : wedgeContourAngle F < 4*Real.pi/3 := by
        apply (div_lt_iff₀ hF0).2
        nlinarith
      constructor <;> linarith
    · rw [wedgeResolventPhase_re,wedgeResolventPhase_im]
      have hθmax : wedgeContourAngle F ≤ 4*Real.pi/3 := by
        apply (div_le_iff₀ hF0).2
        nlinarith
      have hs := Real.sin_le_sin_of_le_of_le_pi_div_two
        (x:=wedgeContourAngle F-Real.pi) (y:=Real.pi/3)
        (by linarith) (by linarith) (by linarith)
      have hc := Real.cos_le_cos_of_nonneg_of_le_pi
        (x:=wedgeContourAngle F-Real.pi) (y:=Real.pi/3)
        (by linarith) (by linarith) (by linarith)
      have hsn := Real.sin_nonneg_of_mem_Icc
        (show wedgeContourAngle F-Real.pi ∈ Icc 0 Real.pi by constructor <;> linarith)
      rw [Real.sin_pi_div_three] at hs
      rw [Real.cos_pi_div_three] at hc
      rw [show Real.pi-wedgeContourAngle F= -(wedgeContourAngle F-Real.pi) by ring,
        Real.sin_neg,abs_neg,abs_of_nonneg hsn,Real.cos_neg]
      have hmul := mul_le_mul_of_nonneg_left hc (Real.sqrt_nonneg 3)
      linarith

end LeanVerification.WedgeFullCompletion
