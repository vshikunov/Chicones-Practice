import LeanVerification.WedgeFullCompletion.CutDensityPhysical
import LeanVerification.WedgeIntegralCompletion.WedgeWidthDecay
import LeanVerification.Loud.PhysicalSpectralZeros

/-! Complete cut data for the actual physical width, including both finite
exceptional energies, all bank limits, zero infinity constant, and proved
decay. Finite endpoint boundedness excludes width poles and point masses. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral WedgeIntegralCompletion
set_option maxHeartbeats 2000000

namespace ActualWedgePair
variable {D F : ℝ} (b : ActualWedgePair D F)

theorem exists_physical_cut_data (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    ∃ d : SlitContour.PhysicalCutData (wedgeSlitWidth F b.right b.left) (height D F),
      d.constant=0 ∧
      EqOn d.physicalWidth (physicalEnergyWidth D F) (Ioo 0 (height D F)) ∧
      d.density =ᵐ[volume.restrict (Ioi (height D F))] b.cutDensity := by
  have hH := height_pos (show D < 0 by linarith) hF
  have hHs := wedge_height_lt_saddle hD hF hDF
  have hFp : 0 < F := by linarith
  have hlp := fun h hh => b.right_annulus hD hF (h:=h) hh
  have hlm := fun h hh => b.left_annulus hF (h:=h) hh
  have hg := wedge_upperWidth_germs_below_height hD hF hDF
    b.right_analytic b.left_analytic b.right_maps b.left_maps b.right_inverse b.left_inverse hlp hlm
  let c : Fin 2 → ℝ := fun j => if j=0 then height D F else wedgeSaddleHeight D F
  have hcp : ∀ j : Fin 2,0 < c j := by
    intro j
    dsimp only [c]
    split_ifs
    · exact hH
    · exact hH.trans hHs
  have hcn : ∀ t : ℝ,t ∉ range c → t ≠ wedgeSaddleHeight D F := by
    intro t ht he
    apply ht
    exact ⟨1,by simp [c,he]⟩
  have hbank (t : ℝ) (ht : height D F < t) (hn : t ∉ range c) :
      Tendsto (upperNormalizedWidth F b.right b.left) (𝓝[upperEnergy] (t : ℂ))
        (𝓝 (upperBank (upperNormalizedWidth F b.right b.left) t)) := by
    have hl := b.upper_width_cut_limit hD hF hDF ht (hcn t hn)
    rwa [upperBank_eq_of_tendsto hl]
  obtain ⟨R,hR,hd⟩ := actual_wedge_upperWidth_uniform_decay hD hF hDF
    b.right_analytic.continuousOn b.left_analytic.continuousOn
    b.right_maps b.left_maps b.right_inverse b.left_inverse
  have hd' : ∀ z ∈ upperEnergy,R ≤ ‖z‖ →
      ‖upperNormalizedWidth F b.right b.left z-(0 : ℂ)‖ ≤
        (2*wedgeHalfRatioDecayBound D F/F)*‖z‖^(-(1/(2*F))) := by simpa using hd
  have hdec := reflectedUpper_decay_bound hR hg hd'
  have hC : 0 ≤ 2*wedgeHalfRatioDecayBound D F/F :=
    div_nonneg (mul_nonneg (by norm_num) (wedgeHalfRatioDecayBound_nonneg hD hF)) hFp.le
  let d : SlitContour.PhysicalCutData (wedgeSlitWidth F b.right b.left) (height D F) := {
    height_pos := hH
    count := 2
    cutpoint := c
    exponent := fun _ => 0
    endpoint := ⟨0,by simp [c]⟩
    cutpoint_ge := fun j => by dsimp only [c];split_ifs;exact le_rfl;exact hHs.le
    exponent_nonneg := fun _ => le_rfl
    exponent_lt_one := fun _ => zero_lt_one
    holomorphic := (wedgeSlitWidth_analytic hD hF hDF b.right_analytic b.left_analytic
      b.right_maps b.left_maps b.right_inverse b.left_inverse hlp hlm).differentiableOn
    real_below := wedgeSlitWidth_real_below hD hF hDF b.right_analytic b.left_analytic
      b.right_maps b.left_maps b.right_inverse b.left_inverse hlp hlm
    upper := upperBank (upperNormalizedWidth F b.right b.left)
    lower := fun t => star (upperBank (upperNormalizedWidth F b.right b.left) t)
    upper_limit := fun t ht hn => reflectedUpper_upper_limit (hbank t ht hn)
    lower_limit := fun t ht hn => reflectedUpper_lower_limit (hbank t ht hn)
    local_growth := fun j => by
      obtain ⟨r,hr,M,hM,hb⟩ := wedgeSlitWidth_finite_bound hD hF (hcp j)
        b.right_inverse b.left_inverse hg
      exact ⟨r,hr,M,hM,fun z hz hd => by
        simpa only [neg_zero,Real.rpow_zero,mul_one] using hb z hz hd⟩
    constant := 0
    decay_exponent := 1/(2*F)
    decay_pos := one_div_pos.mpr (by linarith)
    decay_bound := 2*wedgeHalfRatioDecayBound D F/F
    decay_bound_nonneg := hC
    decay_start := R+1
    decay := hdec }
  refine ⟨d,rfl,?_,?_⟩
  · intro h hh
    have had := (wedge_admissibleEnergy_iff hD hF hDF).mpr hh
    have hv := wedgeSlitWidth_physical_value hFp.ne' had (hlp h had) (hlm h had)
    change Real.sqrt h*(wedgeSlitWidth F b.right b.left (h : ℂ)).re=physicalEnergyWidth D F h
    rw [hv,Complex.ofReal_re]
    have hn := (Real.sqrt_pos.mpr hh.1).ne'
    field_simp
  · have hn : ∀ᵐ t : ℝ,t ≠ wedgeSaddleHeight D F := by
      rw [ae_iff]
      simpa using (measure_singleton (wedgeSaddleHeight D F) : volume {wedgeSaddleHeight D F}=0)
    filter_upwards [ae_restrict_mem measurableSet_Ioi,ae_restrict_of_ae hn] with t ht htn
    exact b.upper_width_cut_density hD hF hDF ht htn

end ActualWedgePair
end LeanVerification.WedgeFullCompletion
