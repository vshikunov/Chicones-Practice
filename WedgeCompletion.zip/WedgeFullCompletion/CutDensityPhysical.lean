import LeanVerification.WedgeFullCompletion.ResidueSign
import LeanVerification.WedgeFullCompletion.FiniteCutBounds

/-! Physical identification of the complete continuum density. The right
bank is proved real below the saddle; both cut limits use the same global
physical inverses as the annular width. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral ContourCompletion
set_option maxHeartbeats 2200000

theorem exists_wedge_right_real_preimage {D F t : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (ht : 0 < t) (hts : t < wedgeSaddleHeight D F) :
    ∃ s : ℝ,0 < s ∧ s < wedgeSaddleLog D ∧ logPotential D F (s : ℂ)=(t : ℂ) := by
  have hs := extra_root_gt_one_of_lt_neg_one D hD
  have hc : ContinuousOn (potential D F) (Icc 1 (D/(D+1))) := by
    intro w hw
    exact (hasDerivAt_potential D F w (by linarith [hw.1])).continuousAt.continuousWithinAt
  obtain ⟨w,hw,he⟩ := intermediate_value_Ioo hs.le hc
    (show t ∈ Ioo (potential D F 1) (potential D F (D/(D+1))) by
      rw [potential_one]
      exact ⟨ht,hts⟩)
  refine ⟨Real.log w,Real.log_pos hw.1,Real.log_lt_log (by linarith [hw.1]) hw.2,?_⟩
  rw [logPotential_real D F _ hF,Real.exp_log (by linarith [hw.1]),he]

namespace ActualWedgePair
variable {D F : ℝ} (b : ActualWedgePair D F)

theorem rightCutLog_real_below_saddle (hD : D < -1) (hF : 3/2 < F)
    {t : ℝ} (ht : 0 < t) (hts : t < wedgeSaddleHeight D F) :
    (b.rightCutLog t).im=0 ∧
      Tendsto b.right (𝓝[upperEnergy] (t : ℂ)) (𝓝 (b.rightCutLog t)) := by
  obtain ⟨s,hs,hss,he⟩ := exists_wedge_right_real_preimage hD hF ht hts
  have hl := b.right_banks s hs hss
  rw [he] at hl
  have heq : b.rightCutLog t=(s : ℂ) := upperBank_eq_of_tendsto hl
  rw [heq]
  exact ⟨rfl,hl⟩

theorem rightDensity_zero_below_saddle (hD : D < -1) (hF : 3/2 < F)
    {t : ℝ} (ht : 0 < t) (hts : t < wedgeSaddleHeight D F) : b.rightDensity t=0 := by
  have hi := (b.rightCutLog_real_below_saddle hD hF ht hts).1
  dsimp only [rightDensity]
  rw [Complex.exp_im]
  simp [Complex.mul_im,hi]

theorem cutDensity_eq_left_below_saddle (hD : D < -1) (hF : 3/2 < F)
    {t : ℝ} (ht : 0 < t) (hts : t < wedgeSaddleHeight D F) :
    b.cutDensity t=b.leftDensity t := by
  rw [b.cutDensity_eq_add,b.rightDensity_zero_below_saddle hD hF ht hts,zero_add]

theorem upper_width_cut_limit (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F < t) (hts : t ≠ wedgeSaddleHeight D F) :
    Tendsto (upperNormalizedWidth F b.right b.left) (𝓝[upperEnergy] (t : ℂ))
      (𝓝 ((Complex.exp ((F : ℂ)*upperBank b.right t)-
        Complex.exp ((F : ℂ)*upperBank b.left t))/((F*Real.sqrt t : ℝ) : ℂ))) := by
  have ht0 : 0 < t := (height_pos (by linarith) hF).trans ht
  have hp : Tendsto b.right (𝓝[upperEnergy] (t : ℂ)) (𝓝 (upperBank b.right t)) := by
    rcases lt_or_gt_of_ne hts with hlo | hhi
    · exact (b.rightCutLog_real_below_saddle hD hF ht0 hlo).2
    · exact (b.rightCutLog_spec hD hF hDF hhi).2.2.2.2
  have hm := tendsto_upperBank_of_germ (b.leftCutLog_spec hD hF hDF ht).2.2.2.1
  have hp' := Complex.continuous_exp.continuousAt.tendsto.comp (hp.const_mul (F : ℂ))
  have hm' := Complex.continuous_exp.continuousAt.tendsto.comp (hm.const_mul (F : ℂ))
  have hs : Tendsto principalSquareRoot (𝓝[upperEnergy] (t : ℂ)) (𝓝 (Real.sqrt t : ℂ)) := by
    rw [←principalSquareRoot_ofReal_pos ht0]
    exact (analyticAt_principalSquareRoot (Or.inl ht0)).continuousAt.tendsto.mono_left nhdsWithin_le_nhds
  have hFn : (F : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (by linarith)
  have hsn : (Real.sqrt t : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr ht0).ne'
  simpa only [upperNormalizedWidth,Complex.ofReal_mul] using
    (hp'.sub hm').div (hs.const_mul (F : ℂ)) (mul_ne_zero hFn hsn)

theorem upper_width_cut_density (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F < t) (hts : t ≠ wedgeSaddleHeight D F) :
    Real.sqrt t*(upperBank (upperNormalizedWidth F b.right b.left) t).im=b.cutDensity t := by
  have ht0 : 0 < t := (height_pos (by linarith) hF).trans ht
  rw [upperBank_eq_of_tendsto (b.upper_width_cut_limit hD hF hDF ht hts),
    Complex.div_ofReal_im,Complex.sub_im,cutDensity,Complex.add_im]
  have hc : Complex.exp ((F : ℂ)*b.leftCutLog t)=
      star (Complex.exp ((F : ℂ)*upperBank b.left t)) := by
    simp only [leftCutLog,Complex.star_def]
    rw [←Complex.exp_conj]
    congr 1
    simp only [map_mul,Complex.conj_ofReal]
  rw [hc]
  simp only [Complex.star_def,Complex.conj_im]
  simp only [rightCutLog]
  have hFn : F ≠ 0 := by linarith
  have hsn : Real.sqrt t ≠ 0 := (Real.sqrt_pos.mpr ht0).ne'
  field_simp
  <;> ring

theorem leftDensity_eq_exp_sin (t : ℝ) :
    b.leftDensity t=Real.exp (F*(b.leftCutLog t).re)/F*Real.sin (F*(b.leftCutLog t).im) := by
  rw [leftDensity,Complex.exp_im]
  simp only [Complex.mul_im,Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,
    zero_mul,add_zero,sub_zero]
  ring

theorem left_scaled_angle_bounds (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F < t) :
    0 < F*(b.leftCutLog t).im ∧ F*(b.leftCutLog t).im < 3*Real.pi/2 := by
  have hs := b.leftCutLog_strip hD hF hDF ht
  have ha := b.leftCutLog_angle_bounds hD hF hDF ht
  have hb := (lt_div_iff₀ (by linarith : 0<2*F)).mp ha.2
  exact ⟨mul_pos (by linarith) hs.1,by nlinarith only [hb]⟩

theorem left_scaled_angle_strictMonoOn (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    StrictMonoOn (fun t => F*(b.leftCutLog t).im) (Ioi (height D F)) := by
  intro x hx y hy hxy
  exact mul_lt_mul_of_pos_left (b.leftCutLog_angle_strictMonoOn hD hF hDF hx hy hxy) (by linarith)

end ActualWedgePair
end LeanVerification.WedgeFullCompletion
