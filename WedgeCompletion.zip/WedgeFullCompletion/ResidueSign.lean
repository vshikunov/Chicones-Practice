import LeanVerification.WedgeFullCompletion.RayBankIdentity
import LeanVerification.WedgeFullCompletion.ResolventAngle
import LeanVerification.WedgeFullCompletion.BankDerivatives

/-! The complete two-ray comparison forces a strictly positive derivative
of the actual physical cut density above the nonzero saddle. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion WedgeIntegralCompletion
set_option maxHeartbeats 2400000

namespace ActualWedgePair
variable {D F : ℝ} (b : ActualWedgePair D F)

theorem actual_residue_sum_im_pos (hD : D < -1) (hF : 3/2 < F)
    (hFu : F < 4) (hDF : -F < D) {t : ℝ} (ht : wedgeSaddleHeight D F < t) :
    0 < (wedgeResidueAt D F (b.rightCutLog t)+wedgeResidueAt D F (b.leftCutLog t)).im := by
  have hF0 : F ≠ 0 := by linarith
  have hR := wedgeRadius_pos hD hF
  have hC := (wedge_coefficients_pos hD hF).2.2
  have hE : 0 < (t-height D F)/wedgeEnergyScale D F :=
    div_pos (sub_pos.mpr ((wedge_height_lt_saddle hD hF hDF).trans ht))
      (wedgeEnergyScale_pos hD hF)
  have hcmp := full_quadratic_resolvent_integral_comparison hE
    (wedgeNormalizedMiddle_gt_two hD hF hDF).le (wedgeResolventPhase_allowed hF hFu)
    (wedgeResolventPhase_ne_zero F) (fun x hx => actual_normalized_real_resolvent_pos hD hF hDF ht hx)
  have hb := residue_horizontal_integral_ray_identity (D:=D) (F:=F) (t:=t) (y:=0) (by simp)
  simp only [Complex.ofReal_zero,zero_mul,add_zero,neg_zero,Complex.exp_zero] at hb
  have hu := residue_horizontal_integral_ray_identity (D:=D) (t:=t) (residue_contour_phase hF0)
  have hs (ζ : ℂ) := residueRayWeight_integral_scaling (E:=t-height D F) (F:=F)
    (A:=wedgeLeading D F) (B:=middle D F) ζ hR hC (wedgeRadius_square hD hF)
  have he := b.actual_residue_integral_identity hD hF hFu hDF ht
  rw [hb,hu,hs,hs] at he
  simp_rw [complexResolventWeight_negative_one] at he
  rw [integral_complex_ofReal] at he
  change -((wedgeResolventScale D F : ℂ)*
      ((∫ x in Ioi (0:ℝ),realResolventWeight ((t-height D F)/wedgeEnergyScale D F)
        (wedgeNormalizedMiddle D F) F x : ℝ) : ℂ))-
      -((wedgeResolventScale D F : ℂ)*
        ∫ x in Ioi (0:ℝ),complexResolventWeight ((t-height D F)/wedgeEnergyScale D F)
          (wedgeNormalizedMiddle D F) F (wedgeResolventPhase F) x)=_ at he
  have hre := congrArg Complex.re he
  simp only [Complex.sub_re,Complex.neg_re,Complex.mul_re,Complex.mul_im,
    Complex.ofReal_re,Complex.ofReal_im,Complex.I_re,Complex.I_im,
    Complex.ofReal_ofNat,mul_zero,zero_mul,sub_zero,zero_sub,add_zero,
    zero_add,mul_one] at hre
  norm_num at hre
  have hpos := mul_pos (wedgeResolventScale_pos hD hF) (sub_pos.mpr (hcmp.2.trans hcmp.1))
  simp only [Complex.add_im]
  nlinarith only [hre,hpos,Real.pi_pos]

def cutDensity (t : ℝ) : ℝ :=
  (Complex.exp ((F : ℂ)*b.rightCutLog t)+Complex.exp ((F : ℂ)*b.leftCutLog t)).im/F

def leftDensity (t : ℝ) : ℝ := (Complex.exp ((F : ℂ)*b.leftCutLog t)).im/F

def rightDensity (t : ℝ) : ℝ := (Complex.exp ((F : ℂ)*b.rightCutLog t)).im/F

theorem cutDensity_eq_add (t : ℝ) : b.cutDensity t=b.rightDensity t+b.leftDensity t := by
  simp only [cutDensity,leftDensity,rightDensity,Complex.add_im,add_div]

theorem cutDensity_hasDerivAt (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) :
    HasDerivAt b.cutDensity
      (wedgeResidueAt D F (b.rightCutLog t)+wedgeResidueAt D F (b.leftCutLog t)).im t := by
  have hF0 : F ≠ 0 := by linarith
  have hp := ((b.rightCutLog_hasDerivAt hD hF hDF ht).const_mul (F : ℂ)).cexp
  have hm := ((b.leftCutLog_hasDerivAt hD hF hDF
    ((wedge_height_lt_saddle hD hF hDF).trans ht)).const_mul (F : ℂ)).cexp
  have hd := (Complex.imCLM.hasFDerivAt.comp_hasDerivAt t (hp.add hm)).div_const F
  convert hd using 1
  simp only [wedgeResidueAt,Complex.imCLM_apply,div_eq_mul_inv,Complex.add_im,
    Complex.mul_im,Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,
    mul_zero,zero_mul,add_zero,zero_add,sub_zero]
  field_simp
  <;> ring

theorem cutDensity_strictMonoOn_above_saddle (hD : D < -1) (hF : 3/2 < F)
    (hFu : F < 4) (hDF : -F < D) :
    StrictMonoOn b.cutDensity (Ioi (wedgeSaddleHeight D F)) := by
  apply strictMonoOn_of_deriv_pos (convex_Ioi _)
  · intro t ht
    exact (b.cutDensity_hasDerivAt hD hF hDF ht).continuousAt.continuousWithinAt
  · intro t ht
    rw [(b.cutDensity_hasDerivAt hD hF hDF (interior_subset ht)).deriv]
    exact b.actual_residue_sum_im_pos hD hF hFu hDF (interior_subset ht)

theorem rightDensity_pos_above_saddle (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) : 0 < b.rightDensity t := by
  obtain ⟨hlo,hhi⟩ := b.rightCutLog_angle_bound hD hF hDF ht
  have hFp : 0 < F := by linarith
  have hx : 0 < F*(b.rightCutLog t).im := mul_pos hFp hlo
  have hu : F*(b.rightCutLog t).im < Real.pi := by
    have hh := (lt_div_iff₀ (by linarith : 0<2*F)).mp hhi
    nlinarith [Real.pi_pos]
  dsimp only [rightDensity]
  rw [Complex.exp_im]
  simp only [Complex.mul_im,Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,
    zero_mul,add_zero,sub_zero]
  exact div_pos (mul_pos (Real.exp_pos _) (Real.sin_pos_of_pos_of_lt_pi hx hu)) hFp

theorem leftDensity_continuous (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    ContinuousOn b.leftDensity (Ioi (height D F)) := by
  have hc := (b.leftCutLog_analytic hD hF hDF).continuousOn
  exact (Complex.continuous_im.comp_continuousOn
    (Complex.continuous_exp.comp_continuousOn (continuousOn_const.mul hc))).div_const F

theorem cutDensity_gt_leftDensity (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) : b.leftDensity t < b.cutDensity t := by
  rw [b.cutDensity_eq_add]
  linarith [b.rightDensity_pos_above_saddle hD hF hDF ht]

end ActualWedgePair
end LeanVerification.WedgeFullCompletion
