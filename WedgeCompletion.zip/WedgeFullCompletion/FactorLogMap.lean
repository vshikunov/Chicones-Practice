import LeanVerification.WedgeFullCompletion.Basic
import LeanVerification.RegionalComplex.RayAngles

/-! A logarithmic factor map for the quadratic potential. Its imaginary
derivative is strictly negative on the convex upper logarithmic strip,
which proves univalence and makes each permitted lifted pole phase unique. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open RegionalComplex MiddleStripCompletion
set_option maxHeartbeats 1500000

def factorLogMap (p u v : ℝ) : ℂ → ℂ := logRayMap (p-2) (-u) (-v)
def factorLogDeriv (p u v : ℝ) : ℂ → ℂ := logRayDeriv (p-2) (-u) (-v)

theorem hasDerivAt_factorLogMap (p u v : ℝ) {z : ℂ} (hz : z ∈ logRayStrip) :
    HasDerivAt (factorLogMap p u v) (factorLogDeriv p u v z) z :=
  hasDerivAt_logRayMap (p-2) (-u) (-v) hz

theorem factorLogMap_analytic (p u v : ℝ) :
    AnalyticOnNhd ℂ (factorLogMap p u v) logRayStrip :=
  logRayMap_analytic (p-2) (-u) (-v)

theorem negative_shifted_quotient_im {u : ℝ} {r : ℂ}
    (hu : 0 < u) (hr : 0 < r.im) : (r/(r+((-u : ℝ) : ℂ))).im < 0 := by
  have hn : r+((-u : ℝ) : ℂ) ≠ 0 := by
    intro he
    have hi := congrArg Complex.im he
    simp only [Complex.add_im,Complex.ofReal_im,add_zero,Complex.zero_im] at hi
    linarith
  rw [shifted_quotient_im]
  exact div_neg_of_neg_of_pos (mul_neg_of_neg_of_pos (neg_neg_of_pos hu) hr)
    (Complex.normSq_pos.mpr hn)

theorem factorLogDeriv_im_neg (p : ℝ) {u v : ℝ}
    (hu : 0 < u) (hv : 0 < v) {z : ℂ} (hz : z ∈ logRayStrip) :
    (factorLogDeriv p u v z).im < 0 := by
  have hi := exp_im_pos_of_logRayStrip hz
  have h₁ := negative_shifted_quotient_im hu hi
  have h₂ := negative_shifted_quotient_im hv hi
  simpa only [factorLogDeriv,logRayDeriv,Complex.add_im,Complex.ofReal_im,zero_add]
    using add_neg h₁ h₂

theorem factorLogMap_injective (p : ℝ) {u v : ℝ} (hu : 0 < u) (hv : 0 < v) :
    Set.InjOn (factorLogMap p u v) logRayStrip := by
  have hinj : Set.InjOn (fun z => -factorLogMap p u v z) logRayStrip :=
    injectiveOn_of_im_deriv_pos logRayStrip_convex
      (fun z hz => (hasDerivAt_factorLogMap p u v hz).neg)
      (fun z hz => by simpa only [Complex.neg_im,neg_pos] using factorLogDeriv_im_neg p hu hv hz)
  intro x hx y hy he
  exact hinj hx hy (congrArg Neg.neg he)

theorem factorLogDeriv_inverse_im_pos (p : ℝ) {u v : ℝ}
    (hu : 0 < u) (hv : 0 < v) {z : ℂ} (hz : z ∈ logRayStrip) :
    0 < (factorLogDeriv p u v z)⁻¹.im := by
  have hn := factorLogDeriv_im_neg p hu hv hz
  have hne : factorLogDeriv p u v z ≠ 0 := by intro he; simpa [he] using hn
  rw [Complex.inv_im]
  exact div_pos (neg_pos.mpr hn) (Complex.normSq_pos.mpr hne)

theorem upper_exp_arg {z : ℂ} (hz : z ∈ logRayStrip) : (Complex.exp z).arg=z.im := by
  have he := Complex.log_exp (by linarith [hz.1,Real.pi_pos]) hz.2.le
  simpa only [Complex.log_im] using congrArg Complex.im he

theorem sub_positive_arg_bounds {u : ℝ} {z : ℂ}
    (hu : 0 < u) (hz : z ∈ logRayStrip) :
    z.im < (Complex.exp z+((-u : ℝ) : ℂ)).arg ∧
      (Complex.exp z+((-u : ℝ) : ℂ)).arg < Real.pi := by
  have hi := exp_im_pos_of_logRayStrip hz
  have hsi : 0 < (Complex.exp z+((-u : ℝ) : ℂ)).im := by simpa using hi
  have h := (shifted_arg_bounds hsi hu).2
  have he : Complex.exp z+((-u : ℝ) : ℂ)+(u : ℂ)=Complex.exp z := by push_cast;ring
  rw [he,upper_exp_arg hz] at h
  exact ⟨h,Complex.arg_lt_pi_iff.mpr (Or.inr hsi.ne')⟩

theorem factorLogMap_phase_bounds (p : ℝ) {u v : ℝ}
    (hu : 0 < u) (hv : 0 < v) {z : ℂ} (hz : z ∈ logRayStrip) :
    p*z.im < (factorLogMap p u v z).im ∧
      (factorLogMap p u v z).im < (p-2)*z.im+2*Real.pi := by
  have h₁ := sub_positive_arg_bounds hu hz
  have h₂ := sub_positive_arg_bounds hv hz
  simp only [factorLogMap,logRayMap,Complex.add_im,Complex.mul_im,
    Complex.ofReal_im,Complex.ofReal_re,zero_mul,add_zero,Complex.log_im]
  constructor <;> nlinarith

theorem factorLogMap_exp (p u v : ℝ) {z : ℂ} (hz : z ∈ logRayStrip) :
    Complex.exp (factorLogMap p u v z)=
      Complex.exp (((p-2 : ℝ) : ℂ)*z)*(Complex.exp z-(u : ℂ))*(Complex.exp z-(v : ℂ)) := by
  have h₁ := Complex.slitPlane_ne_zero (shifted_exp_slitPlane (-u) hz)
  have h₂ := Complex.slitPlane_ne_zero (shifted_exp_slitPlane (-v) hz)
  simp only [factorLogMap,logRayMap,Complex.exp_add]
  rw [Complex.exp_log h₁,Complex.exp_log h₂]
  simp only [Complex.ofReal_neg,sub_eq_add_neg]

theorem negative_exponential_two_phases {q : ℂ} {E : ℝ}
    (hE : 0 < E) (he : Complex.exp q=-(E : ℂ))
    (hlo : 0 < q.im) (hhi : q.im < 5*Real.pi) :
    q=(Real.log E : ℂ)+(Real.pi : ℂ)*Complex.I ∨
      q=(Real.log E : ℂ)+(3*Real.pi : ℝ)*Complex.I := by
  have hb : Complex.exp ((Real.log E : ℂ)+(Real.pi : ℂ)*Complex.I)=-(E : ℂ) := by
    rw [Complex.exp_add,←Complex.ofReal_exp,Real.exp_log hE,Complex.exp_pi_mul_I]
    ring
  obtain ⟨n,hn⟩ := Complex.exp_eq_exp_iff_exists_int.mp (he.trans hb.symm)
  have hi : q.im=(1+2*(n : ℝ))*Real.pi := by
    rw [hn]
    simp
    ring
  have hnl : 0 < 1+2*(n : ℝ) :=
    (mul_pos_iff_of_pos_right Real.pi_pos).mp (by rwa [←hi])
  have hnh : 1+2*(n : ℝ) < 5 :=
    (mul_lt_mul_right Real.pi_pos).mp (by rwa [←hi])
  have hnlo : (-1 : ℝ) < n := by linarith
  have hnhi : (n : ℝ) < 2 := by linarith
  have hni0 : 0 ≤ n := by
    have : (-1 : ℤ) < n := by exact_mod_cast hnlo
    omega
  have hni2 : n < 2 := by exact_mod_cast hnhi
  have hcases : n=0 ∨ n=1 := by omega
  rcases hcases with hn0 | hn1
  · left
    simpa only [hn0,Int.cast_zero,zero_mul,add_zero] using hn
  · right
    rw [hn1] at hn
    simp only [Int.cast_one,one_mul] at hn
    rw [hn]
    push_cast
    ring

end LeanVerification.WedgeFullCompletion
