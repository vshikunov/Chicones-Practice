import LeanVerification.WedgeFullCompletion.EnergyRange
import LeanVerification.MiddleStripSpectral.UpperBankExtension

/-! Actual holomorphic width germs throughout the real line below the cut.
The center germ is the physical Morse germ. Regular negative-energy germs
come from the constructed inverse sheets and actual compactness bounds. -/

noncomputable section
open Set Filter Metric
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral
set_option maxHeartbeats 1800000

section ActualPair
variable {D F : ℝ} {gp gm : ℂ → ℂ}
variable (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
variable (hp : AnalyticOnNhd ℂ gp upperEnergy) (hm : AnalyticOnNhd ℂ gm upperEnergy)
variable (hmp : MapsTo gp upperEnergy (rightDomain D F))
variable (hmm : MapsTo gm upperEnergy (leftDomain D F))
variable (hep : ∀ z ∈ upperEnergy,logPotential D F (gp z)=z)
variable (hem : ∀ z ∈ upperEnergy,logPotential D F (gm z)=z)
include hD hF hp hm hmp hmm hep hem

theorem wedge_upperWidth_regular_germ {x : ℝ}
    (hx0 : x ≠ 0) (hxH : x ≠ height D F) (hxs : x ≠ wedgeSaddleHeight D F) :
    HasUpperGerm (upperNormalizedWidth F gp gm) x := by
  obtain ⟨wp,hwp,hewp,jp,hjp,hjp0,hep',hlp⟩ :=
    actual_right_regular_bank hD hF hp hmp hep hx0 hxH hxs
  obtain ⟨wm,hwm,hewm,jm,hjm,hjm0,hem',hlm⟩ :=
    actual_left_regular_bank hD hF hm hmm hem hx0 hxH hxs
  exact upperNormalizedWidth_regular_germ (by linarith) hx0 ⟨jp,hjp,hep'⟩ ⟨jm,hjm,hem'⟩

variable (hlp : ∀ h,AdmissibleEnergy D F h → Tendsto gp (𝓝[upperEnergy] (h : ℂ))
  (𝓝 (Real.log (rightTurn D F h) : ℂ)))
variable (hlm : ∀ h,AdmissibleEnergy D F h → Tendsto gm (𝓝[upperEnergy] (h : ℂ))
  (𝓝 (Real.log (leftTurn D F h) : ℂ)))
include hDF hlp hlm

theorem wedge_upperWidth_center_continuation :
    ∃ J : ℂ → ℂ,∃ r > 0,AnalyticOnNhd ℂ J (ball (0 : ℂ) r) ∧
      J 0=(2*Real.sqrt 2 : ℝ) ∧
      EqOn (upperNormalizedWidth F gp gm) J (ball (0 : ℂ) r ∩ upperEnergy) := by
  obtain ⟨J,r,hr,hJ,hJ0,_,hJe⟩ := exists_holomorphic_normalized_width_center D F
  obtain ⟨s,hs,hse⟩ := exists_initial_energy_interval D F
  let R := min r s
  have hR : 0 < R := lt_min hr hs
  have hJR : AnalyticOnNhd ℂ J (ball (0 : ℂ) R) := hJ.mono (by
    intro z hz
    change dist z (0 : ℂ) < r
    change dist z (0 : ℂ) < min r s at hz
    exact lt_of_lt_of_le hz (min_le_left _ _))
  have hvalid : ∀ x ∈ Ioo (0 : ℝ) R,AdmissibleEnergy D F x :=
    fun x hx => hse x hx.1 (hx.2.trans_le (min_le_right _ _))
  have hl : ∀ x ∈ Ioo (0 : ℝ) R,
      Tendsto (upperNormalizedWidth F gp gm) (𝓝[upperEnergy] (x : ℂ)) (𝓝 (J x)) := by
    intro x hx
    rw [hJe x hx.1 (hx.2.trans_le (min_le_left _ _))]
    exact upperNormalizedWidth_physical_bank (by linarith) (hvalid x hx)
      (hlp x (hvalid x hx)) (hlm x (hvalid x hx))
  have hreg : ∀ x ∈ Ioo (0 : ℝ) R,HasUpperGerm (upperNormalizedWidth F gp gm) x := by
    intro x hx
    have hxH := ((wedge_admissibleEnergy_iff hD hF hDF).1 (hvalid x hx)).2
    exact wedge_upperWidth_regular_germ hD hF hp hm hmp hmm hep hem hx.1.ne'
      hxH.ne (hxH.trans (wedge_height_lt_saddle hD hF hDF)).ne
  exact ⟨J,R,hR,hJR,hJ0,upper_boundary_match_center_germ hR
    (analyticOnNhd_upperNormalizedWidth (by linarith) hp hm) hJR hl hreg⟩

theorem wedge_upperWidth_center_germ : HasUpperGerm (upperNormalizedWidth F gp gm) 0 := by
  obtain ⟨J,r,hr,hJ,_,he⟩ := wedge_upperWidth_center_continuation
    hD hF hDF hp hm hmp hmm hep hem hlp hlm
  refine ⟨J,hJ 0 (mem_ball_self hr),?_⟩
  filter_upwards [self_mem_nhdsWithin,
    mem_nhdsWithin_of_mem_nhds (ball_mem_nhds (0 : ℂ) hr)] with z hz hb
  exact he ⟨hb,hz⟩

theorem wedge_upperWidth_germs_below_height :
    ∀ x ∈ Iio (height D F),HasUpperGerm (upperNormalizedWidth F gp gm) x := by
  intro x hx
  by_cases hx0 : x=0
  · rw [hx0]
    exact wedge_upperWidth_center_germ hD hF hDF hp hm hmp hmm hep hem hlp hlm
  · exact wedge_upperWidth_regular_germ hD hF hp hm hmp hmm hep hem hx0 hx.ne
      (hx.trans (wedge_height_lt_saddle hD hF hDF)).ne

theorem wedge_upperWidth_bank_real_below :
    ∀ x ∈ Iio (height D F),(upperBank (upperNormalizedWidth F gp gm) x).im=0 := by
  apply upperBank_real_below_of_positive (height_pos (by linarith) hF)
    (wedge_upperWidth_germs_below_height hD hF hDF hp hm hmp hmm hep hem hlp hlm)
  intro x hx
  have hh := (wedge_admissibleEnergy_iff hD hF hDF).2 hx
  rw [upperBank_eq_of_tendsto (upperNormalizedWidth_physical_bank (by linarith) hh
    (hlp x hh) (hlm x hh))]
  rfl

end ActualPair
end LeanVerification.WedgeFullCompletion
