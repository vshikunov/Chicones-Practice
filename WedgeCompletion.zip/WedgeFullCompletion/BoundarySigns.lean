import LeanVerification.WedgeFullCompletion.RadialBoundaries

/-! Signs on every artificial boundary of the two physical-sheet frames.
They exclude an upper (respectively lower) nonreal energy at every finite
boundary point; ordinary continuity is used only after these signs are proved. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open MiddleStripCompletion
set_option maxHeartbeats 1200000

theorem wedgeFirstAngle_mul {F : ℝ} (hF : 3/2 < F) :
    (2*F-1)*wedgeFirstAngle F=Real.pi := by
  have hn : 2*F-1 ≠ 0 := by linarith
  dsimp [wedgeFirstAngle]
  field_simp

theorem wedgeRadius_le_exp {D F x : ℝ} (hD : D < -1) (hF : 3/2 < F)
    (hx : wedgeLogRadius D F ≤ x) : wedgeRadius D F ≤ Real.exp x := by
  rw [←exp_wedgeLogRadius hD hF]
  exact Real.exp_le_exp.mpr hx

theorem exp_le_wedgeRadius {D F x : ℝ} (hD : D < -1) (hF : 3/2 < F)
    (hx : x ≤ wedgeLogRadius D F) : Real.exp x ≤ wedgeRadius D F := by
  rw [←exp_wedgeLogRadius hD hF]
  exact Real.exp_le_exp.mpr hx

theorem wedge_radial_square_le {D F r : ℝ} (hD : D < -1) (hF : 3/2 < F)
    (hr : 0 ≤ r) (hru : r ≤ wedgeRadius D F) :
    wedgeLeading D F*r^2 ≤ trailing D F := by
  rw [←wedgeRadius_square hD hF]
  exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hr hru 2)
    (wedge_coefficients_pos hD hF).1.le

theorem wedge_radial_square_ge {D F r : ℝ} (hD : D < -1) (hF : 3/2 < F)
    (hr : wedgeRadius D F ≤ r) :
    trailing D F ≤ wedgeLeading D F*r^2 := by
  rw [←wedgeRadius_square hD hF]
  exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (wedgeRadius_pos hD hF).le hr 2)
    (wedge_coefficients_pos hD hF).1.le

theorem wedge_first_boundary_le {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F)
    (hz : z.im=wedgeFirstAngle F) (hx : z.re ≤ wedgeLogRadius D F) :
    (logPotential D F z).im ≤ 0 := by
  rw [logPotential_im_radial, hz, radialImag_first_angle D F _ hF]
  exact mul_nonpos_of_nonneg_of_nonpos (Real.exp_pos _).le
    (mul_nonpos_of_nonneg_of_nonpos (wedge_first_angle_sin_pos hF).le
      (sub_nonpos.mpr (wedge_radial_square_le hD hF (Real.exp_pos _).le
        (exp_le_wedgeRadius hD hF hx))))

theorem wedge_first_boundary_ge {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F)
    (hz : z.im=wedgeFirstAngle F) (hx : wedgeLogRadius D F ≤ z.re) :
    0 ≤ (logPotential D F z).im := by
  rw [logPotential_im_radial, hz, radialImag_first_angle D F _ hF]
  exact mul_nonneg (Real.exp_pos _).le
    (mul_nonneg (wedge_first_angle_sin_pos hF).le
      (sub_nonneg.mpr (wedge_radial_square_ge hD hF (wedgeRadius_le_exp hD hF hx))))

theorem wedge_second_boundary_ge {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F)
    (hz : z.im=2*wedgeFirstAngle F) (hx : z.re ≤ wedgeLogRadius D F) :
    0 ≤ (logPotential D F z).im := by
  rw [logPotential_im_radial, hz, radialImag_second_angle D F _ hF]
  exact mul_nonneg (Real.exp_pos _).le
    (mul_nonneg (wedge_second_angle_sin_pos hF).le
      (sub_nonneg.mpr (wedge_radial_square_le hD hF (Real.exp_pos _).le
        (exp_le_wedgeRadius hD hF hx))))

theorem wedge_right_top_neg {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hz : z.im=wedgeRightAngle F) (hx : wedgeLogRadius D F ≤ z.re) :
    (logPotential D F z).im < 0 := by
  rw [logPotential_im_radial, hz, radialImag_right_angle D F _ hF]
  have hp := wedge_coefficients_pos hD hF
  have hg := wedgeRadius_middle_gap hD hF hDF
  have hr := wedgeRadius_le_exp hD hF hx
  have hB := mul_le_mul_of_nonneg_left hr hp.2.1.le
  have hc := mul_le_mul_of_nonneg_left (Real.cos_le_one (wedgeRightAngle F))
    (show 0 ≤ 2*trailing D F by linarith [hp.2.2])
  have hn : 2*trailing D F*Real.cos (wedgeRightAngle F)-middle D F*Real.exp z.re < 0 := by
    linarith
  exact mul_neg_of_pos_of_neg (Real.exp_pos _)
    (mul_neg_of_pos_of_neg (wedge_right_angle_sin_pos hF) hn)

theorem wedge_zero_top_pos {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hz : z.im=wedgeZeroAngle F) (hx : wedgeLogRadius D F ≤ z.re) :
    0 < (logPotential D F z).im := by
  rw [logPotential_im_radial, hz, radialImag_zero_angle D F _ hF]
  have hp := wedge_coefficients_pos hD hF
  have hg := wedgeRadius_middle_gap hD hF hDF
  have hr := wedgeRadius_le_exp hD hF hx
  have hB := mul_le_mul_of_nonneg_left hr hp.2.1.le
  have hc := mul_le_mul_of_nonneg_left (Real.cos_le_one (wedgeZeroAngle F))
    (show 0 ≤ 2*trailing D F by linarith [hp.2.2])
  have hn : 0 < middle D F*Real.exp z.re-2*trailing D F*Real.cos (wedgeZeroAngle F) := by
    linarith
  exact mul_pos (Real.exp_pos _) (mul_pos (wedge_zero_angle_sin_pos hF) hn)

theorem wedge_radius_right_nonpos {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hx : z.re=wedgeLogRadius D F)
    (hlo : wedgeFirstAngle F ≤ z.im) (hhi : z.im ≤ wedgeRightAngle F) :
    (logPotential D F z).im ≤ 0 := by
  have hpos : 0 < 2*F-1 := by linarith
  have hlo' : Real.pi ≤ (2*F-1)*z.im := by
    rw [←wedgeFirstAngle_mul hF]
    exact mul_le_mul_of_nonneg_left hlo hpos.le
  have hhi' : (2*F-1)*z.im ≤ 2*Real.pi := by
    have hu := (wedge_angles hF).2.2.1
    have h := mul_le_mul_of_nonneg_left (hhi.trans hu.le) hpos.le
    nlinarith only [h, wedgeFirstAngle_mul hF]
  rw [logPotential_im_radial, hx, exp_wedgeLogRadius hD hF, radialImag_at_radius hD hF]
  exact mul_nonpos_of_nonneg_of_nonpos (Real.exp_pos _).le
    (mul_nonpos_of_nonpos_of_nonneg (sine_between_pi_two_pi_nonpos hlo' hhi')
      (radial_radius_factor_pos hD hF hDF _).le)

theorem wedge_radius_lower_nonneg {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hx : z.re=wedgeLogRadius D F)
    (hlo : 0 ≤ z.im) (hhi : z.im ≤ wedgeFirstAngle F) :
    0 ≤ (logPotential D F z).im := by
  have hpos : 0 < 2*F-1 := by linarith
  have hs : 0 ≤ Real.sin ((2*F-1)*z.im) := by
    apply Real.sin_nonneg_of_mem_Icc
    refine ⟨mul_nonneg hpos.le hlo, ?_⟩
    rw [←wedgeFirstAngle_mul hF]
    exact mul_le_mul_of_nonneg_left hhi hpos.le
  rw [logPotential_im_radial, hx, exp_wedgeLogRadius hD hF, radialImag_at_radius hD hF]
  exact mul_nonneg (Real.exp_pos _).le
    (mul_nonneg hs (radial_radius_factor_pos hD hF hDF _).le)

theorem wedge_radius_upper_nonneg {D F : ℝ} {z : ℂ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    (hx : z.re=wedgeLogRadius D F)
    (hlo : 2*wedgeFirstAngle F ≤ z.im) (hhi : z.im ≤ wedgeZeroAngle F) :
    0 ≤ (logPotential D F z).im := by
  have hpos : 0 < 2*F-1 := by linarith
  have hlo' : 2*Real.pi ≤ (2*F-1)*z.im := by
    have h := mul_le_mul_of_nonneg_left hlo hpos.le
    nlinarith only [h, wedgeFirstAngle_mul hF]
  have hhi' : (2*F-1)*z.im ≤ 3*Real.pi := by
    have hfn : 2*F ≠ 0 := by linarith
    have he : 2*F*wedgeZeroAngle F=3*Real.pi := by
      dsimp [wedgeZeroAngle]
      field_simp
    have ha : 0 < wedgeZeroAngle F := by
      obtain ⟨ha,hab,hbc,hcd,hd⟩ := wedge_angles hF
      linarith
    have h := mul_le_mul_of_nonneg_left hhi hpos.le
    nlinarith only [h, he, ha]
  rw [logPotential_im_radial, hx, exp_wedgeLogRadius hD hF, radialImag_at_radius hD hF]
  exact mul_nonneg (Real.exp_pos _).le
    (mul_nonneg (sine_between_two_pi_three_pi_nonneg hlo' hhi')
      (radial_radius_factor_pos hD hF hDF _).le)

end LeanVerification.WedgeFullCompletion
