import LeanVerification.WedgeFullCompletion.CutBanks

/-! A package of the two constructed physical inverse functions. Its
existence theorem has only the actual open-wedge parameter hypotheses. -/

noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion MiddleStripSpectral RegionalComplex
set_option maxHeartbeats 1800000

structure ActualWedgePair (D F : ℝ) where
  right : ℂ → ℂ
  left : ℂ → ℂ
  right_analytic : AnalyticOnNhd ℂ right upperEnergy
  left_analytic : AnalyticOnNhd ℂ left upperEnergy
  right_maps : MapsTo right upperEnergy (rightDomain D F)
  left_maps : MapsTo left upperEnergy (leftDomain D F)
  right_inverse : ∀ z ∈ upperEnergy,logPotential D F (right z)=z
  left_inverse : ∀ z ∈ upperEnergy,logPotential D F (left z)=z
  right_banks : ∀ t : ℝ,0 < t → t < wedgeSaddleLog D →
    Tendsto right (𝓝[upperEnergy] (logPotential D F (t : ℂ))) (𝓝 (t : ℂ))
  left_banks : ∀ t : ℝ,t < 0 →
    Tendsto left (𝓝[upperEnergy] (logPotential D F (t : ℂ))) (𝓝 (t : ℂ))

theorem actualWedgePair_nonempty {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) : Nonempty (ActualWedgePair D F) := by
  obtain ⟨gp,hp,hmp,hep,hlp⟩ := actual_right_inverse_all_banks hD hF hDF
  obtain ⟨gm,hm,hmm,hem,hlm⟩ := actual_left_inverse_all_banks hD hF hDF
  exact ⟨⟨gp,gm,hp,hm,hmp,hmm,hep,hem,hlp,hlm⟩⟩

namespace ActualWedgePair
variable {D F : ℝ} (b : ActualWedgePair D F)

def rightCutLog (t : ℝ) : ℂ := upperBank b.right t
def leftCutLog (t : ℝ) : ℂ := star (upperBank b.left t)

theorem right_annulus (hD : D < -1) (hF : 3/2 < F) {h : ℝ}
    (hh : AdmissibleEnergy D F h) :
    Tendsto b.right (𝓝[upperEnergy] (h : ℂ)) (𝓝 (Real.log (rightTurn D F h) : ℂ)) := by
  have hw := rightTurn_spec D F h hh
  have hr := ((inCentralInterval_iff_of_lt_neg_one D _ hD).1 hw.1).2
  have hb := b.right_banks _ (Real.log_pos hw.2.1) (Real.log_lt_log hw.1.1 hr)
  rw [logPotential_real D F _ hF,Real.exp_log hw.1.1,hw.2.2] at hb
  exact hb

theorem left_annulus (hF : 3/2 < F) {h : ℝ} (hh : AdmissibleEnergy D F h) :
    Tendsto b.left (𝓝[upperEnergy] (h : ℂ)) (𝓝 (Real.log (leftTurn D F h) : ℂ)) := by
  have hw := leftTurn_spec D F h hh
  have hb := b.left_banks _ (Real.log_neg hw.1.1 hw.2.1)
  rw [logPotential_real D F _ hF,Real.exp_log hw.1.1,hw.2.2] at hb
  exact hb

theorem rightCutLog_spec (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) :
    b.rightCutLog t ∈ rightFrame D F ∧ 0 < (b.rightCutLog t).im ∧
      logPotential D F (b.rightCutLog t)=(t : ℂ) ∧ HasUpperGerm b.right t ∧
      Tendsto b.right (𝓝[upperEnergy] (t : ℂ)) (𝓝 (b.rightCutLog t)) := by
  obtain ⟨w,hw,hi,he,j,hj,hj0,hej,hl⟩ := actual_right_cut_bank hD hF hDF
    b.right_analytic b.right_maps b.right_inverse ht
  have hb : b.rightCutLog t=w := upperBank_eq_of_tendsto hl
  exact ⟨hb ▸ hw,hb ▸ hi,hb ▸ he,⟨j,hj,hej⟩,by rwa [hb]⟩

theorem leftCutLog_spec (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F < t) :
    b.leftCutLog t ∈ zeroFrame D F ∧ 0 < (b.leftCutLog t).im ∧
      logPotential D F (b.leftCutLog t)=(t : ℂ) ∧ HasUpperGerm b.left t ∧
      Tendsto (fun z => star (b.left z)) (𝓝[upperEnergy] (t : ℂ)) (𝓝 (b.leftCutLog t)) := by
  obtain ⟨w,hw,hi,he,j,hj,hj0,hej,hl⟩ := actual_left_cut_bank hD hF hDF
    b.left_analytic b.left_maps b.left_inverse ht
  have hb : b.leftCutLog t=star w := congrArg star (upperBank_eq_of_tendsto hl)
  rw [hb]
  refine ⟨hw,?_,?_,⟨j,hj,hej⟩,continuous_star.continuousAt.tendsto.comp hl⟩
  · simpa only [Complex.star_def,Complex.conj_im,neg_pos] using hi
  · rw [logPotential_star,he]
    simp

theorem rightCutLog_strip (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) : b.rightCutLog t ∈ logRayStrip := by
  obtain ⟨hw,hi,-⟩ := b.rightCutLog_spec hD hF hDF ht
  have ha := wedge_angles hF
  exact ⟨hi,hw.2.1.trans_lt (ha.2.2.1.trans (ha.2.2.2.1.trans ha.2.2.2.2))⟩

theorem leftCutLog_strip (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F < t) : b.leftCutLog t ∈ logRayStrip := by
  obtain ⟨hw,hi,-⟩ := b.leftCutLog_spec hD hF hDF ht
  exact ⟨hi,hw.2.1.trans_lt (wedge_angles hF).2.2.2.2⟩

theorem rightCutLog_phase (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) :
    actualFactorLog D F (b.rightCutLog t)=
      (Real.log ((t-height D F)/wedgeLeading D F) : ℂ)+(Real.pi : ℂ)*Complex.I := by
  have hs := b.rightCutLog_strip hD hF hDF ht
  have hb := b.rightCutLog_spec hD hF hDF ht
  have hph := factorLog_bank_phase_of_limit hD hF hDF hs hb.2.2.2.2
    (actual_right_factor_phase hD hF hDF b.right_analytic b.right_maps b.right_inverse b.right_banks)
  have hp := factorLog_real_energy_phases hD hF hDF hs
    ((wedge_height_lt_saddle hD hF hDF).trans ht) hb.2.2.1
    (Real.pi_pos.trans_le hph.1) (by linarith [hph.2,Real.pi_pos])
  rcases hp with hp | hp
  · exact hp
  · have hi := congrArg Complex.im hp
    simp at hi
    linarith [hph.2,Real.pi_pos]

theorem leftCutLog_phase (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F < t) :
    actualFactorLog D F (b.leftCutLog t)=
      (Real.log ((t-height D F)/wedgeLeading D F) : ℂ)+(3*Real.pi : ℝ)*Complex.I := by
  have hs := b.leftCutLog_strip hD hF hDF ht
  have hb := b.leftCutLog_spec hD hF hDF ht
  have hph := factorLog_bank_phase_of_limit hD hF hDF hs hb.2.2.2.2
    (actual_left_factor_phase hD hF hDF b.left_analytic b.left_maps b.left_inverse b.left_banks)
  have hp := factorLog_real_energy_phases hD hF hDF hs ht hb.2.2.1
    (by linarith [hph.1,Real.pi_pos]) (by linarith [hph.2,Real.pi_pos])
  rcases hp with hp | hp
  · have hi := congrArg Complex.im hp
    simp at hi
    linarith [hph.1,Real.pi_pos]
  · exact hp

theorem cutLogs_ne (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) : b.rightCutLog t ≠ b.leftCutLog t := by
  intro he
  have hp := b.rightCutLog_phase hD hF hDF ht
  rw [he,b.leftCutLog_phase hD hF hDF ((wedge_height_lt_saddle hD hF hDF).trans ht)] at hp
  have hi := congrArg Complex.im hp
  simp at hi
  linarith [Real.pi_pos]

theorem rightCutLog_angle_bound (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : wedgeSaddleHeight D F < t) :
    0 < (b.rightCutLog t).im ∧ (b.rightCutLog t).im < Real.pi/(2*F) := by
  have hs := b.rightCutLog_strip hD hF hDF ht
  have hp := (actualFactorLog_phase_bounds hD hF hDF hs).1
  rw [b.rightCutLog_phase hD hF hDF ht] at hp
  simp at hp
  exact ⟨hs.1,(lt_div_iff₀ (by linarith : 0<2*F)).2 (by nlinarith only [hp])⟩

theorem leftCutLog_angle_bounds (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D)
    {t : ℝ} (ht : height D F < t) :
    Real.pi/(2*F-2) < (b.leftCutLog t).im ∧
      (b.leftCutLog t).im < 3*Real.pi/(2*F) := by
  have hs := b.leftCutLog_strip hD hF hDF ht
  have hp := actualFactorLog_phase_bounds hD hF hDF hs
  rw [b.leftCutLog_phase hD hF hDF ht] at hp
  simp at hp
  exact ⟨(div_lt_iff₀ (by linarith : 0<2*F-2)).2 (by nlinarith only [hp.2]),
    (lt_div_iff₀ (by linarith : 0<2*F)).2 (by nlinarith only [hp.1])⟩

end ActualWedgePair
end LeanVerification.WedgeFullCompletion
