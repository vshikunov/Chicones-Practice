import LeanVerification.WedgeFullCompletion.ActualPeriod
import LeanVerification.WedgeFullCompletion.DensitySignInputs
import LeanVerification.WedgeIntegralCompletion.TwoDensityBlocks
import LeanVerification.Loud.PhysicalSpectralPeriodZeros
import LeanVerification.BoundaryAssembly.FullBoundaryMultiplicity
import LeanVerification.BoundaryAssembly.ClosedRegions
import LeanVerification.Loud.ParameterCover

/-! Complete physical row 21. The actual interior raised input is bounded
first, using the constructed physical continuum and its proved sign blocks.
Only afterward does the parameter-boundary theorem supply the closed edges. -/

noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace LeanVerification.WedgeFullCompletion
open Loud MiddleStripCompletion WedgeIntegralCompletion
set_option maxHeartbeats 1800000

theorem actual_wedge_cut_data_and_signs {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hFu : F < 4) (hDF : -F < D) :
    ∃ W : ℂ → ℂ,∃ d : SlitContour.PhysicalCutData W (height D F),
      d.constant=0 ∧
      EqOn d.physicalWidth (physicalEnergyWidth D F) (Ioo 0 (height D F)) ∧
      ∃ n : ℕ,n ≤ 2 ∧ Nonempty
        (MeasureSigns.BlockDecomposition (volume.restrict (Ioi (height D F))) d.density n) := by
  obtain ⟨b⟩ := actualWedgePair_nonempty hD hF hDF
  obtain ⟨d,hK,hW,he⟩ := b.exists_physical_cut_data hD hF hDF
  obtain ⟨n,hn,⟨blocks⟩⟩ := punctured_halfline_two_density_blocks
    (height_pos (show D < 0 by linarith) hF).le (wedge_height_lt_saddle hD hF hDF)
    (b.cutDensity_continuous_away_saddle hD hF hDF)
    (b.cutDensity_exists_nonzero hD hF hFu hDF)
    (fun _ hx _ hy _ hz hxy hyz hxn hyp hzn =>
      b.cutDensity_no_negative_positive_negative hD hF hFu hDF hx hy hz hxy hyz hxn hyp hzn)
  exact ⟨wedgeSlitWidth F b.right b.left,d,hK,hW,n,hn,⟨blocks.congr_ae he.symm⟩⟩

theorem wedge_cut_energy_set {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hDF : -F < D) :
    {h : ℝ | AdmissibleEnergy D F h ∧ h < height D F}={h : ℝ | AdmissibleEnergy D F h} := by
  ext h
  exact ⟨fun hh => hh.1,fun hh => ⟨hh,((wedge_admissibleEnergy_iff hD hF hDF).mp hh).2⟩⟩

/-- Actual interior G, on the entire physical annulus, has at most two
zeros counted with analytic multiplicity. This is the missing interior
estimate itself, not a consequence of a boundary-continuity argument. -/
theorem wedge_interior_raised_multiplicity_bound {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hFu : F < 4) (hDF : -F < D) :
    AnalyticMultiplicity.MultiplicityBound 2 (physicalRaisedInput D F)
      {h | AdmissibleEnergy D F h} := by
  obtain ⟨W,d,hK,hW,n,hn,⟨blocks⟩⟩ := actual_wedge_cut_data_and_signs hD hF hFu hDF
  have hb := (physical_raised_moment_zero_bound d blocks hW).mono_bound hn
  rwa [wedge_cut_energy_set hD hF hDF] at hb

theorem wedge_interior_raised_sign_bound {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hFu : F < 4) (hDF : -F < D) :
    SignVariation.AtMostStrictSignChanges 2 (physicalRaisedInput D F)
      {h | AdmissibleEnergy D F h} := by
  have hb := wedge_interior_raised_multiplicity_bound hD hF hFu hDF
  have hset : {h : ℝ | AdmissibleEnergy D F h}=Ioo 0 (height D F) := by
    ext h
    exact wedge_admissibleEnergy_iff hD hF hDF
  apply hb.atMostStrictSignChanges
  · rw [hset]
    exact convex_Ioo _ _
  · exact fun h hh => analyticAt_physicalRaisedInput D F h hh

theorem wedge_interior_period_multiplicity_bound {D F : ℝ}
    (hD : D < -1) (hF : 3/2 < F) (hFu : F < 4) (hDF : -F < D) :
    AnalyticMultiplicity.MultiplicityBound 2 (deriv (periodQuadrature D F))
      {h | AdmissibleEnergy D F h} := by
  obtain ⟨W,d,hK,hW,n,hn,⟨blocks⟩⟩ := actual_wedge_cut_data_and_signs hD hF hFu hDF
  have hb := (physical_cut_period_zero_bound d hn blocks hW).mono_bound hn
  rwa [wedge_cut_energy_set hD hF hDF] at hb

theorem closed_wedge_criticalPeriodBound {D F : ℝ}
    (hF : F ∈ Icc (3/2) 4) (hD : D ∈ Icc (-F) (-1)) : CriticalPeriodBound 2 D F := by
  apply resolventWedge_closed_bound_of_open_raised_signs _ hF hD
  intro p hp
  exact wedge_interior_raised_sign_bound hp.2.2.2 hp.1 hp.2.1 hp.2.2.1

theorem closed_wedge_period_alternative {D F : ℝ}
    (hF : F ∈ Icc (3/2) 4) (hD : D ∈ Icc (-F) (-1)) :
    (∀ h,AdmissibleEnergy D F h → periodQuadrature D F h=2*Real.pi) ∨
      AnalyticMultiplicity.MultiplicityBound 2 (deriv (periodQuadrature D F))
        {h | AdmissibleEnergy D F h} := by
  apply physical_boundary_multiplicity_alternative (p:=(D,F)) (by norm_num : 2 ≤ 2)
    (R:=openResolventWedge 4)
  · rw [closure_openResolventWedge (by norm_num : (3/2 : ℝ)<4)]
    exact ⟨hF.1,hF.2,hD.1,hD.2⟩
  · intro p hp
    exact wedge_interior_raised_sign_bound hp.2.2.2 hp.1 hp.2.1 hp.2.2.1

/-- Full zero-based regional row 21, including F=3/2, F=2, F=4,
D=-F and D=-1. The only premise is the actual table region. -/
theorem full_regional_row21 (D F : ℝ) (h : parameterRegion 21 D F) :
    CriticalPeriodBound (parameterRegionBound 21) D F :=
  closed_wedge_criticalPeriodBound ⟨h.1,h.2.1⟩ ⟨h.2.2.1,h.2.2.2⟩

end LeanVerification.WedgeFullCompletion
