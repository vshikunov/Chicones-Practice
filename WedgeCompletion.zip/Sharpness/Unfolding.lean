import LeanVerification.Sharpness.ParameterPath
import LeanVerification.Sharpness.PeriodTaylorRemainder
import LeanVerification.AnalyticMultiplicity

/-! An analytic unfolding of the actual Loud period derivative. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness
open Loud GeneralMechanical SharpnessAlgebra
set_option maxHeartbeats 1800000

def rescaledSlope (p : ℝ → ℝ×ℝ) (q : ℝ×ℝ) : ℝ :=
  6*aStar-9*aStar*q.2+q.2^2*slopeRemainder (p q.1,q.1*q.2)

def rescaledSlopeDerivative (p : ℝ → ℝ×ℝ) : ℝ×ℝ → ℝ :=
  verticalDerivative (rescaledSlope p)

theorem analyticAt_rescaledSlope {p : ℝ → ℝ×ℝ}
    (hp : AnalyticAt ℝ p 0) (hp0 : p 0=(dStar,fStar)) (z : ℝ) :
    AnalyticAt ℝ (rescaledSlope p) (0,z) := by
  have hm : AnalyticAt ℝ (fun q : ℝ×ℝ => (p q.1,q.1*q.2)) (0,z) :=
    (hp.comp_of_eq (show AnalyticAt ℝ (fun q:ℝ×ℝ => q.1) (0,z) from analyticAt_fst) rfl).prod (analyticAt_fst.mul analyticAt_snd)
  have hR := (analyticAt_slopeRemainder_center (dStar,fStar)).comp_of_eq hm
    (by simp only [hp0,zero_mul])
  exact ((analyticAt_const.sub (analyticAt_const.mul analyticAt_snd)).add
    ((analyticAt_snd.pow 2).mul hR))

theorem rescaledSlope_zero_parameter {p : ℝ → ℝ×ℝ}
    (hp0 : p 0=(dStar,fStar)) (z : ℝ) :
    rescaledSlope p (0,z)=3*aStar*(z-1)*(z-2) := by
  simp only [rescaledSlope,hp0,zero_mul,slopeRemainder_center,tau3_at_star]
  ring

theorem rescaledSlopeDerivative_zero_parameter {p : ℝ → ℝ×ℝ}
    (hp : AnalyticAt ℝ p 0) (hp0 : p 0=(dStar,fStar)) (z : ℝ) :
    rescaledSlopeDerivative p (0,z)=3*aStar*(2*z-3) := by
  rw [rescaledSlopeDerivative,verticalDerivative_eq_deriv (analyticAt_rescaledSlope hp hp0 z)]
  have he : (fun t => rescaledSlope p (0,t))=(fun t => 3*aStar*(t-1)*(t-2)) :=
    funext (rescaledSlope_zero_parameter hp0)
  rw [he]
  have hd := (((hasDerivAt_id z).sub_const 1).const_mul (3*aStar)).mul
    ((hasDerivAt_id z).sub_const 2)
  simp only [id_eq] at hd
  rw [hd.deriv]
  ring

theorem actual_rescaled_slope_identity {p : ℝ → ℝ×ℝ} {ε : ℝ}
    (h1 : periodCoefficient (p ε).1 (p ε).2 1=6*aStar*ε^2)
    (h2 : periodCoefficient (p ε).1 (p ε).2 2=-(9/2:ℝ)*aStar*ε) (z : ℝ) :
    normalizedSlope (p ε,ε*z)=ε^2*rescaledSlope p (ε,z) := by
  rw [actual_slope_taylor_identity,h1,h2]
  dsimp only [rescaledSlope]
  ring

theorem exists_analytic_zero_path {f : ℝ×ℝ → ℝ} {z : ℝ}
    (hf : AnalyticAt ℝ f (0,z)) (hz : f (0,z)=0)
    (hd : deriv (fun t => f (0,t)) z ≠ 0) :
    ∃ u : ℝ → ℝ, AnalyticAt ℝ u 0 ∧ u 0=z ∧
      ∀ᶠ ε in 𝓝 (0:ℝ), f (ε,u ε)=0 := by
  obtain ⟨I,hI,hI0,he,_⟩ := exists_analytic_fiber_inverse_germ hf hd
  simp only [hz] at hI hI0 he
  let u : ℝ → ℝ := fun ε => I (ε,0)
  have hm : AnalyticAt ℝ (fun ε:ℝ => (ε,(0:ℝ))) 0 :=
    analyticAt_id.prod analyticAt_const
  refine ⟨u,hI.comp_of_eq hm rfl,hI0,?_⟩
  have ht : Tendsto (fun ε:ℝ => (ε,(0:ℝ))) (𝓝 0) (𝓝 ((0,0):ℝ×ℝ)) :=
    hm.continuousAt.tendsto
  filter_upwards [ht.eventually he] with ε hε
  exact hε

theorem exists_actual_rescaled_root_paths :
    ∃ (p : ℝ → ℝ×ℝ) (u v : ℝ → ℝ),
      AnalyticAt ℝ p 0 ∧ AnalyticAt ℝ u 0 ∧ AnalyticAt ℝ v 0 ∧
      p 0=(dStar,fStar) ∧ u 0=1 ∧ v 0=2 ∧
      ∀ᶠ ε in 𝓝 (0:ℝ),
        periodCoefficient (p ε).1 (p ε).2 1=6*aStar*ε^2 ∧
        periodCoefficient (p ε).1 (p ε).2 2=-(9/2:ℝ)*aStar*ε ∧
        rescaledSlope p (ε,u ε)=0 ∧ rescaledSlope p (ε,v ε)=0 ∧
        0<u ε ∧ u ε<v ε ∧
        rescaledSlopeDerivative p (ε,u ε)<0 ∧
        0<rescaledSlopeDerivative p (ε,v ε) ∧
        AnalyticAt ℝ (rescaledSlope p) (ε,u ε) ∧
        AnalyticAt ℝ (rescaledSlope p) (ε,v ε) ∧
        (p ε,ε*u ε)∈jointCenterDomain ∧ (p ε,ε*v ε)∈jointCenterDomain := by
  obtain ⟨p,hp,hp0,hcoeff⟩ := exists_actual_sharpness_parameter_path
  have hQ1 := analyticAt_rescaledSlope hp hp0 1
  have hQ2 := analyticAt_rescaledSlope hp hp0 2
  have hzero1 : rescaledSlope p (0,1)=0 := by rw [rescaledSlope_zero_parameter hp0]; ring
  have hzero2 : rescaledSlope p (0,2)=0 := by rw [rescaledSlope_zero_parameter hp0]; ring
  have hd1 : deriv (fun z => rescaledSlope p (0,z)) 1 ≠ 0 := by
    rw [←verticalDerivative_eq_deriv hQ1]
    change rescaledSlopeDerivative p (0,1) ≠ 0
    rw [rescaledSlopeDerivative_zero_parameter hp hp0]
    nlinarith only [aStar_pos]
  have hd2 : deriv (fun z => rescaledSlope p (0,z)) 2 ≠ 0 := by
    rw [←verticalDerivative_eq_deriv hQ2]
    change rescaledSlopeDerivative p (0,2) ≠ 0
    rw [rescaledSlopeDerivative_zero_parameter hp hp0]
    nlinarith only [aStar_pos]
  obtain ⟨u,hu,hu0,huroot⟩ := exists_analytic_zero_path hQ1 hzero1 hd1
  obtain ⟨v,hv,hv0,hvroot⟩ := exists_analytic_zero_path hQ2 hzero2 hd2
  have hmu : AnalyticAt ℝ (fun ε => (ε,u ε)) 0 := analyticAt_id.prod hu
  have hmv : AnalyticAt ℝ (fun ε => (ε,v ε)) 0 := analyticAt_id.prod hv
  have htu : Tendsto (fun ε => (ε,u ε)) (𝓝 0) (𝓝 ((0,1):ℝ×ℝ)) := by
    simpa only [hu0] using hmu.continuousAt.tendsto
  have htv : Tendsto (fun ε => (ε,v ε)) (𝓝 0) (𝓝 ((0,2):ℝ×ℝ)) := by
    simpa only [hv0] using hmv.continuousAt.tendsto
  have hdu : ContinuousAt (fun ε => rescaledSlopeDerivative p (ε,u ε)) 0 :=
    ((analyticAt_verticalDerivative hQ1).continuousAt.comp_of_eq hmu.continuousAt
      (by simp only [hu0]))
  have hdv : ContinuousAt (fun ε => rescaledSlopeDerivative p (ε,v ε)) 0 :=
    ((analyticAt_verticalDerivative hQ2).continuousAt.comp_of_eq hmv.continuousAt
      (by simp only [hv0]))
  have hdu0 : rescaledSlopeDerivative p (0,u 0)<0 := by
    rw [hu0,rescaledSlopeDerivative_zero_parameter hp hp0]
    nlinarith only [aStar_pos]
  have hdv0 : 0<rescaledSlopeDerivative p (0,v 0) := by
    rw [hv0,rescaledSlopeDerivative_zero_parameter hp hp0]
    nlinarith only [aStar_pos]
  have hEu : Tendsto (fun ε => (p ε,ε*u ε)) (𝓝 0) (𝓝 ((dStar,fStar),0)) := by
    simpa only [hp0,id_eq,zero_mul] using
      (hp.continuousAt.prodMk (continuousAt_id.mul hu.continuousAt)).tendsto
  have hEv : Tendsto (fun ε => (p ε,ε*v ε)) (𝓝 0) (𝓝 ((dStar,fStar),0)) := by
    simpa only [hp0,id_eq,zero_mul] using
      (hp.continuousAt.prodMk (continuousAt_id.mul hv.continuousAt)).tendsto
  have hc := isOpen_jointCenterDomain.mem_nhds (jointCenterDomain_contains_center dStar fStar)
  refine ⟨p,u,v,hp,hu,hv,hp0,hu0,hv0,?_⟩
  filter_upwards [hcoeff,huroot,hvroot,
    hu.continuousAt.tendsto.eventually_const_lt (by rw [hu0]; norm_num : 0<u 0),
    hu.continuousAt.eventually_lt hv.continuousAt (by rw [hu0,hv0]; norm_num),
    hdu.tendsto.eventually_lt_const hdu0,hdv.tendsto.eventually_const_lt hdv0,
    htu.eventually hQ1.eventually_analyticAt,htv.eventually hQ2.eventually_analyticAt,
    hEu.eventually hc,hEv.eventually hc] with ε hc hr1 hr2 huε huv hd1ε hd2ε ha1 ha2 he1 he2
  exact ⟨hc.1,hc.2,hr1,hr2,huε,huv,hd1ε,hd2ε,ha1,ha2,he1,he2⟩

end LeanVerification.Sharpness
