import LeanVerification.Sharpness.Unfolding

/-! Two distinct simple critical energies of the actual physical period. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness
open Loud GeneralMechanical SharpnessAlgebra
set_option maxHeartbeats 2200000

theorem hasDerivAt_normalizedSlope_of_rescaling {p : ℝ → ℝ×ℝ} {ε z : ℝ}
    (hε : ε≠0)
    (h1 : periodCoefficient (p ε).1 (p ε).2 1=6*aStar*ε^2)
    (h2 : periodCoefficient (p ε).1 (p ε).2 2=-(9/2:ℝ)*aStar*ε)
    (hQ : AnalyticAt ℝ (rescaledSlope p) (ε,z)) :
    HasDerivAt (fun h => normalizedSlope (p ε,h))
      (ε*rescaledSlopeDerivative p (ε,z)) (ε*z) := by
  have hQd : HasDerivAt (fun t => rescaledSlope p (ε,t))
      (rescaledSlopeDerivative p (ε,z)) z := by
    rw [rescaledSlopeDerivative,verticalDerivative_eq_deriv hQ]
    exact hQ.curry_right.differentiableAt.hasDerivAt
  have he : ε*z/ε=z := by field_simp
  have hQd' : HasDerivAt (fun t => rescaledSlope p (ε,t))
      (rescaledSlopeDerivative p (ε,z)) (ε*z/ε) := by rw [he]; exact hQd
  have hd := ((hQd'.comp (ε*z) ((hasDerivAt_id (ε*z)).div_const ε)).const_mul (ε^2))
  simp only [id_eq] at hd
  have hde : ε^2*(rescaledSlopeDerivative p (ε,z)*(1/ε)) =
      ε*rescaledSlopeDerivative p (ε,z) := by field_simp; ring
  rw [hde] at hd
  apply hd.congr_of_eventuallyEq
  exact Filter.Eventually.of_forall (fun h => by
    have hs := actual_rescaled_slope_identity h1 h2 (h/ε)
    simpa only [mul_div_cancel₀ h hε] using hs)

theorem isolatedCriticalEnergy_of_simple {D F h : ℝ}
    (hh : AdmissibleEnergy D F h)
    (hz : deriv (periodQuadrature D F) h=0)
    (hd : deriv (deriv (periodQuadrature D F)) h≠0) :
    IsolatedCriticalEnergy D F h := by
  have ha := (analyticAt_periodQuadrature_energy D F h hh).deriv
  have hn : ¬ ∀ᶠ k in 𝓝 h, deriv (periodQuadrature D F) k=0 := by
    intro he
    have heq : deriv (periodQuadrature D F) =ᶠ[𝓝 h] (fun _ => (0:ℝ)) := he
    have hz' := heq.deriv_eq
    exact hd (by simpa only [deriv_const] using hz')
  have hpunc := ha.eventually_eq_zero_or_eventually_ne_zero.resolve_left hn
  have he : ∀ᶠ k in 𝓝 h, k≠h → deriv (periodQuadrature D F) k≠0 := by
    simpa only [eventually_nhdsWithin_iff,mem_compl_iff,mem_singleton_iff] using hpunc
  obtain ⟨ε,hε,he⟩ := Metric.eventually_nhds_iff.mp he
  refine ⟨hh,hz,ε,hε,?_⟩
  intro k _ hk hdist
  exact he (by simpa only [Real.dist_eq] using hdist) hk

def SimpleCriticalEnergy (D F h : ℝ) : Prop :=
  AdmissibleEnergy D F h ∧ deriv (periodQuadrature D F) h=0 ∧
    deriv (deriv (periodQuadrature D F)) h≠0

theorem simpleCriticalEnergy_isolated {D F h : ℝ} (hh : SimpleCriticalEnergy D F h) :
    IsolatedCriticalEnergy D F h :=
  isolatedCriticalEnergy_of_simple hh.1 hh.2.1 hh.2.2

theorem simpleCriticalEnergy_multiplicity_one {D F h : ℝ}
    (hh : SimpleCriticalEnergy D F h) :
    AnalyticMultiplicity.vanishingOrder (deriv (periodQuadrature D F)) h=1 := by
  rw [AnalyticMultiplicity.vanishingOrder_eq
    (analyticAt_periodQuadrature_energy D F h hh.1).deriv]
  exact AnalyticMultiplicity.order_eq_one_of_deriv_ne_zero
    (analyticAt_periodQuadrature_energy D F h hh.1).deriv hh.2.1 hh.2.2

theorem actual_physical_critical_point_of_rescaling {p : ℝ → ℝ×ℝ} {ε z : ℝ}
    (hε : 0<ε) (hz : 0<z)
    (h1 : periodCoefficient (p ε).1 (p ε).2 1=6*aStar*ε^2)
    (h2 : periodCoefficient (p ε).1 (p ε).2 2=-(9/2:ℝ)*aStar*ε)
    (hQ : AnalyticAt ℝ (rescaledSlope p) (ε,z))
    (hr : rescaledSlope p (ε,z)=0)
    (he : (p ε,ε*z)∈jointCenterDomain) :
    AdmissibleEnergy (p ε).1 (p ε).2 (ε*z) ∧
    deriv (periodQuadrature (p ε).1 (p ε).2) (ε*z)=0 ∧
    deriv (deriv (periodQuadrature (p ε).1 (p ε).2)) (ε*z)=
      (2*Real.pi)*ε*rescaledSlopeDerivative p (ε,z) := by
  have hpos : 0<ε*z := mul_pos hε hz
  have had := (jointCenterPeriod_eq_periodQuadrature he hpos).1
  have hzero := actual_rescaled_slope_identity h1 h2 z
  rw [hr,mul_zero,normalizedSlope_eq_physical_derivative he hpos] at hzero
  have hd := hasDerivAt_normalizedSlope_of_rescaling (ne_of_gt hε) h1 h2 hQ
  have hT := hasDerivAt_physical_derivative_of_slope he hpos hd
  refine ⟨had,(div_eq_zero_iff.mp hzero).resolve_right (mul_ne_zero (by norm_num) Real.pi_ne_zero),?_⟩
  simpa only [mul_assoc] using hT.deriv

theorem exists_two_simple_physical_critical_paths :
    ∃ (p : ℝ → ℝ×ℝ) (h₁ h₂ : ℝ → ℝ),
      AnalyticAt ℝ p 0 ∧ AnalyticAt ℝ h₁ 0 ∧ AnalyticAt ℝ h₂ 0 ∧
      p 0=(dStar,fStar) ∧ h₁ 0=0 ∧ h₂ 0=0 ∧
      deriv h₁ 0=1 ∧ deriv h₂ 0=2 ∧
      ∃ δ>0, ∀ ε, 0<ε → ε<δ →
        0<h₁ ε ∧ h₁ ε<h₂ ε ∧
        SimpleCriticalEnergy (p ε).1 (p ε).2 (h₁ ε) ∧
        SimpleCriticalEnergy (p ε).1 (p ε).2 (h₂ ε) ∧
        deriv (deriv (periodQuadrature (p ε).1 (p ε).2)) (h₁ ε)<0 ∧
        0<deriv (deriv (periodQuadrature (p ε).1 (p ε).2)) (h₂ ε) := by
  obtain ⟨p,u,v,hp,hu,hv,hp0,hu0,hv0,hev⟩ := exists_actual_rescaled_root_paths
  let h₁ : ℝ → ℝ := fun ε => ε*u ε
  let h₂ : ℝ → ℝ := fun ε => ε*v ε
  have hh1 : AnalyticAt ℝ h₁ 0 := analyticAt_id.mul hu
  have hh2 : AnalyticAt ℝ h₂ 0 := analyticAt_id.mul hv
  have hd1 : deriv h₁ 0=1 := by
    have hd := (hasDerivAt_id 0).mul hu.differentiableAt.hasDerivAt
    simpa only [id_eq,hu0,one_mul,zero_mul,add_zero] using hd.deriv
  have hd2 : deriv h₂ 0=2 := by
    have hd := (hasDerivAt_id 0).mul hv.differentiableAt.hasDerivAt
    simpa only [id_eq,hv0,one_mul,zero_mul,add_zero] using hd.deriv
  refine ⟨p,h₁,h₂,hp,hh1,hh2,hp0,by simp only [h₁,zero_mul],
    by simp only [h₂,zero_mul],hd1,hd2,?_⟩
  obtain ⟨δ,hδ,hlocal⟩ := Metric.eventually_nhds_iff.mp hev
  refine ⟨δ,hδ,?_⟩
  intro ε hε hεδ
  have he := hlocal (y:=ε) (by simpa only [Real.dist_eq,sub_zero,abs_of_pos hε] using hεδ)
  rcases he with ⟨hc1,hc2,hr1,hr2,huε,huv,hd1ε,hd2ε,ha1,ha2,he1,he2⟩
  have hvε := huε.trans huv
  have hcrit1 := actual_physical_critical_point_of_rescaling hε huε hc1 hc2 ha1 hr1 he1
  have hcrit2 := actual_physical_critical_point_of_rescaling hε hvε hc1 hc2 ha2 hr2 he2
  have hfactor : 0<(2*Real.pi)*ε := mul_pos (mul_pos (by norm_num) Real.pi_pos) hε
  have hsign1 : deriv (deriv (periodQuadrature (p ε).1 (p ε).2)) (h₁ ε)<0 := by
    change deriv (deriv (periodQuadrature (p ε).1 (p ε).2)) (ε*u ε)<0
    rw [hcrit1.2.2]
    exact mul_neg_of_pos_of_neg hfactor hd1ε
  have hsign2 : 0<deriv (deriv (periodQuadrature (p ε).1 (p ε).2)) (h₂ ε) := by
    change 0<deriv (deriv (periodQuadrature (p ε).1 (p ε).2)) (ε*v ε)
    rw [hcrit2.2.2]
    exact mul_pos hfactor hd2ε
  exact ⟨mul_pos hε huε,mul_lt_mul_of_pos_left huv hε,
    ⟨hcrit1.1,hcrit1.2.1,ne_of_lt hsign1⟩,
    ⟨hcrit2.1,hcrit2.2.1,ne_of_gt hsign2⟩,hsign1,hsign2⟩

theorem exists_two_distinct_simple_physical_critical_energies :
    ∃ D F h₁ h₂ : ℝ, 0<h₁ ∧ h₁<h₂ ∧
      SimpleCriticalEnergy D F h₁ ∧ SimpleCriticalEnergy D F h₂ := by
  obtain ⟨p,h₁,h₂,_,_,_,_,_,_,_,_,δ,hδ,hpath⟩ := exists_two_simple_physical_critical_paths
  have h := hpath (δ/2) (by linarith) (by linarith)
  exact ⟨(p (δ/2)).1,(p (δ/2)).2,h₁ (δ/2),h₂ (δ/2),h.1,h.2.1,h.2.2.1,h.2.2.2.1⟩

theorem sharpness_two_isolated_critical_periods :
    ∃ D F : ℝ, ∃ s : Finset ℝ, s.card=2 ∧ ∀ h∈s, IsolatedCriticalEnergy D F h := by
  classical
  obtain ⟨D,F,h₁,h₂,_,hlt,hs1,hs2⟩ := exists_two_distinct_simple_physical_critical_energies
  refine ⟨D,F,{h₁,h₂},?_,?_⟩
  · exact Finset.card_pair (ne_of_lt hlt)
  · intro h hh
    simp only [Finset.mem_insert,Finset.mem_singleton] at hh
    rcases hh with rfl|rfl
    · exact simpleCriticalEnergy_isolated hs1
    · exact simpleCriticalEnergy_isolated hs2

end LeanVerification.Sharpness
