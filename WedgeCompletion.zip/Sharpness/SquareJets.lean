import LeanVerification.Sharpness.MorseJets

/-! Actual even-amplitude and energy derivative conversion. -/
noncomputable section
open Filter Set
open scoped Topology
namespace LeanVerification.Sharpness
set_option maxHeartbeats 1600000

def squareJet (f : ℝ → ℝ) (n : ℕ) (x : ℝ) := iteratedDeriv n f (x^2/2)

theorem hasDerivAt_squareJet {f : ℝ → ℝ} {x : ℝ}
    (hf : AnalyticAt ℝ f (x^2/2)) (n : ℕ) :
    HasDerivAt (squareJet f n) (squareJet f (n+1) x*x) x := by
  have hd := (hf.iterated_deriv n).differentiableAt.hasDerivAt.comp x
    (((hasDerivAt_id x).pow 2).div_const 2)
  change HasDerivAt (fun u => iteratedDeriv n f (u^2/2))
    (iteratedDeriv (n+1) f (x^2/2)*x) x
  rw [iteratedDeriv_succ]
  convert hd using 1 <;> simp only [iteratedDeriv_eq_iterate,Function.comp_def,id_eq,
    Nat.reduceSub,Nat.cast_ofNat,pow_one,mul_one] <;> ring

def squareChain0 (P : ℕ → ℝ) (x : ℝ) := P 0

def squareChain1 (P : ℕ → ℝ) (x : ℝ) := (P 1 * x)

def squareChain2 (P : ℕ → ℝ) (x : ℝ) := (P 1 + (P 2 * (x ^ 2)))

def squareChain3 (P : ℕ → ℝ) (x : ℝ) := ((P 3 * (x ^ 3)) + (3 * P 2 * x))

def squareChain4 (P : ℕ → ℝ) (x : ℝ) := ((3 * P 2) + (P 4 * (x ^ 4)) + (6 * P 3 * (x ^ 2)))

def squareChain5 (P : ℕ → ℝ) (x : ℝ) := ((P 5 * (x ^ 5)) + (10 * P 4 * (x ^ 3)) + (15 * P 3 * x))

def squareChain6 (P : ℕ → ℝ) (x : ℝ) := ((15 * P 3) + (P 6 * (x ^ 6)) + (15 * P 5 * (x ^ 4)) + (45 * P 4 * (x ^ 2)))

theorem hasDerivAt_squareChain0 {f : ℝ → ℝ} {x : ℝ}
    (hf : AnalyticAt ℝ f (x^2/2)) :
    HasDerivAt (fun u => squareChain0 (fun k => squareJet f k u) u)
      (squareChain1 (fun k => squareJet f k x) x) x := by
  have hP := hasDerivAt_squareJet hf
  have hd := hP 0
  convert hd using 1 <;> dsimp only [squareChain0,squareChain1,id_eq] <;> ring

theorem hasDerivAt_squareChain1 {f : ℝ → ℝ} {x : ℝ}
    (hf : AnalyticAt ℝ f (x^2/2)) :
    HasDerivAt (fun u => squareChain1 (fun k => squareJet f k u) u)
      (squareChain2 (fun k => squareJet f k x) x) x := by
  have hP := hasDerivAt_squareJet hf
  have hd := (hP 1).mul (hasDerivAt_id x)
  convert hd using 1 <;> dsimp only [squareChain1,squareChain2,id_eq] <;> ring

theorem hasDerivAt_squareChain2 {f : ℝ → ℝ} {x : ℝ}
    (hf : AnalyticAt ℝ f (x^2/2)) :
    HasDerivAt (fun u => squareChain2 (fun k => squareJet f k u) u)
      (squareChain3 (fun k => squareJet f k x) x) x := by
  have hP := hasDerivAt_squareJet hf
  have hd := (hP 1).add ((hP 2).mul ((hasDerivAt_id x).pow 2))
  convert hd using 1 <;> dsimp only [squareChain2,squareChain3,id_eq] <;> ring

theorem hasDerivAt_squareChain3 {f : ℝ → ℝ} {x : ℝ}
    (hf : AnalyticAt ℝ f (x^2/2)) :
    HasDerivAt (fun u => squareChain3 (fun k => squareJet f k u) u)
      (squareChain4 (fun k => squareJet f k x) x) x := by
  have hP := hasDerivAt_squareJet hf
  have hd := ((hP 3).mul ((hasDerivAt_id x).pow 3)).add (((hasDerivAt_const x (3)).mul (hP 2)).mul (hasDerivAt_id x))
  convert hd using 1 <;> dsimp only [squareChain3,squareChain4,id_eq] <;> ring

theorem hasDerivAt_squareChain4 {f : ℝ → ℝ} {x : ℝ}
    (hf : AnalyticAt ℝ f (x^2/2)) :
    HasDerivAt (fun u => squareChain4 (fun k => squareJet f k u) u)
      (squareChain5 (fun k => squareJet f k x) x) x := by
  have hP := hasDerivAt_squareJet hf
  have hd := (((hasDerivAt_const x (3)).mul (hP 2)).add ((hP 4).mul ((hasDerivAt_id x).pow 4))).add (((hasDerivAt_const x (6)).mul (hP 3)).mul ((hasDerivAt_id x).pow 2))
  convert hd using 1 <;> dsimp only [squareChain4,squareChain5,id_eq] <;> ring

theorem hasDerivAt_squareChain5 {f : ℝ → ℝ} {x : ℝ}
    (hf : AnalyticAt ℝ f (x^2/2)) :
    HasDerivAt (fun u => squareChain5 (fun k => squareJet f k u) u)
      (squareChain6 (fun k => squareJet f k x) x) x := by
  have hP := hasDerivAt_squareJet hf
  have hd := (((hP 5).mul ((hasDerivAt_id x).pow 5)).add (((hasDerivAt_const x (10)).mul (hP 4)).mul ((hasDerivAt_id x).pow 3))).add (((hasDerivAt_const x (15)).mul (hP 3)).mul (hasDerivAt_id x))
  convert hd using 1 <;> dsimp only [squareChain5,squareChain6,id_eq] <;> ring

theorem square_composition_center_jets {f : ℝ → ℝ} (hf : AnalyticAt ℝ f 0) :
    iteratedDeriv 2 (fun x => f (x^2/2)) 0 = deriv f 0 ∧
    iteratedDeriv 4 (fun x => f (x^2/2)) 0 = 3*iteratedDeriv 2 f 0 ∧
    iteratedDeriv 6 (fun x => f (x^2/2)) 0 = 15*iteratedDeriv 3 f 0 := by
  have ha : ∀ᶠ x : ℝ in 𝓝 0, AnalyticAt ℝ f (x^2/2) := by
    exact (show ContinuousAt (fun x:ℝ => x^2/2) 0 by fun_prop).eventually
      (by simpa using hf.eventually_analyticAt)
  have h0 : iteratedDeriv 0 (fun x => f (x^2/2)) =ᶠ[𝓝 0]
      (fun x => squareChain0 (fun k => squareJet f k x) x) := by
    filter_upwards [] with x
    simp [squareChain0,squareJet]
  have h1 : iteratedDeriv 1 (fun x => f (x^2/2)) =ᶠ[𝓝 0]
      (fun x => squareChain1 (fun k => squareJet f k x) x) := by
    filter_upwards [ha,eventually_eventually_nhds.mpr h0] with x hx he
    have heq : iteratedDeriv 0 (fun x => f (x^2/2)) =ᶠ[𝓝 x]
      (fun x => squareChain0 (fun k => squareJet f k x) x) := he
    rw [show 1=0+1 by rfl,iteratedDeriv_succ,heq.deriv_eq]
    exact (hasDerivAt_squareChain0 hx).deriv
  have h2 : iteratedDeriv 2 (fun x => f (x^2/2)) =ᶠ[𝓝 0]
      (fun x => squareChain2 (fun k => squareJet f k x) x) := by
    filter_upwards [ha,eventually_eventually_nhds.mpr h1] with x hx he
    have heq : iteratedDeriv 1 (fun x => f (x^2/2)) =ᶠ[𝓝 x]
      (fun x => squareChain1 (fun k => squareJet f k x) x) := he
    rw [show 2=1+1 by rfl,iteratedDeriv_succ,heq.deriv_eq]
    exact (hasDerivAt_squareChain1 hx).deriv
  have h3 : iteratedDeriv 3 (fun x => f (x^2/2)) =ᶠ[𝓝 0]
      (fun x => squareChain3 (fun k => squareJet f k x) x) := by
    filter_upwards [ha,eventually_eventually_nhds.mpr h2] with x hx he
    have heq : iteratedDeriv 2 (fun x => f (x^2/2)) =ᶠ[𝓝 x]
      (fun x => squareChain2 (fun k => squareJet f k x) x) := he
    rw [show 3=2+1 by rfl,iteratedDeriv_succ,heq.deriv_eq]
    exact (hasDerivAt_squareChain2 hx).deriv
  have h4 : iteratedDeriv 4 (fun x => f (x^2/2)) =ᶠ[𝓝 0]
      (fun x => squareChain4 (fun k => squareJet f k x) x) := by
    filter_upwards [ha,eventually_eventually_nhds.mpr h3] with x hx he
    have heq : iteratedDeriv 3 (fun x => f (x^2/2)) =ᶠ[𝓝 x]
      (fun x => squareChain3 (fun k => squareJet f k x) x) := he
    rw [show 4=3+1 by rfl,iteratedDeriv_succ,heq.deriv_eq]
    exact (hasDerivAt_squareChain3 hx).deriv
  have h5 : iteratedDeriv 5 (fun x => f (x^2/2)) =ᶠ[𝓝 0]
      (fun x => squareChain5 (fun k => squareJet f k x) x) := by
    filter_upwards [ha,eventually_eventually_nhds.mpr h4] with x hx he
    have heq : iteratedDeriv 4 (fun x => f (x^2/2)) =ᶠ[𝓝 x]
      (fun x => squareChain4 (fun k => squareJet f k x) x) := he
    rw [show 5=4+1 by rfl,iteratedDeriv_succ,heq.deriv_eq]
    exact (hasDerivAt_squareChain4 hx).deriv
  have h6 : iteratedDeriv 6 (fun x => f (x^2/2)) =ᶠ[𝓝 0]
      (fun x => squareChain6 (fun k => squareJet f k x) x) := by
    filter_upwards [ha,eventually_eventually_nhds.mpr h5] with x hx he
    have heq : iteratedDeriv 5 (fun x => f (x^2/2)) =ᶠ[𝓝 x]
      (fun x => squareChain5 (fun k => squareJet f k x) x) := he
    rw [show 6=5+1 by rfl,iteratedDeriv_succ,heq.deriv_eq]
    exact (hasDerivAt_squareChain5 hx).deriv
  refine ⟨?_,?_,?_⟩
  · simpa [squareChain2,squareJet,iteratedDeriv_one] using h2.self_of_nhds
  · simpa [squareChain4,squareJet] using h4.self_of_nhds
  · simpa [squareChain6,squareJet] using h6.self_of_nhds

end LeanVerification.Sharpness
