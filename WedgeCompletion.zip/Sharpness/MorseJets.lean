import LeanVerification.Sharpness.ForceTaylor
import LeanVerification.Loud.SpatialFlightVariation

/-! Finite derivative certificates for the actual inverse Morse coordinate. -/
noncomputable section
open Filter Set
open scoped Topology
namespace LeanVerification.Sharpness
open Loud
set_option maxHeartbeats 2400000
set_option maxRecDepth 10000

def positionJet (ψ : ℝ → ℝ) (n : ℕ) (x : ℝ) := iteratedDeriv n ψ x
def forceJet (g ψ : ℝ → ℝ) (n : ℕ) (x : ℝ) := iteratedDeriv n g (ψ x)

theorem hasDerivAt_positionJet {ψ : ℝ → ℝ} {x : ℝ}
    (hψ : AnalyticAt ℝ ψ x) (n : ℕ) :
    HasDerivAt (positionJet ψ n) (positionJet ψ (n+1) x) x := by
  change HasDerivAt (iteratedDeriv n ψ) (iteratedDeriv (n+1) ψ x) x
  rw [iteratedDeriv_succ]
  simpa only [iteratedDeriv_eq_iterate] using
    (hψ.iterated_deriv n).differentiableAt.hasDerivAt

theorem hasDerivAt_forceJet {g ψ : ℝ → ℝ} {x : ℝ}
    (hg : AnalyticAt ℝ g (ψ x)) (hψ : AnalyticAt ℝ ψ x) (n : ℕ) :
    HasDerivAt (forceJet g ψ n)
      (forceJet g ψ (n+1) x * positionJet ψ 1 x) x := by
  have hd := (hg.iterated_deriv n).differentiableAt.hasDerivAt.comp x
    hψ.differentiableAt.hasDerivAt
  change HasDerivAt (fun u => iteratedDeriv n g (ψ u))
    (iteratedDeriv (n+1) g (ψ x) * iteratedDeriv 1 ψ x) x
  rw [iteratedDeriv_one, iteratedDeriv_succ]
  simpa only [iteratedDeriv_eq_iterate, Function.comp_def] using hd

def chain0 (G P : ℕ → ℝ) : ℝ :=
  (G 0 * P 1)

def chain1 (G P : ℕ → ℝ) : ℝ :=
  ((G 0 * P 2) + (G 1 * (P 1 ^ 2)))

def chain2 (G P : ℕ → ℝ) : ℝ :=
  ((G 0 * P 3) + (G 2 * (P 1 ^ 3)) + (3 * G 1 * P 1 * P 2))

def chain3 (G P : ℕ → ℝ) : ℝ :=
  ((G 0 * P 4) + (G 3 * (P 1 ^ 4)) + (3 * G 1 * (P 2 ^ 2)) + (4 * G 1 * P 1 * P 3) + (6 * G 2 * P 2 * (P 1 ^ 2)))

def chain4 (G P : ℕ → ℝ) : ℝ :=
  ((G 0 * P 5) + (G 4 * (P 1 ^ 5)) + (5 * G 1 * P 1 * P 4) + (10 * G 1 * P 2 * P 3) + (10 * G 2 * P 3 * (P 1 ^ 2)) + (10 * G 3 * P 2 * (P 1 ^ 3)) + (15 * G 2 * P 1 * (P 2 ^ 2)))

def chain5 (G P : ℕ → ℝ) : ℝ :=
  ((G 0 * P 6) + (G 5 * (P 1 ^ 6)) + (10 * G 1 * (P 3 ^ 2)) + (15 * G 2 * (P 2 ^ 3)) + (6 * G 1 * P 1 * P 5) + (15 * G 1 * P 2 * P 4) + (15 * G 2 * P 4 * (P 1 ^ 2)) + (15 * G 4 * P 2 * (P 1 ^ 4)) + (20 * G 3 * P 3 * (P 1 ^ 3)) + (45 * G 3 * (P 1 ^ 2) * (P 2 ^ 2)) + (60 * G 2 * P 1 * P 2 * P 3))

def chain6 (G P : ℕ → ℝ) : ℝ :=
  ((G 0 * P 7) + (G 6 * (P 1 ^ 7)) + (7 * G 1 * P 1 * P 6) + (21 * G 1 * P 2 * P 5) + (21 * G 2 * P 5 * (P 1 ^ 2)) + (21 * G 5 * P 2 * (P 1 ^ 5)) + (35 * G 1 * P 3 * P 4) + (35 * G 3 * P 4 * (P 1 ^ 3)) + (35 * G 4 * P 3 * (P 1 ^ 4)) + (70 * G 2 * P 1 * (P 3 ^ 2)) + (105 * G 2 * P 3 * (P 2 ^ 2)) + (105 * G 3 * P 1 * (P 2 ^ 3)) + (105 * G 4 * (P 1 ^ 3) * (P 2 ^ 2)) + (105 * G 2 * P 1 * P 2 * P 4) + (210 * G 3 * P 2 * P 3 * (P 1 ^ 2)))

def chain7 (G P : ℕ → ℝ) : ℝ :=
  ((G 0 * P 8) + (G 7 * (P 1 ^ 8)) + (35 * G 1 * (P 4 ^ 2)) + (105 * G 3 * (P 2 ^ 4)) + (8 * G 1 * P 1 * P 7) + (28 * G 1 * P 2 * P 6) + (28 * G 2 * P 6 * (P 1 ^ 2)) + (28 * G 6 * P 2 * (P 1 ^ 6)) + (56 * G 1 * P 3 * P 5) + (56 * G 3 * P 5 * (P 1 ^ 3)) + (56 * G 5 * P 3 * (P 1 ^ 5)) + (70 * G 4 * P 4 * (P 1 ^ 4)) + (210 * G 2 * P 4 * (P 2 ^ 2)) + (210 * G 5 * (P 1 ^ 4) * (P 2 ^ 2)) + (280 * G 2 * P 2 * (P 3 ^ 2)) + (280 * G 3 * (P 1 ^ 2) * (P 3 ^ 2)) + (420 * G 4 * (P 1 ^ 2) * (P 2 ^ 3)) + (168 * G 2 * P 1 * P 2 * P 5) + (280 * G 2 * P 1 * P 3 * P 4) + (420 * G 3 * P 2 * P 4 * (P 1 ^ 2)) + (560 * G 4 * P 2 * P 3 * (P 1 ^ 3)) + (840 * G 3 * P 1 * P 3 * (P 2 ^ 2)))

theorem hasDerivAt_chain0 {g ψ : ℝ → ℝ} {x : ℝ}
    (hg : AnalyticAt ℝ g (ψ x)) (hψ : AnalyticAt ℝ ψ x) :
    HasDerivAt (fun u => chain0 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u))
      (chain1 (fun k => forceJet g ψ k x) (fun k => positionJet ψ k x)) x := by
  have hG := hasDerivAt_forceJet hg hψ
  have hP := hasDerivAt_positionJet hψ
  have hd := (hG 0).mul (hP 1)
  convert hd using 1 <;> dsimp only [chain0, chain1] <;> ring

theorem hasDerivAt_chain1 {g ψ : ℝ → ℝ} {x : ℝ}
    (hg : AnalyticAt ℝ g (ψ x)) (hψ : AnalyticAt ℝ ψ x) :
    HasDerivAt (fun u => chain1 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u))
      (chain2 (fun k => forceJet g ψ k x) (fun k => positionJet ψ k x)) x := by
  have hG := hasDerivAt_forceJet hg hψ
  have hP := hasDerivAt_positionJet hψ
  have hd := ((hG 0).mul (hP 2)).add ((hG 1).mul ((hP 1).pow 2))
  convert hd using 1 <;> dsimp only [chain1, chain2] <;> ring

theorem hasDerivAt_chain2 {g ψ : ℝ → ℝ} {x : ℝ}
    (hg : AnalyticAt ℝ g (ψ x)) (hψ : AnalyticAt ℝ ψ x) :
    HasDerivAt (fun u => chain2 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u))
      (chain3 (fun k => forceJet g ψ k x) (fun k => positionJet ψ k x)) x := by
  have hG := hasDerivAt_forceJet hg hψ
  have hP := hasDerivAt_positionJet hψ
  have hd := (((hG 0).mul (hP 3)).add ((hG 2).mul ((hP 1).pow 3))).add ((((hasDerivAt_const x (3)).mul (hG 1)).mul (hP 1)).mul (hP 2))
  convert hd using 1 <;> dsimp only [chain2, chain3] <;> ring

theorem hasDerivAt_chain3 {g ψ : ℝ → ℝ} {x : ℝ}
    (hg : AnalyticAt ℝ g (ψ x)) (hψ : AnalyticAt ℝ ψ x) :
    HasDerivAt (fun u => chain3 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u))
      (chain4 (fun k => forceJet g ψ k x) (fun k => positionJet ψ k x)) x := by
  have hG := hasDerivAt_forceJet hg hψ
  have hP := hasDerivAt_positionJet hψ
  have hd := (((((hG 0).mul (hP 4)).add ((hG 3).mul ((hP 1).pow 4))).add (((hasDerivAt_const x (3)).mul (hG 1)).mul ((hP 2).pow 2))).add ((((hasDerivAt_const x (4)).mul (hG 1)).mul (hP 1)).mul (hP 3))).add ((((hasDerivAt_const x (6)).mul (hG 2)).mul (hP 2)).mul ((hP 1).pow 2))
  convert hd using 1 <;> dsimp only [chain3, chain4] <;> ring

theorem hasDerivAt_chain4 {g ψ : ℝ → ℝ} {x : ℝ}
    (hg : AnalyticAt ℝ g (ψ x)) (hψ : AnalyticAt ℝ ψ x) :
    HasDerivAt (fun u => chain4 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u))
      (chain5 (fun k => forceJet g ψ k x) (fun k => positionJet ψ k x)) x := by
  have hG := hasDerivAt_forceJet hg hψ
  have hP := hasDerivAt_positionJet hψ
  have hd := (((((((hG 0).mul (hP 5)).add ((hG 4).mul ((hP 1).pow 5))).add ((((hasDerivAt_const x (5)).mul (hG 1)).mul (hP 1)).mul (hP 4))).add ((((hasDerivAt_const x (10)).mul (hG 1)).mul (hP 2)).mul (hP 3))).add ((((hasDerivAt_const x (10)).mul (hG 2)).mul (hP 3)).mul ((hP 1).pow 2))).add ((((hasDerivAt_const x (10)).mul (hG 3)).mul (hP 2)).mul ((hP 1).pow 3))).add ((((hasDerivAt_const x (15)).mul (hG 2)).mul (hP 1)).mul ((hP 2).pow 2))
  convert hd using 1 <;> dsimp only [chain4, chain5] <;> ring

theorem hasDerivAt_chain5 {g ψ : ℝ → ℝ} {x : ℝ}
    (hg : AnalyticAt ℝ g (ψ x)) (hψ : AnalyticAt ℝ ψ x) :
    HasDerivAt (fun u => chain5 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u))
      (chain6 (fun k => forceJet g ψ k x) (fun k => positionJet ψ k x)) x := by
  have hG := hasDerivAt_forceJet hg hψ
  have hP := hasDerivAt_positionJet hψ
  have hd := (((((((((((hG 0).mul (hP 6)).add ((hG 5).mul ((hP 1).pow 6))).add (((hasDerivAt_const x (10)).mul (hG 1)).mul ((hP 3).pow 2))).add (((hasDerivAt_const x (15)).mul (hG 2)).mul ((hP 2).pow 3))).add ((((hasDerivAt_const x (6)).mul (hG 1)).mul (hP 1)).mul (hP 5))).add ((((hasDerivAt_const x (15)).mul (hG 1)).mul (hP 2)).mul (hP 4))).add ((((hasDerivAt_const x (15)).mul (hG 2)).mul (hP 4)).mul ((hP 1).pow 2))).add ((((hasDerivAt_const x (15)).mul (hG 4)).mul (hP 2)).mul ((hP 1).pow 4))).add ((((hasDerivAt_const x (20)).mul (hG 3)).mul (hP 3)).mul ((hP 1).pow 3))).add ((((hasDerivAt_const x (45)).mul (hG 3)).mul ((hP 1).pow 2)).mul ((hP 2).pow 2))).add (((((hasDerivAt_const x (60)).mul (hG 2)).mul (hP 1)).mul (hP 2)).mul (hP 3))
  convert hd using 1 <;> dsimp only [chain5, chain6] <;> ring

theorem hasDerivAt_chain6 {g ψ : ℝ → ℝ} {x : ℝ}
    (hg : AnalyticAt ℝ g (ψ x)) (hψ : AnalyticAt ℝ ψ x) :
    HasDerivAt (fun u => chain6 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u))
      (chain7 (fun k => forceJet g ψ k x) (fun k => positionJet ψ k x)) x := by
  have hG := hasDerivAt_forceJet hg hψ
  have hP := hasDerivAt_positionJet hψ
  have hd := (((((((((((((((hG 0).mul (hP 7)).add ((hG 6).mul ((hP 1).pow 7))).add ((((hasDerivAt_const x (7)).mul (hG 1)).mul (hP 1)).mul (hP 6))).add ((((hasDerivAt_const x (21)).mul (hG 1)).mul (hP 2)).mul (hP 5))).add ((((hasDerivAt_const x (21)).mul (hG 2)).mul (hP 5)).mul ((hP 1).pow 2))).add ((((hasDerivAt_const x (21)).mul (hG 5)).mul (hP 2)).mul ((hP 1).pow 5))).add ((((hasDerivAt_const x (35)).mul (hG 1)).mul (hP 3)).mul (hP 4))).add ((((hasDerivAt_const x (35)).mul (hG 3)).mul (hP 4)).mul ((hP 1).pow 3))).add ((((hasDerivAt_const x (35)).mul (hG 4)).mul (hP 3)).mul ((hP 1).pow 4))).add ((((hasDerivAt_const x (70)).mul (hG 2)).mul (hP 1)).mul ((hP 3).pow 2))).add ((((hasDerivAt_const x (105)).mul (hG 2)).mul (hP 3)).mul ((hP 2).pow 2))).add ((((hasDerivAt_const x (105)).mul (hG 3)).mul (hP 1)).mul ((hP 2).pow 3))).add ((((hasDerivAt_const x (105)).mul (hG 4)).mul ((hP 1).pow 3)).mul ((hP 2).pow 2))).add (((((hasDerivAt_const x (105)).mul (hG 2)).mul (hP 1)).mul (hP 2)).mul (hP 4))).add (((((hasDerivAt_const x (210)).mul (hG 3)).mul (hP 2)).mul (hP 3)).mul ((hP 1).pow 2))
  convert hd using 1 <;> dsimp only [chain6, chain7] <;> ring

theorem morse_chain_equations (D F : ℝ) :
    chain2 (fun k => forceJet (forceInPosition D F) (morsePosition D F) k 0)
      (fun k => positionJet (morsePosition D F) k 0) = 0 ∧
    chain3 (fun k => forceJet (forceInPosition D F) (morsePosition D F) k 0)
      (fun k => positionJet (morsePosition D F) k 0) = 0 ∧
    chain4 (fun k => forceJet (forceInPosition D F) (morsePosition D F) k 0)
      (fun k => positionJet (morsePosition D F) k 0) = 0 ∧
    chain5 (fun k => forceJet (forceInPosition D F) (morsePosition D F) k 0)
      (fun k => positionJet (morsePosition D F) k 0) = 0 ∧
    chain6 (fun k => forceJet (forceInPosition D F) (morsePosition D F) k 0)
      (fun k => positionJet (morsePosition D F) k 0) = 0 ∧
    chain7 (fun k => forceJet (forceInPosition D F) (morsePosition D F) k 0)
      (fun k => positionJet (morsePosition D F) k 0) = 0 := by
  let g := forceInPosition D F
  let ψ := morsePosition D F
  have hnh : morseRange D F ∈ 𝓝 (0:ℝ) := (isOpen_morseRange D F).mem_nhds (morseRange_zero D F)
  have hψ : ∀ u ∈ morseRange D F, AnalyticAt ℝ ψ u := analyticAt_morsePosition D F
  have hg : ∀ u ∈ morseRange D F, AnalyticAt ℝ g (ψ u) := by
    intro u hu
    exact analyticAt_forceInPosition D F _ (mechanicalDomain_morsePosition D F u hu)
  have h0 : (fun u => chain0 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u)) =ᶠ[𝓝 0] id := by
    filter_upwards [hnh] with u hu
    simp only [chain0,forceJet,positionJet,iteratedDeriv_zero,iteratedDeriv_one,id_eq,g,ψ]
    rw [force_morsePosition D F u hu]
    exact div_mul_cancel₀ u (morsePosition_deriv_pos D F u hu).ne'
  have h1 : (fun u => chain1 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u)) =ᶠ[𝓝 0]
      (fun _ : ℝ => (1:ℝ)) := by
    filter_upwards [hnh, eventually_eventually_nhds.mpr h0] with u hu he
    exact ((hasDerivAt_chain0 (hg u hu) (hψ u hu)).congr_of_eventuallyEq (Filter.EventuallyEq.symm he)).unique
      (hasDerivAt_id u)
  have h2 : (fun u => chain2 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u)) =ᶠ[𝓝 0]
      (fun _ : ℝ => (0:ℝ)) := by
    filter_upwards [hnh, eventually_eventually_nhds.mpr h1] with u hu he
    exact ((hasDerivAt_chain1 (hg u hu) (hψ u hu)).congr_of_eventuallyEq (Filter.EventuallyEq.symm he)).unique
      (hasDerivAt_const u (1:ℝ))
  have h3 : (fun u => chain3 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u)) =ᶠ[𝓝 0]
      (fun _ : ℝ => (0:ℝ)) := by
    filter_upwards [hnh, eventually_eventually_nhds.mpr h2] with u hu he
    exact ((hasDerivAt_chain2 (hg u hu) (hψ u hu)).congr_of_eventuallyEq (Filter.EventuallyEq.symm he)).unique
      (hasDerivAt_const u (0:ℝ))
  have h4 : (fun u => chain4 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u)) =ᶠ[𝓝 0]
      (fun _ : ℝ => (0:ℝ)) := by
    filter_upwards [hnh, eventually_eventually_nhds.mpr h3] with u hu he
    exact ((hasDerivAt_chain3 (hg u hu) (hψ u hu)).congr_of_eventuallyEq (Filter.EventuallyEq.symm he)).unique
      (hasDerivAt_const u (0:ℝ))
  have h5 : (fun u => chain5 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u)) =ᶠ[𝓝 0]
      (fun _ : ℝ => (0:ℝ)) := by
    filter_upwards [hnh, eventually_eventually_nhds.mpr h4] with u hu he
    exact ((hasDerivAt_chain4 (hg u hu) (hψ u hu)).congr_of_eventuallyEq (Filter.EventuallyEq.symm he)).unique
      (hasDerivAt_const u (0:ℝ))
  have h6 : (fun u => chain6 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u)) =ᶠ[𝓝 0]
      (fun _ : ℝ => (0:ℝ)) := by
    filter_upwards [hnh, eventually_eventually_nhds.mpr h5] with u hu he
    exact ((hasDerivAt_chain5 (hg u hu) (hψ u hu)).congr_of_eventuallyEq (Filter.EventuallyEq.symm he)).unique
      (hasDerivAt_const u (0:ℝ))
  have h7 : (fun u => chain7 (fun k => forceJet g ψ k u) (fun k => positionJet ψ k u)) =ᶠ[𝓝 0]
      (fun _ : ℝ => (0:ℝ)) := by
    filter_upwards [hnh, eventually_eventually_nhds.mpr h6] with u hu he
    exact ((hasDerivAt_chain6 (hg u hu) (hψ u hu)).congr_of_eventuallyEq (Filter.EventuallyEq.symm he)).unique
      (hasDerivAt_const u (0:ℝ))
  exact ⟨h2.self_of_nhds, h3.self_of_nhds, h4.self_of_nhds, h5.self_of_nhds, h6.self_of_nhds, h7.self_of_nhds⟩

def inverseJet2 (G : ℕ → ℝ) : ℝ :=
  ((-1 / 3 : ℝ) * G 2)

def inverseJet3 (G : ℕ → ℝ) : ℝ :=
  (((-1 / 4 : ℝ) * G 3) + ((5 / 12 : ℝ) * (G 2 ^ 2)))

def inverseJet4 (G : ℕ → ℝ) : ℝ :=
  (((-8 / 9 : ℝ) * (G 2 ^ 3)) + ((-1 / 5 : ℝ) * G 4) + (G 2 * G 3))

def inverseJet5 (G : ℕ → ℝ) : ℝ :=
  (((-1 / 6 : ℝ) * G 5) + ((35 / 48 : ℝ) * (G 3 ^ 2)) + ((385 / 144 : ℝ) * (G 2 ^ 4)) + ((-35 / 8 : ℝ) * G 3 * (G 2 ^ 2)) + ((7 / 6 : ℝ) * G 2 * G 4))

def inverseJet6 (G : ℕ → ℝ) : ℝ :=
  (((-280 / 27 : ℝ) * (G 2 ^ 5)) + ((-1 / 7 : ℝ) * G 6) + (2 * G 3 * G 4) + ((-25 / 3 : ℝ) * G 2 * (G 3 ^ 2)) + ((-20 / 3 : ℝ) * G 4 * (G 2 ^ 2)) + ((4 / 3 : ℝ) * G 2 * G 5) + ((200 / 9 : ℝ) * G 3 * (G 2 ^ 3)))

def inverseJet7 (G : ℕ → ℝ) : ℝ :=
  (((-385 / 64 : ℝ) * (G 3 ^ 3)) + ((-1 / 8 : ℝ) * G 7) + ((63 / 40 : ℝ) * (G 4 ^ 2)) + ((85085 / 1728 : ℝ) * (G 2 ^ 6)) + ((-25025 / 192 : ℝ) * G 3 * (G 2 ^ 4)) + ((-77 / 8 : ℝ) * G 5 * (G 2 ^ 2)) + ((3 / 2 : ℝ) * G 2 * G 6) + ((21 / 8 : ℝ) * G 3 * G 5) + ((1001 / 24 : ℝ) * G 4 * (G 2 ^ 3)) + ((5005 / 64 : ℝ) * (G 2 ^ 2) * (G 3 ^ 2)) + ((-231 / 8 : ℝ) * G 2 * G 3 * G 4))

theorem morse_position_jets (D F : ℝ) :
    iteratedDeriv 2 (morsePosition D F) 0 = inverseJet2
      (fun k => iteratedDeriv k (forceInPosition D F) 0) ∧
    iteratedDeriv 3 (morsePosition D F) 0 = inverseJet3
      (fun k => iteratedDeriv k (forceInPosition D F) 0) ∧
    iteratedDeriv 4 (morsePosition D F) 0 = inverseJet4
      (fun k => iteratedDeriv k (forceInPosition D F) 0) ∧
    iteratedDeriv 5 (morsePosition D F) 0 = inverseJet5
      (fun k => iteratedDeriv k (forceInPosition D F) 0) ∧
    iteratedDeriv 6 (morsePosition D F) 0 = inverseJet6
      (fun k => iteratedDeriv k (forceInPosition D F) 0) ∧
    iteratedDeriv 7 (morsePosition D F) 0 = inverseJet7
      (fun k => iteratedDeriv k (forceInPosition D F) 0) := by
  obtain ⟨h2,h3,h4,h5,h6,h7⟩ := morse_chain_equations D F
  have hg0 : forceInPosition D F 0 = 0 := by simp [forceInPosition,force]
  have hg1 : iteratedDeriv 1 (forceInPosition D F) 0 = 1 := by
    rw [force_derivative_at_center]
    simp only [fallingStep_succ, fallingStep_zero, Nat.cast_zero, zero_mul, sub_zero]
    ring
  have hp1 : iteratedDeriv 1 (morsePosition D F) 0 = 1 := by
    simpa only [iteratedDeriv_one] using (hasDerivAt_morsePosition_zero D F).deriv
  simp only [chain2,chain3,chain4,chain5,chain6,chain7,forceJet,positionJet,
    morsePosition_zero,iteratedDeriv_zero,hg0,hg1,hp1,zero_mul,mul_zero,mul_one,one_mul,
    one_pow,zero_add,add_zero] at h2 h3 h4 h5 h6 h7
  have hp2 : iteratedDeriv 2 (morsePosition D F) 0 = inverseJet2
      (fun k => iteratedDeriv k (forceInPosition D F) 0) := by
    dsimp only [inverseJet2] at h2 ⊢
    linear_combination (1 / 3 : ℝ) * h2
  have hp3 : iteratedDeriv 3 (morsePosition D F) 0 = inverseJet3
      (fun k => iteratedDeriv k (forceInPosition D F) 0) := by
    rw [hp2] at h3
    dsimp only [inverseJet2, inverseJet3] at h3 ⊢
    linear_combination (1 / 4 : ℝ) * h3
  have hp4 : iteratedDeriv 4 (morsePosition D F) 0 = inverseJet4
      (fun k => iteratedDeriv k (forceInPosition D F) 0) := by
    rw [hp2, hp3] at h4
    dsimp only [inverseJet2, inverseJet3, inverseJet4] at h4 ⊢
    linear_combination (1 / 5 : ℝ) * h4
  have hp5 : iteratedDeriv 5 (morsePosition D F) 0 = inverseJet5
      (fun k => iteratedDeriv k (forceInPosition D F) 0) := by
    rw [hp2, hp3, hp4] at h5
    dsimp only [inverseJet2, inverseJet3, inverseJet4, inverseJet5] at h5 ⊢
    linear_combination (1 / 6 : ℝ) * h5
  have hp6 : iteratedDeriv 6 (morsePosition D F) 0 = inverseJet6
      (fun k => iteratedDeriv k (forceInPosition D F) 0) := by
    rw [hp2, hp3, hp4, hp5] at h6
    dsimp only [inverseJet2, inverseJet3, inverseJet4, inverseJet5, inverseJet6] at h6 ⊢
    linear_combination (1 / 7 : ℝ) * h6
  have hp7 : iteratedDeriv 7 (morsePosition D F) 0 = inverseJet7
      (fun k => iteratedDeriv k (forceInPosition D F) 0) := by
    rw [hp2, hp3, hp4, hp5, hp6] at h7
    dsimp only [inverseJet2, inverseJet3, inverseJet4, inverseJet5, inverseJet6, inverseJet7] at h7 ⊢
    linear_combination (1 / 8 : ℝ) * h7
  exact ⟨hp2, hp3, hp4, hp5, hp6, hp7⟩

end LeanVerification.Sharpness
