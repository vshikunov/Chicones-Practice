import LeanVerification.Sharpness.TauPolynomials
import LeanVerification.GeneralMechanical.ParametricInverse

/-! The parameter path is constructed from the actual first two period coefficients. -/
noncomputable section
open Filter Set
open scoped Topology
namespace LeanVerification.Sharpness
open Loud SharpnessAlgebra
set_option maxHeartbeats 1600000

theorem plane_linear_formula (L : (ℝ×ℝ) →L[ℝ] (ℝ×ℝ)) (p : ℝ×ℝ) :
    L p = p.1 • L (1,0) + p.2 • L (0,1) := by
  have hp : p = p.1 • ((1,0):ℝ×ℝ) + p.2 • ((0,1):ℝ×ℝ) := by ext <;> simp
  calc
    L p = L (p.1 • ((1,0):ℝ×ℝ) + p.2 • ((0,1):ℝ×ℝ)) := congrArg L hp
    _ = _ := by rw [map_add,map_smul,map_smul]

theorem plane_linear_bijective (L : (ℝ×ℝ) →L[ℝ] (ℝ×ℝ))
    (hdet : (L (1,0)).1*(L (0,1)).2 - (L (0,1)).1*(L (1,0)).2 ≠ 0) :
    Function.Bijective L := by
  let a := (L (1,0)).1
  let b := (L (0,1)).1
  let c := (L (1,0)).2
  let d := (L (0,1)).2
  change a*d-b*c ≠ 0 at hdet
  constructor
  · intro p q hpq
    have h1 := congrArg Prod.fst hpq
    have h2 := congrArg Prod.snd hpq
    rw [plane_linear_formula L p,plane_linear_formula L q] at h1 h2
    change p.1*a+p.2*b=q.1*a+q.2*b at h1
    change p.1*c+p.2*d=q.1*c+q.2*d at h2
    apply Prod.ext
    · have he : (a*d-b*c)*(p.1-q.1)=0 := by linear_combination d*h1-b*h2
      exact sub_eq_zero.mp ((mul_eq_zero.mp he).resolve_left hdet)
    · have he : (a*d-b*c)*(p.2-q.2)=0 := by linear_combination a*h2-c*h1
      exact sub_eq_zero.mp ((mul_eq_zero.mp he).resolve_left hdet)
  · intro q
    refine ⟨((d*q.1-b*q.2)/(a*d-b*c),(a*q.2-c*q.1)/(a*d-b*c)),?_⟩
    rw [plane_linear_formula]
    apply Prod.ext
    · change ((d*q.1-b*q.2)/(a*d-b*c))*a+((a*q.2-c*q.1)/(a*d-b*c))*b=q.1
      field_simp [hdet]
      ring
    · change ((d*q.1-b*q.2)/(a*d-b*c))*c+((a*q.2-c*q.1)/(a*d-b*c))*d=q.2
      field_simp [hdet]
      ring

def coefficientMap (p : ℝ×ℝ) : ℝ×ℝ :=
  (periodCoefficient p.1 p.2 1,periodCoefficient p.1 p.2 2)

theorem analyticAt_coefficientMap (p : ℝ×ℝ) : AnalyticAt ℝ coefficientMap p := by
  have h := (analyticAt_tau1Polynomial p).prod (analyticAt_tau2Polynomial p)
  have he : coefficientMap = (fun q : ℝ×ℝ => (tau1Polynomial q.1 q.2,tau2Polynomial q.1 q.2)) := by
    funext q
    simp only [coefficientMap,actual_tau1_polynomial,actual_tau2_polynomial]
  rw [he]
  exact h

theorem coefficientMap_star : coefficientMap (dStar,fStar) = (0,0) := by
  simp only [coefficientMap,tau1_at_star,tau2_at_star]

theorem fderiv_coefficientMap_bijective :
    Function.Bijective (fderiv ℝ coefficientMap (dStar,fStar)) := by
  let L := fderiv ℝ coefficientMap (dStar,fStar)
  have hC := (analyticAt_coefficientMap (dStar,fStar)).differentiableAt.hasFDerivAt
  have hD := hC.comp_hasDerivAt dStar
    ((hasDerivAt_id dStar).prodMk (hasDerivAt_const dStar fStar))
  have hF := hC.comp_hasDerivAt fStar
    ((hasDerivAt_const fStar dStar).prodMk (hasDerivAt_id fStar))
  have h1 : deriv (fun d => periodCoefficient d fStar 1) dStar = (L (1,0)).1 := by
    have hh : HasDerivAt (fun d => periodCoefficient d fStar 1) ((L (1,0)).1) dStar :=
      (ContinuousLinearMap.fst ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt dStar hD
    exact hh.deriv
  have h2 : deriv (fun d => periodCoefficient d fStar 2) dStar = (L (1,0)).2 := by
    have hh : HasDerivAt (fun d => periodCoefficient d fStar 2) ((L (1,0)).2) dStar :=
      (ContinuousLinearMap.snd ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt dStar hD
    exact hh.deriv
  have h3 : deriv (fun f => periodCoefficient dStar f 1) fStar = (L (0,1)).1 := by
    have hh : HasDerivAt (fun f => periodCoefficient dStar f 1) ((L (0,1)).1) fStar :=
      (ContinuousLinearMap.fst ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt fStar hF
    exact hh.deriv
  have h4 : deriv (fun f => periodCoefficient dStar f 2) fStar = (L (0,1)).2 := by
    have hh : HasDerivAt (fun f => periodCoefficient dStar f 2) ((L (0,1)).2) fStar :=
      (ContinuousLinearMap.snd ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt fStar hF
    exact hh.deriv
  apply plane_linear_bijective
  simpa only [actualCoefficientJacobian,h1,h2,h3,h4] using actual_jacobian_at_star_ne_zero

theorem exists_actual_coefficient_inverse :
    ∃ J : (ℝ×ℝ) → (ℝ×ℝ), AnalyticAt ℝ J (0,0) ∧ J (0,0)=(dStar,fStar) ∧
      ∀ᶠ q in 𝓝 ((0,0):ℝ×ℝ), coefficientMap (J q)=q := by
  let L := fderiv ℝ coefficientMap (dStar,fStar)
  let e := ContinuousLinearEquiv.ofBijective L
    (LinearMap.ker_eq_bot.mpr fderiv_coefficientMap_bijective.1)
    (LinearMap.range_eq_top.mpr fderiv_coefficientMap_bijective.2)
  have he : HasStrictFDerivAt coefficientMap (e : (ℝ×ℝ) →L[ℝ] (ℝ×ℝ)) (dStar,fStar) := by
    simpa only [e,ContinuousLinearEquiv.coe_ofBijective,L] using
      (analyticAt_coefficientMap (dStar,fStar)).hasStrictFDerivAt
  let J := he.localInverse coefficientMap _ _
  have hJ : AnalyticAt ℝ J (coefficientMap (dStar,fStar)) :=
    (he.toPartialHomeomorph coefficientMap).analyticAt_symm' he.mem_toPartialHomeomorph_source
      (analyticAt_coefficientMap (dStar,fStar)) he.hasFDerivAt.fderiv
  refine ⟨J,?_,?_,?_⟩
  · simpa only [coefficientMap_star] using hJ
  · simpa only [coefficientMap_star] using he.localInverse_apply_image
  · simpa only [coefficientMap_star] using he.eventually_right_inverse

theorem exists_actual_sharpness_parameter_path :
    ∃ p : ℝ → ℝ×ℝ, AnalyticAt ℝ p 0 ∧ p 0=(dStar,fStar) ∧
      ∀ᶠ ε in 𝓝 (0:ℝ),
        periodCoefficient (p ε).1 (p ε).2 1 = 6*aStar*ε^2 ∧
        periodCoefficient (p ε).1 (p ε).2 2 = -(9/2:ℝ)*aStar*ε := by
  obtain ⟨J,hJ,hJ0,he⟩ := exists_actual_coefficient_inverse
  let a : ℝ → ℝ×ℝ := fun ε => (6*aStar*ε^2,-(9/2:ℝ)*aStar*ε)
  have ha : AnalyticAt ℝ a 0 :=
    ((analyticAt_const.mul analyticAt_const).mul (analyticAt_id.pow 2)).prod
      ((analyticAt_const.mul analyticAt_const).mul analyticAt_id)
  have ha0 : a 0=(0,0) := by simp [a]
  refine ⟨J ∘ a,hJ.comp_of_eq ha ha0,?_,?_⟩
  · simpa only [Function.comp_apply,ha0] using hJ0
  · have ht : Tendsto a (𝓝 0) (𝓝 ((0,0):ℝ×ℝ)) := ha0 ▸ ha.continuousAt.tendsto
    filter_upwards [ht.eventually he] with ε hε
    exact ⟨congrArg Prod.fst hε,congrArg Prod.snd hε⟩

end LeanVerification.Sharpness
