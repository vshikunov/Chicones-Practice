import LeanVerification.Sharpness.PhysicalSharpness

/-! Exact parameter tangent and retention of the stated open parameter region. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness
open Loud SharpnessAlgebra
set_option maxHeartbeats 1800000

theorem actual_partial_coefficients_at_star :
    deriv (fun d => periodCoefficient d fStar 1) dStar = (rStar-9)/24 ∧
    deriv (fun f => periodCoefficient dStar f 1) fStar = (rStar-45)/120 ∧
    deriv (fun d => periodCoefficient d fStar 2) dStar = (rStar-21)/600 ∧
    deriv (fun f => periodCoefficient dStar f 2) fStar = 7*(rStar-5)/1000 := by
  simp_rw [actual_tau1_polynomial,actual_tau2_polynomial]
  rw [(hasDerivAt_tau1_D dStar fStar).deriv,(hasDerivAt_tau1_F dStar fStar).deriv,
    (hasDerivAt_tau2_D dStar fStar).deriv,(hasDerivAt_tau2_F dStar fStar).deriv]
  dsimp only [dStar,fStar]
  refine ⟨by ring,by ring,?_,?_⟩
  · linear_combination (13*rStar/57600-41/32000)*rStar_sq
  · linear_combination (13*rStar/288000-41/32000)*rStar_sq

theorem coefficientMap_fderiv_columns :
    fderiv ℝ coefficientMap (dStar,fStar) (1,0)=
      ((rStar-9)/24,(rStar-21)/600) ∧
    fderiv ℝ coefficientMap (dStar,fStar) (0,1)=
      ((rStar-45)/120,7*(rStar-5)/1000) := by
  let L := fderiv ℝ coefficientMap (dStar,fStar)
  have hC := (analyticAt_coefficientMap (dStar,fStar)).differentiableAt.hasFDerivAt
  have hD := hC.comp_hasDerivAt dStar
    ((hasDerivAt_id dStar).prodMk (hasDerivAt_const dStar fStar))
  have hF := hC.comp_hasDerivAt fStar
    ((hasDerivAt_const fStar dStar).prodMk (hasDerivAt_id fStar))
  have h1 : HasDerivAt (fun d => periodCoefficient d fStar 1) ((L (1,0)).1) dStar :=
    (ContinuousLinearMap.fst ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt dStar hD
  have h2 : HasDerivAt (fun d => periodCoefficient d fStar 2) ((L (1,0)).2) dStar :=
    (ContinuousLinearMap.snd ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt dStar hD
  have h3 : HasDerivAt (fun f => periodCoefficient dStar f 1) ((L (0,1)).1) fStar :=
    (ContinuousLinearMap.fst ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt fStar hF
  have h4 : HasDerivAt (fun f => periodCoefficient dStar f 2) ((L (0,1)).2) fStar :=
    (ContinuousLinearMap.snd ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt fStar hF
  have hp := actual_partial_coefficients_at_star
  exact ⟨Prod.ext (h1.deriv.symm.trans hp.1) (h2.deriv.symm.trans hp.2.2.1),
    Prod.ext (h3.deriv.symm.trans hp.2.1) (h4.deriv.symm.trans hp.2.2.2)⟩

theorem coefficientMap_expected_tangent :
    fderiv ℝ coefficientMap (dStar,fStar)
      ((rStar-3)/500,(195-17*rStar)/8000) = (0,-(9/2:ℝ)*aStar) := by
  rw [plane_linear_formula,coefficientMap_fderiv_columns.1,coefficientMap_fderiv_columns.2]
  apply Prod.ext
  · change (rStar-3)/500*((rStar-9)/24)+(195-17*rStar)/8000*((rStar-45)/120)=0
    linear_combination (21/320000:ℝ)*rStar_sq
  · change (rStar-3)/500*((rStar-21)/600)+(195-17*rStar)/8000*(7*(rStar-5)/1000)=-(9/2:ℝ)*aStar
    dsimp only [aStar]
    linear_combination (-277/24000000:ℝ)*rStar_sq

theorem actual_sharpness_parameter_tangent {p : ℝ → ℝ×ℝ}
    (hp : AnalyticAt ℝ p 0) (hp0 : p 0=(dStar,fStar))
    (hc : ∀ᶠ ε in 𝓝 (0:ℝ),
      periodCoefficient (p ε).1 (p ε).2 1=6*aStar*ε^2 ∧
      periodCoefficient (p ε).1 (p ε).2 2=-(9/2:ℝ)*aStar*ε) :
    deriv p 0=((rStar-3)/500,(195-17*rStar)/8000) := by
  have he : (fun ε => coefficientMap (p ε)) =ᶠ[𝓝 0]
      (fun ε => (6*aStar*ε^2,-(9/2:ℝ)*aStar*ε)) := by
    filter_upwards [hc] with ε hε
    exact Prod.ext hε.1 hε.2
  have hd := (analyticAt_coefficientMap (p 0)).differentiableAt.hasFDerivAt.comp_hasDerivAt 0
    hp.differentiableAt.hasDerivAt
  have ht := ((((hasDerivAt_id 0).pow 2).const_mul (6*aStar))).prodMk
    ((hasDerivAt_id 0).const_mul (-(9/2:ℝ)*aStar))
  have ht' : deriv (fun ε:ℝ => (6*aStar*ε^2,-(9/2:ℝ)*aStar*ε)) 0=
      (0,-(9/2:ℝ)*aStar) := by simpa using ht.deriv
  have hmap : fderiv ℝ coefficientMap (dStar,fStar) (deriv p 0)=(0,-(9/2:ℝ)*aStar) := by
    simpa only [hp0] using hd.deriv.symm.trans (he.deriv_eq.trans ht')
  exact fderiv_coefficientMap_bijective.1 (hmap.trans coefficientMap_expected_tangent.symm)

theorem parameter_path_eventually_in_sharpness_region {p : ℝ → ℝ×ℝ}
    (hp : ContinuousAt p 0) (hp0 : p 0=(dStar,fStar)) :
    ∀ᶠ ε in 𝓝 (0:ℝ), (-1/2:ℝ)<(p ε).1 ∧ (p ε).1<0 ∧
      0<(p ε).2 ∧ (p ε).2<1/2 := by
  have hD : ContinuousAt (fun ε => (p ε).1) 0 := continuousAt_fst.comp hp
  have hF : ContinuousAt (fun ε => (p ε).2) 0 := continuousAt_snd.comp hp
  have hs := star_in_parameter_region
  filter_upwards [hD.tendsto.eventually_const_lt (by simpa only [hp0] using hs.1),
    hD.tendsto.eventually_lt_const (by simpa only [hp0] using hs.2.1),
    hF.tendsto.eventually_const_lt (by simpa only [hp0] using hs.2.2.1),
    hF.tendsto.eventually_lt_const (by simpa only [hp0] using hs.2.2.2)] with ε h1 h2 h3 h4
  exact ⟨h1,h2,h3,h4⟩

end LeanVerification.Sharpness
