import LeanVerification.Sharpness.ActualCoefficients
import LeanVerification.SharpnessAlgebra

/-! Exact polynomial coefficients of the actual physical period and its Jacobian. -/
noncomputable section
open Filter Set
open scoped Topology
namespace LeanVerification.Sharpness
open Loud SharpnessAlgebra
set_option maxHeartbeats 2400000
set_option maxRecDepth 12000

def tau1Polynomial (D F : ℝ) : ℝ :=
  ((1 / 12 : ℝ) + ((-5 / 12 : ℝ) * F) + ((-1 / 12 : ℝ) * D) + ((1 / 3 : ℝ) * (F ^ 2)) + ((5 / 6 : ℝ) * (D ^ 2)) + ((5 / 6 : ℝ) * D * F))

def tau2Polynomial (D F : ℝ) : ℝ :=
  ((1 / 576 : ℝ) + ((-89 / 72 : ℝ) * (F ^ 3)) + ((-29 / 288 : ℝ) * F) + ((-1 / 288 : ℝ) * D) + ((7 / 192 : ℝ) * (D ^ 2)) + ((25 / 36 : ℝ) * (F ^ 4)) + ((41 / 64 : ℝ) * (F ^ 2)) + ((175 / 144 : ℝ) * (D ^ 3)) + ((385 / 144 : ℝ) * (D ^ 4)) + ((-23 / 16 : ℝ) * D * (F ^ 2)) + ((7 / 24 : ℝ) * F * (D ^ 2)) + ((7 / 32 : ℝ) * D * F) + ((77 / 16 : ℝ) * (D ^ 2) * (F ^ 2)) + ((89 / 36 : ℝ) * D * (F ^ 3)) + ((385 / 72 : ℝ) * F * (D ^ 3)))

def tau3Polynomial (D F : ℝ) : ℝ :=
  ((-139 / 311040 : ℝ) + ((-366193 / 311040 : ℝ) * (F ^ 3)) + ((-27817 / 6480 : ℝ) * (F ^ 5)) + ((-233 / 103680 : ℝ) * (D ^ 2)) + ((-97 / 103680 : ℝ) * F) + ((139 / 103680 : ℝ) * D) + ((2387 / 62208 : ℝ) * (D ^ 3)) + ((9041 / 4860 : ℝ) * (F ^ 6)) + ((15409 / 103680 : ℝ) * (F ^ 2)) + ((23023 / 10368 : ℝ) * (D ^ 4)) + ((55055 / 5184 : ℝ) * (D ^ 5)) + ((85085 / 7776 : ℝ) * (D ^ 6)) + ((89749 / 25920 : ℝ) * (F ^ 4)) + ((-157609 / 25920 : ℝ) * (D ^ 2) * (F ^ 3)) + ((-49697 / 103680 : ℝ) * D * (F ^ 2)) + ((-30881 / 3240 : ℝ) * D * (F ^ 4)) + ((-3793 / 103680 : ℝ) * F * (D ^ 2)) + ((23 / 5184 : ℝ) * D * F) + ((13475 / 10368 : ℝ) * F * (D ^ 3)) + ((14581 / 17280 : ℝ) * (D ^ 2) * (F ^ 2)) + ((27817 / 3240 : ℝ) * D * (F ^ 5)) + ((45353 / 5184 : ℝ) * (D ^ 3) * (F ^ 2)) + ((85085 / 2592 : ℝ) * F * (D ^ 5)) + ((97097 / 5184 : ℝ) * F * (D ^ 4)) + ((119119 / 2592 : ℝ) * (D ^ 4) * (F ^ 2)) + ((145723 / 6480 : ℝ) * (D ^ 2) * (F ^ 4)) + ((186973 / 51840 : ℝ) * D * (F ^ 3)) + ((305921 / 7776 : ℝ) * (D ^ 3) * (F ^ 3)))

theorem actual_tau1_polynomial (D F : ℝ) :
    periodCoefficient D F 1 = tau1Polynomial D F := by
  rw [(actual_period_first_three_coefficients D F).1,(morse_position_jets D F).2.1]
  simp only [inverseJet3]
  simp_rw [force_derivative_at_center]
  norm_num [fallingStep,Finset.prod_range_succ,tau1Polynomial]
  ring

theorem actual_tau2_polynomial (D F : ℝ) :
    periodCoefficient D F 2 = tau2Polynomial D F := by
  rw [(actual_period_first_three_coefficients D F).2.1,(morse_position_jets D F).2.2.2.1]
  simp only [inverseJet5]
  simp_rw [force_derivative_at_center]
  norm_num [fallingStep,Finset.prod_range_succ,tau2Polynomial]
  ring

theorem actual_tau3_polynomial (D F : ℝ) :
    periodCoefficient D F 3 = tau3Polynomial D F := by
  rw [(actual_period_first_three_coefficients D F).2.2,(morse_position_jets D F).2.2.2.2.2]
  simp only [inverseJet7]
  simp_rw [force_derivative_at_center]
  norm_num [fallingStep,Finset.prod_range_succ,tau3Polynomial]
  ring

theorem analyticAt_tau1Polynomial (p : ℝ × ℝ) :
    AnalyticAt ℝ (fun q : ℝ × ℝ => tau1Polynomial q.1 q.2) p := by
  exact (((((analyticAt_const).add ((analyticAt_const).mul (analyticAt_snd))).add ((analyticAt_const).mul (analyticAt_fst))).add ((analyticAt_const).mul ((analyticAt_snd).pow 2))).add ((analyticAt_const).mul ((analyticAt_fst).pow 2))).add (((analyticAt_const).mul (analyticAt_fst)).mul (analyticAt_snd))

theorem hasDerivAt_tau1_D (D F : ℝ) :
    HasDerivAt (fun d => tau1Polynomial d F) (((-1 / 12 : ℝ) + ((5 / 3 : ℝ) * D) + ((5 / 6 : ℝ) * F))) D := by
  have hd := (((((hasDerivAt_const D ((1 / 12 : ℝ))).add ((hasDerivAt_const D ((-5 / 12 : ℝ))).mul (hasDerivAt_const D F))).add ((hasDerivAt_const D ((-1 / 12 : ℝ))).mul (hasDerivAt_id D))).add ((hasDerivAt_const D ((1 / 3 : ℝ))).mul ((hasDerivAt_const D F).pow 2))).add ((hasDerivAt_const D ((5 / 6 : ℝ))).mul ((hasDerivAt_id D).pow 2))).add (((hasDerivAt_const D ((5 / 6 : ℝ))).mul (hasDerivAt_id D)).mul (hasDerivAt_const D F))
  convert hd using 1 <;> dsimp only [tau1Polynomial,id_eq] <;> ring

theorem hasDerivAt_tau1_F (D F : ℝ) :
    HasDerivAt (fun f => tau1Polynomial D f) (((-5 / 12 : ℝ) + ((2 / 3 : ℝ) * F) + ((5 / 6 : ℝ) * D))) F := by
  have hd := (((((hasDerivAt_const F ((1 / 12 : ℝ))).add ((hasDerivAt_const F ((-5 / 12 : ℝ))).mul (hasDerivAt_id F))).add ((hasDerivAt_const F ((-1 / 12 : ℝ))).mul (hasDerivAt_const F D))).add ((hasDerivAt_const F ((1 / 3 : ℝ))).mul ((hasDerivAt_id F).pow 2))).add ((hasDerivAt_const F ((5 / 6 : ℝ))).mul ((hasDerivAt_const F D).pow 2))).add (((hasDerivAt_const F ((5 / 6 : ℝ))).mul (hasDerivAt_const F D)).mul (hasDerivAt_id F))
  convert hd using 1 <;> dsimp only [tau1Polynomial,id_eq] <;> ring

theorem analyticAt_tau2Polynomial (p : ℝ × ℝ) :
    AnalyticAt ℝ (fun q : ℝ × ℝ => tau2Polynomial q.1 q.2) p := by
  exact ((((((((((((((analyticAt_const).add ((analyticAt_const).mul ((analyticAt_snd).pow 3))).add ((analyticAt_const).mul (analyticAt_snd))).add ((analyticAt_const).mul (analyticAt_fst))).add ((analyticAt_const).mul ((analyticAt_fst).pow 2))).add ((analyticAt_const).mul ((analyticAt_snd).pow 4))).add ((analyticAt_const).mul ((analyticAt_snd).pow 2))).add ((analyticAt_const).mul ((analyticAt_fst).pow 3))).add ((analyticAt_const).mul ((analyticAt_fst).pow 4))).add (((analyticAt_const).mul (analyticAt_fst)).mul ((analyticAt_snd).pow 2))).add (((analyticAt_const).mul (analyticAt_snd)).mul ((analyticAt_fst).pow 2))).add (((analyticAt_const).mul (analyticAt_fst)).mul (analyticAt_snd))).add (((analyticAt_const).mul ((analyticAt_fst).pow 2)).mul ((analyticAt_snd).pow 2))).add (((analyticAt_const).mul (analyticAt_fst)).mul ((analyticAt_snd).pow 3))).add (((analyticAt_const).mul (analyticAt_snd)).mul ((analyticAt_fst).pow 3))

theorem hasDerivAt_tau2_D (D F : ℝ) :
    HasDerivAt (fun d => tau2Polynomial d F) (((-1 / 288 : ℝ) + ((-23 / 16 : ℝ) * (F ^ 2)) + ((7 / 32 : ℝ) * F) + ((7 / 96 : ℝ) * D) + ((89 / 36 : ℝ) * (F ^ 3)) + ((175 / 48 : ℝ) * (D ^ 2)) + ((385 / 36 : ℝ) * (D ^ 3)) + ((7 / 12 : ℝ) * D * F) + ((77 / 8 : ℝ) * D * (F ^ 2)) + ((385 / 24 : ℝ) * F * (D ^ 2)))) D := by
  have hd := ((((((((((((((hasDerivAt_const D ((1 / 576 : ℝ))).add ((hasDerivAt_const D ((-89 / 72 : ℝ))).mul ((hasDerivAt_const D F).pow 3))).add ((hasDerivAt_const D ((-29 / 288 : ℝ))).mul (hasDerivAt_const D F))).add ((hasDerivAt_const D ((-1 / 288 : ℝ))).mul (hasDerivAt_id D))).add ((hasDerivAt_const D ((7 / 192 : ℝ))).mul ((hasDerivAt_id D).pow 2))).add ((hasDerivAt_const D ((25 / 36 : ℝ))).mul ((hasDerivAt_const D F).pow 4))).add ((hasDerivAt_const D ((41 / 64 : ℝ))).mul ((hasDerivAt_const D F).pow 2))).add ((hasDerivAt_const D ((175 / 144 : ℝ))).mul ((hasDerivAt_id D).pow 3))).add ((hasDerivAt_const D ((385 / 144 : ℝ))).mul ((hasDerivAt_id D).pow 4))).add (((hasDerivAt_const D ((-23 / 16 : ℝ))).mul (hasDerivAt_id D)).mul ((hasDerivAt_const D F).pow 2))).add (((hasDerivAt_const D ((7 / 24 : ℝ))).mul (hasDerivAt_const D F)).mul ((hasDerivAt_id D).pow 2))).add (((hasDerivAt_const D ((7 / 32 : ℝ))).mul (hasDerivAt_id D)).mul (hasDerivAt_const D F))).add (((hasDerivAt_const D ((77 / 16 : ℝ))).mul ((hasDerivAt_id D).pow 2)).mul ((hasDerivAt_const D F).pow 2))).add (((hasDerivAt_const D ((89 / 36 : ℝ))).mul (hasDerivAt_id D)).mul ((hasDerivAt_const D F).pow 3))).add (((hasDerivAt_const D ((385 / 72 : ℝ))).mul (hasDerivAt_const D F)).mul ((hasDerivAt_id D).pow 3))
  convert hd using 1 <;> dsimp only [tau2Polynomial,id_eq] <;> ring

theorem hasDerivAt_tau2_F (D F : ℝ) :
    HasDerivAt (fun f => tau2Polynomial D f) (((-29 / 288 : ℝ) + ((-89 / 24 : ℝ) * (F ^ 2)) + ((7 / 24 : ℝ) * (D ^ 2)) + ((7 / 32 : ℝ) * D) + ((25 / 9 : ℝ) * (F ^ 3)) + ((41 / 32 : ℝ) * F) + ((385 / 72 : ℝ) * (D ^ 3)) + ((-23 / 8 : ℝ) * D * F) + ((77 / 8 : ℝ) * F * (D ^ 2)) + ((89 / 12 : ℝ) * D * (F ^ 2)))) F := by
  have hd := ((((((((((((((hasDerivAt_const F ((1 / 576 : ℝ))).add ((hasDerivAt_const F ((-89 / 72 : ℝ))).mul ((hasDerivAt_id F).pow 3))).add ((hasDerivAt_const F ((-29 / 288 : ℝ))).mul (hasDerivAt_id F))).add ((hasDerivAt_const F ((-1 / 288 : ℝ))).mul (hasDerivAt_const F D))).add ((hasDerivAt_const F ((7 / 192 : ℝ))).mul ((hasDerivAt_const F D).pow 2))).add ((hasDerivAt_const F ((25 / 36 : ℝ))).mul ((hasDerivAt_id F).pow 4))).add ((hasDerivAt_const F ((41 / 64 : ℝ))).mul ((hasDerivAt_id F).pow 2))).add ((hasDerivAt_const F ((175 / 144 : ℝ))).mul ((hasDerivAt_const F D).pow 3))).add ((hasDerivAt_const F ((385 / 144 : ℝ))).mul ((hasDerivAt_const F D).pow 4))).add (((hasDerivAt_const F ((-23 / 16 : ℝ))).mul (hasDerivAt_const F D)).mul ((hasDerivAt_id F).pow 2))).add (((hasDerivAt_const F ((7 / 24 : ℝ))).mul (hasDerivAt_id F)).mul ((hasDerivAt_const F D).pow 2))).add (((hasDerivAt_const F ((7 / 32 : ℝ))).mul (hasDerivAt_const F D)).mul (hasDerivAt_id F))).add (((hasDerivAt_const F ((77 / 16 : ℝ))).mul ((hasDerivAt_const F D).pow 2)).mul ((hasDerivAt_id F).pow 2))).add (((hasDerivAt_const F ((89 / 36 : ℝ))).mul (hasDerivAt_const F D)).mul ((hasDerivAt_id F).pow 3))).add (((hasDerivAt_const F ((385 / 72 : ℝ))).mul (hasDerivAt_id F)).mul ((hasDerivAt_const F D).pow 3))
  convert hd using 1 <;> dsimp only [tau2Polynomial,id_eq] <;> ring

def actualCoefficientJacobian (D F : ℝ) : ℝ :=
  deriv (fun d => periodCoefficient d F 1) D * deriv (fun f => periodCoefficient D f 2) F -
    deriv (fun f => periodCoefficient D f 1) F * deriv (fun d => periodCoefficient d F 2) D

theorem tau1_at_star : periodCoefficient dStar fStar 1 = 0 := by
  rw [actual_tau1_polynomial]
  dsimp only [tau1Polynomial,dStar,fStar,aStar]
  linear_combination ((1 / 1200 : ℝ)) * rStar_sq

theorem tau2_at_star : periodCoefficient dStar fStar 2 = 0 := by
  rw [actual_tau2_polynomial]
  dsimp only [tau2Polynomial,dStar,fStar,aStar]
  linear_combination (((-237 / 640000 : ℝ) + ((13 / 5760000 : ℝ) * (rStar ^ 2)))) * rStar_sq

theorem tau3_at_star : periodCoefficient dStar fStar 3 = aStar := by
  rw [actual_tau3_polynomial]
  dsimp only [tau3Polynomial,dStar,fStar,aStar]
  linear_combination (((183719 / 1382400000 : ℝ) + ((-119569 / 51840000000 : ℝ) * (rStar ^ 2)) + ((1 / 1440000000 : ℝ) * (rStar ^ 3)) + ((1123 / 288000000 : ℝ) * rStar) + ((2399 / 311040000000 : ℝ) * (rStar ^ 4)))) * rStar_sq

theorem actual_jacobian_at_star : actualCoefficientJacobian dStar fStar = displayedJacobianValue := by
  simp only [actualCoefficientJacobian]
  simp_rw [actual_tau1_polynomial,actual_tau2_polynomial]
  rw [(hasDerivAt_tau1_D dStar fStar).deriv,(hasDerivAt_tau1_F dStar fStar).deriv,
    (hasDerivAt_tau2_D dStar fStar).deriv,(hasDerivAt_tau2_F dStar fStar).deriv]
  dsimp only [dStar,fStar,displayedJacobianValue]
  linear_combination (((1 / 3600 : ℝ) + ((1 / 40000 : ℝ) * rStar))) * rStar_sq

theorem actual_jacobian_at_star_ne_zero : actualCoefficientJacobian dStar fStar ≠ 0 := by
  rw [actual_jacobian_at_star]
  exact displayedJacobianValue_ne_zero

theorem actual_third_coefficient_positive : 0 < periodCoefficient dStar fStar 3 := by
  rw [tau3_at_star]
  exact aStar_pos

end LeanVerification.Sharpness
