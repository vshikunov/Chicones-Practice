import LeanVerification.Loud.ForceJets
import LeanVerification.Loud.PeriodDifferentiation
import Mathlib.Analysis.Calculus.IteratedDeriv.Lemmas

/-! Exact jets of the actual mechanical Loud force, including F = 0. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness
open Loud
set_option maxHeartbeats 1200000

def powerPosition (F a X : ℝ) : ℝ := inversePosition F X ^ a

def fallingStep (F a : ℝ) (n : ℕ) : ℝ :=
  ∏ k ∈ Finset.range n, (a - (k : ℝ) * F)

@[simp] theorem fallingStep_zero (F a : ℝ) : fallingStep F a 0 = 1 := by
  simp [fallingStep]

theorem fallingStep_succ (F a : ℝ) (n : ℕ) :
    fallingStep F a (n+1) = fallingStep F a n * (a - (n : ℝ)*F) := by
  simp [fallingStep, Finset.prod_range_succ]

theorem analyticAt_powerPosition (F a X : ℝ) (hX : mechanicalDomain F X) :
    AnalyticAt ℝ (powerPosition F a) X := by
  exact (analyticAt_rpow_const a _ (inversePosition_pos F X hX)).comp
    (analyticAt_inversePosition F X hX)

theorem hasDerivAt_powerPosition (F a X : ℝ) (hX : mechanicalDomain F X) :
    HasDerivAt (powerPosition F a) (a * powerPosition F (a-F) X) X := by
  have hw := inversePosition_pos F X hX
  have hd := (Real.hasDerivAt_rpow_const (x := inversePosition F X) (p := a)
    (Or.inl hw.ne')).comp X (hasDerivAt_inversePosition F X hX)
  convert hd using 1
  dsimp only [powerPosition]
  rw [mul_assoc, ← Real.rpow_add hw]
  congr 2
  ring

theorem iteratedDeriv_powerPosition (F a X : ℝ) (hX : mechanicalDomain F X)
    (n : ℕ) :
    iteratedDeriv n (powerPosition F a) X =
      fallingStep F a n * powerPosition F (a-(n : ℝ)*F) X := by
  induction n generalizing X with
  | zero => simp
  | succ n ih =>
    have ho : IsOpen {X : ℝ | mechanicalDomain F X} :=
      isOpen_lt continuous_const (continuous_const.add (continuous_const.mul continuous_id))
    have he : iteratedDeriv n (powerPosition F a) =ᶠ[𝓝 X]
        fun x => fallingStep F a n * powerPosition F (a-(n : ℝ)*F) x := by
      filter_upwards [ho.mem_nhds hX] with x hx
      exact ih x hx
    rw [iteratedDeriv_succ, he.deriv_eq,
      ((hasDerivAt_powerPosition F (a-(n : ℝ)*F) X hX).const_mul
        (fallingStep F a n)).deriv, fallingStep_succ]
    simp only [Nat.cast_add, Nat.cast_one]
    rw [show a-(n : ℝ)*F-F = a-((n : ℝ)+1)*F by ring]
    ring

theorem force_power_expansion (D F X : ℝ) (hX : mechanicalDomain F X) :
    forceInPosition D F X =
      (D+1)*powerPosition F F X - (2*D+1)*powerPosition F (F-1) X +
        D*powerPosition F (F-2) X := by
  have hw := inversePosition_pos F X hX
  have h0 : inversePosition F X ^ F = inversePosition F X ^ (F-2) * inversePosition F X ^ (2:ℕ) := by
    rw [← Real.rpow_natCast, ← Real.rpow_add hw]
    congr 1
    norm_num
  have h1 : inversePosition F X ^ (F-1) = inversePosition F X ^ (F-2) * inversePosition F X := by
    nth_rw 3 [← Real.rpow_one (inversePosition F X)]
    rw [← Real.rpow_add hw]
    congr 1
    ring
  dsimp only [forceInPosition, force, powerPosition]
  rw [h0,h1]
  ring

theorem analyticAt_forceInPosition (D F X : ℝ) (hX : mechanicalDomain F X) :
    AnalyticAt ℝ (forceInPosition D F) X := by
  have ho : IsOpen {X : ℝ | mechanicalDomain F X} :=
    isOpen_lt continuous_const (continuous_const.add (continuous_const.mul continuous_id))
  apply (((analyticAt_const.mul (analyticAt_powerPosition F F X hX)).sub
    (analyticAt_const.mul (analyticAt_powerPosition F (F-1) X hX))).add
    (analyticAt_const.mul (analyticAt_powerPosition F (F-2) X hX))).congr
  filter_upwards [ho.mem_nhds hX] with x hx
  exact (force_power_expansion D F x hx).symm

theorem iteratedDeriv_forceInPosition (D F X : ℝ) (hX : mechanicalDomain F X)
    (n : ℕ) :
    iteratedDeriv n (forceInPosition D F) X =
      (D+1)*fallingStep F F n*powerPosition F (F-(n : ℝ)*F) X -
      (2*D+1)*fallingStep F (F-1) n*powerPosition F (F-1-(n : ℝ)*F) X +
      D*fallingStep F (F-2) n*powerPosition F (F-2-(n : ℝ)*F) X := by
  induction n generalizing X with
  | zero => simp [force_power_expansion D F X hX]
  | succ n ih =>
    have ho : IsOpen {X : ℝ | mechanicalDomain F X} :=
      isOpen_lt continuous_const (continuous_const.add (continuous_const.mul continuous_id))
    have he : iteratedDeriv n (forceInPosition D F) =ᶠ[𝓝 X] fun x =>
        (D+1)*fallingStep F F n*powerPosition F (F-(n : ℝ)*F) x -
        (2*D+1)*fallingStep F (F-1) n*powerPosition F (F-1-(n : ℝ)*F) x +
        D*fallingStep F (F-2) n*powerPosition F (F-2-(n : ℝ)*F) x := by
      filter_upwards [ho.mem_nhds hX] with x hx
      exact ih x hx
    have hd := (((hasDerivAt_powerPosition F (F-(n : ℝ)*F) X hX).const_mul
        ((D+1)*fallingStep F F n)).sub
      ((hasDerivAt_powerPosition F (F-1-(n : ℝ)*F) X hX).const_mul
        ((2*D+1)*fallingStep F (F-1) n))).add
      ((hasDerivAt_powerPosition F (F-2-(n : ℝ)*F) X hX).const_mul
        (D*fallingStep F (F-2) n))
    rw [iteratedDeriv_succ, he.deriv_eq, hd.deriv]
    simp only [fallingStep_succ, Nat.cast_add, Nat.cast_one]
    rw [show F-(n : ℝ)*F-F=F-((n : ℝ)+1)*F by ring,
      show F-1-(n : ℝ)*F-F=F-1-((n : ℝ)+1)*F by ring,
      show F-2-(n : ℝ)*F-F=F-2-((n : ℝ)+1)*F by ring]
    ring

theorem force_derivative_at_center (D F : ℝ) (n : ℕ) :
    iteratedDeriv n (forceInPosition D F) 0 =
      (D+1)*fallingStep F F n -(2*D+1)*fallingStep F (F-1) n +
        D*fallingStep F (F-2) n := by
  simpa only [powerPosition, inversePosition_zero, Real.one_rpow, mul_one] using
    iteratedDeriv_forceInPosition D F 0 (mechanicalDomain_zero F) n

end LeanVerification.Sharpness
