import LeanVerification.Sharpness.Fold.ImplicitCurvature
import Mathlib.Analysis.Calculus.Deriv.MeanValue

/-! A strictly concave analytic graph has two strictly monotone sides. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness.Fold
set_option maxHeartbeats 2200000

theorem exists_fold_window {k : ℝ → ℝ} {h : ℝ} {P : ℝ → Prop}
    (hk : AnalyticAt ℝ k h) (hk1 : deriv k h=0) (hk2 : deriv (deriv k) h<0)
    (hP : ∀ᶠ t in 𝓝 h,P t) :
    ∃ r>0,
      (∀ t∈Icc (h-r) (h+r),P t ∧ AnalyticAt ℝ k t) ∧
      StrictMonoOn k (Icc (h-r) h) ∧ StrictAntiOn k (Icc h (h+r)) ∧
      (∀ t∈Ico (h-r) h,0<deriv k t) ∧
      (∀ t∈Ioc h (h+r),deriv k t<0) := by
  have he : ∀ᶠ t in 𝓝 h,P t ∧ AnalyticAt ℝ k t ∧ deriv (deriv k) t<0 := by
    filter_upwards [hP,hk.eventually_analyticAt,
      hk.deriv.deriv.continuousAt.tendsto.eventually_lt_const hk2] with t ht ha hd
    exact ⟨ht,ha,hd⟩
  obtain ⟨δ,hδ,hlocal⟩ := Metric.eventually_nhds_iff.mp he
  let r := δ/2
  have hr : 0<r := by dsimp only [r]; linarith
  have hdata : ∀ t∈Icc (h-r) (h+r),P t ∧ AnalyticAt ℝ k t ∧ deriv (deriv k) t<0 := by
    intro t ht
    apply hlocal
    rw [Real.dist_eq]
    have hb : |t-h|≤r := abs_le.mpr ⟨by linarith [ht.1],by linarith [ht.2]⟩
    exact hb.trans_lt (by dsimp only [r]; linarith)
  have hdanti : StrictAntiOn (deriv k) (Icc (h-r) (h+r)) := by
    apply strictAntiOn_of_deriv_neg (convex_Icc _ _)
      (fun t ht => (hdata t ht).2.1.deriv.continuousAt.continuousWithinAt)
    intro t ht
    exact (hdata t (interior_subset ht)).2.2
  have hleft : ∀ t∈Ico (h-r) h,0<deriv k t := by
    intro t ht
    have he := hdanti ⟨ht.1,by linarith [ht.2]⟩ ⟨by linarith,by linarith⟩ ht.2
    simpa only [hk1] using he
  have hright : ∀ t∈Ioc h (h+r),deriv k t<0 := by
    intro t ht
    have he := hdanti ⟨by linarith,by linarith⟩ ⟨by linarith [ht.1],ht.2⟩ ht.1
    simpa only [hk1] using he
  have hm : StrictMonoOn k (Icc (h-r) h) := by
    apply strictMonoOn_of_deriv_pos (convex_Icc _ _)
      (fun t ht => (hdata t ⟨ht.1,by linarith [ht.2]⟩).2.1.continuousAt.continuousWithinAt)
    intro t ht
    have ht' : t∈Ioo (h-r) h := by simpa only [interior_Icc] using ht
    exact hleft t ⟨ht'.1.le,ht'.2⟩
  have ha : StrictAntiOn k (Icc h (h+r)) := by
    apply strictAntiOn_of_deriv_neg (convex_Icc _ _)
      (fun t ht => (hdata t ⟨by linarith [ht.1],ht.2⟩).2.1.continuousAt.continuousWithinAt)
    intro t ht
    have ht' : t∈Ioo h (h+r) := by simpa only [interior_Icc] using ht
    exact hright t ⟨ht'.1,ht'.2.le⟩
  exact ⟨r,hr,(fun t ht => ⟨(hdata t ht).1,(hdata t ht).2.1⟩),hm,ha,hleft,hright⟩

theorem fold_window_strict_max {k : ℝ → ℝ} {h r : ℝ} (hr : 0<r)
    (hm : StrictMonoOn k (Icc (h-r) h)) (ha : StrictAntiOn k (Icc h (h+r)))
    {t : ℝ} (ht : t∈Icc (h-r) (h+r)) (hne : t≠h) : k t<k h := by
  rcases lt_or_gt_of_ne hne with hlt|hgt
  · exact hm ⟨ht.1,hlt.le⟩ ⟨by linarith,le_rfl⟩ hlt
  · exact ha ⟨le_rfl,by linarith⟩ ⟨hgt.le,ht.2⟩ hgt

end LeanVerification.Sharpness.Fold
