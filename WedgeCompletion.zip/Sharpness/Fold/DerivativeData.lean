import LeanVerification.Sharpness.PathTangent
import LeanVerification.AnalyticTwoPartials

/-! Actual derivative fields for the physical fold equations. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness.Fold
open Loud GeneralMechanical SharpnessAlgebra
set_option maxHeartbeats 2200000

def slopeEnergyDerivative : PeriodParameterSpace → ℝ := verticalDerivative normalizedSlope
def slopeEnergySecondDerivative : PeriodParameterSpace → ℝ := verticalDerivative slopeEnergyDerivative

def slopeParameterDerivative (q : PeriodParameterSpace) : ℝ :=
  fderiv ℝ normalizedSlope q (((1,0),0) : PeriodParameterSpace)

theorem analyticAt_slopeEnergyDerivative {q : PeriodParameterSpace} (hq : q∈jointCenterDomain) :
    AnalyticAt ℝ slopeEnergyDerivative q :=
  analyticAt_verticalDerivative (analyticAt_normalizedSlope hq)

theorem analyticAt_slopeEnergySecondDerivative {q : PeriodParameterSpace} (hq : q∈jointCenterDomain) :
    AnalyticAt ℝ slopeEnergySecondDerivative q :=
  analyticAt_verticalDerivative (analyticAt_slopeEnergyDerivative hq)

theorem analyticAt_slopeParameterDerivative {q : PeriodParameterSpace} (hq : q∈jointCenterDomain) :
    AnalyticAt ℝ slopeParameterDerivative q := by
  exact ((ContinuousLinearMap.apply ℝ ℝ (((1,0),0):PeriodParameterSpace)).analyticAt _).comp
    (analyticAt_normalizedSlope hq).fderiv

theorem slopeEnergyDerivative_eq {q : PeriodParameterSpace} (hq : q∈jointCenterDomain) :
    slopeEnergyDerivative q=deriv (fun h => normalizedSlope (q.1,h)) q.2 :=
  verticalDerivative_eq_deriv (analyticAt_normalizedSlope hq)

theorem slopeEnergySecondDerivative_eq {q : PeriodParameterSpace} (hq : q∈jointCenterDomain) :
    slopeEnergySecondDerivative q=deriv (fun h => slopeEnergyDerivative (q.1,h)) q.2 :=
  verticalDerivative_eq_deriv (analyticAt_slopeEnergyDerivative hq)

theorem slopeEnergyDerivative_fiber_germ {q : PeriodParameterSpace} (hq : q∈jointCenterDomain) :
    (fun h => slopeEnergyDerivative (q.1,h)) =ᶠ[𝓝 q.2]
      deriv (fun h => normalizedSlope (q.1,h)) := by
  have ht : Tendsto (fun h:ℝ => (q.1,h)) (𝓝 q.2) (𝓝 q) :=
    (continuousAt_const.prodMk continuousAt_id).tendsto
  filter_upwards [ht.eventually (isOpen_jointCenterDomain.mem_nhds hq)] with h hh
  exact slopeEnergyDerivative_eq hh

theorem slopeParameterDerivative_eq {q : PeriodParameterSpace} (hq : q∈jointCenterDomain) :
    slopeParameterDerivative q=deriv (fun D => normalizedSlope ((D,q.1.2),q.2)) q.1.1 := by
  have hd := (analyticAt_normalizedSlope hq).differentiableAt.hasFDerivAt.comp_hasDerivAt q.1.1
    (((hasDerivAt_id q.1.1).prodMk (hasDerivAt_const q.1.1 q.1.2)).prodMk
      (hasDerivAt_const q.1.1 q.2))
  exact hd.deriv.symm

theorem fold_center_data (p : ℝ×ℝ) :
    normalizedSlope (p,0)=periodCoefficient p.1 p.2 1 ∧
    slopeEnergyDerivative (p,0)=2*periodCoefficient p.1 p.2 2 ∧
    slopeEnergySecondDerivative (p,0)=6*periodCoefficient p.1 p.2 3 := by
  have hq := jointCenterDomain_contains_center p.1 p.2
  have hs := slope_center_jets p
  refine ⟨hs.1,?_,?_⟩
  · rw [slopeEnergyDerivative_eq hq]
    exact hs.2.1
  · rw [slopeEnergySecondDerivative_eq hq,(slopeEnergyDerivative_fiber_germ hq).deriv_eq]
    exact hs.2.2

theorem fold_star_data :
    normalizedSlope ((dStar,fStar),0)=0 ∧ slopeEnergyDerivative ((dStar,fStar),0)=0 ∧
      slopeEnergySecondDerivative ((dStar,fStar),0)=6*aStar ∧
      slopeParameterDerivative ((dStar,fStar),0)=(rStar-9)/24 := by
  have h := fold_center_data (dStar,fStar)
  simp only [tau1_at_star,tau2_at_star,tau3_at_star,mul_zero] at h
  refine ⟨h.1,h.2.1,h.2.2,?_⟩
  rw [slopeParameterDerivative_eq (jointCenterDomain_contains_center dStar fStar)]
  have he : (fun D => normalizedSlope ((D,fStar),0)) =
      (fun D => periodCoefficient D fStar 1) := funext (fun D => (slope_center_jets (D,fStar)).1)
  rw [he]
  exact actual_partial_coefficients_at_star.1

theorem fold_star_second_pos : 0<slopeEnergySecondDerivative ((dStar,fStar),0) := by
  rw [fold_star_data.2.2.1]
  exact mul_pos (by norm_num) aStar_pos

theorem fold_star_parameter_pos : 0<slopeParameterDerivative ((dStar,fStar),0) := by
  rw [fold_star_data.2.2.2]
  have hr := rStar_bounds.1
  exact div_pos (by linarith) (by norm_num)

theorem physical_second_derivative_eq {D F h : ℝ}
    (hq : ((D,F),h)∈jointCenterDomain) (hh : 0<h) :
    deriv (deriv (periodQuadrature D F)) h=(2*Real.pi)*slopeEnergyDerivative ((D,F),h) := by
  have hd : HasDerivAt (fun k => normalizedSlope ((D,F),k))
      (slopeEnergyDerivative ((D,F),h)) h := by
    rw [slopeEnergyDerivative_eq hq]
    exact (analyticAt_normalizedSlope hq).curry_right.differentiableAt.hasDerivAt
  exact (hasDerivAt_physical_derivative_of_slope hq hh hd).deriv

theorem physical_third_derivative_eq {D F h : ℝ}
    (hq : ((D,F),h)∈jointCenterDomain) (hh : 0<h) :
    deriv (deriv (deriv (periodQuadrature D F))) h=
      (2*Real.pi)*slopeEnergySecondDerivative ((D,F),h) := by
  have hd : HasDerivAt (fun k => slopeEnergyDerivative ((D,F),k))
      (slopeEnergySecondDerivative ((D,F),h)) h := by
    rw [slopeEnergySecondDerivative_eq hq]
    exact (analyticAt_slopeEnergyDerivative hq).curry_right.differentiableAt.hasDerivAt
  have ht : Tendsto (fun k:ℝ => (((D,F),k):PeriodParameterSpace)) (𝓝 h) (𝓝 ((D,F),h)) :=
    (continuousAt_const.prodMk continuousAt_id).tendsto
  have he : deriv (deriv (periodQuadrature D F)) =ᶠ[𝓝 h]
      fun k => (2*Real.pi)*slopeEnergyDerivative ((D,F),k) := by
    filter_upwards [ht.eventually (isOpen_jointCenterDomain.mem_nhds hq),Ioi_mem_nhds hh] with k hk hkp
    exact physical_second_derivative_eq hk hkp
  rw [he.deriv_eq]
  exact (hd.const_mul (2*Real.pi)).deriv

end LeanVerification.Sharpness.Fold
