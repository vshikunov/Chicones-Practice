import LeanVerification.Sharpness.Fold.ParameterCurve

/-! Physical admissibility, double multiplicity, and derivative limits of the fold. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness.Fold
open Loud GeneralMechanical SharpnessAlgebra
set_option maxHeartbeats 2600000

def physicalSlopeParameterDerivative (D F h : ℝ) : ℝ :=
  deriv (fun d => deriv (periodQuadrature d F) h) D

theorem physical_slopeParameterDerivative_eq {D F h : ℝ}
    (hq : ((D,F),h)∈jointCenterDomain) (hh : 0<h) :
    physicalSlopeParameterDerivative D F h=(2*Real.pi)*slopeParameterDerivative ((D,F),h) := by
  have hd : HasDerivAt (fun d => normalizedSlope ((d,F),h))
      (slopeParameterDerivative ((D,F),h)) D := by
    rw [slopeParameterDerivative_eq hq]
    have hf := (analyticAt_normalizedSlope hq).comp_of_eq
      ((analyticAt_id.prod analyticAt_const).prod analyticAt_const) rfl
    exact hf.differentiableAt.hasDerivAt
  have ht : Tendsto (fun d:ℝ => (((d,F),h):PeriodParameterSpace)) (𝓝 D) (𝓝 ((D,F),h)) :=
    ((continuousAt_id.prodMk continuousAt_const).prodMk continuousAt_const).tendsto
  have he : (fun d => deriv (periodQuadrature d F) h) =ᶠ[𝓝 D]
      fun d => (2*Real.pi)*normalizedSlope ((d,F),h) := by
    filter_upwards [ht.eventually (isOpen_jointCenterDomain.mem_nhds hq)] with d hdq
    rw [normalizedSlope_eq_physical_derivative hdq hh]
    field_simp [Real.pi_ne_zero]
  exact ((hd.const_mul (2*Real.pi)).congr_of_eventuallyEq he).deriv

def DoubleCriticalEnergy (D F h : ℝ) : Prop :=
  AdmissibleEnergy D F h ∧ deriv (periodQuadrature D F) h=0 ∧
    deriv (deriv (periodQuadrature D F)) h=0 ∧
    deriv (deriv (deriv (periodQuadrature D F))) h≠0

theorem doubleCriticalEnergy_multiplicity_two {D F h : ℝ} (hc : DoubleCriticalEnergy D F h) :
    AnalyticMultiplicity.vanishingOrder (deriv (periodQuadrature D F)) h=2 := by
  rw [AnalyticMultiplicity.vanishingOrder_eq (analyticAt_periodQuadrature_energy D F h hc.1).deriv]
  exact AnalyticMultiplicity.order_eq_two_of_second_deriv_ne_zero
    (analyticAt_periodQuadrature_energy D F h hc.1).deriv hc.2.1 hc.2.2.1 hc.2.2.2

theorem doubleCriticalEnergy_isolated {D F h : ℝ} (hc : DoubleCriticalEnergy D F h) :
    IsolatedCriticalEnergy D F h := by
  have ha := (analyticAt_periodQuadrature_energy D F h hc.1).deriv
  have hn : ¬ ∀ᶠ k in 𝓝 h,deriv (periodQuadrature D F) k=0 := by
    intro he
    have heq : deriv (periodQuadrature D F) =ᶠ[𝓝 h] fun _ => (0:ℝ) := he
    have hz := heq.deriv.deriv_eq
    have hconst : deriv (fun _ :ℝ => (0:ℝ))=(fun _ => 0) := funext (fun x => deriv_const x 0)
    rw [hconst,deriv_const] at hz
    exact hc.2.2.2 hz
  have hpunc := ha.eventually_eq_zero_or_eventually_ne_zero.resolve_left hn
  have he : ∀ᶠ k in 𝓝 h,k≠h → deriv (periodQuadrature D F) k≠0 := by
    simpa only [eventually_nhdsWithin_iff,mem_compl_iff,mem_singleton_iff] using hpunc
  obtain ⟨ε,hε,he⟩ := Metric.eventually_nhds_iff.mp he
  refine ⟨hc.1,hc.2.1,ε,hε,?_⟩
  intro k _ hk hdist
  exact he (by simpa only [Real.dist_eq] using hdist) hk

theorem physical_fold_of_normalized_equations {D F h : ℝ}
    (hq : ((D,F),h)∈jointCenterDomain) (hh : 0<h)
    (he : foldEquations (h,(D,F))=(0,0))
    (h2 : 0<slopeEnergySecondDerivative ((D,F),h))
    (hD : 0<slopeParameterDerivative ((D,F),h)) :
    DoubleCriticalEnergy D F h ∧
      0<deriv (deriv (deriv (periodQuadrature D F))) h ∧
      0<physicalSlopeParameterDerivative D F h := by
  have hz := congrArg Prod.fst he
  have hdz := congrArg Prod.snd he
  change normalizedSlope ((D,F),h)=0 at hz
  change slopeEnergyDerivative ((D,F),h)=0 at hdz
  have ht0 : deriv (periodQuadrature D F) h=0 := by
    rw [normalizedSlope_eq_physical_derivative hq hh] at hz
    exact (div_eq_zero_iff.mp hz).resolve_right (mul_ne_zero (by norm_num) Real.pi_ne_zero)
  have ht1 : deriv (deriv (periodQuadrature D F)) h=0 := by
    rw [physical_second_derivative_eq hq hh,hdz,mul_zero]
  have ht2 : 0<deriv (deriv (deriv (periodQuadrature D F))) h := by
    rw [physical_third_derivative_eq hq hh]
    exact mul_pos (mul_pos (by norm_num) Real.pi_pos) h2
  have htD : 0<physicalSlopeParameterDerivative D F h := by
    rw [physical_slopeParameterDerivative_eq hq hh]
    exact mul_pos (mul_pos (by norm_num) Real.pi_pos) hD
  exact ⟨⟨(jointCenterPeriod_eq_periodQuadrature hq hh).1,ht0,ht1,ht2.ne'⟩,ht2,htD⟩

theorem exists_regular_fold_parameter_curve :
    ∃ p : ℝ → ℝ×ℝ,AnalyticAt ℝ p 0 ∧ p 0=(dStar,fStar) ∧ deriv p 0=foldTangent ∧
      (∀ᶠ h in 𝓝 (0:ℝ), foldEquations (h,p h)=(0,0) ∧ (p h,h)∈jointCenterDomain ∧
        0<slopeEnergySecondDerivative (p h,h) ∧ 0<slopeParameterDerivative (p h,h) ∧
        (-1/2:ℝ)<(p h).1 ∧ (p h).1<0 ∧ 0<(p h).2 ∧ (p h).2<1/2) ∧
      (∀ᶠ q in 𝓝 ((0,(dStar,fStar)):ℝ×(ℝ×ℝ)),foldEquations q=(0,0) → p q.1=q.2) := by
  obtain ⟨p,hp,hp0,he,hu⟩ := exists_actual_fold_parameter_curve
  have hm : Tendsto (fun h:ℝ => (p h,h)) (𝓝 0) (𝓝 ((dStar,fStar),0)) := by
    simpa only [hp0,id_eq] using (hp.continuousAt.prodMk continuousAt_id).tendsto
  have hbase := jointCenterDomain_contains_center dStar fStar
  have h2 := (analyticAt_slopeEnergySecondDerivative hbase).continuousAt.tendsto.comp hm
  have hD := (analyticAt_slopeParameterDerivative hbase).continuousAt.tendsto.comp hm
  refine ⟨p,hp,hp0,actual_fold_parameter_tangent hp hp0 he,?_,hu⟩
  filter_upwards [he,hm.eventually (isOpen_jointCenterDomain.mem_nhds hbase),
    h2.eventually_const_lt fold_star_second_pos,hD.eventually_const_lt fold_star_parameter_pos,
    parameter_path_eventually_in_sharpness_region hp.continuousAt hp0] with h hh hdom hh2 hhD hreg
  exact ⟨hh,hdom,hh2,hhD,hreg⟩

theorem exists_physical_fold_curve :
    ∃ p : ℝ → ℝ×ℝ,AnalyticAt ℝ p 0 ∧ p 0=(dStar,fStar) ∧ deriv p 0=foldTangent ∧
      ∃ δ>0,∀ h,0<h → h<δ → DoubleCriticalEnergy (p h).1 (p h).2 h ∧
        0<deriv (deriv (deriv (periodQuadrature (p h).1 (p h).2))) h ∧
        0<physicalSlopeParameterDerivative (p h).1 (p h).2 h ∧
        (-1/2:ℝ)<(p h).1 ∧ (p h).1<0 ∧ 0<(p h).2 ∧ (p h).2<1/2 := by
  obtain ⟨p,hp,hp0,hpt,he,_⟩ := exists_regular_fold_parameter_curve
  obtain ⟨δ,hδ,hlocal⟩ := Metric.eventually_nhds_iff.mp he
  refine ⟨p,hp,hp0,hpt,δ,hδ,?_⟩
  intro h hh hhδ
  obtain ⟨hz,hdom,h2,hD,hreg⟩ := hlocal (y:=h)
    (by simpa only [Real.dist_eq,sub_zero,abs_of_pos hh] using hhδ)
  have hc := physical_fold_of_normalized_equations hdom hh hz h2 hD
  exact ⟨hc.1,hc.2.1,hc.2.2,hreg⟩

theorem physical_fold_derivative_limits {p : ℝ → ℝ×ℝ}
    (hp : ContinuousAt p 0) (hp0 : p 0=(dStar,fStar)) :
    Tendsto (fun h => physicalSlopeParameterDerivative (p h).1 (p h).2 h)
      (𝓝[>] (0:ℝ)) (𝓝 ((2*Real.pi)*((rStar-9)/24))) ∧
    Tendsto (fun h => deriv (deriv (deriv (periodQuadrature (p h).1 (p h).2))) h)
      (𝓝[>] (0:ℝ)) (𝓝 (12*Real.pi*aStar)) := by
  have hbase := jointCenterDomain_contains_center dStar fStar
  have hm : Tendsto (fun h:ℝ => (p h,h)) (𝓝 0) (𝓝 ((dStar,fStar),0)) := by
    simpa only [hp0,id_eq] using (hp.prodMk continuousAt_id).tendsto
  have he := hm.eventually (isOpen_jointCenterDomain.mem_nhds hbase)
  have hc : Tendsto (fun _ :ℝ => 2*Real.pi) (𝓝 (0:ℝ)) (𝓝 (2*Real.pi)) := tendsto_const_nhds
  have hD := hc.mul ((analyticAt_slopeParameterDerivative hbase).continuousAt.tendsto.comp hm)
  have h2 := hc.mul ((analyticAt_slopeEnergySecondDerivative hbase).continuousAt.tendsto.comp hm)
  constructor
  · have hh : Tendsto (fun h:ℝ => (2*Real.pi)*slopeParameterDerivative (p h,h))
        (𝓝[>] (0:ℝ)) (𝓝 ((2*Real.pi)*((rStar-9)/24))) := by
      simpa only [fold_star_data.2.2.2] using hD.mono_left nhdsWithin_le_nhds
    apply hh.congr'
    filter_upwards [he.filter_mono nhdsWithin_le_nhds,self_mem_nhdsWithin] with h hq hh
    exact (physical_slopeParameterDerivative_eq hq hh).symm
  · have hh : Tendsto (fun h:ℝ => (2*Real.pi)*slopeEnergySecondDerivative (p h,h))
        (𝓝[>] (0:ℝ)) (𝓝 (12*Real.pi*aStar)) := by
      have heq : (2*Real.pi)*(6*aStar)=12*Real.pi*aStar := by ring
      simpa only [fold_star_data.2.2.1,heq] using h2.mono_left nhdsWithin_le_nhds
    apply hh.congr'
    filter_upwards [he.filter_mono nhdsWithin_le_nhds,self_mem_nhdsWithin] with h hq hh
    exact (physical_third_derivative_eq hq hh).symm

end LeanVerification.Sharpness.Fold
