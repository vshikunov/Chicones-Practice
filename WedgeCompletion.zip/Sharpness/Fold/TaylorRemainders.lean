import LeanVerification.Sharpness.Fold.ParameterCurve

/-! Explicit analytic remainder statements for the displayed local expansions. -/
noncomputable section
open Set Filter Asymptotics
open scoped Topology
namespace LeanVerification.Sharpness.Fold
set_option maxHeartbeats 1800000

theorem analytic_linear_remainder {f : ℝ → ℝ} (hf : AnalyticAt ℝ f 0) :
    (fun x => f x-f 0-deriv f 0*x) =O[𝓝 (0:ℝ)] (fun x => x^2) := by
  have hs := hf.hasFPowerSeriesAt.isBigO_sub_partialSum_pow 2
  simpa [FormalMultilinearSeries.partialSum,Finset.sum_range_succ,
    FormalMultilinearSeries.ofScalars_apply_eq,iteratedDeriv_zero,iteratedDeriv_one,
    Nat.factorial,Real.norm_eq_abs,sq_abs,sub_sub,mul_comm] using hs

theorem analytic_quadratic_remainder {f : ℝ → ℝ} (hf : AnalyticAt ℝ f 0) :
    (fun x => f x-f 0-deriv f 0*x-deriv (deriv f) 0/2*x^2)
      =O[𝓝 (0:ℝ)] (fun x => ‖x‖^3) := by
  have hs := hf.hasFPowerSeriesAt.isBigO_sub_partialSum_pow 3
  simpa [FormalMultilinearSeries.partialSum,Finset.sum_range_succ,
    FormalMultilinearSeries.ofScalars_apply_eq,iteratedDeriv_succ,iteratedDeriv_zero,
    Nat.factorial,sub_sub,add_assoc,mul_comm] using hs


theorem actual_fold_parameter_remainders {p : ℝ → ℝ×ℝ}
    (hp : AnalyticAt ℝ p 0) (hp0 : p 0=(SharpnessAlgebra.dStar,SharpnessAlgebra.fStar))
    (he : ∀ᶠ h in 𝓝 (0:ℝ),foldEquations (h,p h)=(0,0)) :
    (fun h => (p h).1-SharpnessAlgebra.dStar-(SharpnessAlgebra.rStar-3)/750*h)
      =O[𝓝 (0:ℝ)] (fun h => h^2) ∧
    (fun h => (p h).2-SharpnessAlgebra.fStar-(195-17*SharpnessAlgebra.rStar)/12000*h)
      =O[𝓝 (0:ℝ)] (fun h => h^2) := by
  have hpt := actual_fold_parameter_tangent hp hp0 he
  have haD : AnalyticAt ℝ (fun h => (p h).1) 0 := analyticAt_fst.comp hp
  have haF : AnalyticAt ℝ (fun h => (p h).2) 0 := analyticAt_snd.comp hp
  have hdD : HasDerivAt (fun h => (p h).1) (deriv p 0).1 0 :=
    (ContinuousLinearMap.fst ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt 0 hp.differentiableAt.hasDerivAt
  have hdF : HasDerivAt (fun h => (p h).2) (deriv p 0).2 0 :=
    (ContinuousLinearMap.snd ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt 0 hp.differentiableAt.hasDerivAt
  have hD : deriv (fun h => (p h).1) 0=(SharpnessAlgebra.rStar-3)/750 := by
    rw [hdD.deriv,hpt]
    rfl
  have hF : deriv (fun h => (p h).2) 0=(195-17*SharpnessAlgebra.rStar)/12000 := by
    rw [hdF.deriv,hpt]
    rfl
  constructor
  · simpa only [hp0,hD] using analytic_linear_remainder haD
  · simpa only [hp0,hF] using analytic_linear_remainder haF

end LeanVerification.Sharpness.Fold
