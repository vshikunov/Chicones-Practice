import LeanVerification.Sharpness.Fold.ParameterInverse
import LeanVerification.Sharpness.Fold.DerivativeData

/-! The actual analytic fold parameter curve and its exact tangent. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness.Fold
open Loud GeneralMechanical SharpnessAlgebra
set_option maxHeartbeats 2400000

def scaleSecond : (ℝ×ℝ) →L[ℝ] ℝ×ℝ :=
  (ContinuousLinearMap.fst ℝ ℝ ℝ).prod ((2:ℝ) • ContinuousLinearMap.snd ℝ ℝ ℝ)

theorem scaleSecond_apply (p : ℝ×ℝ) : scaleSecond p=(p.1,2*p.2) := by simp [scaleSecond]

theorem scaleSecond_bijective : Function.Bijective scaleSecond := by
  constructor
  · intro p q he
    have h1 := congrArg Prod.fst he
    have h2 := congrArg Prod.snd he
    simp only [scaleSecond_apply] at h1 h2
    exact Prod.ext h1 (by linarith)
  · intro q
    refine ⟨(q.1,q.2/2),?_⟩
    rw [scaleSecond_apply]
    ext <;> dsimp <;> ring

def foldEquations (q : ℝ×(ℝ×ℝ)) : ℝ×ℝ :=
  (normalizedSlope (q.2,q.1),slopeEnergyDerivative (q.2,q.1))

theorem analyticAt_foldEquations {q : ℝ×(ℝ×ℝ)} (hq : (q.2,q.1)∈jointCenterDomain) :
    AnalyticAt ℝ foldEquations q := by
  have hm : AnalyticAt ℝ (fun r : ℝ×(ℝ×ℝ) => (r.2,r.1)) q :=
    analyticAt_snd.prod analyticAt_fst
  exact ((analyticAt_normalizedSlope hq).comp_of_eq hm rfl).prod
    ((analyticAt_slopeEnergyDerivative hq).comp_of_eq hm rfl)

theorem foldEquations_center (p : ℝ×ℝ) :
    foldEquations (0,p)=scaleSecond (coefficientMap p) := by
  rw [foldEquations,(fold_center_data p).1,(fold_center_data p).2.1]
  rw [scaleSecond_apply]
  rfl

theorem foldEquations_star : foldEquations (0,(dStar,fStar))=(0,0) := by
  rw [foldEquations_center,coefficientMap_star,scaleSecond_apply]
  norm_num

def foldParameterLinear : (ℝ×ℝ) →L[ℝ] ℝ×ℝ :=
  (fderiv ℝ foldEquations (0,(dStar,fStar))).comp (ContinuousLinearMap.inr ℝ ℝ (ℝ×ℝ))

theorem foldParameterLinear_eq : foldParameterLinear=
    scaleSecond.comp (fderiv ℝ coefficientMap (dStar,fStar)) := by
  have hf := analyticAt_foldEquations (q:=(0,(dStar,fStar))) (jointCenterDomain_contains_center dStar fStar)
  have hcomp := hf.differentiableAt.hasFDerivAt.comp (dStar,fStar)
    (ContinuousLinearMap.inr ℝ ℝ (ℝ×ℝ)).hasFDerivAt
  have he : (fun p:ℝ×ℝ => foldEquations (0,p))=(fun p => scaleSecond (coefficientMap p)) :=
    funext foldEquations_center
  have hc := scaleSecond.hasFDerivAt.comp (dStar,fStar)
    (analyticAt_coefficientMap (dStar,fStar)).differentiableAt.hasFDerivAt
  have hh : fderiv ℝ (fun p:ℝ×ℝ => foldEquations (0,p)) (dStar,fStar)=foldParameterLinear :=
    hcomp.fderiv
  rw [←hh,he]
  exact hc.fderiv

theorem foldParameterLinear_bijective : Function.Bijective foldParameterLinear := by
  rw [foldParameterLinear_eq]
  exact scaleSecond_bijective.comp fderiv_coefficientMap_bijective

theorem exists_actual_fold_parameter_curve :
    ∃ p : ℝ → ℝ×ℝ, AnalyticAt ℝ p 0 ∧ p 0=(dStar,fStar) ∧
      (∀ᶠ h in 𝓝 (0:ℝ),foldEquations (h,p h)=(0,0)) ∧
      (∀ᶠ q in 𝓝 ((0,(dStar,fStar)):ℝ×(ℝ×ℝ)),
        foldEquations q=(0,0) → p q.1=q.2) := by
  obtain ⟨I,hI,hI0,hr,hl⟩ := exists_analytic_vector_fiber_inverse
    (analyticAt_foldEquations (q:=(0,(dStar,fStar))) (jointCenterDomain_contains_center dStar fStar)) foldParameterLinear_bijective
  simp only [foldEquations_star] at hI hI0 hr
  let p : ℝ → ℝ×ℝ := fun h => I (h,(0,0))
  have hm : AnalyticAt ℝ (fun h:ℝ => (h,((0,0):ℝ×ℝ))) 0 := analyticAt_id.prod analyticAt_const
  refine ⟨p,hI.comp_of_eq hm rfl,hI0,?_,?_⟩
  · filter_upwards [hm.continuousAt.tendsto.eventually hr] with h hh
    exact hh
  · filter_upwards [hl] with q hq
    intro hz
    simpa only [p,hz] using hq

theorem foldEquations_energy_column :
    fderiv ℝ foldEquations (0,(dStar,fStar)) (1,0)=(0,6*aStar) := by
  have hq := jointCenterDomain_contains_center dStar fStar
  have hH : HasDerivAt (fun h => normalizedSlope ((dStar,fStar),h)) 0 0 := by
    have hd := (analyticAt_normalizedSlope hq).curry_right.differentiableAt.hasDerivAt
    rwa [←slopeEnergyDerivative_eq hq,fold_star_data.2.1] at hd
  have hE : HasDerivAt (fun h => slopeEnergyDerivative ((dStar,fStar),h)) (6*aStar) 0 := by
    have hd := (analyticAt_slopeEnergyDerivative hq).curry_right.differentiableAt.hasDerivAt
    rwa [←slopeEnergySecondDerivative_eq hq,fold_star_data.2.2.1] at hd
  have hm : HasDerivAt (fun h:ℝ => (h,((dStar,fStar):ℝ×ℝ))) (1,0) (0:ℝ) :=
    (hasDerivAt_id (0:ℝ)).prodMk (hasDerivAt_const (0:ℝ) ((dStar,fStar):ℝ×ℝ))
  have hf := (analyticAt_foldEquations (q:=(0,(dStar,fStar))) hq).differentiableAt.hasFDerivAt.comp_hasDerivAt_of_eq (0:ℝ) hm rfl
  exact hf.unique (hH.prodMk hE)

def foldTangent : ℝ×ℝ := ((rStar-3)/750,(195-17*rStar)/12000)

theorem foldParameterLinear_tangent : foldParameterLinear foldTangent=(0,-6*aStar) := by
  have hv : foldTangent=(2/3:ℝ) • (((rStar-3)/500,(195-17*rStar)/8000):ℝ×ℝ) := by
    ext <;> dsimp only [foldTangent,Prod.smul_fst,Prod.smul_snd,smul_eq_mul] <;> ring
  rw [foldParameterLinear_eq,hv,ContinuousLinearMap.comp_apply,map_smul,
    coefficientMap_expected_tangent,scaleSecond_apply]
  ext <;> dsimp only [Prod.smul_fst,Prod.smul_snd,smul_eq_mul] <;> ring

theorem actual_fold_parameter_tangent {p : ℝ → ℝ×ℝ}
    (hp : AnalyticAt ℝ p 0) (hp0 : p 0=(dStar,fStar))
    (he : ∀ᶠ h in 𝓝 (0:ℝ),foldEquations (h,p h)=(0,0)) : deriv p 0=foldTangent := by
  let L := fderiv ℝ foldEquations (0,(dStar,fStar))
  have hf : AnalyticAt ℝ foldEquations (0,p 0) := by
    rw [hp0]
    exact analyticAt_foldEquations (q:=(0,(dStar,fStar))) (jointCenterDomain_contains_center dStar fStar)
  have hd := hf.differentiableAt.hasFDerivAt.comp_hasDerivAt 0
    ((hasDerivAt_id 0).prodMk hp.differentiableAt.hasDerivAt)
  have heq : (fun h => foldEquations (h,p h)) =ᶠ[𝓝 0] fun _ => ((0,0):ℝ×ℝ) := he
  have hL : L (1,deriv p 0)=0 := by
    simpa only [hp0,deriv_const] using hd.deriv.symm.trans heq.deriv_eq
  have hv : ((1,deriv p 0):ℝ×(ℝ×ℝ))=(1,0)+(0,deriv p 0) := by simp
  rw [hv,map_add,show L (1,0)=(0,6*aStar) from foldEquations_energy_column] at hL
  have hA : foldParameterLinear (deriv p 0)=(0,-6*aStar) := by
    have h1 := congrArg Prod.fst hL
    have h2 := congrArg Prod.snd hL
    apply Prod.ext
    · change (L (0,deriv p 0)).1=0
      change 0+(L (0,deriv p 0)).1=0 at h1
      linarith
    · change (L (0,deriv p 0)).2= -6*aStar
      change 6*aStar+(L (0,deriv p 0)).2=0 at h2
      linarith
  exact foldParameterLinear_bijective.1 (hA.trans foldParameterLinear_tangent.symm)

end LeanVerification.Sharpness.Fold
