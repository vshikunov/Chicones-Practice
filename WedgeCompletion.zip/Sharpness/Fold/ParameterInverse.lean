import LeanVerification.Sharpness.PathTangent

/-! Analytic inversion of a vector fiber with parameters retained. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness.Fold

variable {E P : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup P] [NormedSpace ℝ P]
  [CompleteSpace E] [CompleteSpace P] [FiniteDimensional ℝ E] [FiniteDimensional ℝ P]
set_option maxHeartbeats 2000000

theorem vector_triangular_bijective (l : (E×P) →L[ℝ] P)
    (ha : Function.Bijective (l.comp (ContinuousLinearMap.inr ℝ E P))) :
    Function.Bijective ((ContinuousLinearMap.fst ℝ E P).prod l) := by
  have hs (q : E×P) : l q=l (q.1,0)+l (0,q.2) := by
    have he : q=(q.1,0)+(0,q.2) := by simp
    conv_lhs => rw [he]
    exact map_add l _ _
  constructor
  · intro q r he
    have hp := congrArg Prod.fst he
    have hl := congrArg Prod.snd he
    change q.1=r.1 at hp
    change l q=l r at hl
    apply Prod.ext hp
    apply ha.1
    change l (0,q.2)=l (0,r.2)
    rw [hs q,hs r,hp] at hl
    exact add_left_cancel hl
  · intro q
    obtain ⟨v,hv⟩ := ha.2 (q.2-l (q.1,0))
    refine ⟨(q.1,v),Prod.ext rfl ?_⟩
    change l (q.1,v)=q.2
    change l (0,v)=q.2-l (q.1,0) at hv
    rw [hs,hv]
    abel

theorem exists_analytic_vector_fiber_inverse {f : E×P → P} {e : E} {p : P}
    (hf : AnalyticAt ℝ f (e,p))
    (ha : Function.Bijective ((fderiv ℝ f (e,p)).comp (ContinuousLinearMap.inr ℝ E P))) :
    ∃ I : E×P → P, AnalyticAt ℝ I (e,f (e,p)) ∧ I (e,f (e,p))=p ∧
      (∀ᶠ q in 𝓝 (e,f (e,p)),f (q.1,I q)=q.2) ∧
      (∀ᶠ q in 𝓝 (e,p),I (q.1,f q)=q.2) := by
  let G : E×P → E×P := fun q => (q.1,f q)
  let l := fderiv ℝ f (e,p)
  let L := (ContinuousLinearMap.fst ℝ E P).prod l
  have hL : Function.Bijective L := vector_triangular_bijective l ha
  let v := ContinuousLinearEquiv.ofBijective L
    (LinearMap.ker_eq_bot.mpr hL.1) (LinearMap.range_eq_top.mpr hL.2)
  have he : HasStrictFDerivAt G (v : (E×P) →L[ℝ] E×P) (e,p) := by
    simpa only [G,v,ContinuousLinearEquiv.coe_ofBijective,L,l] using
      hasStrictFDerivAt_fst.prodMk hf.hasStrictFDerivAt
  let J := he.localInverse G _ _
  have hG : AnalyticAt ℝ G (e,p) := analyticAt_fst.prod hf
  have hJ : AnalyticAt ℝ J (G (e,p)) :=
    (he.toPartialHomeomorph G).analyticAt_symm' he.mem_toPartialHomeomorph_source hG he.hasFDerivAt.fderiv
  refine ⟨fun q => (J q).2,analyticAt_snd.comp hJ,?_,?_,?_⟩
  · exact congrArg Prod.snd he.localInverse_apply_image
  · filter_upwards [he.eventually_right_inverse] with q hq
    have hp := congrArg Prod.fst hq
    have hf' := congrArg Prod.snd hq
    change (J q).1=q.1 at hp
    change f (J q)=q.2 at hf'
    simpa only [←hp,Prod.mk.eta] using hf'
  · filter_upwards [he.eventually_left_inverse] with q hq
    exact congrArg Prod.snd hq

end LeanVerification.Sharpness.Fold
