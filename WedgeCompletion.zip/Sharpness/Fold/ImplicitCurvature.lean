import LeanVerification.Sharpness.Fold.DerivativeData
import LeanVerification.GeneralMechanical.ParametricInverse

/-! Derivatives of an actual analytic implicit level graph. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness.Fold
open AnalyticTwoPartials GeneralMechanical
set_option maxHeartbeats 2400000

theorem scalar_linear_formula (L : (ℝ×ℝ) →L[ℝ] ℝ) (p : ℝ×ℝ) :
    L p=p.1*L (1,0)+p.2*L (0,1) := by
  have he : p=p.1 • ((1,0):ℝ×ℝ)+p.2 • ((0,1):ℝ×ℝ) := by ext <;> simp
  conv_lhs => rw [he]
  rw [map_add,map_smul,map_smul]
  rfl

theorem hasDerivAt_graph_composition {f : ℝ×ℝ → ℝ} {k : ℝ → ℝ} {h : ℝ}
    (hf : AnalyticAt ℝ f (k h,h)) (hk : AnalyticAt ℝ k h) :
    HasDerivAt (fun t => f (k t,t))
      (left f (k h,h)*deriv k h+right f (k h,h)) h := by
  have hm : HasDerivAt (fun t => (k t,t)) (deriv k h,1) h :=
    hk.differentiableAt.hasDerivAt.prodMk (hasDerivAt_id h)
  have hd := hf.differentiableAt.hasFDerivAt.comp_hasDerivAt_of_eq h hm rfl
  apply hd.congr_deriv
  rw [scalar_linear_formula,left_eq_fderiv hf.differentiableAt,right_eq_fderiv hf.differentiableAt]
  ring

theorem implicit_graph_derivative_zero {f : ℝ×ℝ → ℝ} {k : ℝ → ℝ} {h : ℝ}
    (hf : AnalyticAt ℝ f (k h,h)) (hk : AnalyticAt ℝ k h)
    (he : ∀ᶠ t in 𝓝 h,f (k t,t)=0)
    (hx : left f (k h,h)≠0) (hy : right f (k h,h)=0) : deriv k h=0 := by
  have hzero : (fun t => f (k t,t)) =ᶠ[𝓝 h] fun _ => (0:ℝ) := he
  have hd := (hasDerivAt_graph_composition hf hk).deriv
  rw [hzero.deriv_eq,deriv_const,hy,add_zero] at hd
  exact (mul_eq_zero.mp hd.symm).resolve_left hx

theorem implicit_graph_second_derivative {f : ℝ×ℝ → ℝ} {k : ℝ → ℝ} {h : ℝ}
    (hf : AnalyticAt ℝ f (k h,h)) (hk : AnalyticAt ℝ k h)
    (he : ∀ᶠ t in 𝓝 h,f (k t,t)=0)
    (hx : left f (k h,h)≠0) (hy : right f (k h,h)=0) :
    deriv (deriv k) h = -right (right f) (k h,h)/left f (k h,h) := by
  have hk0 := implicit_graph_derivative_zero hf hk he hx hy
  have hmap : ContinuousAt (fun t => (k t,t)) h := hk.continuousAt.prodMk continuousAt_id
  have hanalytic : ∀ᶠ t in 𝓝 h,AnalyticAt ℝ f (k t,t) := hmap.eventually hf.eventually_analyticAt
  have hgerm : deriv (fun t => f (k t,t)) =ᶠ[𝓝 h]
      fun t => left f (k t,t)*deriv k t+right f (k t,t) := by
    filter_upwards [hanalytic,hk.eventually_analyticAt] with t hft hkt
    exact (hasDerivAt_graph_composition hft hkt).deriv
  have hzero : (fun t => f (k t,t)) =ᶠ[𝓝 h] fun _ => (0:ℝ) := he
  have hz2 : deriv (deriv (fun t => f (k t,t))) h=0 := by
    have hc : deriv (fun _ :ℝ => (0:ℝ))=(fun _ => 0) := funext (fun x => deriv_const x 0)
    rw [hzero.deriv.deriv_eq,hc,deriv_const]
  have hL := hasDerivAt_graph_composition (analyticAt_left hf) hk
  have hR := hasDerivAt_graph_composition (analyticAt_right hf) hk
  have hd := (hL.mul hk.deriv.differentiableAt.hasDerivAt).add hR
  have hder := hd.deriv
  rw [←hgerm.deriv_eq,hz2,hk0] at hder
  simp only [mul_zero,zero_mul,zero_add,add_zero] at hder
  apply (eq_div_iff hx).mpr
  nlinarith only [hder]

theorem exists_analytic_fixed_level_graph {f : ℝ×ℝ → ℝ} {x h : ℝ}
    (hf : AnalyticAt ℝ f (x,h)) (hz : f (x,h)=0) (hx : left f (x,h)≠0) :
    ∃ k : ℝ → ℝ,AnalyticAt ℝ k h ∧ k h=x ∧
      (∀ᶠ t in 𝓝 h,f (k t,t)=0) ∧
      (∀ᶠ q in 𝓝 (x,h),f q=0 ↔ q.1=k q.2) := by
  let G : ℝ×ℝ → ℝ := fun q => f (q.2,q.1)
  have hG : AnalyticAt ℝ G (h,x) := hf.comp_of_eq (analyticAt_snd.prod analyticAt_fst) rfl
  have hGz : G (h,x)=0 := hz
  have hGd : deriv (fun t => G (h,t)) x≠0 := hx
  obtain ⟨I,hI,hI0,hr,hl⟩ := exists_analytic_fiber_inverse_germ hG hGd
  simp only [hGz] at hI hI0 hr
  let k : ℝ → ℝ := fun t => I (t,0)
  have hm : AnalyticAt ℝ (fun t:ℝ => (t,(0:ℝ))) h := analyticAt_id.prod analyticAt_const
  have hk : AnalyticAt ℝ k h := hI.comp_of_eq hm rfl
  have he : ∀ᶠ t in 𝓝 h,f (k t,t)=0 := by
    filter_upwards [hm.continuousAt.tendsto.eventually hr] with t ht
    exact ht
  refine ⟨k,hk,hI0,he,?_⟩
  have ht : Tendsto (fun q:ℝ×ℝ => (q.2,q.1)) (𝓝 (x,h)) (𝓝 (h,x)) :=
    (continuousAt_snd.prodMk continuousAt_fst).tendsto
  have hte : Tendsto (fun q:ℝ×ℝ => q.2) (𝓝 (x,h)) (𝓝 h) := continuousAt_snd.tendsto
  filter_upwards [ht.eventually hl,hte.eventually he] with q hq hroot
  constructor
  · intro hzq
    change I (q.2,f q)=q.1 at hq
    rw [hzq] at hq
    exact hq.symm
  · intro hqk
    simpa only [←hqk,Prod.mk.eta] using hroot

end LeanVerification.Sharpness.Fold
