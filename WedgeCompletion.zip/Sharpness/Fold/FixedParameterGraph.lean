import LeanVerification.Sharpness.Fold.PhysicalFold
import LeanVerification.Sharpness.Fold.ImplicitCurvature

/-! The physical fold as a local graph at fixed F, with actual curvature. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness.Fold
open Loud GeneralMechanical SharpnessAlgebra AnalyticTwoPartials
set_option maxHeartbeats 2600000

def fixedParameterSlope (F : ℝ) (q : ℝ×ℝ) : ℝ := normalizedSlope ((q.1,F),q.2)

theorem analyticAt_fixedParameterSlope {D F h : ℝ} (hq : ((D,F),h)∈jointCenterDomain) :
    AnalyticAt ℝ (fixedParameterSlope F) (D,h) :=
  (analyticAt_normalizedSlope hq).comp_of_eq
    ((analyticAt_fst.prod analyticAt_const).prod analyticAt_snd) rfl

theorem left_fixedParameterSlope {D F h : ℝ} (hq : ((D,F),h)∈jointCenterDomain) :
    left (fixedParameterSlope F) (D,h)=slopeParameterDerivative ((D,F),h) :=
  (slopeParameterDerivative_eq hq).symm

theorem right_fixedParameterSlope {D F h : ℝ} (hq : ((D,F),h)∈jointCenterDomain) :
    right (fixedParameterSlope F) (D,h)=slopeEnergyDerivative ((D,F),h) :=
  (slopeEnergyDerivative_eq hq).symm

theorem right_right_fixedParameterSlope {D F h : ℝ} (hq : ((D,F),h)∈jointCenterDomain) :
    right (right (fixedParameterSlope F)) (D,h)=slopeEnergySecondDerivative ((D,F),h) := by
  have ht : Tendsto (fun t:ℝ => (((D,F),t):PeriodParameterSpace)) (𝓝 h) (𝓝 ((D,F),h)) :=
    (continuousAt_const.prodMk continuousAt_id).tendsto
  have he : (fun t => right (fixedParameterSlope F) (D,t)) =ᶠ[𝓝 h]
      (fun t => slopeEnergyDerivative ((D,F),t)) := by
    filter_upwards [ht.eventually (isOpen_jointCenterDomain.mem_nhds hq)] with t htq
    exact right_fixedParameterSlope htq
  change deriv (fun t => right (fixedParameterSlope F) (D,t)) h=_
  rw [he.deriv_eq]
  exact (slopeEnergySecondDerivative_eq hq).symm

theorem exists_actual_fixed_parameter_fold_graph {D F h : ℝ}
    (hq : ((D,F),h)∈jointCenterDomain) (hh : 0<h)
    (he : foldEquations (h,(D,F))=(0,0))
    (h2 : 0<slopeEnergySecondDerivative ((D,F),h))
    (hD : 0<slopeParameterDerivative ((D,F),h)) :
    ∃ k : ℝ → ℝ,AnalyticAt ℝ k h ∧ k h=D ∧ deriv k h=0 ∧
      deriv (deriv k) h= -deriv (deriv (deriv (periodQuadrature D F))) h/
        physicalSlopeParameterDerivative D F h ∧ deriv (deriv k) h<0 ∧
      (∀ᶠ q in 𝓝 ((D,h):ℝ×ℝ),AdmissibleEnergy q.1 F q.2 ∧
        (deriv (periodQuadrature q.1 F) q.2=0 ↔ q.1=k q.2)) := by
  have hz := congrArg Prod.fst he
  have hdz := congrArg Prod.snd he
  change normalizedSlope ((D,F),h)=0 at hz
  change slopeEnergyDerivative ((D,F),h)=0 at hdz
  have hf := analyticAt_fixedParameterSlope hq
  have hx : left (fixedParameterSlope F) (D,h)≠0 := by
    rw [left_fixedParameterSlope hq]
    exact hD.ne'
  obtain ⟨k,hk,hk0,heq,hiff⟩ := exists_analytic_fixed_level_graph hf hz hx
  have hf' : AnalyticAt ℝ (fixedParameterSlope F) (k h,h) := by rw [hk0]; exact hf
  have hx' : left (fixedParameterSlope F) (k h,h)≠0 := by rw [hk0]; exact hx
  have hy' : right (fixedParameterSlope F) (k h,h)=0 := by
    rw [hk0,right_fixedParameterSlope hq,hdz]
  have hk1 := implicit_graph_derivative_zero hf' hk heq hx' hy'
  have hk2 := implicit_graph_second_derivative hf' hk heq hx' hy'
  rw [hk0,right_right_fixedParameterSlope hq,left_fixedParameterSlope hq] at hk2
  have hcurv : deriv (deriv k) h<0 := by
    rw [hk2]
    exact div_neg_of_neg_of_pos (neg_neg_of_pos h2) hD
  refine ⟨k,hk,hk0,hk1,?_,hcurv,?_⟩
  · rw [hk2,physical_third_derivative_eq hq hh,physical_slopeParameterDerivative_eq hq hh]
    field_simp [Real.pi_ne_zero,hD.ne']
    <;> ring
  · have hm : Tendsto (fun q:ℝ×ℝ => (((q.1,F),q.2):PeriodParameterSpace))
        (𝓝 (D,h)) (𝓝 ((D,F),h)) :=
      ((continuousAt_fst.prodMk continuousAt_const).prodMk continuousAt_snd).tendsto
    have hp : ∀ᶠ q:ℝ×ℝ in 𝓝 (D,h),0<q.2 := continuousAt_snd.tendsto.eventually_const_lt hh
    filter_upwards [hiff,hm.eventually (isOpen_jointCenterDomain.mem_nhds hq),hp] with q hqi hqdom hqp
    refine ⟨(jointCenterPeriod_eq_periodQuadrature hqdom hqp).1,?_⟩
    have hzero : deriv (periodQuadrature q.1 F) q.2=0 ↔ fixedParameterSlope F q=0 := by
      change _ ↔ normalizedSlope ((q.1,F),q.2)=0
      rw [normalizedSlope_eq_physical_derivative hqdom hqp]
      constructor
      · intro hez
        rw [hez,zero_div]
      · intro hez
        exact (div_eq_zero_iff.mp hez).resolve_right (mul_ne_zero (by norm_num) Real.pi_ne_zero)
    exact hzero.trans hqi

theorem exists_physical_fold_curve_with_local_graphs :
    ∃ p : ℝ → ℝ×ℝ,AnalyticAt ℝ p 0 ∧ p 0=(dStar,fStar) ∧ deriv p 0=foldTangent ∧
      ∃ δ>0,∀ h,0<h → h<δ →
        DoubleCriticalEnergy (p h).1 (p h).2 h ∧
        (∃ k : ℝ → ℝ,AnalyticAt ℝ k h ∧ k h=(p h).1 ∧ deriv k h=0 ∧
          deriv (deriv k) h= -deriv (deriv (deriv (periodQuadrature (p h).1 (p h).2))) h/
            physicalSlopeParameterDerivative (p h).1 (p h).2 h ∧ deriv (deriv k) h<0 ∧
          (∀ᶠ q in 𝓝 (((p h).1,h):ℝ×ℝ),AdmissibleEnergy q.1 (p h).2 q.2 ∧
            (deriv (periodQuadrature q.1 (p h).2) q.2=0 ↔ q.1=k q.2))) := by
  obtain ⟨p,hp,hp0,hpt,he,_⟩ := exists_regular_fold_parameter_curve
  obtain ⟨δ,hδ,hlocal⟩ := Metric.eventually_nhds_iff.mp he
  refine ⟨p,hp,hp0,hpt,δ,hδ,?_⟩
  intro h hh hhδ
  obtain ⟨hz,hdom,h2,hD,_⟩ := hlocal (y:=h)
    (by simpa only [Real.dist_eq,sub_zero,abs_of_pos hh] using hhδ)
  exact ⟨(physical_fold_of_normalized_equations hdom hh hz h2 hD).1,
    exists_actual_fixed_parameter_fold_graph hdom hh hz h2 hD⟩

end LeanVerification.Sharpness.Fold
