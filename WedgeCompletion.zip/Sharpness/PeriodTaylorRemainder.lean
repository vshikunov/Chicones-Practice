import LeanVerification.Sharpness.ActualCoefficients
import LeanVerification.Loud.IsochronousCriticalPeriods

/-! An actual joint analytic remainder for the normalized period derivative. -/
noncomputable section
open Set Filter
open scoped Topology
namespace LeanVerification.Sharpness
open Loud GeneralMechanical
set_option maxHeartbeats 1800000

def normalizedPeriod (q : PeriodParameterSpace) : ℝ := jointCenterPeriod q/(2*Real.pi)
def normalizedSlope : PeriodParameterSpace → ℝ := verticalDerivative normalizedPeriod
def slopeRemainder : PeriodParameterSpace → ℝ := jointDslope (jointDslope normalizedSlope)

theorem analyticAt_normalizedPeriod {q : PeriodParameterSpace} (hq : q ∈ jointCenterDomain) :
    AnalyticAt ℝ normalizedPeriod q :=
  (analyticOnNhd_jointCenterPeriod q hq).div analyticAt_const
    (mul_ne_zero (by norm_num) Real.pi_ne_zero)

theorem analyticAt_normalizedSlope {q : PeriodParameterSpace} (hq : q ∈ jointCenterDomain) :
    AnalyticAt ℝ normalizedSlope q :=
  analyticAt_verticalDerivative (analyticAt_normalizedPeriod hq)

theorem analyticAt_slopeRemainder_center (p : ℝ×ℝ) :
    AnalyticAt ℝ slopeRemainder (p,0) :=
  analyticAt_jointDslope_center (analyticAt_jointDslope_center
    (analyticAt_normalizedSlope (jointCenterDomain_contains_center p.1 p.2)))

theorem normalized_derivative_coefficient (p : ℝ×ℝ) (n : ℕ) :
    iteratedDeriv n (fun h => normalizedPeriod (p,h)) 0 =
      (n.factorial:ℝ)*periodCoefficient p.1 p.2 n := by
  have h : iteratedDeriv n (fun h => normalizedPeriod (p,h)) 0 =
      iteratedDeriv n (centerPeriod p.1 p.2) 0/(2*Real.pi) := by
    simpa only [normalizedPeriod,centerPeriod,div_eq_mul_inv,mul_comm,Prod.mk.eta] using
      iteratedDeriv_const_mul (n := n) (analyticAt_centerPeriod p.1 p.2).contDiffAt
        ((2*Real.pi)⁻¹)
  rw [h,periodCoefficient]
  have hn : (n.factorial:ℝ) ≠ 0 := by exact_mod_cast n.factorial_ne_zero
  field_simp [hn,Real.pi_ne_zero]
  ring

theorem slope_fiber_germ {q : PeriodParameterSpace} (hq : q ∈ jointCenterDomain) :
    (fun h => normalizedSlope (q.1,h)) =ᶠ[𝓝 q.2]
      deriv (fun h => normalizedPeriod (q.1,h)) := by
  have ht : Tendsto (fun h:ℝ => (q.1,h)) (𝓝 q.2) (𝓝 q) :=
    (continuousAt_const.prodMk continuousAt_id).tendsto
  filter_upwards [ht.eventually (isOpen_jointCenterDomain.mem_nhds hq)] with h hh
  exact verticalDerivative_eq_deriv (analyticAt_normalizedPeriod hh)

theorem slope_center_jets (p : ℝ×ℝ) :
    normalizedSlope (p,0) = periodCoefficient p.1 p.2 1 ∧
    deriv (fun h => normalizedSlope (p,h)) 0 = 2*periodCoefficient p.1 p.2 2 ∧
    deriv (deriv (fun h => normalizedSlope (p,h))) 0 = 6*periodCoefficient p.1 p.2 3 := by
  have he := slope_fiber_germ (jointCenterDomain_contains_center p.1 p.2)
  have h1 := normalized_derivative_coefficient p 1
  have h2 := normalized_derivative_coefficient p 2
  have h3 := normalized_derivative_coefficient p 3
  norm_num [Nat.factorial,iteratedDeriv_succ,iteratedDeriv_zero] at h1 h2 h3
  refine ⟨?_,?_,?_⟩
  · exact he.self_of_nhds.trans h1
  · exact he.deriv_eq.trans h2
  · have h := he.iteratedDeriv_eq 2
    simp only [iteratedDeriv_succ,iteratedDeriv_zero] at h
    exact h.trans h3

theorem slopeRemainder_center (p : ℝ×ℝ) :
    slopeRemainder (p,0)=3*periodCoefficient p.1 p.2 3 := by
  have h := second_division_at_center
    (analyticAt_normalizedSlope (jointCenterDomain_contains_center p.1 p.2))
  change 2*slopeRemainder (p,0)=_ at h
  rw [(slope_center_jets p).2.2] at h
  linarith

theorem actual_slope_taylor_identity (q : PeriodParameterSpace) :
    normalizedSlope q = periodCoefficient q.1.1 q.1.2 1 +
      2*periodCoefficient q.1.1 q.1.2 2*q.2 + q.2^2*slopeRemainder q := by
  have h1 := spatial_division_identity normalizedSlope q
  have h2 := spatial_division_identity (jointDslope normalizedSlope) q
  have hc := slope_center_jets q.1
  have hd : jointDslope normalizedSlope (q.1,0)=2*periodCoefficient q.1.1 q.1.2 2 := by
    simpa only [jointDslope,dslope_same] using hc.2.1
  rw [hc.1] at h1
  rw [hd] at h2
  change jointDslope normalizedSlope q - 2*periodCoefficient q.1.1 q.1.2 2 =
    q.2*slopeRemainder q at h2
  rw [show jointDslope normalizedSlope q =
      2*periodCoefficient q.1.1 q.1.2 2 + q.2*slopeRemainder q by linarith] at h1
  nlinarith only [h1]

theorem centerPeriod_germ_eq_physical {D F h : ℝ}
    (hq : ((D,F),h) ∈ jointCenterDomain) (hh : 0<h) :
    centerPeriod D F =ᶠ[𝓝 h] periodQuadrature D F := by
  have ht : Tendsto (fun k:ℝ => (((D,F),k):PeriodParameterSpace)) (𝓝 h) (𝓝 ((D,F),h)) :=
    (continuousAt_const.prodMk continuousAt_id).tendsto
  filter_upwards [ht.eventually (isOpen_jointCenterDomain.mem_nhds hq),Ioi_mem_nhds hh] with k hk hkp
  exact (jointCenterPeriod_eq_periodQuadrature hk hkp).2

theorem normalizedSlope_eq_physical_derivative {D F h : ℝ}
    (hq : ((D,F),h) ∈ jointCenterDomain) (hh : 0<h) :
    normalizedSlope ((D,F),h) = deriv (periodQuadrature D F) h/(2*Real.pi) := by
  rw [show normalizedSlope ((D,F),h) = deriv (fun k => normalizedPeriod ((D,F),k)) h from
    verticalDerivative_eq_deriv (analyticAt_normalizedPeriod hq)]
  have hc : AnalyticAt ℝ (centerPeriod D F) h :=
    (analyticOnNhd_jointCenterPeriod _ hq).curry_right
  have hd := hc.differentiableAt.hasDerivAt.div_const (2*Real.pi)
  rw [show (fun k => normalizedPeriod ((D,F),k)) =
      (fun k => centerPeriod D F k/(2*Real.pi)) by rfl,hd.deriv]
  rw [(centerPeriod_germ_eq_physical hq hh).deriv_eq]

theorem hasDerivAt_physical_derivative_of_slope {D F h d : ℝ}
    (hq : ((D,F),h) ∈ jointCenterDomain) (hh : 0<h)
    (hd : HasDerivAt (fun k => normalizedSlope ((D,F),k)) d h) :
    HasDerivAt (deriv (periodQuadrature D F)) ((2*Real.pi)*d) h := by
  have ht : Tendsto (fun k:ℝ => (((D,F),k):PeriodParameterSpace)) (𝓝 h) (𝓝 ((D,F),h)) :=
    (continuousAt_const.prodMk continuousAt_id).tendsto
  apply (hd.const_mul (2*Real.pi)).congr_of_eventuallyEq
  filter_upwards [ht.eventually (isOpen_jointCenterDomain.mem_nhds hq),Ioi_mem_nhds hh] with k hk hkp
  rw [normalizedSlope_eq_physical_derivative hk hkp]
  field_simp [Real.pi_ne_zero]

end LeanVerification.Sharpness
