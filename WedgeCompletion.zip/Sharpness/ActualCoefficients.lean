import LeanVerification.Sharpness.SquareJets
import LeanVerification.Loud.JointEnergyExtension
import LeanVerification.GeneralMechanical.JointDivision
import Mathlib.Analysis.SpecialFunctions.Integrals

/-! The first three coefficients of the actual signed-energy period. -/
noncomputable section
open Set Filter MeasureTheory Metric
open scoped Topology
namespace LeanVerification.Sharpness
open Loud
set_option maxHeartbeats 1600000

def centerPeriod (D F h : ℝ) : ℝ := jointCenterPeriod ((D,F),h)

def periodCoefficient (D F : ℝ) (n : ℕ) : ℝ :=
  iteratedDeriv n (centerPeriod D F) 0 / ((n.factorial:ℝ)*(2*Real.pi))

theorem analyticAt_centerPeriod (D F : ℝ) : AnalyticAt ℝ (centerPeriod D F) 0 :=
  (analyticOnNhd_jointCenterPeriod _ (jointCenterDomain_contains_center D F)).curry_right

theorem normalized_period_power_series (D F : ℝ) :
    HasFPowerSeriesAt (fun h => centerPeriod D F h/(2*Real.pi))
      (FormalMultilinearSeries.ofScalars ℝ (periodCoefficient D F)) 0 := by
  have ha : AnalyticAt ℝ (fun h => centerPeriod D F h/(2*Real.pi)) 0 :=
    (analyticAt_centerPeriod D F).div analyticAt_const
      (mul_ne_zero (by norm_num) Real.pi_ne_zero)
  have h := ha.hasFPowerSeriesAt
  have hec : periodCoefficient D F = (fun n =>
      iteratedDeriv n (fun h => centerPeriod D F h/(2*Real.pi)) 0/(n.factorial:ℝ)) := by
    funext n
    have he : iteratedDeriv n (fun h => centerPeriod D F h/(2*Real.pi)) 0 =
      iteratedDeriv n (centerPeriod D F) 0/(2*Real.pi) := by
      simpa only [div_eq_mul_inv,mul_comm] using
        iteratedDeriv_const_mul (n := n) (analyticAt_centerPeriod D F).contDiffAt
          ((2*Real.pi)⁻¹)
    rw [he]
    dsimp only [periodCoefficient]
    ring
  rw [hec]
  exact h

theorem centerPeriod_eq_regularized {D F h : ℝ}
    (hq : ((D,F),h) ∈ jointCenterDomain) (hh : 0 ≤ h) :
    centerPeriod D F h = regularizedPeriod D F h := by
  rcases eq_or_lt_of_le hh with he | hp
  · subst h
    simp only [centerPeriod,jointCenterPeriod_zero,regularizedPeriod_zero]
  · obtain ⟨ha,he⟩ := jointCenterPeriod_eq_periodQuadrature hq hp
    exact he.trans (regularizedPeriod_eq_periodQuadrature D F h ha).symm

theorem amplitude_center_composition (D F : ℝ) :
    amplitudeDerivative D F 0 =ᶠ[𝓝 0] fun r => centerPeriod D F (r^2/2) := by
  have ht : Tendsto (fun r:ℝ => (((D,F),r^2/2):PeriodParameterSpace)) (𝓝 0)
      (𝓝 ((D,F),0)) := by
    simpa using (show ContinuousAt (fun r:ℝ => (((D,F),r^2/2):PeriodParameterSpace)) 0 by fun_prop).tendsto
  filter_upwards [ht.eventually (isOpen_jointCenterDomain.mem_nhds (jointCenterDomain_contains_center D F))] with r hr
  rw [centerPeriod_eq_regularized hr (by positivity), ← amplitudeDerivative_zero_eq_regularized]
  have hs : Real.sqrt (2*(r^2/2)) = |r| := by
    rw [show 2*(r^2/2)=r^2 by ring,Real.sqrt_sq_eq_abs]
  rw [hs]
  rcases le_total 0 r with hp | hn
  · rw [abs_of_nonneg hp]
  · rw [abs_of_nonpos hn,amplitudePeriod_even]

theorem amplitude_iteratedDeriv_at_center (D F : ℝ) (n : ℕ) :
    iteratedDeriv n (amplitudeDerivative D F 0) 0 = amplitudeDerivative D F n 0 := by
  obtain ⟨H,hH⟩ := exists_admissibleEnergy D F
  have hR : 0 < Real.sqrt (2*H) := Real.sqrt_pos.mpr (by linarith [hH.1])
  let I := Ioo (-Real.sqrt (2*H)) (Real.sqrt (2*H))
  have h0 : (0:ℝ) ∈ I := ⟨by change -Real.sqrt (2*H)<0; linarith,hR⟩
  have he := iteratedDerivWithin_amplitudeDerivative D F H hH n h0
  rw [iteratedDerivWithin_eq_iteratedFDerivWithin,
    iteratedFDerivWithin_of_isOpen n isOpen_Ioo h0] at he
  exact he

theorem amplitudeDerivative_at_zero (D F : ℝ) (n : ℕ) :
    amplitudeDerivative D F n 0 =
      2*iteratedDeriv (n+1) (morsePosition D F) 0 *
        ∫ θ in -(Real.pi/2)..Real.pi/2, Real.sin θ^n := by
  simp only [amplitudeDerivative,amplitudeKernel,zero_mul,
    intervalIntegral.integral_const_mul]
  ring

theorem even_sine_moments :
    (∫ θ in -(Real.pi/2)..Real.pi/2, Real.sin θ^2)=Real.pi/2 ∧
    (∫ θ in -(Real.pi/2)..Real.pi/2, Real.sin θ^4)=3*Real.pi/8 ∧
    (∫ θ in -(Real.pi/2)..Real.pi/2, Real.sin θ^6)=5*Real.pi/16 := by
  have h2 : (∫ θ in -(Real.pi/2)..Real.pi/2, Real.sin θ^2)=Real.pi/2 := by
    rw [integral_sin_sq]
    simp only [Real.sin_neg,Real.cos_neg,Real.sin_pi_div_two,Real.cos_pi_div_two,mul_zero]
    ring
  have h4 : (∫ θ in -(Real.pi/2)..Real.pi/2, Real.sin θ^4)=3*Real.pi/8 := by
    rw [show (4:ℕ)=2+2 by rfl,integral_sin_pow]
    simp only [Real.sin_neg,Real.cos_neg,Real.sin_pi_div_two,Real.cos_pi_div_two,mul_zero,h2]
    norm_num [Nat.factorial]
    ring
  have h6 : (∫ θ in -(Real.pi/2)..Real.pi/2, Real.sin θ^6)=5*Real.pi/16 := by
    rw [show (6:ℕ)=4+2 by rfl,integral_sin_pow]
    simp only [Real.sin_neg,Real.cos_neg,Real.sin_pi_div_two,Real.cos_pi_div_two,mul_zero,h4]
    norm_num [Nat.factorial]
    ring
  exact ⟨h2,h4,h6⟩

theorem actual_period_first_three_coefficients (D F : ℝ) :
    periodCoefficient D F 1 = iteratedDeriv 3 (morsePosition D F) 0/2 ∧
    periodCoefficient D F 2 = iteratedDeriv 5 (morsePosition D F) 0/16 ∧
    periodCoefficient D F 3 = iteratedDeriv 7 (morsePosition D F) 0/288 := by
  obtain ⟨h2,h4,h6⟩ := square_composition_center_jets (analyticAt_centerPeriod D F)
  have he := amplitude_center_composition D F
  rw [←he.iteratedDeriv_eq 2,amplitude_iteratedDeriv_at_center,
    amplitudeDerivative_at_zero,even_sine_moments.1] at h2
  rw [←he.iteratedDeriv_eq 4,amplitude_iteratedDeriv_at_center,
    amplitudeDerivative_at_zero,even_sine_moments.2.1] at h4
  rw [←he.iteratedDeriv_eq 6,amplitude_iteratedDeriv_at_center,
    amplitudeDerivative_at_zero,even_sine_moments.2.2] at h6
  refine ⟨?_,?_,?_⟩
  · dsimp only [periodCoefficient]
    rw [iteratedDeriv_one,←h2]
    norm_num [Nat.factorial]
    field_simp [Real.pi_ne_zero]
    ring
  · dsimp only [periodCoefficient]
    norm_num [Nat.factorial]
    apply (eq_div_iff (by norm_num : (16:ℝ)≠0)).2
    field_simp [Real.pi_ne_zero] at h4 ⊢
    nlinarith only [h4]
  · dsimp only [periodCoefficient]
    norm_num [Nat.factorial]
    apply (eq_div_iff (by norm_num : (288:ℝ)≠0)).2
    field_simp [Real.pi_ne_zero] at h6 ⊢
    nlinarith only [h6]

end LeanVerification.Sharpness
